@echo off
setlocal
cd /d "%~dp0"
echo === Nexu Language Provider Adapters ===
node compiler\cli.mjs provider list || goto :fail
echo.
echo Use: node compiler\cli.mjs provider show ^<adapter.id^>
echo.
pause
exit /b 0
:fail
echo.
echo [FAIL] Could not list provider adapters.
pause
exit /b 1
