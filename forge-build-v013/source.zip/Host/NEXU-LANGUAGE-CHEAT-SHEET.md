# Nexu Language 0.6.0 — Cheat Sheet

**Baseline:** Components, Navigation, Persistence & Local AI Bridge

## App / module

```nex
app MyApp { fn start() {} }
module Utils { fn hello(): String { return "Hi" } }
import { hello } from "./utils.nex"
```

## Values and types

```nex
let name: String = "Nexu"
let count: Number = 3
let ready: Bool = true
let files: List<String> = ["a", "b"]
```

`let` is immutable.

## Functions / async / Result

```nex
fn add(a: Number, b: Number): Number { return a + b }
async fn wait(): String { await delay(10) return "done" }

match result {
  ok(value) { print(value) }
  err(reason) { print(reason) }
}
```

## Capabilities

```nex
capability project.read allow
capability project.write confirm
capability network.ai deny
```

Policies: `allow`, `confirm`, `deny`.

## AI + agent

```nex
ai Assistant {
  model "local.qwen"
  fallback "openai"
  privacy local_first
}

agent Coder {
  use Assistant
  permission project.read allow
  permission project.write confirm
  tool project.write confirm
}
```

## Feature Modules

```nex
use ai.chat.full {
  model "local.qwen"
  fallback "openai"
  privacy local_first
  memory conversation
  cancellable true
}

use agent.coder { writes confirm tests true }
```

## Local Qwen provider

```nex
provider LocalQwen {
  adapter "ollama.chat"
  route "local.qwen"
  model "qwen3:8b"
  base_url "http://127.0.0.1:11434"
}
```

Rules: loopback HTTP only; Ollama cloud-model names are blocked by this local provider.

## Online OpenAI provider

```nex
provider OpenAI {
  adapter "openai.responses"
  route "openai"
  model "gpt-5.6"
  key_env "OPENAI_API_KEY"
}
```

Cloud calls require the app's `network.ai` policy and a confirmation surface when policy is `confirm`.

## Components

```nex
component Header {
  row Bar {
    text Title { label: "My App" }
  }
}

ui Workspace {
  mount Header MainHeader
}
```

0.6 components are static templates: UI nodes/properties only.

## Screens + navigation

```nex
ui Workspace {
  start_screen: Home
  screen Home {
    button Go { label: "Settings" on click { navigate Settings } }
  }
  screen Settings { text Title { label: "Settings" } }
}
```

## Focus

```nex
on click {
  navigate Settings
  focus SearchInput
}
```

Target must be focusable; host must provide `ui.focus`.

## Persistent stores

```nex
store Preferences {
  persist local
  state theme: String = "dark"
  state launches: Number = 0
}

let theme: String = await load Preferences.theme
save Preferences.theme = "light"
```

0.6 store state supports `String`, `Number`, `Bool` literals.

## UI state/events

```nex
ui Workspace {
  state status: String = "Ready"
  text Status { bind: status }
  button Reset { label: "Reset" on click { set status = "Ready" } }
}
```

## Chat

```nex
chat AssistantChat {
  use ai.chat.full
  on send(message: String) {
    let answer = await chatSend(message)
  }
  on clear { chatClear() }
  on stop { chatStop() }
}
```

## Host

```nex
host PreviewHost {
  adapter "console.preview"
  provides ui.render
  provides ui.confirm
  provides ui.focus
  provides storage.local
}
```

## Recipes

```text
AI Chat Full
AI Chat Core
Coding Agent
Project Workspace
Local Storage
Local Authentication
```

## CLI

```text
check <app.nex>
build <app.nex> --out-dir build
run <app.nex>
explain <app.nex>
metrics <app.nex>
local-ai doctor <app.nex>
feature list | feature show <id>
host list | host show <id>
provider list | provider show <id>
recipe list | recipe show/preview/apply ...
```

## Baseline safety rules

- No arbitrary host JavaScript escape hatch.
- Imports cannot escape the entry project root.
- `let` stays immutable.
- `Result` matches are exhaustive.
- Feature Modules are inspectable contracts, not opaque macros.
- Recipes validate and back up before writing.
- Provider/host adapters must be compiler-known.
- `deny` is authoritative.
- `confirm` fails closed without explicit approval.
- `ollama.chat` is loopback/local-only and rejects cloud-model names.
- `openai.responses` reads only `OPENAI_API_KEY`.
- Persistent values are runtime type-validated.
- No runtime-speed claim without benchmark evidence.
