# Nexu AI 3D Forge v0.10.0 — Universal Creation Intelligence, Fast Cache & Full Studio UX

**Status:** Candidate

## New

- Universal Prompt Intelligence for natural creation wording, aliases and common spelling errors.
- 43 permanent local generation grammars (12 more than v0.9).
- 269 recognised subject phrases + 118 descriptive/modifier phrases.
- Live Prompt Coach that shows what Forge recognised before generation.
- Fast / Balanced / Maximum Quality generation modes.
- FastForge exact-recipe cache: repeated identical validated recipes can reuse an existing successful build without running Blender again.
- Brotli-compressed FastForge cache index.
- Blender master-file compression in Balanced and Maximum Quality modes.
- New Forge Home dashboard with recent work, creation knowledge and cache status.
- FastForge/storage controls in System Centre.
- Lazy loading/async decoding for asset thumbnails.

## New permanent object grammars

Door, Window frame, Sword, Shield, Axe, Hammer, Spear, Bucket, Pot, Book, Torch and Wagon wheel.

## Preserved

- v0.9 creature foundations and organic generation.
- v0.8 local learning/dataset pipeline.
- v0.8.1 no-PowerShell Windows build-security repair.
- v0.7 Android companion compatibility.
- user-owned asset storage outside application versions.
- no paid generation API, credits or temporary neural provider.
- no prompt → Python/shell execution.
- minimum 14px desktop text rule.

## Compression decision

Forge does not compress its primary GLB with Draco in this release because the built-in viewer does not yet ship a Draco decoder. Instead, storage savings come from avoiding duplicate builds, compressing the cache index, and using Blender's own `.blend` compression outside Fast mode.

## Qualification boundary

The source/automated gates pass in the available environment. A physical Windows + Blender 5.2 run is still required to measure real cache-hit latency, `.blend` size savings, generation-mode timings and the twelve new asset grammars before promotion beyond Candidate.
