# Nexu AI 3D Forge v0.1.3 — Blender Bootstrap Repair

## Trigger
Target-PC diagnostics showed Node.js 24.19.0 PASS and Blender NOT FOUND.

## Repair
- Adds `SETUP-NEXU-3D.cmd` as the one-click Blender prerequisite bootstrap.
- Keeps CMD as a thin launcher; install logic lives in `3d-forge/setup-windows.mjs`.
- Uses Windows Package Manager (WinGet) with the exact package ID `BlenderFoundation.Blender`.
- Pins Blender to stable `5.2.0` x64 for this candidate instead of installing an uncontrolled future major/minor.
- Verifies the pinned version is offered before install.
- Never uses `--ignore-security-hash`, mirrors, preview Blender builds, or silent security bypasses.
- Re-verifies Blender after installation.
- Expands Blender discovery to common machine and per-user Blender 5.2/5.2.0 paths.

## Target flow
`SETUP-NEXU-3D.cmd` -> `CHECK-NEXU-3D.cmd` -> `BUILD-NEXU-3D.cmd`

## Verification boundary
The build environment is not Windows and cannot execute WinGet or install Blender. Node syntax/static tests are run here; the real WinGet/Blender install is target-PC verification.
