# Nexu AI 3D Forge v0.8.0 — Full Pack Status

- **Windows Forge:** v0.8.0 Asset Intelligence & Learning Candidate.
- **Android Creator Companion:** v0.7.1 remains compatible and is not falsely relabelled.
- **Parent language:** Nexu Language 0.6.0 preserved.
- **New permanent capability:** 23 local asset grammar families, Safe Mesh Repair v1, seven-view dataset capture, local preference evidence and bounded accepted-result adaptation.
- **External AI provider:** none shipped; no paid or temporary provider is required.
- **Windows user data:** remains outside the installed application directory under `Documents\Nexu AI 3D Forge`.
- **Release boundary:** exact Windows install/update/repair lifecycle and real Blender 5.2 v0.8 generation remain physical qualification gates.
