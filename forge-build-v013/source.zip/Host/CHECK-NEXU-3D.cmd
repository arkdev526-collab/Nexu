@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Nexu AI 3D Forge - Doctor

echo ============================================================
echo  NEXU AI 3D FORGE v0.2.0 - ENVIRONMENT DOCTOR
echo ============================================================
echo.
node 3d-forge\cli.mjs doctor
set "NEXU_EXIT=%ERRORLEVEL%"
echo.
if "%NEXU_EXIT%"=="0" (
  echo READY - Node and Blender requirements passed.
) else (
  echo NOT READY - repair the requirement shown above.
)
echo.
pause
exit /b %NEXU_EXIT%
