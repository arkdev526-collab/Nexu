# Nexu AI 3D Forge — Technology Overrides

## PowerShell compatibility for Android engineering handoff

**Technology:** Windows PowerShell 5.1 compatibility surface only when PowerShell 7 is not installed.  
**Normal Sumero baseline:** current supported PowerShell 7 LTS for new automation.  
**Reason:** The Android engineering build/Doctor workflow still supports a standard Windows 11 machine before optional PowerShell 7 is installed. Android CMD launchers may prefer `pwsh.exe` and fall back to inbox `powershell.exe`; those scripts are intentionally limited to syntax supported by both. The Windows Forge Setup build path itself no longer uses PowerShell as of v0.8.1.  
**Scope:** Android candidate build/Doctor handoff only. The Windows candidate builder uses inbox CMD/curl/certutil/tar plus the package-owned Go builder; normal Forge runtime remains Node.js + Blender and .NET MAUI on Android.  
**Security:** no execution-policy system change, remote script execution, Defender/SmartScreen/UAC bypass or checksum bypass.  
**Review date:** 21 August 2026.

## Android private-LAN cleartext transport envelope

**Technology:** Android permits HTTP transport to dynamically selected private IPv4 LAN addresses.  
**Normal Sumero baseline:** authenticated TLS for network transport where a deployable trust model exists.  
**Reason:** v0.7 pairs a user-owned Android device directly with a user-owned Windows PC on a changing private LAN. A per-install private CA/self-signed certificate flow would add substantial certificate-management and trust complexity before Forge has a production pairing PKI.  
**Compensating protection:** Forge rejects public/non-private IPv4 hosts; pairing uses a one-use 10-minute out-of-band secret; every sensitive companion RPC payload is independently AES-256-GCM encrypted and authenticated with a per-device 256-bit secret stored in Android Secure Storage; request replay is rejected; responses are cryptographically bound to the initiating request nonce; no cloud fallback is allowed.  
**Residual risk:** HTTP transport metadata such as source/destination IP, timing and message size remains observable on the local network. Application-layer encryption is not represented as equivalent to TLS.  
**Review target:** v0.8 should reassess pinned TLS or an authenticated local transport after real-device pairing reliability is measured.  
**Review date:** 21 August 2026.

### v0.8 review — Android private-LAN transport
Reviewed 23 August 2026. The exception is retained for v0.8 because this milestone changes desktop Asset Intelligence/Learning and does not introduce a new Android transport. Replacing the encrypted application channel with a locally managed TLS trust system without physical multi-device qualification would add certificate lifecycle risk without improving the v0.8 generation goal. Reassess after the Android companion has completed real-device pairing/reconnect qualification. No public-network or cloud exposure is permitted meanwhile.

## v0.10.1 compatibility decisions

No new technology exception is required. Stable Node Brotli and Blender-native blend compression are used inside the existing approved stack. Experimental Node Zstd and compressed glTF extensions are deliberately not adopted for the protected primary viewport path in this milestone.
