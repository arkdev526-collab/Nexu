# Nexu AI 3D Forge v0.9.0 — Architecture

## Creation path

```text
User brief
  ↓
Creation Intelligence
  ↓
Object grammar OR Creature grammar
  ↓
Validated Nexu3D 1.2 recipe
  ↓
Trusted package-owned Blender worker
  ↓
Geometry + PBR + repair + QA + exports + dataset
```

## Creature path

```text
Creature grammar
  ↓
Bounded morphology
  ↓
Guide volumes / limb segments
  ↓
Voxel body remesh
  ↓
Controllable detail parts
  ├─ wings / membranes
  ├─ horns / claws / beak
  ├─ fins
  └─ dorsal spikes
  ↓
Triangle-budget calibration
  ↓
Safe mesh repair
  ↓
UV / PBR
  ↓
Collision / LOD
  ↓
QA / BLEND / FBX / GLB / dataset
```

## Foundation grammars

| Grammar | Archetype | Limbs | Wings |
|---|---|---:|---:|
| dragon | winged quadruped | 4 | 2 |
| wyvern | winged biped | 2 | 2 |
| griffin | hybrid winged quadruped | 4 | 2 |
| wolf | terrestrial quadruped | 4 | 0 |
| giant-spider | arachnid | 8 | 0 |
| snake | serpent | 0 | 0 |
| bird | avian | 2 | 2 |
| fish | aquatic | 0 | 0 |

## Security boundary
Creation Intelligence emits data only. `procedural_creature` is an allow-listed recipe type. Creature kind, style, anatomy, material references and morphology are schema-validated before the trusted worker sees them. No prompt is emitted as Python, JavaScript, shell code or Blender script.

## Learning boundary
Creature feedback stores bounded morphology metadata and outcome evidence. After at least two accepted results for a grammar, medians may inform omitted defaults. Explicit prompt constraints always override learned defaults. No reference-image bytes are written into the preference ledger.

## Current product boundary
v0.9 creatures are **static game assets**. The foundation is intentionally not represented as animation-ready rigged character generation.
