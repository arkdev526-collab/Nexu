# Nexu AI 3D Forge v0.5.0 — Security & Privacy

## Trust boundary

Forge never routes user prompt text directly into Python, shell, PowerShell or Blender scripting. Natural language is transformed into allow-listed Nexu3D data, validated, then consumed by package-owned worker code.

## Local Studio

- Binds only to `127.0.0.1`.
- Uses a cryptographically random startup token and HttpOnly/SameSite session cookie.
- Checks mutation request origin.
- Uses restrictive browser security headers.
- Reference files and generated assets are root-confined.
- Exposed file extensions are allow-listed.

## References

PNG/JPEG/WebP files are accepted only after MIME/magic validation and a 12 MB bound. Reference evidence is local and bounded. No reference image is uploaded to a cloud provider by default.

## External processes

Node and Blender are invoked by explicit argument arrays with no shell command construction. Blender continues to use trusted package-owned worker code; arbitrary user add-ons/scripts are outside the Forge execution contract.

## Updates

A production update manifest must use HTTPS. A newer payload must specify HTTPS Setup URL, exact byte size and a 64-character SHA-256 digest. Downloaded Setup is not launched until size and SHA-256 match. Rollback verifies the retained version's package manifest before switching the active version.

## Candidate boundary

The v0.5 installer is unsigned until a real Sumero Studio signing certificate is supplied. No SmartScreen-reputation or signing claim is made.
