# Build, Install and Pair the Android Creator Companion

## 1. Doctor
Double-click `DOCTOR-ANDROID.cmd`.

It is read-only and checks:
- .NET 10.0.4xx selected by `global.json`;
- MAUI/Android workload;
- JDK 21;
- Android SDK platform 36;
- ADB and connected-device state.

## 2. Build/install
Enable Developer options + USB debugging on the Android device and authorise the PC, then double-click:

`BUILD-ANDROID-AND-INSTALL.cmd`

The workflow restores the pinned project, invokes the official `SignAndroidPackage` target in Release mode, copies the signed engineering APK to:

`artifacts\android\Nexu-AI-3D-Forge-Android-v0.10.1.apk`

and, when exactly one authorised device is connected, runs `adb install -r`.

The engineering candidate intentionally uses the .NET Android debug signing identity for direct device testing. A public/Play release requires a protected Sumero Studio Android signing key and separate release-signing gate.

## 3. Pair
1. Open Windows Forge v0.7.0 or newer.
2. Open **System → Android Companion**.
3. Select **Create pairing code**.
4. On Android open **Pair**.
5. Enter the shown private IPv4 host, port and complete pairing code.
6. Select **Pair this device**.

If pairing fails, confirm both devices are on the same private LAN and that the Windows firewall allows the chosen Forge Companion port only on the private network profile.
