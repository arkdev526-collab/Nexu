# Nexu AI 3D Forge — Material Decisions

## D-080-01 — Owned generation foundation before external neural provider
**State:** Accepted for v0.8.0  
**Decision:** Ship 23 package-owned local asset grammars, mesh repair, dataset capture and preference learning. Do not ship TripoSR or another neural runtime in this milestone.  
**Reason:** The user requires free/local/final components rather than paid services or temporary experiments. TripoSR is free/MIT but its upstream Windows runtime is not yet a fully pinned Forge-qualified provider bundle.  
**Revisit:** When a complete provider can be pinned, licensed, installed, updated and removed reproducibly on Windows.

## D-080-02 — Learning remains bounded and user-controlled
**State:** Accepted  
**Decision:** Good/Needs Work evidence is stored locally. After at least two accepted results for one grammar, Forge may reuse the median accepted triangle target only when the next prompt omits an explicit polycount.  
**Protection:** Explicit user constraints always win. No image bytes are stored in the preference ledger and no learning data is uploaded.

## D-080-03 — Dataset capture is a normal generation stage
**State:** Accepted  
**Decision:** Successful generation may create seven local training views and a structured dataset record.  
**Reason:** This creates owned, well-labelled evidence for future ranking/fine-tuning without scraping third-party asset libraries.

## D-080-04 — Exact Windows native toolchain
**State:** Accepted  
**Decision:** Use Go 1.26.6 for the v0.8 native launcher/setup builder, with the official Windows x64 archive SHA-256 pinned in the build script.  
**Reason:** Current stable primary-source verification on 23 August 2026 supersedes the earlier 1.26.5 patch pin.

## D-090-01 — Owned organic creature foundation before neural dependency
**State:** Accepted for v0.9.0  
**Decision:** Implement reusable deterministic creature grammars using bounded guide volumes plus Blender 5.2 voxel remesh and authored detail geometry.  
**Reason:** This permanently expands Forge with free/local technology already inside the trusted Blender boundary and creates labelled datasets for future owned learning without introducing an unqualified external model runtime.

## D-090-02 — Creature foundation is static, not animation-ready
**State:** Accepted  
**Decision:** v0.9 exports static game creatures. It does not claim rigging, animation topology or facial-animation readiness.  
**Reason:** Geometry quality, anatomy, materials, QA and editability must qualify before character-rig scope is added.

## D-090-03 — Anatomy is validated before Blender
**State:** Accepted  
**Decision:** Foundation species have bounded limb/wing contracts (for example Dragon 4+2, Wyvern 2+2, Spider 8+0). Invalid recipes are rejected rather than repaired by arbitrary code.

## D-090-04 — Learning may tune morphology only when omitted
**State:** Accepted  
**Decision:** After sufficient accepted local evidence, median morphology may inform omitted defaults. Explicit prompt cues and explicit target polycount always override learned values.

## v0.10.0 — Universal Creation Intelligence, Fast Cache & Full Studio UX

- **Accepted:** expand permanent owned grammars from 31 to 43 and add natural-language alias/typo/action interpretation rather than claiming arbitrary unsupported object generation.
- **Accepted:** preserve Nexu3D schema 1.2 for backward compatibility; generation mode is a compatible quality field rather than a schema-breaking change.
- **Accepted:** FastForge exact recipe fingerprint reuse. Cache metadata points to existing validated user assets; editable output files are never hard-linked.
- **Accepted:** Brotli for cache metadata because it is stable in the protected Node runtime. Do not adopt experimental Node Zstd.
- **Accepted:** Blender master compression for Balanced/Maximum Quality; Fast prioritises speed and saves the master uncompressed.
- **Deferred:** Draco/Meshopt compression on the primary GLB until Forge ships and validates a matching decoder in its own viewport.
- **Accepted:** Forge Home + live Prompt Coach as the main post-onboarding application experience; retain minimum 14px desktop text.


## v0.10.1 — Android prerequisite auto-repair

- The Android build workflow now uses the official .NET for Android `InstallAndroidDependencies` target to provision the exact project dependencies into controlled local paths when JDK 21 or Android API 36 is missing.
- Managed JDK path: `%LOCALAPPDATA%\Sumero Studio\BuildTools\Android\jdk-21`.
- Android SDK path: `%LOCALAPPDATA%\Android\Sdk`.
- ADB is invoked through redirected native-process capture so normal daemon-start messages on stderr do not become terminating PowerShell `NativeCommandError` failures.
- Doctor remains read-only; only the explicit Build + Install workflow performs repair.
- Existing v0.10.0 Universal Creation / FastForge / Studio behaviour is preserved.
