# Nexu AI 3D Forge v0.7.0 — Android Creator Companion

## Added
- First Android creator application under `mobile/NexuAI3DForge.Android`.
- Touch-first Create workspace with Unreal/ASA and Generic profiles.
- Real generation stage/progress display and queue cancellation.
- Reference-image picker for PNG/JPEG/WebP with local pixel evidence.
- Structured non-destructive refinement from Android.
- Material preset/intelligence planning and generation from Android.
- Local embedded WebGL2 GLB viewer with touch orbit, pinch zoom, two-finger pan, solid/material/wireframe, collision overlay and LOD selection.
- Asset Library and Queue pages.
- Explicit Pair page with device secret stored in Android Secure Storage.
- Windows System Centre Android Companion pairing/revoke surface.
- Separate private-LAN companion server and allow-listed encrypted RPC contract.

## Preserved
- Proven Windows Nexu3D → Blender 5.2 worker architecture.
- Existing `.blend`, `.fbx`, `.glb`, LOD, collision, PBR/material and asset-version workflows.
- Loopback-only protected Windows Studio surface.
- No arbitrary prompt → Python/shell/native execution.
- User-created assets remain outside installed program versions.

## Compatibility
- Android target: API 36; minimum API 30.
- Android app package ID: `uk.co.sumerostudio.nexuai3dforge`.
- Android versionName 0.7.0 / versionCode 70.
- Windows and Android must both be on a compatible v0.7 Companion protocol for pairing.
