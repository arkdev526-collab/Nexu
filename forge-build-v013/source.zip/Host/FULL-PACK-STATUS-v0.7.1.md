# Nexu AI 3D Forge v0.7.1 Full Pack Status

- **Windows Forge host:** v0.7.0 Android Creator Companion Candidate (unchanged working host baseline).
- **Android Creator Companion:** v0.7.1 Build Repair.
- **Reason for patch:** fixes the Android Doctor PowerShell scope typo that stopped the build after the .NET/Android workload checks passed.
- **Architecture:** Android remains a companion; Windows Forge + Nexu3D + Blender remain the trusted heavy-generation worker.
- **User data:** Windows-generated assets remain outside the installed program directory.

This combined source tree is provided for development convenience. The Windows application version is intentionally not relabelled as 0.7.1 because the Windows host code did not change in the Android-only repair.
