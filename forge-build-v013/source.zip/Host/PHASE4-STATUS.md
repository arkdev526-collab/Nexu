# Nexu Language 0.4.0 — Phase 4 Status

**Codename:** Declarative UI & Host Adapter Contracts  
**Status:** Release baseline candidate  
**Date:** 2026-08-13

## Protected predecessor

Nexu Language 0.3.0 Feature Modules & Recipes remains the protected previous baseline. 0.4.0 preserves the 0.3 feature/recipe model and the separately preserved 0.2.1 Task & Effect Foundation.

## Implemented

- declarative `ui` syntax and AST;
- compiler-known UI schemas;
- chat-to-`ai.chat.full` feature binding;
- host declaration syntax and validation;
- runtime host capability gate;
- compiler-known Node preview and browser DOM hosts;
- runtime routing of network-capable AI through the host gate;
- upgraded AI Chat Full full-stack recipe;
- headless AI Chat Core recipe;
- CLI host catalogue/explain/metrics support;
- Nexu AI reference UI authored in `.nex`.

## Reference app

`examples/nexu-ai.nex` currently resolves four Feature Modules, three UI nodes and the `console.preview` host.

Current metrics:

```text
AUTHORED_NEX_LINES 98
GENERATED_TS_LINES 392
GENERATED_TO_AUTHORED_RATIO 4.00x
FEATURES 4
EXPLICIT_FEATURES 2
AUTO_DEPENDENCIES 2
UI_NODES 3
HOST_ADAPTER console.preview
```

## Validation

- compiler regression suite: **42/42 PASS**;
- Nexu AI semantic/project check: PASS;
- Nexu AI TypeScript build: PASS;
- Nexu AI bootstrap run: PASS;
- generated TypeScript strict-check with workspace TypeScript 5.8.3: PASS;
- compiler-known host catalogue tests: PASS;
- runtime confirm gate fail-closed test: PASS;
- AI Chat Full safe recipe composition tests: PASS.

The workspace Node runtime is 22.16.0. The production verifier intentionally requires the project's Node 24.19.x baseline, so production-runtime verification remains pending rather than being falsely reported as passed.

## Known boundary

Nexu is not self-hosting: the reference application is Nexu source, while the bootstrap compiler remains JavaScript modules and output remains TypeScript/JavaScript. 0.4.0 is not an operating-system sandbox and does not ship a production network AI adapter.

## Recommended next milestone

After exercising this baseline through real Nexu AI UI work, the strongest next direction is **0.5.0 State, Events & Provider Adapters**: typed UI state/events, focus/accessibility behaviours, narrow provider adapters, confirmation surfaces and host tests before wider platform adapters.
