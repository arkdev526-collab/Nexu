# Nexu AI 3D Forge v0.7.0 — QA Results

**Candidate:** Android Creator Companion  
**Date:** 2026-08-21

## Passed in available build environment
- Forge deterministic suite: **44/44 PASS**.
- Protected Nexu Language compiler suite with `FORCE_COLOR=1`: **70/70 PASS**.
- Combined automated tests: **114/114 PASS**.
- Nexu AI semantic check: PASS.
- Nexu AI generated TypeScript build: PASS.
- Changed Node/Studio/Companion JavaScript syntax: PASS.
- Android embedded viewer JavaScript syntax: PASS.
- Blender worker Python compile: PASS.
- Android XAML/XML/project parse: **10/10 PASS**.
- Android declared text-size gate: minimum 14sp PASS; normal body 16sp.
- Android stable-runtime gate: `net10.0-android`, MAUI 10.0.90, no experimental CoreCLR marker PASS.
- Companion AES-GCM tamper/time/replay tests: PASS.
- One-use pairing and real encrypted RPC integration test: PASS.
- Private-address and allow-listed RPC gates: PASS.
- Response binding to initiating request nonce: PASS.
- Android backup disabled for pairing-key reliability: PASS.
- Windows v0.7 source packaging payload manifest: 27 files verified during engineering PE build.
- Windows Setup engineering candidate: PE32+ Windows GUI x64 produced successfully.

## Fixed during v0.7 QA
1. Android `SettingsPage.xaml` contained an unescaped `&` and failed XML parsing. Corrected to `&amp;` and reran the full XML gate.
2. The first tamper regression could accidentally replace a base64url character with the same character. The test now deterministically changes the ciphertext and reliably proves authentication failure.
3. Companion response authentication is now bound to each initiating request nonce to prevent an otherwise-valid response being replayed against a different request within the time window.
4. Large GLB injection into Android WebView now uses bounded 128 KiB chunks instead of one large `EvaluateJavaScriptAsync` payload.
5. Android backup is disabled so a paired-device secret is not restored onto another Android installation without its matching keystore state.

## Not executable in this environment
- .NET SDK / MAUI Android compiler is not installed in the container, therefore the APK itself has **not** been compiled here.
- No physical Android device is attached, therefore install, touch, Secure Storage, local-network pairing and real GLB rendering remain target-device gates.
- Windows Setup has not been physically clicked through on Windows for v0.7.
- The engineering Setup EXE was cross-compiled using the container's Go 1.23.2; the authoritative Windows release builder remains pinned to Go 1.26.5 and must produce the final candidate on Windows before release qualification.
- ASA DevKit import remains a separate engine qualification gate.

## Candidate decision
**CANDIDATE — NOT QUALIFIED RELEASE.** Source/protocol/static gates passed; target Windows + Android compilation and physical functional qualification remain mandatory.
