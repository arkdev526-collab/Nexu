[CmdletBinding()]
param([switch]$NoInstall)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root 'mobile\NexuAI3DForge.Android\NexuAI3DForge.Android.csproj'
$Artifacts = Join-Path $Root 'artifacts\android'
$FinalApk = Join-Path $Artifacts 'Nexu-AI-3D-Forge-Android-v0.10.1.apk'
$Log = Join-Path $Artifacts 'android-build.log'
$ManagedRoot = Join-Path $env:LOCALAPPDATA 'Sumero Studio\BuildTools\Android'
$ManagedJdk = Join-Path $ManagedRoot 'jdk-21'
$AndroidSdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'

function Step([string]$Text) { Write-Host ''; Write-Host (">> {0}" -f $Text) -ForegroundColor Cyan }
function LogLine([string]$Text) { $Text | Tee-Object -FilePath $Log -Append }
function Quote-NativeArg([string]$Value) {
  if ($Value -notmatch '[\s"]') { return $Value }
  return '"' + $Value.Replace('"','\"') + '"'
}
function Invoke-NativeCapture([string]$File,[string[]]$Arguments) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $File
  $psi.Arguments = (($Arguments | ForEach-Object { Quote-NativeArg $_ }) -join ' ')
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $psi
  [void]$process.Start()
  $stdoutTask = $process.StandardOutput.ReadToEndAsync()
  $stderrTask = $process.StandardError.ReadToEndAsync()
  $process.WaitForExit()
  $stdout = $stdoutTask.Result
  $stderr = $stderrTask.Result
  return [pscustomobject]@{ ExitCode = $process.ExitCode; StdOut = $stdout; StdErr = $stderr }
}
function Run([string]$File,[string[]]$Arguments) {
  Write-Host ("> {0} {1}" -f $File,($Arguments -join ' '))
  $result = Invoke-NativeCapture $File $Arguments
  if ($result.StdOut) { $result.StdOut.TrimEnd() | Tee-Object -FilePath $Log -Append | Write-Host }
  if ($result.StdErr) { $result.StdErr.TrimEnd() | Tee-Object -FilePath $Log -Append | Write-Host }
  if ($result.ExitCode -ne 0) { throw "$File failed with exit code $($result.ExitCode)." }
}
function Set-AndroidEnvironment {
  $env:ANDROID_SDK_ROOT = $AndroidSdk
  $env:ANDROID_HOME = $AndroidSdk
  if (Test-Path -LiteralPath (Join-Path $ManagedJdk 'bin\java.exe')) {
    $env:JAVA_HOME = $ManagedJdk
    if (($env:PATH -split ';') -notcontains (Join-Path $ManagedJdk 'bin')) { $env:PATH = (Join-Path $ManagedJdk 'bin') + ';' + $env:PATH }
  }
}
function Repair-AndroidPrerequisites([string]$Dotnet) {
  Step 'Auto-repairing Android prerequisites with the official .NET for Android dependency target'
  New-Item -ItemType Directory -Force -Path $ManagedRoot | Out-Null
  New-Item -ItemType Directory -Force -Path $AndroidSdk | Out-Null
  Write-Host '[INFO] This may download Microsoft JDK 21 and the Android API 36 SDK components.' -ForegroundColor Yellow
  Write-Host '[INFO] Android SDK licences are accepted for this build because the user explicitly started the Android build/install workflow.' -ForegroundColor Yellow
  Run $Dotnet @(
    'build',$Project,
    '-t:InstallAndroidDependencies',
    '-f','net10.0-android',
    '--nologo',
    "-p:AndroidSdkDirectory=$AndroidSdk",
    "-p:JavaSdkDirectory=$ManagedJdk",
    '-p:AcceptAndroidSDKLicenses=True'
  )
  Set-AndroidEnvironment
}

New-Item -ItemType Directory -Force -Path $Artifacts | Out-Null
"Nexu AI 3D Forge v0.10.1 Android build - $(Get-Date -Format o)" | Set-Content -LiteralPath $Log -Encoding UTF8
$dotnet = (Get-Command dotnet.exe -ErrorAction Stop).Source
Set-AndroidEnvironment

Step 'Running read-only Android Doctor'
$doctor = Join-Path $Root 'DOCTOR-ANDROID.ps1'
& $doctor
$doctorExit = $LASTEXITCODE
if ($doctorExit -ne 0) {
  Repair-AndroidPrerequisites $dotnet
  Step 'Re-running Android Doctor after automatic repair'
  & $doctor
  if ($LASTEXITCODE -ne 0) { throw 'Android Doctor still does not pass after automatic prerequisite repair. See the Doctor output above.' }
}

Step 'Restoring pinned Android project dependencies'
Run $dotnet @('restore',$Project,'--nologo')

Step 'Building and signing the Release APK for engineering/device testing'
Run $dotnet @(
  'build',$Project,
  '-f','net10.0-android',
  '-c','Release',
  '-t:SignAndroidPackage',
  '--no-restore',
  '--nologo',
  '-warnaserror',
  '-p:AndroidPackageFormats=apk',
  '-p:AndroidKeyStore=false',
  "-p:AndroidSdkDirectory=$AndroidSdk",
  "-p:JavaSdkDirectory=$ManagedJdk"
)

$searchRoot = Join-Path (Split-Path -Parent $Project) 'bin\Release\net10.0-android'
$apk = Get-ChildItem -LiteralPath $searchRoot -Recurse -File -Filter '*-Signed.apk' | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
if (-not $apk) { throw "The build completed but no signed APK was found under $searchRoot." }
Copy-Item -LiteralPath $apk.FullName -Destination $FinalApk -Force
$hash = (Get-FileHash -LiteralPath $FinalApk -Algorithm SHA256).Hash.ToUpperInvariant()
"$hash  $(Split-Path -Leaf $FinalApk)" | Set-Content -LiteralPath ($FinalApk + '.sha256.txt') -Encoding ASCII
Write-Host ''; Write-Host "[PASS] APK: $FinalApk" -ForegroundColor Green
Write-Host "[PASS] SHA-256: $hash" -ForegroundColor Green
Write-Host '[INFO] This candidate APK uses the .NET Android debug signing key for direct device testing. It is not a Google Play signing identity.' -ForegroundColor Yellow

if ($NoInstall) { exit 0 }
$adb = Join-Path $AndroidSdk 'platform-tools\adb.exe'
if (-not (Test-Path -LiteralPath $adb)) {
  Write-Host '[INFO] APK built successfully but ADB is unavailable, so USB installation was skipped.' -ForegroundColor Yellow
  Start-Process explorer.exe -ArgumentList "/select,`"$FinalApk`""
  exit 0
}
$adbResult = Invoke-NativeCapture $adb @('devices')
if ($adbResult.StdErr.Trim()) { Write-Host ("[INFO] ADB: {0}" -f ($adbResult.StdErr.Trim() -replace "`r?`n", ' | ')) -ForegroundColor DarkGray }
if ($adbResult.ExitCode -ne 0) { throw "adb devices failed with exit code $($adbResult.ExitCode)." }
$devices = $adbResult.StdOut -split "`r?`n" | Select-Object -Skip 1 | Where-Object { $_ -match '\tdevice$' }
if (@($devices).Count -eq 0) {
  Write-Host '[INFO] APK built successfully. No authorised Android device is connected, so installation was skipped.' -ForegroundColor Yellow
  Start-Process explorer.exe -ArgumentList "/select,`"$FinalApk`""
  exit 0
}
if (@($devices).Count -ne 1) { throw 'More than one Android device/emulator is authorised. Leave exactly one connected and rerun for deterministic installation.' }
Step 'Installing/updating Nexu AI 3D Forge on the connected Android device'
$install = Invoke-NativeCapture $adb @('install','-r',$FinalApk)
if ($install.StdOut.Trim()) { $install.StdOut.Trim() | Tee-Object -FilePath $Log -Append | Write-Host }
if ($install.StdErr.Trim()) { $install.StdErr.Trim() | Tee-Object -FilePath $Log -Append | Write-Host }
if ($install.ExitCode -ne 0) { throw "adb install failed with exit code $($install.ExitCode)." }
Write-Host ''; Write-Host '[PASS] Android Creator Companion installed/updated.' -ForegroundColor Green
Write-Host 'Open Nexu AI 3D Forge on Android, then use Pair to connect to Windows Forge.'
