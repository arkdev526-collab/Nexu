# Nexu Language 0.2.0 — Phase 2 Status

## Codename

**Identity Foundation**

## Completed

- Preserved the 0.1.0 Phase 1 bootstrap baseline.
- Added `app` and reusable `module` compilation units.
- Added local selective imports with recursive project compilation.
- Added typed records and record construction.
- Added `List<T>`, list literals, field access, and numeric indexing.
- Added `Result<T, E>`, `ok(...)`, `err(...)`, and exhaustive `match`.
- Added `async fn`, `await`, and bootstrap `delay(...)` task support.
- Added explicit app capability policies: `allow`, `confirm`, `deny`.
- Added first-class `ai` model/privacy declarations.
- Added first-class `agent` declarations and permissions.
- Added compile-time permission-escalation prevention.
- Added local import-root containment.
- Added non-Void all-path return validation.
- Added TypeScript type-only imports so records do not leak into JavaScript runtime imports.

## Validation completed in the build workspace

- compiler test suite: **17/17 PASS**
- Node syntax check across compiler/tests: **PASS**
- Nexu AI project check: **PASS**
- Nexu AI TypeScript build: **PASS**
- Nexu AI JavaScript bootstrap execution: **PASS**
- generated TypeScript strict-check using workspace TypeScript 5.8.3: **PASS**

Expected Nexu AI demo output:

```text
Nexu AI online
README.md
Local Qwen model ready
```

## Verification gaps

- The build workspace runs Node.js 22.16.0. The production bootstrap baseline remains Node.js 24.19.x LTS, so `compiler/verify.mjs` intentionally rejects this workspace runtime.
- Current TypeScript 7.0.2 was identified from the official package registry, but the build workspace could not install it because outbound npm installation is unavailable/misconfigured. Generated TypeScript therefore has not yet been executed through TypeScript 7.0.2 here.
- No Windows CMD execution was possible in this Linux build workspace.

## Deferred within Phase 2

The next 0.2.x increment should implement the task/effect model before declarative UI:

1. cancellable task handles and timeout/cancellation propagation
2. explicit effect annotations derived from capabilities
3. AI invocation expressions that consume declared `ai` policies
4. agent tool/action declarations with approval boundaries
5. only then first-class `ui` blocks

This ordering prevents UI and AI syntax from outrunning the security/runtime semantics beneath them.
