# Nexu AI 3D Forge v0.10.0 — Full Pack Status

The full handoff must contain one complete v0.10 source tree and one top-level Windows build/install command. It preserves Android companion source/workflow from the current compatible baseline.

Current automated status:
- 43 permanent local grammars;
- 387 recognised subject/modifier phrases;
- FastForge exact validated-build reuse;
- Fast/Balanced/Maximum Quality modes;
- Forge Home + live Prompt Coach;
- 14px minimum desktop text;
- no paid generation provider;
- no PowerShell in the Windows candidate build route;
- automated regression passing.

Physical Windows/Blender qualification is still pending.
