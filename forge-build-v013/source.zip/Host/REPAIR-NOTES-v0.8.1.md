# Nexu AI 3D Forge v0.8.1 — Build Security Repair

## Fixed
The v0.8.0 Windows build entry point invoked an unsigned `.ps1` file with `-File`. On Windows systems whose PowerShell execution policy requires signed scripts, this correctly failed with `SecurityError: ... is not digitally signed`.

v0.8.1 removes the PowerShell script from the Windows build path entirely. `BUILD-WINDOWS-CANDIDATE.cmd` now uses Windows inbox `curl.exe`, `certutil.exe` and `tar.exe` only to obtain and verify the official Go 1.26.6 archive, then runs the package-owned standard-library Go builder.

No execution policy is changed, weakened or bypassed. The user does not need to run `Set-ExecutionPolicy`, unblock files, or open an elevated shell.

## Preserved
All v0.8.0 Asset Intelligence & Learning behaviour is preserved: 23 asset grammars, bounded local preference learning, seven-view dataset capture, safe mesh repair, local-first provider policy, Android companion protocol, and the Node 24.19 / Blender 5.2 production engine.
