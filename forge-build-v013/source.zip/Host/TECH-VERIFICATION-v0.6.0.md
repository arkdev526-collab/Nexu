# Technology Verification — v0.6.0

**Verified:** 2026-08-21

## Material model
- Blender 5.2 LTS Principled BSDF is based on OpenPBR Surface and is appropriate for interoperable PBR material authoring.
  - https://docs.blender.org/manual/en/5.2/render/shader_nodes/shader/principled.html
- Unreal Engine 5.8 physically based materials use Base Color, Roughness, Metallic and Specular as core PBR inputs.
  - https://dev.epicgames.com/documentation/en-us/unreal-engine/physically-based-materials-in-unreal-engine

## Product workflow research
Current AI 3D products increasingly separate geometry from later texture/material refinement and expose PBR map generation. Forge adopts the principle — material work as an editable stage — while retaining local-first ownership and structured changes.
- Meshy seamless PBR texture guidance: https://help.meshy.ai/en/articles/16102795-how-to-create-seamless-pbr-textures-with-meshy
- Meshy texture update workflow: https://help.meshy.ai/en/articles/12127474-revamping-model-texture-with-text-prompt-or-image-upload

## Runtime pins preserved
- Node.js: 24.19.x LTS project target.
- Blender: stable 5.2.x project target.
- Windows release builder source remains pinned to Go 1.26.5. The downloadable engineering installer produced in this non-Windows container is not a final production-toolchain qualification.
