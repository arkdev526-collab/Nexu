# Nexu AI 3D Forge v0.7.1 — Technology Verification

**Verified:** 2026-08-21

## Android
- .NET 10 `net10.0-android` is the target; .NET for Android in .NET 10 supports API 36 and JDK 21.
- Experimental Android CoreCLR is deliberately not enabled; Mono remains the production runtime path.
- .NET MAUI package baseline is pinned to stable 10.0.90; no .NET 11 preview packages are used.
- Android API 36 is the compile/target surface; minimum API 30 is a product compatibility decision.
- Windows development uses the supported MAUI/Android workload path and JDK 21.

## Windows Forge
- Node 24.19.x LTS and Blender 5.2.x remain the protected working generation baseline.
- Windows setup source remains pinned to Go 1.26.5; any EXE cross-compiled in the assistant environment with an older compiler is an unsigned engineering test candidate only.

## Dependency policy
The Android project intentionally has one explicit NuGet dependency family: `Microsoft.Maui.Controls` 10.0.90. It does not add a third-party HTTP, crypto, image-processing or 3D-viewer package. The viewport is local WebGL2 code adapted from the existing Forge viewer.


## v0.7.1 repair
- Corrected the Android Doctor failure-state assignment to valid PowerShell syntax: `$script:failed = $true`.
- The Windows companion protocol remains compatible with Forge v0.7.0 or newer.
