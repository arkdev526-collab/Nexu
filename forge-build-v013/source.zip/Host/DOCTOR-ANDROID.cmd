@echo off
setlocal
cd /d "%~dp0"
where pwsh.exe >nul 2>nul
if %ERRORLEVEL%==0 (
  pwsh.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DOCTOR-ANDROID.ps1"
) else (
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DOCTOR-ANDROID.ps1"
)
set "EC=%ERRORLEVEL%"
echo.
pause
exit /b %EC%
