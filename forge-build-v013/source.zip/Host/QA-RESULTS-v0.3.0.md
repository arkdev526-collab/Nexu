# Nexu AI 3D Forge v0.3.0 — QA Results

**Date:** 17 August 2026  
**Status:** build-environment QA complete; target-Windows Studio smoke test pending.

## Passed in this build workspace

- protected Nexu Language compiler suite: **70/70 PASS**;
- complete Nexu 3D Forge suite including Studio: **16/16 PASS**;
- Nexu AI semantic/source check: **PASS**;
- Nexu AI TypeScript generation/build: **PASS**;
- generated TypeScript strict check with available TypeScript 5.8.3: **PASS**;
- `studio-server.mjs` syntax: **PASS**;
- `studio-launcher.mjs` syntax: **PASS**;
- modified `blender.mjs` syntax: **PASS**;
- Studio inline browser JavaScript syntax: **PASS**;
- Blender worker Python compile: **PASS**;
- live local Studio HTTP boot: **PASS**;
- unauthenticated health route: **PASS**;
- token → HttpOnly SameSite session exchange: **PASS**;
- authenticated status API: **PASS**;
- same-origin authenticated Plan API: **PASS**;
- real barrel brief → Nexu3D Unreal/ASA recipe through Studio API: **PASS**;
- output-root traversal rejection: **PASS**;
- prompt bounds: **PASS**;
- Studio source checks for accessibility/reduced motion/application workspaces: **PASS**;
- detached non-shell launcher policy source test: **PASS**;
- Blender cancellation/output callback bridge source test: **PASS**.

## Preserved regression evidence

Existing v0.2.0 Forge tests still pass after the Blender bridge was extended for cancellation/output callbacks. Existing CLI callers do not need to pass the new optional values.

## Build-environment limitations

The build workspace runs Node 22.16.0, so the protected production verifier correctly fails because the project requires Node 24.19.x. The build workspace is not the target Windows 11 machine and does not contain the installed Blender 5.2.x runtime used successfully by the user in the previous candidate. Therefore the following are **not claimed** here:

- Edge app-mode launch on the target Windows PC;
- live Blender generation initiated from the new Studio queue;
- active Windows Blender process cancellation;
- Windows Explorer open action;
- Open in Blender action;
- final visual validation of the UI in the target Windows Edge rendering environment.

The next evidence step is a one-click `NEXU-3D-STUDIO.cmd` target-PC smoke test, followed by one model build from the Create workspace.
