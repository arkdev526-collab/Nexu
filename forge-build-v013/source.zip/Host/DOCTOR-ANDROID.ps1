[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root 'mobile\NexuAI3DForge.Android\NexuAI3DForge.Android.csproj'
$failed = $false

function Pass([string]$Name,[string]$Detail) { Write-Host ("[PASS] {0}: {1}" -f $Name,$Detail) -ForegroundColor Green }
function Fail([string]$Name,[string]$Detail) { $script:failed = $true; Write-Host ("[FAIL] {0}: {1}" -f $Name,$Detail) -ForegroundColor Red }
function Info([string]$Name,[string]$Detail) { Write-Host ("[INFO] {0}: {1}" -f $Name,$Detail) -ForegroundColor Cyan }

function Quote-NativeArg([string]$Value) {
  if ($Value -notmatch '[\s"]') { return $Value }
  return '"' + $Value.Replace('"','\"') + '"'
}
function Invoke-NativeCapture([string]$File,[string[]]$Arguments) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $File
  $psi.Arguments = (($Arguments | ForEach-Object { Quote-NativeArg $_ }) -join ' ')
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $psi
  [void]$process.Start()
  $stdoutTask = $process.StandardOutput.ReadToEndAsync()
  $stderrTask = $process.StandardError.ReadToEndAsync()
  $process.WaitForExit()
  $stdout = $stdoutTask.Result
  $stderr = $stderrTask.Result
  return [pscustomobject]@{ ExitCode = $process.ExitCode; StdOut = $stdout; StdErr = $stderr }
}

Write-Host '============================================================'
Write-Host ' NEXU AI 3D FORGE v0.10.1 - ANDROID DOCTOR'
Write-Host ' Read-only environment check'
Write-Host '============================================================'

if (-not (Test-Path -LiteralPath $Project)) { Fail 'Project' 'Android project is missing.' } else { Pass 'Project' $Project }

$dotnet = Get-Command dotnet.exe -ErrorAction SilentlyContinue
if (-not $dotnet) { Fail '.NET SDK' 'dotnet.exe was not found. Install the .NET 10 SDK.' }
else {
  $sdk = (& $dotnet.Source --version 2>&1 | Out-String).Trim()
  if ($sdk -match '^10\.0\.4\d\d$') { Pass '.NET SDK' $sdk } else { Fail '.NET SDK' "Expected the 10.0.4xx feature band selected by global.json; found $sdk." }
  $workloads = (& $dotnet.Source workload list 2>&1 | Out-String)
  if ($workloads -match '(?m)^\s*(maui|android)\s') { Pass '.NET MAUI / Android workload' (($Matches[1]).Trim()) } else { Fail '.NET MAUI / Android workload' 'No MAUI/Android workload was detected.' }
}

$managedJdk = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Sumero Studio\BuildTools\Android\jdk-21' } else { $null }
$javaCandidates = @()
if ($managedJdk) { $javaCandidates += (Join-Path $managedJdk 'bin\java.exe') }
if ($env:JAVA_HOME) { $javaCandidates += (Join-Path $env:JAVA_HOME 'bin\java.exe') }
$java = Get-Command java.exe -ErrorAction SilentlyContinue
if ($java) { $javaCandidates += $java.Source }
if ($env:ProgramFiles) {
  $microsoftRoot = Join-Path $env:ProgramFiles 'Microsoft'
  if (Test-Path -LiteralPath $microsoftRoot) {
    $javaCandidates += Get-ChildItem -LiteralPath $microsoftRoot -Directory -Filter 'jdk-21*' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | ForEach-Object { Join-Path $_.FullName 'bin\java.exe' }
  }
  $javaCandidates += (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr\bin\java.exe')
}
$javaPath = $null
$javaVersion = $null
foreach ($candidate in ($javaCandidates | Select-Object -Unique)) {
  if (-not $candidate -or -not (Test-Path -LiteralPath $candidate)) { continue }
  $jr = Invoke-NativeCapture $candidate @('-version')
  $versionText = (($jr.StdErr + "`n" + $jr.StdOut) -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -First 1).Trim()
  if ($jr.ExitCode -eq 0 -and $versionText -match '"21(?:\.|")') { $javaPath = $candidate; $javaVersion = $versionText; break }
}
if (-not $javaPath) { Fail 'JDK' 'JDK 21 was not found. The v0.10.1 build script can install a private Microsoft JDK automatically.' }
else { Pass 'JDK 21' "$javaVersion ($javaPath)" }

$sdkCandidates = @()
if ($env:ANDROID_SDK_ROOT) { $sdkCandidates += $env:ANDROID_SDK_ROOT }
if ($env:ANDROID_HOME) { $sdkCandidates += $env:ANDROID_HOME }
if ($env:LOCALAPPDATA) { $sdkCandidates += (Join-Path $env:LOCALAPPDATA 'Android\Sdk') }
$androidSdk = $sdkCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $androidSdk) { Fail 'Android SDK' 'Android SDK directory was not found. v0.10.1 can create it automatically.' }
else {
  Pass 'Android SDK' $androidSdk
  if (Test-Path -LiteralPath (Join-Path $androidSdk 'platforms\android-36\android.jar')) { Pass 'Android API 36' 'platforms\android-36' } else { Fail 'Android API 36' 'platforms\android-36 is missing. v0.10.1 can install it automatically.' }
  $adbPath = Join-Path $androidSdk 'platform-tools\adb.exe'
  if (-not (Test-Path -LiteralPath $adbPath)) { Fail 'ADB' 'platform-tools\adb.exe is missing.' }
  else {
    Pass 'ADB' $adbPath
    $adbResult = Invoke-NativeCapture $adbPath @('devices')
    if ($adbResult.StdErr.Trim()) { Info 'ADB startup' ($adbResult.StdErr.Trim() -replace "`r?`n", ' | ') }
    if ($adbResult.ExitCode -ne 0) { Fail 'ADB devices' "adb devices exited with code $($adbResult.ExitCode)." }
    else {
      $devices = $adbResult.StdOut -split "`r?`n" | Select-Object -Skip 1 | Where-Object { $_ -match '\tdevice$' }
      if (@($devices).Count -eq 0) { Info 'Connected Android device' 'None. Build can still create an APK; USB install requires USB debugging and one authorised device.' }
      elseif (@($devices).Count -eq 1) { Pass 'Connected Android device' (($devices -split '\t')[0]) }
      else { Info 'Connected Android devices' ("{0} devices; automatic install requires exactly one." -f @($devices).Count) }
    }
  }
}

Write-Host '------------------------------------------------------------'
if ($failed) {
  Write-Host 'ANDROID DOCTOR: REPAIR NEEDED' -ForegroundColor Yellow
  Write-Host 'No changes were made by Doctor. BUILD-ANDROID-AND-INSTALL will now auto-repair JDK/API dependencies when possible.'
  exit 1
}
Write-Host 'ANDROID DOCTOR: READY' -ForegroundColor Green
exit 0
