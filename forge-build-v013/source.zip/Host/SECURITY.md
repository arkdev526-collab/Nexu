# Nexu Language 0.6.0 Security Model

## Core rule

**High-level does not mean hidden, and local does not mean cloud.**

Policy strength remains:

```text
allow < confirm < deny
```

Explicit `deny` is authoritative.

## Capability separation

0.6 distinguishes at least these relevant authorities:

```text
ai.local       local model/provider execution
network.ai     online/cloud AI execution
ui.render      UI rendering
ui.confirm     approval surface
ui.focus       host focus movement
storage.local  local application persistence
```

A capability does not imply another capability. `ui.confirm` does not grant `network.ai`. `ai.local` does not grant cloud access.

## Host runtime gate

Generated host operations verify capability, deny/confirm policy, host declaration, host-provided capability, adapter implementation, approval where required, and cancellation before invocation.

0.6 built-in hosts expose:

```text
console.preview -> ui.render, ui.confirm, ui.focus, storage.local
web.dom         -> ui.render, ui.confirm, ui.focus, storage.local
```

## Provider runtime gate

Provider operations verify:

1. route resolution;
2. operation match;
3. cancellation state;
4. every declared capability requirement;
5. deny policy;
6. confirmation policy through an explicit host confirmation surface;
7. adapter implementation;
8. then provider invocation.

Provider adapters remain compiler-known trusted runtime code. Arbitrary third-party adapter loading is not enabled.

## Local Ollama provider

The 0.6 `ollama.chat` adapter is deliberately local-only:

- Node/server environment only;
- HTTP loopback URL only (`127.0.0.1`, `localhost`, `[::1]`);
- no URL credentials;
- no query/hash;
- no arbitrary API path;
- `ai.local allow` requirement;
- cloud-tagged Ollama model routes are rejected by the Nexu local adapter.

The adapter sends prompts only to the configured loopback Ollama service. However, the Ollama service is an external process with its own configuration. Users requiring an Ollama-wide offline guarantee should also disable Ollama Cloud at the Ollama service level. Nexu does not claim to inspect or control all external Ollama settings.

## Online OpenAI provider

The production `openai.responses` adapter remains separate from the local route:

- Node/server only in 0.6;
- compiler-fixed OpenAI Responses endpoint;
- credential read only from `OPENAI_API_KEY`;
- arbitrary environment-variable names rejected;
- requires `network.ai confirm`;
- cannot execute after denial;
- cannot silently bridge into a browser-only host.

No real OpenAI network request is required for release QA.

## Persistent stores

Persistent stores:

- derive/use `storage.local`;
- use compiler-known store/key scopes rather than arbitrary source paths;
- validate String/Number/Bool value types on load and save;
- fail on corrupted type rather than silently coercing it.

### Not a secret store

The 0.6 preview persistence implementations are **not encrypted**:

- console preview writes JSON under `.nexu-data`;
- web DOM uses browser `localStorage`.

Do not store passwords, API keys, tokens, private keys or other secrets in 0.6 stores.

## Components/navigation/focus

- Component declarations are validated even when not mounted.
- 0.6 components cannot hide state/events/feature bindings or nested mounts.
- `navigate` accepts only compiler-known screen targets and only in UI events.
- `focus` accepts only compiler-known focusable targets and only in UI events.
- focus crosses `ui.focus` host capability instead of exposing raw DOM/native calls.

## UI state/events

`let` remains immutable. `set` is restricted to declared UI state inside declarative UI event handlers. Event payload signatures are compiler-known and participate in effect analysis.

## Tasks

`Task<T>` remains cancellable. Parent cancellation propagates to awaited Nexu tasks, timeout cancels child work, and `chatStop()` cancels the active chat task when configured cancellable.

## Imports

Local `.nex` imports cannot escape the entry project root.

## Recipes

Recipe application validates existing/proposed source, backs up before write, revalidates after write, rolls back on failure and refuses ambiguous destructive UI/host merges.

## Boundary

0.6 is **not an OS sandbox**, encrypted vault, network firewall or process-isolation system. Compiler-known host/provider adapters are trusted runtime code and require review. No arbitrary native/JavaScript source escape hatch or third-party adapter loading is enabled.
