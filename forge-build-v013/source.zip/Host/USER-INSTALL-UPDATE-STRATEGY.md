# User Install & Update Strategy

## Normal user contract
Users receive exactly one public installer per version:

`Nexu-AI-3D-Forge-Setup-<version>-x64.exe`

The same setup executable handles:

1. fresh install when Forge is absent;
2. update when an older version is installed;
3. repair when the same version is installed;
4. rollback through the retained previous-version mechanism;
5. uninstall from Windows Installed Apps.

## Data separation
Application binaries:
`%LOCALAPPDATA%\\Programs\\Sumero Studio\\Nexu AI 3D Forge`

User-created content:
`%USERPROFILE%\\Documents\\Nexu AI 3D Forge`

Updates must never delete or overwrite the user-content root.

## Future update delivery
The installed Update Centre already validates a future HTTPS manifest, exact download size and SHA-256 before launching the downloaded setup executable. Until Sumero Studio publishes a production update endpoint, users can simply download the next `Setup.exe`; it updates the existing install in place.

This is intentionally simpler and safer than shipping a compiler or source-build bootstrap to ordinary users.
