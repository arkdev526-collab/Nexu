@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [FAIL] Node.js is not installed or not on PATH.
  echo Install Node.js 24.19.x LTS, then run this file again.
  pause
  exit /b 1
)
node compiler\verify.mjs || goto :fail
node --test tests\*.test.mjs || goto :fail
if exist build rmdir /s /q build
node compiler\cli.mjs build examples\nexu-ai.nex --out-dir build || goto :fail
echo.
echo [PASS] Nexu Language 0.6.0 Components, Navigation, Persistence ^& Local AI Bridge is ready.
echo Generated TypeScript is in build\
pause
exit /b 0
:fail
echo.
echo [FAIL] Verification failed. See the error above.
pause
exit /b 1
