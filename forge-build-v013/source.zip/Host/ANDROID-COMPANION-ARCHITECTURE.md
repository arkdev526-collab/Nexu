# Android Creator Companion Architecture

## Boundary

```text
Android Creator Companion
  UI / touch viewport / references / material & refine requests
                  │
                  │ private LAN + paired encrypted RPC
                  ▼
Windows Nexu AI 3D Forge
  allow-listed companion handlers
                  │
                  ▼
validated Nexu3D recipe / operations
                  │
                  ▼
trusted package-owned Blender worker
                  │
                  ▼
BLEND / FBX / GLB / PBR / LOD / collision
```

Blender is deliberately not ported to Android. Android remains responsive and battery-conscious while Windows performs heavy deterministic generation.

## Pairing
1. Windows creates a random 8-character offer ID and 16-character out-of-band secret.
2. Offer expires after 10 minutes and is one-use.
3. Android derives the one-time pairing key and sends an authenticated encrypted pairing request.
4. Windows creates a random 32-byte per-device secret.
5. Android stores the resulting secret in MAUI Secure Storage.
6. Windows stores paired device metadata/secrets under Forge runtime data and allows explicit revocation.

## RPC security
- allow-listed methods only;
- request nonces are replay-protected;
- response AAD is bound to the initiating request nonce;
- 5-minute message clock window;
- AES-256-GCM confidentiality/integrity;
- private IPv4 destination validation on Android and private source filtering on Windows;
- no shell, Python or arbitrary module invocation surface.

## Offline state
Without Windows pairing, Android remains a clear **PC Offline** state. v0.7 does not silently fall back to cloud generation.
