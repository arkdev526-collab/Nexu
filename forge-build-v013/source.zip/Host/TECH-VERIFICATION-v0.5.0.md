# Nexu AI 3D Forge v0.5.0 — Technology Verification

**Verified:** 18 August 2026

| Technology | Selected/observed | Status | Decision |
|---|---|---|---|
| Node.js | 24.19.x LTS project pin | Supported project baseline | Preserve; application runtime |
| Blender | 5.2.0 stable | Stable | Preserve; proven worker baseline |
| Windows App SDK | 2.3.1 stable | Stable | Evaluated; full WinUI shell deferred to correct Windows toolchain/qualification |
| Go | 1.26.5 | Current stable patch checked from go.dev | Pin for Windows launcher/Setup compilation |
| Go 1.27 | draft/prerelease at verification time | Not stable | Reject |
| WebGL2 | platform browser capability | Stable platform API | Use for local live viewport |
| Three.js | r185 researched | Current project release | Not added; dependency-free viewer keeps candidate smaller and avoids unvendored network dependency |
| TripoSR | MIT | Research candidate | Deferred pending pinned Windows runtime/hardware QA |
| Hunyuan3D 2.1 | community licence | Licence incompatible for UK/EU territory | Block |
| TRELLIS.2 | official Linux/high-VRAM path | Not practical default | Block as default |

## Go build-tool correction

The available container contains Go 1.23.2. Go's support policy only supports a major release until two newer major releases exist; therefore that compiler is not accepted for the final v0.5 Windows binary. The project now pins `go 1.26.0` + `toolchain go1.26.5`. The Windows one-click build script downloads `go1.26.5.windows-amd64.zip` from go.dev and requires SHA-256:

`97e6b2a833b6d89f9ff17d25419ac0a7e3b482a044e9ab18cdef834bd834fd38`

before compilation.

## Official source register

- Go stable downloads / hashes: https://go.dev/dl/
- Go release policy/history: https://go.dev/doc/devel/release
- Windows App SDK downloads: https://learn.microsoft.com/windows/apps/windows-app-sdk/downloads
- Node downloads: https://nodejs.org/en/download
- Blender official builds: https://builder.blender.org/download/daily/
- Unreal FBX content pipeline: https://dev.epicgames.com/documentation/en-us/unreal-engine/fbx-content-pipeline

## Verification gap

The container cannot obtain the verified Go 1.26.5 archive directly because outbound container DNS/download access is unavailable. It also has no Windows/.NET/Blender runtime. Therefore the current environment validates source and contracts, while the included Windows builder performs the production-toolchain compile on the target PC.
