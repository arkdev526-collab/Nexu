@echo off
setlocal
cd /d "%~dp0"
echo === Nexu Language Host Adapters ===
node compiler\cli.mjs host list || goto :fail
echo.
echo Use: node compiler\cli.mjs host show ^<adapter.id^>
echo.
pause
exit /b 0
:fail
echo.
echo [FAIL] Could not list host adapters.
pause
exit /b 1
