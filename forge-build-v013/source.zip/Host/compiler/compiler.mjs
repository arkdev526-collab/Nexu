import { lex } from './lexer.mjs';
import { parse } from './parser.mjs';
import { analyse } from './semantic.mjs';
import { emit } from './emitter.mjs';

export function compile(source, target = 'typescript', externalSymbols = new Map()) {
  const tokens = lex(source);
  const ast = parse(tokens);
  analyse(ast, externalSymbols);
  const output = emit(ast, target);
  return { tokens, ast, output };
}
