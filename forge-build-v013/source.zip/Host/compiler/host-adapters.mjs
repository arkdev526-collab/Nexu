import { NexuDiagnosticError } from './diagnostics.mjs';

const ADAPTERS = [
  Object.freeze({
    id: 'console.preview',
    title: 'Console Preview Host',
    summary: 'Safe Node/bootstrap host that renders a compact declarative-UI outline and fails confirmation requests closed.',
    capabilities: Object.freeze(['ui.render', 'ui.confirm', 'ui.focus', 'storage.local']),
    environment: 'node'
  }),
  Object.freeze({
    id: 'web.dom',
    title: 'Web DOM Host',
    summary: 'Dependency-free browser DOM host for Nexu declarative UI plus an explicit confirmation surface.',
    capabilities: Object.freeze(['ui.render', 'ui.confirm', 'ui.focus', 'storage.local']),
    environment: 'browser'
  })
];

export const HOST_ADAPTER_CATALOG = new Map(ADAPTERS.map(adapter => [adapter.id, adapter]));

export function listHostAdapters() {
  return ADAPTERS.map(adapter => ({
    id: adapter.id,
    title: adapter.title,
    summary: adapter.summary,
    environment: adapter.environment,
    capabilities: [...adapter.capabilities]
  }));
}

export function getHostAdapter(id) {
  return HOST_ADAPTER_CATALOG.get(id) ?? null;
}

export function validateHostDeclaration(decl) {
  const adapter = getHostAdapter(decl.adapter);
  if (!adapter) {
    throw new NexuDiagnosticError(
      `Unknown host adapter '${decl.adapter}'. Nexu 0.6.0 only permits compiler-known adapters so runtime capability enforcement cannot be bypassed.`,
      decl.token
    );
  }
  if (!decl.provides.length) throw new NexuDiagnosticError(`Host '${decl.name}' must declare at least one provided capability`, decl.token);
  const seen = new Set();
  for (const item of decl.provides) {
    if (seen.has(item.path)) throw new NexuDiagnosticError(`Host '${decl.name}' repeats provided capability '${item.path}'`, item.token);
    seen.add(item.path);
    if (!adapter.capabilities.includes(item.path)) {
      throw new NexuDiagnosticError(`Host adapter '${adapter.id}' does not implement capability '${item.path}'`, item.token);
    }
  }
  return {
    name: decl.name,
    adapter: adapter.id,
    title: adapter.title,
    environment: adapter.environment,
    provides: [...seen],
    token: decl.token
  };
}
