import { NexuDiagnosticError } from './diagnostics.mjs';

const ADAPTERS = [
  Object.freeze({
    id: 'test.echo',
    title: 'Deterministic Echo Provider',
    summary: 'Offline test-only AI provider used to validate Nexu provider routing without network access or secrets.',
    environment: 'any',
    operation: 'ai.ask',
    testOnly: true,
    requirements: Object.freeze([]),
    config: Object.freeze({
      route: Object.freeze({ type: 'String', required: true }),
      prefix: Object.freeze({ type: 'String', default: 'Echo' })
    })
  }),
  Object.freeze({
    id: 'ollama.chat',
    title: 'Ollama Local Chat Provider',
    summary: 'Production local AI provider for Ollama /api/chat. Endpoints are restricted to loopback so local-only policy cannot silently become remote.',
    environment: 'node',
    operation: 'ai.ask',
    testOnly: false,
    requirements: Object.freeze([
      Object.freeze({ path: 'ai.local', policy: 'allow', reason: 'Invoke the configured local Ollama model over the loopback interface.' })
    ]),
    config: Object.freeze({
      route: Object.freeze({ type: 'String', required: true }),
      model: Object.freeze({ type: 'String', default: 'qwen3:8b' }),
      base_url: Object.freeze({ type: 'String', default: 'http://127.0.0.1:11434' })
    })
  }),
  Object.freeze({
    id: 'openai.responses',
    title: 'OpenAI Responses Provider',
    summary: 'Node/server provider for the OpenAI Responses API using a fixed official endpoint and an API key read from an environment variable.',
    environment: 'node',
    operation: 'ai.ask',
    testOnly: false,
    requirements: Object.freeze([
      Object.freeze({ path: 'network.ai', policy: 'confirm', reason: 'Send an AI prompt to the configured OpenAI Responses API provider.' })
    ]),
    config: Object.freeze({
      route: Object.freeze({ type: 'String', required: true }),
      model: Object.freeze({ type: 'String', default: 'gpt-5.6' }),
      key_env: Object.freeze({ type: 'String', default: 'OPENAI_API_KEY' })
    })
  })
];

export const PROVIDER_ADAPTER_CATALOG = new Map(ADAPTERS.map(adapter => [adapter.id, adapter]));

export function listProviderAdapters() {
  return ADAPTERS.map(adapter => ({
    id: adapter.id,
    title: adapter.title,
    summary: adapter.summary,
    environment: adapter.environment,
    operation: adapter.operation,
    testOnly: adapter.testOnly,
    requirements: adapter.requirements.map(x => ({ ...x })),
    config: Object.fromEntries(Object.entries(adapter.config).map(([key, value]) => [key, { ...value }]))
  }));
}

export function getProviderAdapter(id) {
  return PROVIDER_ADAPTER_CATALOG.get(id) ?? null;
}

function normaliseConfigValue(entry, schema, providerName) {
  if (!schema) throw new NexuDiagnosticError(`Provider '${providerName}' has no config '${entry.key}'`, entry.token);
  if (schema.type === 'String' && entry.valueKind !== 'String') {
    throw new NexuDiagnosticError(`Provider '${providerName}' config '${entry.key}' must be a quoted String`, entry.valueToken ?? entry.token);
  }
  if (schema.type === 'Bool' && entry.valueKind !== 'Bool') {
    throw new NexuDiagnosticError(`Provider '${providerName}' config '${entry.key}' must be Bool`, entry.valueToken ?? entry.token);
  }
  return entry.value;
}

export function validateProviderDeclaration(decl) {
  const adapter = getProviderAdapter(decl.adapter);
  if (!adapter) {
    throw new NexuDiagnosticError(
      `Unknown provider adapter '${decl.adapter}'. Nexu 0.6.0 permits compiler-known provider adapters only.`,
      decl.token
    );
  }

  const config = {};
  const seen = new Set();
  for (const entry of decl.config) {
    if (seen.has(entry.key)) throw new NexuDiagnosticError(`Provider '${decl.name}' repeats config '${entry.key}'`, entry.token);
    seen.add(entry.key);
    config[entry.key] = normaliseConfigValue(entry, adapter.config[entry.key], decl.name);
  }
  for (const [key, schema] of Object.entries(adapter.config)) {
    if (!(key in config)) {
      if ('default' in schema) config[key] = schema.default;
      else if (schema.required) throw new NexuDiagnosticError(`Provider '${decl.name}' requires config '${key}'`, decl.token);
    }
  }
  if (!String(config.route ?? '').trim()) throw new NexuDiagnosticError(`Provider '${decl.name}' route cannot be empty`, decl.token);
  if (adapter.id === 'openai.responses' && config.key_env !== 'OPENAI_API_KEY') {
    throw new NexuDiagnosticError(`Provider '${decl.name}' must use key_env \"OPENAI_API_KEY\" in Nexu 0.6.0 so source cannot redirect unrelated environment secrets into the OpenAI provider`, decl.token);
  }
  if (adapter.id === 'ollama.chat') {
    let parsed;
    try { parsed = new URL(String(config.base_url)); } catch { throw new NexuDiagnosticError(`Provider '${decl.name}' base_url must be a valid loopback URL`, decl.token); }
    const allowedHosts = new Set(['127.0.0.1', 'localhost', '[::1]']);
    if (parsed.protocol !== 'http:' || !allowedHosts.has(parsed.hostname) || parsed.username || parsed.password || parsed.search || parsed.hash) {
      throw new NexuDiagnosticError(`Provider '${decl.name}' ollama.chat base_url must be plain HTTP on localhost, 127.0.0.1, or ::1 with no credentials/query/fragment`, decl.token);
    }
    if (parsed.pathname !== '/' && parsed.pathname !== '') throw new NexuDiagnosticError(`Provider '${decl.name}' ollama.chat base_url must not include an API path; Nexu owns /api/chat`, decl.token);
    config.base_url = parsed.origin;
    if (!String(config.model ?? '').trim()) throw new NexuDiagnosticError(`Provider '${decl.name}' Ollama model cannot be empty`, decl.token);
    if (/(?:^|[:_-])cloud(?:$|[:_-])/i.test(String(config.model))) {
      throw new NexuDiagnosticError(`Provider '${decl.name}' cannot use Ollama cloud model '${config.model}'; ollama.chat is a local-only provider in Nexu 0.6.0`, decl.token);
    }
  }

  return Object.freeze({
    name: decl.name,
    adapter: adapter.id,
    title: adapter.title,
    environment: adapter.environment,
    operation: adapter.operation,
    testOnly: adapter.testOnly,
    route: config.route,
    config: Object.freeze({ ...config }),
    requirements: Object.freeze(adapter.requirements.map(x => Object.freeze({ ...x }))),
    token: decl.token
  });
}
