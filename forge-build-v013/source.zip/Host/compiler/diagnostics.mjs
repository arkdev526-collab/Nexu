export class NexuDiagnosticError extends Error {
  constructor(message, token) {
    const where = token ? ` (${token.line}:${token.column})` : '';
    super(`${message}${where}`);
    this.name = 'NexuDiagnosticError';
    this.token = token ?? null;
  }
}
