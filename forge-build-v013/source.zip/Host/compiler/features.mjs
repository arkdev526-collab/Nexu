import { NexuDiagnosticError } from './diagnostics.mjs';

const value = (type, defaultValue, extra = {}) => Object.freeze({ type, default: defaultValue, ...extra });

const FEATURE_DEFINITIONS = [
  {
    id: 'storage.local',
    title: 'Local Storage',
    summary: 'Local-first application storage contract.',
    configs: {
      encrypted: value('Bool', false),
      scope: value('Enum', 'app', { values: ['app', 'project'] })
    },
    dependencies: [],
    capabilities: () => [{ path: 'storage.local', policy: 'allow', reason: 'Persist local application data.' }],
    validate(config, token) {
      if (config.encrypted) throw new NexuDiagnosticError("Feature 'storage.local' cannot set encrypted true in 0.6 because the built-in persistence hosts are not encrypted; use encrypted false and do not store secrets", token);
    },
    provides: ['local persistence contract', 'storage capability metadata', 'explicit unencrypted-store contract']
  },
  {
    id: 'project.workspace',
    title: 'Project Workspace',
    summary: 'Read/review/write project workspace contract with write approval by default.',
    configs: {
      read: value('Bool', true),
      write: value('Bool', true)
    },
    dependencies: [],
    capabilities: config => [
      ...(config.read ? [{ path: 'project.read', policy: 'allow', reason: 'Read project context.' }] : []),
      ...(config.write ? [{ path: 'project.write', policy: 'confirm', reason: 'Project changes require approval.' }] : [])
    ],
    provides: ['project context', 'read contract', 'approval-gated write contract']
  },
  {
    id: 'ai.chat.full',
    title: 'AI Chat Full',
    summary: 'Full headless AI chat foundation with history, cancellation, model policy and safe fallback metadata.',
    configs: {
      name: value('String', 'Nexu AI'),
      model: value('String', 'local.qwen'),
      fallback: value('StringOrNone', null),
      privacy: value('Enum', 'local_first', { values: ['local_only', 'local_first', 'cloud_allowed'] }),
      memory: value('Enum', 'conversation', { values: ['none', 'conversation', 'project'] }),
      streaming: value('Bool', true),
      markdown: value('Bool', true),
      code_blocks: value('Bool', true),
      cancellable: value('Bool', true)
    },
    dependencies: config => config.memory === 'none' ? [] : ['storage.local'],
    capabilities: config => [
      ...(config.memory === 'none' ? [] : [{ path: 'storage.local', policy: 'allow', reason: 'Persist conversation memory locally.' }]),
      ...(String(config.model ?? '').startsWith('local.') ? [{ path: 'ai.local', policy: 'allow', reason: 'Invoke an explicitly declared local AI provider without cloud access.' }] : []),
      ...((config.privacy !== 'local_only' || config.fallback) ? [{ path: 'network.ai', policy: 'confirm', reason: 'Cloud/fallback AI access must cross an approval boundary.' }] : [])
    ],
    validate(config, token) {
      if (config.privacy === 'local_only' && config.fallback) throw new NexuDiagnosticError("Feature 'ai.chat.full' is local_only and cannot declare a fallback", token);
    },
    provides: ['chat session', 'conversation history', 'cancellable send task', 'model policy', 'fallback policy', 'streaming intent', 'markdown intent', 'code-block intent']
  },
  {
    id: 'agent.coder',
    title: 'Coding Agent',
    summary: 'Approval-gated coding-agent contract built on AI Chat Full and Project Workspace.',
    configs: {
      writes: value('Enum', 'confirm', { values: ['confirm', 'deny'] }),
      tests: value('Bool', true)
    },
    dependencies: ['ai.chat.full', 'project.workspace'],
    capabilities: config => [
      { path: 'project.read', policy: 'allow', reason: 'Inspect project context.' },
      { path: 'project.write', policy: config.writes, reason: 'Code changes remain confirmation-gated or denied.' }
    ],
    provides: ['coding-agent contract', 'project inspection', 'approval-gated writes', 'test intent']
  },
  {
    id: 'auth.local',
    title: 'Local Authentication',
    summary: 'Local authentication intent without silently adding a remote identity provider.',
    configs: {
      method: value('Enum', 'pin', { values: ['pin', 'passkey'] }),
      lock_on_start: value('Bool', true)
    },
    dependencies: ['storage.local'],
    capabilities: () => [{ path: 'storage.local', policy: 'allow', reason: 'Store local authentication state.' }],
    provides: ['local authentication contract', 'startup lock intent']
  }
];

export const FEATURE_CATALOG = new Map(FEATURE_DEFINITIONS.map(feature => [feature.id, Object.freeze(feature)]));

export function listFeatures() {
  return FEATURE_DEFINITIONS.map(feature => ({ id: feature.id, title: feature.title, summary: feature.summary }));
}

export function getFeature(id) { return FEATURE_CATALOG.get(id) ?? null; }

function normaliseConfigValue(entry, schema, featureId) {
  const actual = entry.value;
  if (schema.type === 'Bool') {
    if (entry.valueKind !== 'Bool') throw new NexuDiagnosticError(`Feature '${featureId}' config '${entry.key}' must be Bool`, entry.token);
    return actual;
  }
  if (schema.type === 'String') {
    if (entry.valueKind !== 'String') throw new NexuDiagnosticError(`Feature '${featureId}' config '${entry.key}' must be a quoted String`, entry.token);
    return actual;
  }
  if (schema.type === 'StringOrNone') {
    if (entry.valueKind === 'String') return actual;
    if (entry.valueKind === 'Name' && actual === 'none') return null;
    throw new NexuDiagnosticError(`Feature '${featureId}' config '${entry.key}' must be a quoted String or 'none'`, entry.token);
  }
  if (schema.type === 'Number') {
    if (entry.valueKind !== 'Number') throw new NexuDiagnosticError(`Feature '${featureId}' config '${entry.key}' must be Number`, entry.token);
    return actual;
  }
  if (schema.type === 'Enum') {
    if (entry.valueKind !== 'Name' || !schema.values.includes(actual)) {
      throw new NexuDiagnosticError(`Feature '${featureId}' config '${entry.key}' must be one of: ${schema.values.join(', ')}`, entry.token);
    }
    return actual;
  }
  throw new NexuDiagnosticError(`Unsupported feature config schema '${schema.type}'`, entry.token);
}

export function resolveFeatureUse(decl) {
  const feature = getFeature(decl.path);
  if (!feature) throw new NexuDiagnosticError(`Unknown Nexu feature '${decl.path}'`, decl.token);
  const config = Object.fromEntries(Object.entries(feature.configs).map(([key, schema]) => [key, schema.default]));
  const seen = new Set();
  for (const entry of decl.config) {
    if (seen.has(entry.key)) throw new NexuDiagnosticError(`Feature '${decl.path}' repeats config '${entry.key}'`, entry.token);
    seen.add(entry.key);
    const schema = feature.configs[entry.key];
    if (!schema) throw new NexuDiagnosticError(`Feature '${decl.path}' has no config '${entry.key}'`, entry.token);
    config[entry.key] = normaliseConfigValue(entry, schema, decl.path);
  }
  feature.validate?.(config, decl.token);
  const dependencies = typeof feature.dependencies === 'function' ? feature.dependencies(config) : feature.dependencies;
  const capabilities = feature.capabilities(config);
  return { id: feature.id, title: feature.title, summary: feature.summary, config: Object.freeze(config), dependencies: [...dependencies], capabilities, provides: [...feature.provides], explicit: true, token: decl.token };
}

export function resolveFeaturePlan(declarations) {
  const explicit = new Map();
  for (const decl of declarations) {
    if (explicit.has(decl.path)) throw new NexuDiagnosticError(`Feature '${decl.path}' is already used by this app`, decl.token);
    explicit.set(decl.path, resolveFeatureUse(decl));
  }

  const resolved = new Map();
  const visiting = new Set();
  function add(id, from = null) {
    if (resolved.has(id)) return;
    if (visiting.has(id)) throw new NexuDiagnosticError(`Circular Nexu feature dependency detected at '${id}'`);
    const feature = getFeature(id);
    if (!feature) throw new NexuDiagnosticError(`Feature '${from}' depends on unknown feature '${id}'`);
    visiting.add(id);
    let item = explicit.get(id);
    if (!item) {
      const config = Object.fromEntries(Object.entries(feature.configs).map(([key, schema]) => [key, schema.default]));
      feature.validate?.(config);
      const dependencies = typeof feature.dependencies === 'function' ? feature.dependencies(config) : feature.dependencies;
      item = { id, title: feature.title, summary: feature.summary, config: Object.freeze(config), dependencies: [...dependencies], capabilities: feature.capabilities(config), provides: [...feature.provides], explicit: false, token: null };
    }
    for (const dependency of item.dependencies) add(dependency, id);
    visiting.delete(id);
    resolved.set(id, item);
  }
  for (const id of explicit.keys()) add(id);
  return [...resolved.values()];
}
