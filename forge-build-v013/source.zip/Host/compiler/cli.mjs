#!/usr/bin/env node
import { rm } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileProject, writeProjectBuild } from './project.mjs';
import { getFeature, listFeatures } from './features.mjs';
import { applyRecipeToFile, listRecipes, previewRecipeForFile, renderRecipe } from './recipes.mjs';
import { NexuDiagnosticError } from './diagnostics.mjs';
import { getHostAdapter, listHostAdapters } from './host-adapters.mjs';
import { getProviderAdapter, listProviderAdapters } from './provider-adapters.mjs';

function usage() {
  console.log(`Nexu Language 0.6.0 Components, Navigation, Persistence & Local AI Bridge

Usage:
  node compiler/cli.mjs check <entry.nex>
  node compiler/cli.mjs build <entry.nex> [--out-dir build]
  node compiler/cli.mjs run <entry.nex>
  node compiler/cli.mjs explain <entry.nex>
  node compiler/cli.mjs metrics <entry.nex>

  node compiler/cli.mjs feature list
  node compiler/cli.mjs feature show <feature.id>

  node compiler/cli.mjs host list
  node compiler/cli.mjs host show <adapter.id>

  node compiler/cli.mjs provider list
  node compiler/cli.mjs provider show <adapter.id>
  node compiler/cli.mjs local-ai doctor <entry.nex>

  node compiler/cli.mjs recipe list
  node compiler/cli.mjs recipe show "AI Chat Full"
  node compiler/cli.mjs recipe preview "AI Chat Full" <entry.nex>
  node compiler/cli.mjs recipe apply "AI Chat Full" <entry.nex>
`);
}

function assertNexFile(input) {
  if (!input) throw new Error('A Nexu .nex input file is required');
  const inputPath = resolve(input);
  if (!inputPath.endsWith('.nex')) throw new Error('Nexu source files must use the .nex extension');
  return inputPath;
}

function printFeature(feature) {
  console.log(`${feature.id} — ${feature.title}`);
  console.log(feature.summary);
  console.log(`Provides: ${feature.provides.join(', ')}`);
  const dependencies = typeof feature.dependencies === 'function' ? 'configuration-dependent' : feature.dependencies.join(', ') || 'none';
  console.log(`Dependencies: ${dependencies}`);
  console.log('Config:');
  for (const [key, schema] of Object.entries(feature.configs)) {
    const allowed = schema.values ? ` [${schema.values.join(' | ')}]` : '';
    console.log(`  ${key}: ${schema.type}${allowed} (default ${JSON.stringify(schema.default)})`);
  }
}

function printPlan(project) {
  const entry = project.units.get(project.entryPath);
  const analysis = entry?.ast.analysis;
  if (!analysis) return;
  console.log(`APP ${entry.ast.container.name}`);
  console.log(`FEATURES ${analysis.featurePlan.length}`);
  for (const feature of analysis.featurePlan) {
    console.log(`  ${feature.explicit ? '*' : '+'} ${feature.id} — ${feature.title}`);
    if (feature.dependencies.length) console.log(`      dependencies: ${feature.dependencies.join(', ')}`);
    if (feature.capabilities.length) console.log(`      capabilities: ${feature.capabilities.map(x => `${x.path}:${x.policy}`).join(', ')}`);
    console.log(`      provides: ${feature.provides.join(', ')}`);
  }
  console.log('PROVIDER CONTRACTS');
  if (!analysis.providers?.length) console.log('  none');
  else for (const provider of analysis.providers) {
    console.log(`  ${provider.name}: ${provider.adapter} -> ${provider.route} (${provider.environment})`);
    console.log(`      operation: ${provider.operation}`);
    console.log(`      requires: ${provider.requirements.length ? provider.requirements.map(x => `${x.path}:${x.policy}`).join(', ') : 'none'}`);
  }
  console.log('HOST CONTRACT');
  if (!analysis.host) console.log('  none');
  else {
    console.log(`  ${analysis.host.name}: ${analysis.host.adapter} (${analysis.host.environment})`);
    console.log(`  provides: ${analysis.host.provides.join(', ') || 'none'}`);
  }
  console.log('PERSISTENT STORES');
  if (!analysis.stores?.size) console.log('  none');
  else for (const [name, store] of analysis.stores) console.log(`  ${name}: ${store.persistence} [${[...store.states].map(([key, state]) => `${key}:${state.type.name}`).join(', ')}]`);
  console.log('COMPONENTS');
  console.log(`  ${analysis.components?.join(', ') || 'none'}`);
  console.log('DECLARATIVE UI');
  if (!analysis.ui) console.log('  none');
  else {
    const nodes = [];
    const walk = items => { for (const item of items) { nodes.push(`${item.type}:${item.name}${item.feature ? `[${item.feature}]` : ''}`); walk(item.children); } };
    walk(analysis.ui.children);
    console.log(`  ${analysis.ui.name}`);
    console.log(`  screens: ${analysis.ui.screens?.join(', ') || 'none'}`);
    console.log(`  start screen: ${analysis.ui.properties?.start_screen ?? 'none'}`);
    console.log(`  states: ${analysis.ui.states?.map(x => `${x.name}:${x.type.name}`).join(', ') || 'none'}`);
    const rootEvents = analysis.ui.events?.map(x => x.name) ?? [];
    const eventNames = [...rootEvents];
    const collectEvents = items => { for (const item of items ?? []) { for (const event of item.events ?? []) eventNames.push(`${item.name}.${event.name}`); collectEvents(item.children); } };
    collectEvents(analysis.ui.children);
    console.log(`  events: ${eventNames.join(', ') || 'none'}`);
    console.log(`  nodes: ${nodes.join(', ') || 'none'}`);
  }
  console.log('EFFECTIVE CAPABILITIES');
  if (!analysis.capabilities.size) console.log('  none');
  for (const [path, policy] of analysis.capabilities) console.log(`  ${path}: ${policy}`);
  console.log('FUNCTION EFFECTS');
  const effectful = [...analysis.functions].filter(([, fn]) => fn.effects?.size);
  if (!effectful.length) console.log('  none');
  for (const [name, fn] of effectful) console.log(`  ${name}: ${[...fn.effects].join(', ')}`);
}

async function sourceCommand(command, input, rest) {
  const inputPath = assertNexFile(input);
  if (command === 'check') {
    const project = await compileProject(inputPath, 'typescript');
    let tokenCount = 0;
    for (const record of project.units.values()) tokenCount += record.tokens.length;
    console.log(`PASS ${input} (${project.units.size} unit(s), ${tokenCount} tokens)`);
    return;
  }
  if (command === 'build') {
    const outIndex = rest.indexOf('--out-dir');
    const outDir = outIndex >= 0 && rest[outIndex + 1] ? resolve(rest[outIndex + 1]) : resolve('build');
    const project = await compileProject(inputPath, 'typescript');
    const result = await writeProjectBuild(project, outDir);
    console.log(`BUILT ${project.units.size} unit(s) -> ${result.outDir}`);
    for (const file of result.written) console.log(`  ${file.output}`);
    return;
  }
  if (command === 'explain') {
    const project = await compileProject(inputPath, 'typescript');
    printPlan(project);
    return;
  }
  if (command === 'metrics') {
    const project = await compileProject(inputPath, 'typescript');
    let sourceLines = 0, generatedLines = 0;
    for (const record of project.units.values()) {
      sourceLines += record.source.split(/\r?\n/).filter(line => line.trim() && !line.trim().startsWith('//')).length;
      generatedLines += record.output.split(/\r?\n/).filter(line => line.trim() && !line.trim().startsWith('//')).length;
    }
    const entry = project.units.get(project.entryPath);
    const features = entry?.ast.analysis?.featurePlan ?? [];
    const ratio = sourceLines ? generatedLines / sourceLines : 0;
    console.log(`AUTHORED_NEX_LINES ${sourceLines}`);
    console.log(`GENERATED_TS_LINES ${generatedLines}`);
    console.log(`GENERATED_TO_AUTHORED_RATIO ${ratio.toFixed(2)}x`);
    console.log(`FEATURES ${features.length}`);
    console.log(`EXPLICIT_FEATURES ${features.filter(x => x.explicit).length}`);
    console.log(`AUTO_DEPENDENCIES ${features.filter(x => !x.explicit).length}`);
    const ui = entry?.ast.analysis?.ui;
    let uiNodes = 0;
    const countUi = nodes => { for (const node of nodes ?? []) { uiNodes += 1; countUi(node.children); } };
    countUi(ui?.children);
    console.log(`UI_NODES ${uiNodes}`);
    console.log(`UI_STATES ${ui?.states?.length ?? 0}`);
    let uiEvents = ui?.events?.length ?? 0;
    const countEvents = nodes => { for (const node of nodes ?? []) { uiEvents += node.events?.length ?? 0; countEvents(node.children); } };
    countEvents(ui?.children);
    console.log(`UI_EVENTS ${uiEvents}`);
    const analysis = entry?.ast.analysis;
    console.log(`COMPONENTS ${analysis?.components?.length ?? 0}`);
    console.log(`SCREENS ${ui?.screens?.length ?? 0}`);
    console.log(`PERSISTENT_STORES ${analysis?.stores?.size ?? 0}`);
    console.log(`PROVIDERS ${analysis?.providers?.length ?? 0}`);
    console.log(`LOCAL_AI_PROVIDERS ${analysis?.providers?.filter(x => x.adapter === 'ollama.chat').length ?? 0}`);
    console.log(`HOST_ADAPTER ${analysis?.host?.adapter ?? 'none'}`);
    console.log('NOTE Generated lines are a compiler expansion metric, not a claim that a human-written TypeScript equivalent would contain the same number of lines.');
    return;
  }
  const runDir = resolve('.nexu-run');
  await rm(runDir, { recursive: true, force: true });
  const project = await compileProject(inputPath, 'javascript');
  const entry = project.units.get(project.entryPath);
  if (entry?.ast.analysis?.host?.environment === 'browser') {
    throw new Error(`Host adapter '${entry.ast.analysis.host.adapter}' requires a browser. Use 'build' and load the generated module in a browser host instead of CLI 'run'.`);
  }
  const result = await writeProjectBuild(project, runDir);
  try {
    await import(`${pathToFileURL(result.entryOutput).href}?v=${Date.now()}`);
  } finally {
    await rm(runDir, { recursive: true, force: true });
  }
}

async function localAiDoctor(input) {
  const inputPath = assertNexFile(input);
  const project = await compileProject(inputPath, 'typescript');
  const entry = project.units.get(project.entryPath);
  const providers = entry?.ast.analysis?.providers?.filter(provider => provider.adapter === 'ollama.chat') ?? [];
  if (!providers.length) throw new Error('No ollama.chat provider is declared in this Nexu app.');
  for (const provider of providers) {
    const baseUrl = String(provider.config.base_url);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort('local-ai-doctor-timeout'), 3000);
    try {
      const [versionResponse, tagsResponse] = await Promise.all([
        fetch(`${baseUrl}/api/version`, { signal: controller.signal }),
        fetch(`${baseUrl}/api/tags`, { signal: controller.signal })
      ]);
      if (!versionResponse.ok) throw new Error(`Ollama version endpoint returned HTTP ${versionResponse.status}`);
      if (!tagsResponse.ok) throw new Error(`Ollama model endpoint returned HTTP ${tagsResponse.status}`);
      const versionBody = await versionResponse.json();
      const tagsBody = await tagsResponse.json();
      const models = Array.isArray(tagsBody?.models) ? tagsBody.models : [];
      const configured = String(provider.config.model);
      const found = models.some(model => model?.name === configured || model?.model === configured);
      console.log(`OLLAMA ${provider.name} ${baseUrl} version=${String(versionBody?.version ?? 'unknown')}`);
      console.log(`MODEL ${configured} ${found ? 'READY' : 'MISSING'}`);
      if (!found) throw new Error(`Configured Ollama model '${configured}' is not installed. Install/pull it in Ollama, then run local-ai doctor again.`);
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error(`Ollama at ${baseUrl} did not respond within 3 seconds.`);
      if (error instanceof TypeError || error?.cause?.code === 'ECONNREFUSED') throw new Error(`Could not reach Ollama at ${baseUrl}. Start Ollama locally, ensure the configured model is installed, then run the doctor again.`);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
  console.log('PASS Local AI provider doctor');
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  if (!command) { usage(); process.exitCode = 2; return; }

  if (['check', 'build', 'run', 'explain', 'metrics'].includes(command)) {
    await sourceCommand(command, args[1], args.slice(2));
    return;
  }

  if (command === 'local-ai' && args[1] === 'doctor') {
    await localAiDoctor(args[2]);
    return;
  }

  if (command === 'feature') {
    const action = args[1];
    if (action === 'list') {
      for (const feature of listFeatures()) console.log(`${feature.id}\t${feature.title}\t${feature.summary}`);
      return;
    }
    if (action === 'show' && args[2]) {
      const feature = getFeature(args[2]);
      if (!feature) throw new NexuDiagnosticError(`Unknown Nexu feature '${args[2]}'`);
      printFeature(feature);
      return;
    }
    usage(); process.exitCode = 2; return;
  }

  if (command === 'host') {
    const action = args[1];
    if (action === 'list') {
      for (const adapter of listHostAdapters()) console.log(`${adapter.id}\t${adapter.environment}\t${adapter.capabilities.join(',')}\t${adapter.title}`);
      return;
    }
    if (action === 'show' && args[2]) {
      const adapter = getHostAdapter(args[2]);
      if (!adapter) throw new NexuDiagnosticError(`Unknown Nexu host adapter '${args[2]}'`);
      console.log(`${adapter.id} — ${adapter.title}`);
      console.log(adapter.summary);
      console.log(`Environment: ${adapter.environment}`);
      console.log(`Capabilities: ${adapter.capabilities.join(', ') || 'none'}`);
      return;
    }
    usage(); process.exitCode = 2; return;
  }

  if (command === 'provider') {
    const action = args[1];
    if (action === 'list') {
      for (const adapter of listProviderAdapters()) console.log(`${adapter.id}\t${adapter.environment}\t${adapter.operation}\t${adapter.testOnly ? 'test-only' : 'production'}\t${adapter.title}`);
      return;
    }
    if (action === 'show' && args[2]) {
      const adapter = getProviderAdapter(args[2]);
      if (!adapter) throw new NexuDiagnosticError(`Unknown Nexu provider adapter '${args[2]}'`);
      console.log(`${adapter.id} — ${adapter.title}`);
      console.log(adapter.summary);
      console.log(`Environment: ${adapter.environment}`);
      console.log(`Operation: ${adapter.operation}`);
      console.log(`Test only: ${adapter.testOnly ? 'yes' : 'no'}`);
      console.log(`Requirements: ${adapter.requirements.length ? adapter.requirements.map(x => `${x.path}:${x.policy}`).join(', ') : 'none'}`);
      console.log(`Config: ${Object.keys(adapter.config).join(', ') || 'none'}`);
      return;
    }
    usage(); process.exitCode = 2; return;
  }

  if (command === 'recipe') {
    const action = args[1];
    if (action === 'list') {
      for (const recipe of listRecipes()) console.log(`${recipe.title}\t${recipe.feature}\t${recipe.aliases.join(' | ')}`);
      return;
    }
    if (action === 'show' && args[2]) {
      const recipe = renderRecipe(args[2]);
      console.log(`${recipe.title} -> ${recipe.feature}\n\n${recipe.snippet}`);
      return;
    }
    if ((action === 'preview' || action === 'apply') && args[2] && args[3]) {
      const result = action === 'preview'
        ? await previewRecipeForFile(args[2], args[3])
        : await applyRecipeToFile(args[2], args[3]);
      console.log(`${result.changed ? (action === 'apply' ? 'APPLIED' : 'PREVIEW') : 'NO CHANGE'} ${result.recipe.title} -> ${result.recipe.feature}`);
      if (result.backup) console.log(`BACKUP ${result.backup}`);
      if (action === 'preview' && result.changed) console.log(`\n${result.source}`);
      if (!result.changed && result.reason) console.log(result.reason);
      return;
    }
    usage(); process.exitCode = 2; return;
  }

  usage(); process.exitCode = 2;
}

main().catch(error => {
  if (error instanceof NexuDiagnosticError) {
    console.error(`NEXU ERROR: ${error.message}`); process.exitCode = 1; return;
  }
  console.error(`ERROR: ${error?.message ?? error}`); process.exitCode = 1;
});
