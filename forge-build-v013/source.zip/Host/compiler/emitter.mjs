const primitiveMap = { String: 'string', Number: 'number', Bool: 'boolean', Void: 'void', Unknown: 'unknown' };
const indent = (level) => '  '.repeat(level);

function emitType(type) {
  if (primitiveMap[type.name]) return primitiveMap[type.name];
  if (type.name === 'List') return `ReadonlyArray<${emitType(type.args[0])}>`;
  if (type.name === 'Result') return `NexuResult<${emitType(type.args[0])}, ${emitType(type.args[1])}>`;
  if (type.name === 'Task') return `NexuTask<${emitType(type.args[0])}>`;
  return type.name;
}

function importedPath(source, target) {
  if (!source.endsWith('.nex')) return source;
  return source.slice(0, -4) + (target === 'typescript' ? '.js' : '.mjs');
}

function emitExpression(expr, target, context = {}) {
  switch (expr.kind) {
    case 'StringLiteral': return JSON.stringify(expr.value);
    case 'NumberLiteral': return String(expr.value);
    case 'BooleanLiteral': return expr.value ? 'true' : 'false';
    case 'Identifier': return expr.uiState ? (target === 'typescript' ? `__nexuUiState.get<${emitType(expr.inferredType)}>(${JSON.stringify(expr.name)})` : `__nexuUiState.get(${JSON.stringify(expr.name)})`) : expr.name;
    case 'GroupingExpression': return `(${emitExpression(expr.expression, target, context)})`;
    case 'ListLiteral': return `[${expr.elements.map(e => emitExpression(e, target, context)).join(', ')}]`;
    case 'RecordLiteral': return `{ ${expr.fields.map(f => `${f.name}: ${emitExpression(f.value, target, context)}`).join(', ')} }`;
    case 'MemberExpression': return `${emitExpression(expr.object, target, context)}.${expr.member}`;
    case 'IndexExpression': return `${emitExpression(expr.object, target, context)}[${emitExpression(expr.index, target, context)}]`;
    case 'UnaryExpression': return `${expr.operator}${emitExpression(expr.operand, target, context)}`;
    case 'AwaitExpression': {
      const signal = context.signal ?? 'undefined';
      return `await __nexuAwait(${emitExpression(expr.operand, target, context)}, ${signal})`;
    }
    case 'StoreLoadExpression': { const inner = expr.inferredType?.name === 'Task' ? expr.inferredType.args?.[0] : null; const generic = target === 'typescript' && inner ? `<${emitType(inner)}>` : ''; return `__nexuStoreLoad${generic}(${JSON.stringify(expr.store)}, ${JSON.stringify(expr.key)})`; }
    case 'AiAskExpression': return `__nexuAsk(${expr.ai}, ${emitExpression(expr.prompt, target, context)})`;
    case 'BinaryExpression': {
      const operator = expr.operator === '==' ? '===' : expr.operator === '!=' ? '!==' : expr.operator;
      return `${emitExpression(expr.left, target, context)} ${operator} ${emitExpression(expr.right, target, context)}`;
    }
    case 'CallExpression': {
      const callee = emitExpression(expr.callee, target, context);
      const args = expr.args.map(a => emitExpression(a, target, context)).join(', ');
      if (callee === 'print') return `console.log(${args})`;
      if (callee === 'ok') return `__nexuOk(${args})`;
      if (callee === 'err') return `__nexuErr(${args})`;
      if (callee === 'delay') return `__nexuDelay(${args})`;
      if (callee === 'timeout') return `__nexuTimeout(${args})`;
      if (callee === 'cancel') return `__nexuCancel(${args})`;
      if (callee === 'chatSend') return `__nexuAiChatFull.send(${args})`;
      if (callee === 'chatClear') return `__nexuAiChatFull.clear()`;
      if (callee === 'chatStop') return `__nexuAiChatFull.stop()`;
      return `${callee}(${args})`;
    }
    default: throw new Error(`Cannot emit expression '${expr.kind}'`);
  }
}

function emitStatements(statements, level, target, state, context = {}) {
  const lines = [];
  for (const stmt of statements) {
    if (stmt.kind === 'LetStatement') {
      const annotation = target === 'typescript' ? `: ${emitType(stmt.resolvedType ?? stmt.type ?? stmt.initializer.inferredType)}` : '';
      lines.push(`${indent(level)}const ${stmt.name}${annotation} = ${emitExpression(stmt.initializer, target, context)};`);
    } else if (stmt.kind === 'SetStatement') {
      lines.push(`${indent(level)}__nexuUiState.set(${JSON.stringify(stmt.name)}, ${emitExpression(stmt.value, target, context)});`);
    } else if (stmt.kind === 'StoreSaveStatement') {
      const signal = context.signal ?? 'undefined';
      lines.push(`${indent(level)}await __nexuAwait(__nexuStoreSave(${JSON.stringify(stmt.store)}, ${JSON.stringify(stmt.key)}, ${emitExpression(stmt.value, target, context)}), ${signal});`);
    } else if (stmt.kind === 'NavigateStatement') {
      lines.push(`${indent(level)}await __nexuNavigate(${JSON.stringify(stmt.target)});`);
    } else if (stmt.kind === 'FocusStatement') {
      const signal = context.signal ?? 'undefined';
      lines.push(`${indent(level)}await __nexuHostInvoke("ui.focus", "ui.focus", Object.freeze({ name: ${JSON.stringify(stmt.target)} }), ${signal});`);
    } else if (stmt.kind === 'ExpressionStatement') {
      lines.push(`${indent(level)}${emitExpression(stmt.expression, target, context)};`);
    } else if (stmt.kind === 'ReturnStatement') {
      lines.push(`${indent(level)}return${stmt.value ? ` ${emitExpression(stmt.value, target, context)}` : ''};`);
    } else if (stmt.kind === 'IfStatement') {
      lines.push(`${indent(level)}if (${emitExpression(stmt.condition, target, context)}) {`);
      lines.push(...emitStatements(stmt.thenBranch, level + 1, target, state, context));
      if (stmt.elseBranch) {
        lines.push(`${indent(level)}} else {`);
        lines.push(...emitStatements(stmt.elseBranch, level + 1, target, state, context));
      }
      lines.push(`${indent(level)}}`);
    } else if (stmt.kind === 'MatchStatement') {
      const temp = `__nexuMatch${++state.matchCounter}`;
      const okArm = stmt.arms.find(a => a.variant === 'ok');
      const errArm = stmt.arms.find(a => a.variant === 'err');
      lines.push(`${indent(level)}const ${temp} = ${emitExpression(stmt.value, target, context)};`);
      lines.push(`${indent(level)}if (${temp}.kind === "ok") {`);
      lines.push(`${indent(level + 1)}const ${okArm.binding} = ${temp}.value;`);
      lines.push(...emitStatements(okArm.body, level + 1, target, state, context));
      lines.push(`${indent(level)}} else {`);
      lines.push(`${indent(level + 1)}const ${errArm.binding} = ${temp}.error;`);
      lines.push(...emitStatements(errArm.body, level + 1, target, state, context));
      lines.push(`${indent(level)}}`);
    }
  }
  return lines;
}

function emitTaskRuntime(target) {
  if (target === 'typescript') {
    return [
      'type NexuResult<T, E> =',
      '  | { readonly kind: "ok"; readonly value: T }',
      '  | { readonly kind: "err"; readonly error: E };',
      '',
      'type NexuTask<T> = Readonly<{',
      '  readonly promise: Promise<T>;',
      '  readonly signal: AbortSignal;',
      '  cancel(reason?: string): void;',
      '}>;',
      '',
      'function __nexuOk<T>(value: T): NexuResult<T, never> { return { kind: "ok", value }; }',
      'function __nexuErr<E>(error: E): NexuResult<never, E> { return { kind: "err", error }; }',
      'function __nexuTask<T>(runner: (signal: AbortSignal) => Promise<T> | T): NexuTask<T> {',
      '  const controller = new AbortController();',
      '  const promise = Promise.resolve().then(() => runner(controller.signal));',
      '  return Object.freeze({ promise, signal: controller.signal, cancel: (reason?: string) => controller.abort(reason) });',
      '}',
      'async function __nexuAwait<T>(task: NexuTask<T>, parentSignal?: AbortSignal): Promise<T> {',
      '  if (parentSignal?.aborted) task.cancel("parent-cancelled");',
      '  const relay = () => task.cancel("parent-cancelled");',
      '  parentSignal?.addEventListener("abort", relay, { once: true });',
      '  try { return await task.promise; } finally { parentSignal?.removeEventListener("abort", relay); }',
      '}',
      'function __nexuDelay(milliseconds: number): NexuTask<void> {',
      '  return __nexuTask(signal => new Promise<void>((resolve, reject) => {',
      '    const timer = setTimeout(resolve, milliseconds);',
      '    const stop = () => { clearTimeout(timer); reject(new Error("Nexu task cancelled")); };',
      '    if (signal.aborted) stop(); else signal.addEventListener("abort", stop, { once: true });',
      '  }));',
      '}',
      'function __nexuTimeout<T>(task: NexuTask<T>, milliseconds: number): NexuTask<T> {',
      '  return __nexuTask(async signal => {',
      '    const timer = setTimeout(() => task.cancel("timeout"), milliseconds);',
      '    try { return await __nexuAwait(task, signal); } finally { clearTimeout(timer); }',
      '  });',
      '}',
      'function __nexuCancel<T>(task: NexuTask<T>): void { task.cancel("cancelled"); }',
      'function __nexuAsk(ai: Readonly<{ model: string; fallback?: string; privacy: string }>, prompt: string): NexuTask<NexuResult<string, string>> {',
      '  return __nexuTask(async signal => {',
      '    if (signal.aborted) return __nexuErr("AI request cancelled");',
      '    if (!prompt.trim()) return __nexuErr("AI prompt cannot be empty");',
      '    const routes = ai.fallback ? [ai.model, ai.fallback] : [ai.model];',
      '    let lastError = `No provider adapter is connected for ${ai.model}`;',
      '    for (const route of routes) {',
      '      if (signal.aborted) return __nexuErr("AI request cancelled");',
      '      try {',
      '        const response = await __nexuProviderInvoke(route, "ai.ask", Object.freeze({ model: ai.model, privacy: ai.privacy, prompt }), signal);',
      '        if (typeof response === "string") return __nexuOk(response);',
      '        lastError = `Provider ${route} returned a non-String AI response`;',
      '      } catch (error) { lastError = error instanceof Error ? error.message : String(error); }',
      '    }',
      '    return __nexuErr(lastError);',
      '  });',
      '}',
      ''
    ];
  }
  return [
    'function __nexuOk(value) { return { kind: "ok", value }; }',
    'function __nexuErr(error) { return { kind: "err", error }; }',
    'function __nexuTask(runner) {',
    '  const controller = new AbortController();',
    '  const promise = Promise.resolve().then(() => runner(controller.signal));',
    '  return Object.freeze({ promise, signal: controller.signal, cancel: (reason) => controller.abort(reason) });',
    '}',
    'async function __nexuAwait(task, parentSignal) {',
    '  if (parentSignal?.aborted) task.cancel("parent-cancelled");',
    '  const relay = () => task.cancel("parent-cancelled");',
    '  parentSignal?.addEventListener("abort", relay, { once: true });',
    '  try { return await task.promise; } finally { parentSignal?.removeEventListener("abort", relay); }',
    '}',
    'function __nexuDelay(milliseconds) {',
    '  return __nexuTask(signal => new Promise((resolve, reject) => {',
    '    const timer = setTimeout(resolve, milliseconds);',
    '    const stop = () => { clearTimeout(timer); reject(new Error("Nexu task cancelled")); };',
    '    if (signal.aborted) stop(); else signal.addEventListener("abort", stop, { once: true });',
    '  }));',
    '}',
    'function __nexuTimeout(task, milliseconds) {',
    '  return __nexuTask(async signal => {',
    '    const timer = setTimeout(() => task.cancel("timeout"), milliseconds);',
    '    try { return await __nexuAwait(task, signal); } finally { clearTimeout(timer); }',
    '  });',
    '}',
    'function __nexuCancel(task) { task.cancel("cancelled"); }',
    'function __nexuAsk(ai, prompt) {',
    '  return __nexuTask(async signal => {',
    '    if (signal.aborted) return __nexuErr("AI request cancelled");',
    '    if (!prompt.trim()) return __nexuErr("AI prompt cannot be empty");',
    '    const routes = ai.fallback ? [ai.model, ai.fallback] : [ai.model];',
    '    let lastError = `No provider adapter is connected for ${ai.model}`;',
    '    for (const route of routes) {',
    '      if (signal.aborted) return __nexuErr("AI request cancelled");',
    '      try {',
    '        const response = await __nexuProviderInvoke(route, "ai.ask", Object.freeze({ model: ai.model, privacy: ai.privacy, prompt }), signal);',
    '        if (typeof response === "string") return __nexuOk(response);',
    '        lastError = `Provider ${route} returned a non-String AI response`;',
    '      } catch (error) { lastError = error instanceof Error ? error.message : String(error); }',
    '    }',
    '    return __nexuErr(lastError);',
    '  });',
    '}',
    ''
  ];
}



function uiHasFeature(node, featureId) {
  if (!node) return false;
  if (node.feature === featureId) return true;
  return (node.children ?? []).some(child => uiHasFeature(child, featureId));
}

function serialiseUi(ui) {
  if (!ui) return null;
  const cleanNode = node => ({
    type: node.type,
    name: node.name,
    properties: node.properties,
    feature: node.feature,
    events: (node.events ?? []).map(event => event.name),
    children: (node.children ?? []).map(cleanNode)
  });
  return {
    name: ui.name,
    properties: ui.properties,
    states: (ui.states ?? []).map(state => ({ name: state.name, type: state.type.name, initial: state.initial })),
    events: (ui.events ?? []).map(event => event.name),
    children: (ui.children ?? []).map(cleanNode)
  };
}

function collectUiEvents(ui) {
  const events = [];
  if (!ui) return events;
  for (const event of ui.events ?? []) events.push({ owner: ui.name, event });
  const walk = nodes => {
    for (const node of nodes ?? []) {
      for (const event of node.events ?? []) events.push({ owner: node.name, event });
      walk(node.children);
    }
  };
  walk(ui.children);
  return events;
}

function eventFunctionName(owner, eventName) {
  return `__nexuUiEvent_${owner}_${eventName}`.replace(/[^A-Za-z0-9_]/g, '_');
}

function emitUiRuntime(ui, target) {
  const typePreludeTs = [
    'type NexuUiScalar = string | number | boolean;',
    'type NexuUiNode = Readonly<{',
    '  type: string; name: string; properties: Readonly<Record<string, NexuUiScalar>>;',
    '  feature: string | null; events: ReadonlyArray<string>; children: ReadonlyArray<NexuUiNode>;',
    '}>;',
    'type NexuUiTree = Readonly<{',
    '  name: string; properties: Readonly<Record<string, NexuUiScalar>>;',
    '  states: ReadonlyArray<Readonly<{ name: string; type: string; initial: NexuUiScalar }>>;',
    '  events: ReadonlyArray<string>; children: ReadonlyArray<NexuUiNode>;',
    '}>;',
    'type NexuUiChatBridge = Readonly<{',
    '  send(prompt: string): Promise<NexuResult<string, string>>;',
    '  clear(): void; stop(): void;',
    '  history(): ReadonlyArray<Readonly<{ role: string; content: string; createdAt: number }>>;',
    '}>;',
    'type NexuUiStateStore = Readonly<{',
    '  get<T extends NexuUiScalar>(name: string): T;',
    '  set(name: string, value: NexuUiScalar): void;',
    '  snapshot(): Readonly<Record<string, NexuUiScalar>>;',
    '  subscribe(listener: (name: string, value: NexuUiScalar) => void): () => void;',
    '}>;',
    'type NexuUiEventBridge = Readonly<{',
    '  has(owner: string, event: string): boolean;',
    '  dispatch(owner: string, event: string, payload?: Readonly<Record<string, NexuUiScalar>>): Promise<void>;',
    '}>;',
    'type NexuUiRenderPayload = Readonly<{ tree: NexuUiTree; state: NexuUiStateStore; events: NexuUiEventBridge; activeScreen: string | null; chat?: NexuUiChatBridge }>;',
    ''
  ];
  if (!ui) return target === 'typescript' ? typePreludeTs : [];

  const clean = serialiseUi(ui);
  const tree = JSON.stringify(clean);
  const hasChat = uiHasFeature(ui, 'ai.chat.full');
  const initialState = Object.fromEntries((ui.states ?? []).map(state => [state.name, state.initial]));
  const eventRecords = collectUiEvents(ui);
  const state = { matchCounter: 0 };
  const lines = [];

  if (target === 'typescript') lines.push(...typePreludeTs);
  lines.push(`const __nexuUiTree = Object.freeze(${tree})${target === 'typescript' ? ' as unknown as NexuUiTree' : ''};`);
  lines.push(`const __nexuUiScreenNames = Object.freeze(${JSON.stringify(ui.screens ?? [])}${target === 'typescript' ? ' as readonly string[]' : ''});`);
  lines.push(`let __nexuUiActiveScreen${target === 'typescript' ? ': string | null' : ''} = ${JSON.stringify(ui.properties?.start_screen ?? null)};`);
  lines.push(`let __nexuUiReadyFired = false;`, '');
  if (target === 'typescript') {
    lines.push(
      `const __nexuUiStateValues: Record<string, NexuUiScalar> = { ...${JSON.stringify(initialState)} };`,
      'const __nexuUiStateListeners = new Set<(name: string, value: NexuUiScalar) => void>();',
      'const __nexuUiState: NexuUiStateStore = Object.freeze({',
      '  get: <T extends NexuUiScalar>(name: string): T => { if (!(name in __nexuUiStateValues)) throw new Error(`Unknown Nexu UI state ${name}`); return __nexuUiStateValues[name] as T; },',
      '  set: (name: string, value: NexuUiScalar): void => { if (!(name in __nexuUiStateValues)) throw new Error(`Unknown Nexu UI state ${name}`); __nexuUiStateValues[name] = value; for (const listener of __nexuUiStateListeners) listener(name, value); },',
      '  snapshot: () => Object.freeze({ ...__nexuUiStateValues }),',
      '  subscribe: listener => { __nexuUiStateListeners.add(listener); return () => __nexuUiStateListeners.delete(listener); }',
      '});',
      ''
    );
  } else {
    lines.push(
      `const __nexuUiStateValues = { ...${JSON.stringify(initialState)} };`,
      'const __nexuUiStateListeners = new Set();',
      'const __nexuUiState = Object.freeze({',
      '  get: name => { if (!(name in __nexuUiStateValues)) throw new Error(`Unknown Nexu UI state ${name}`); return __nexuUiStateValues[name]; },',
      '  set: (name, value) => { if (!(name in __nexuUiStateValues)) throw new Error(`Unknown Nexu UI state ${name}`); __nexuUiStateValues[name] = value; for (const listener of __nexuUiStateListeners) listener(name, value); },',
      '  snapshot: () => Object.freeze({ ...__nexuUiStateValues }),',
      '  subscribe: listener => { __nexuUiStateListeners.add(listener); return () => __nexuUiStateListeners.delete(listener); }',
      '});',
      ''
    );
  }

  for (const { owner, event } of eventRecords) {
    const fn = eventFunctionName(owner, event.name);
    const payloadType = target === 'typescript' ? ': Readonly<Record<string, NexuUiScalar>>' : '';
    const returnType = target === 'typescript' ? ': Promise<void>' : '';
    lines.push(`async function ${fn}(payload${payloadType})${returnType} {`);
    for (const param of event.params) {
      if (target === 'typescript') lines.push(`  const ${param.name}: ${emitType(param.type)} = payload[${JSON.stringify(param.name)}] as ${emitType(param.type)};`);
      else lines.push(`  const ${param.name} = payload[${JSON.stringify(param.name)}];`);
    }
    lines.push('  const __nexuEventTask = __nexuTask(async (__nexuSignal) => {');
    lines.push(...emitStatements(event.body, 2, target, state, { signal: '__nexuSignal' }));
    lines.push('  });');
    lines.push('  await __nexuAwait(__nexuEventTask);');
    lines.push('}', '');
  }

  const eventCases = eventRecords.map(({ owner, event }) => ({ owner, name: event.name, fn: eventFunctionName(owner, event.name) }));
  if (target === 'typescript') {
    lines.push(
      `const __nexuUiEventKeys = new Set<string>(${JSON.stringify(eventCases.map(x => `${x.owner}:${x.name}`))});`,
      'const __nexuUiEvents: NexuUiEventBridge = Object.freeze({',
      '  has: (owner, event) => __nexuUiEventKeys.has(`${owner}:${event}`),',
      '  dispatch: async (owner, event, payload = {}) => {',
      '    const key = `${owner}:${event}`;',
      '    switch (key) {'
    );
    for (const item of eventCases) lines.push(`      case ${JSON.stringify(`${item.owner}:${item.name}`)}: await ${item.fn}(payload); return;`);
    lines.push('      default: throw new Error(`Unknown Nexu UI event ${key}`);', '    }', '  }', '});', '');
  } else {
    lines.push(
      `const __nexuUiEventKeys = new Set(${JSON.stringify(eventCases.map(x => `${x.owner}:${x.name}`))});`,
      'const __nexuUiEvents = Object.freeze({',
      '  has: (owner, event) => __nexuUiEventKeys.has(`${owner}:${event}`),',
      '  dispatch: async (owner, event, payload = {}) => { const key = `${owner}:${event}`; switch (key) {'
    );
    for (const item of eventCases) lines.push(`      case ${JSON.stringify(`${item.owner}:${item.name}`)}: await ${item.fn}(payload); return;`);
    lines.push('      default: throw new Error(`Unknown Nexu UI event ${key}`); } }', '});', '');
  }

  lines.push(`async function __nexuRenderUi()${target === 'typescript' ? ': Promise<void>' : ''} {`);
  if (hasChat) {
    if (target === 'typescript') {
      lines.push(
        '  const chat: NexuUiChatBridge = Object.freeze({',
        '    send: async (prompt: string) => await __nexuAwait(__nexuAiChatFull.send(prompt)),',
        '    clear: () => __nexuAiChatFull.clear(),',
        '    stop: () => __nexuAiChatFull.stop(),',
        '    history: () => __nexuAiChatFull.history()',
        '  });',
        '  await __nexuHostInvoke("ui.render", "ui.render", Object.freeze({ tree: __nexuUiTree, state: __nexuUiState, events: __nexuUiEvents, activeScreen: __nexuUiActiveScreen, chat } satisfies NexuUiRenderPayload));'
      );
    } else {
      lines.push(
        '  const chat = Object.freeze({ send: async prompt => await __nexuAwait(__nexuAiChatFull.send(prompt)), clear: () => __nexuAiChatFull.clear(), stop: () => __nexuAiChatFull.stop(), history: () => __nexuAiChatFull.history() });',
        '  await __nexuHostInvoke("ui.render", "ui.render", Object.freeze({ tree: __nexuUiTree, state: __nexuUiState, events: __nexuUiEvents, activeScreen: __nexuUiActiveScreen, chat }));'
      );
    }
  } else {
    lines.push(`  await __nexuHostInvoke("ui.render", "ui.render", Object.freeze({ tree: __nexuUiTree, state: __nexuUiState, events: __nexuUiEvents, activeScreen: __nexuUiActiveScreen }${target === 'typescript' ? ' satisfies NexuUiRenderPayload' : ''}));`);
  }
  if ((ui.events ?? []).some(event => event.name === 'ready')) lines.push(`  if (!__nexuUiReadyFired) { __nexuUiReadyFired = true; await __nexuUiEvents.dispatch(${JSON.stringify(ui.name)}, "ready", {}); }`);
  lines.push('}', '');
  lines.push(`async function __nexuNavigate(name${target === 'typescript' ? ': string' : ''})${target === 'typescript' ? ': Promise<void>' : ''} { if (!__nexuUiScreenNames.includes(name)) throw new Error(\`Unknown Nexu screen \${name}\`); if (__nexuUiActiveScreen === name) return; __nexuUiActiveScreen = name; await __nexuRenderUi(); }`, '');
  return lines;
}

function emitHostRuntime(host, target) {
  const contract = host ? JSON.stringify({ name: host.name, adapter: host.adapter, environment: host.environment, provides: host.provides }) : 'null';
  if (target === 'typescript') {
    return [
      'type NexuHostPolicy = "allow" | "confirm" | "deny";',
      'type NexuHostRequest = Readonly<{ capability: string; operation: string; payload: unknown; signal?: AbortSignal }>;',
      'type NexuHostAdapter = Readonly<{ id: string; capabilities: ReadonlyArray<string>; approve?(request: NexuHostRequest): boolean | Promise<boolean>; invoke(request: NexuHostRequest): unknown | Promise<unknown>; }>;',
      `const __nexuHostContract = ${contract === 'null' ? 'null' : `Object.freeze(${contract})`} as null | Readonly<{ name: string; adapter: string; environment: string; provides: ReadonlyArray<string> }>;`,
      'function __nexuConsoleOutline(tree: NexuUiTree, activeScreen: string | null): string { const parts: string[] = []; const walk = (nodes: ReadonlyArray<NexuUiNode>) => { for (const node of nodes) { if (node.type === "screen" && activeScreen && node.name !== activeScreen) continue; parts.push(`${node.type} ${node.name}${node.feature ? `[${node.feature}]` : ""}`); walk(node.children); } }; walk(tree.children); return `UI ${tree.name}: ${parts.join(" | ")}`; }',
      'function __nexuNodeStorage(operation: string, payload: Readonly<{ scope?: string; key?: string; value?: unknown }>): unknown { const gp = globalThis as typeof globalThis & { process?: { cwd?: () => string; getBuiltinModule?: (id: string) => unknown } }; const proc = gp.process; if (!proc?.cwd || !proc.getBuiltinModule) throw new Error("console.preview storage.local requires Node.js"); const fs = proc.getBuiltinModule("fs") as { existsSync(path: string): boolean; mkdirSync(path: string, options?: { recursive?: boolean }): void; readFileSync(path: string, encoding: string): string; writeFileSync(path: string, data: string, encoding: string): void; renameSync(oldPath: string, newPath: string): void }; const safe = (value: string) => value.replace(/[^A-Za-z0-9_.-]/g, "_"); const dir = `${proc.cwd()}/.nexu-data`; fs.mkdirSync(dir, { recursive: true }); const file = `${dir}/${safe(String(payload.scope ?? "app"))}-${safe(String(payload.key ?? "state"))}.json`; if (operation === "storage.read") { if (!fs.existsSync(file)) return undefined; return JSON.parse(fs.readFileSync(file, "utf8")); } if (operation === "storage.write") { const temp = `${file}.tmp`; fs.writeFileSync(temp, JSON.stringify(payload.value), "utf8"); fs.renameSync(temp, file); return; } throw new Error(`console.preview storage cannot execute ${operation}`); }',
      'function __nexuCreateConsolePreviewAdapter(): NexuHostAdapter { return Object.freeze({ id: "console.preview", capabilities: Object.freeze(["ui.render", "ui.confirm", "ui.focus", "storage.local"]), approve: () => false, invoke: request => { if (request.operation === "ui.render") { const payload = request.payload as NexuUiRenderPayload; console.log(__nexuConsoleOutline(payload.tree, payload.activeScreen)); return; } if (request.operation === "ui.confirm") { const payload = request.payload as Readonly<{ message?: string }>; console.log(`CONFIRMATION REQUIRED (denied by console.preview): ${payload.message ?? "Nexu operation"}`); return false; } if (request.operation === "ui.focus") { const payload = request.payload as Readonly<{ name?: string }>; console.log(`FOCUS ${payload.name ?? "unknown"}`); return; } if (request.operation === "storage.read" || request.operation === "storage.write") return __nexuNodeStorage(request.operation, request.payload as Readonly<{ scope?: string; key?: string; value?: unknown }>); throw new Error(`console.preview cannot execute ${request.operation}`); } }); }',
      'function __nexuCreateWebDomAdapter(): NexuHostAdapter { return Object.freeze({ id: "web.dom", capabilities: Object.freeze(["ui.render", "ui.confirm", "ui.focus", "storage.local"]), approve: () => false, invoke: async request => { if (request.operation === "ui.confirm") { const data = request.payload as Readonly<{ message?: string }>; return typeof globalThis.confirm === "function" ? globalThis.confirm(data.message ?? "Allow this Nexu operation?") : false; } if (request.operation === "ui.focus") { if (typeof document === "undefined") throw new Error("web.dom host requires a browser DOM"); const data = request.payload as Readonly<{ name?: string }>; const target = Array.from(document.querySelectorAll<HTMLElement>("[data-nexu-name]")).find(el => el.dataset.nexuName === data.name); if (!target) throw new Error(`Unknown DOM focus target ${data.name ?? ""}`); target.focus(); return; } if (request.operation === "storage.read" || request.operation === "storage.write") { if (typeof localStorage === "undefined") throw new Error("web.dom storage.local requires localStorage"); const data = request.payload as Readonly<{ scope?: string; key?: string; value?: unknown }>; const key = `nexu:${String(data.scope ?? "app")}:${String(data.key ?? "state")}`; if (request.operation === "storage.read") { const raw = localStorage.getItem(key); return raw === null ? undefined : JSON.parse(raw); } localStorage.setItem(key, JSON.stringify(data.value)); return; } if (request.operation !== "ui.render") throw new Error(`web.dom cannot execute ${request.operation}`); if (typeof document === "undefined") throw new Error("web.dom host requires a browser DOM"); const payload = request.payload as NexuUiRenderPayload; const old = document.querySelector(`[data-nexu-root="${payload.tree.name}"]`) as (HTMLElement & { __nexuDispose?: () => void }) | null; old?.__nexuDispose?.(); old?.remove(); const root = document.createElement("main") as HTMLElement & { __nexuDispose?: () => void }; root.dataset.nexuRoot = payload.tree.name; root.dataset.nexuLayout = String(payload.tree.properties.layout ?? "stack"); root.setAttribute("aria-label", String(payload.tree.properties.title ?? payload.tree.name)); const refreshBoundState = (name: string, value: NexuUiScalar) => { for (const el of Array.from(root.querySelectorAll<HTMLElement>(`[data-nexu-bind="${name}"]`))) el.textContent = String(value); }; const renderNode = (node: NexuUiNode): HTMLElement => { if (node.type === "text") { const el = document.createElement("p"); el.dataset.nexuNode = node.type; el.dataset.nexuName = node.name; const bind = typeof node.properties.bind === "string" ? node.properties.bind : null; if (bind) { el.dataset.nexuBind = bind; el.textContent = String(payload.state.get(bind)); } else el.textContent = String(node.properties.label ?? node.name); if (typeof node.properties.aria_label === "string") el.setAttribute("aria-label", node.properties.aria_label); if (node.properties.focusable === true) el.tabIndex = 0; return el; } if (node.type === "button") { const el = document.createElement("button"); el.type = "button"; el.dataset.nexuNode = node.type; el.dataset.nexuName = node.name; el.textContent = String(node.properties.label ?? node.name); el.disabled = node.properties.disabled === true; el.setAttribute("aria-label", String(node.properties.aria_label ?? node.properties.label ?? node.name)); if (payload.events.has(node.name, "click")) el.addEventListener("click", () => { void payload.events.dispatch(node.name, "click", {}); }); return el; } if (node.type === "input") { const wrap = document.createElement("label"); wrap.dataset.nexuNode = node.type; const caption = document.createElement("span"); caption.textContent = String(node.properties.label ?? node.name); const input = document.createElement("input"); input.dataset.nexuName = node.name; input.type = "text"; input.placeholder = String(node.properties.placeholder ?? ""); input.setAttribute("aria-label", String(node.properties.aria_label ?? node.properties.label ?? node.name)); if (payload.events.has(node.name, "change")) input.addEventListener("input", () => { void payload.events.dispatch(node.name, "change", { value: input.value }); }); if (payload.events.has(node.name, "submit")) input.addEventListener("keydown", event => { if (event.key === "Enter") void payload.events.dispatch(node.name, "submit", { value: input.value }); }); wrap.append(caption, input); return wrap; } const element = document.createElement(node.type === "sidebar" || node.type === "dock" ? "aside" : "section"); element.dataset.nexuNode = node.type; element.dataset.nexuName = node.name; if (typeof node.properties.width === "number") element.style.width = `${node.properties.width}px`; if (node.properties.hidden === true || (node.type === "screen" && payload.activeScreen && node.name !== payload.activeScreen)) element.hidden = true; if (typeof node.properties.aria_label === "string") element.setAttribute("aria-label", node.properties.aria_label); if (node.properties.focusable === true || node.type === "chat") element.tabIndex = 0; const heading = document.createElement("h2"); heading.textContent = String(node.properties.label ?? node.name); element.appendChild(heading); if (node.type === "chat" && payload.chat) { const log = document.createElement("div"); log.setAttribute("aria-live", "polite"); const input = document.createElement("textarea"); input.rows = 3; input.placeholder = String(node.properties.placeholder ?? "Message Nexu AI"); input.setAttribute("aria-label", input.placeholder); const send = document.createElement("button"); send.type = "button"; send.textContent = "Send"; const clear = document.createElement("button"); clear.type = "button"; clear.textContent = "Clear"; const stop = document.createElement("button"); stop.type = "button"; stop.textContent = "Stop"; const refresh = () => { log.replaceChildren(); for (const message of payload.chat?.history() ?? []) { const item = document.createElement("p"); item.textContent = `${message.role}: ${message.content}`; log.appendChild(item); } }; send.addEventListener("click", async () => { const prompt = input.value.trim(); if (!prompt) return; send.disabled = true; try { if (payload.events.has(node.name, "send")) await payload.events.dispatch(node.name, "send", { message: prompt }); else await payload.chat!.send(prompt); input.value = ""; refresh(); } finally { send.disabled = false; } }); clear.addEventListener("click", async () => { if (payload.events.has(node.name, "clear")) await payload.events.dispatch(node.name, "clear", {}); else payload.chat!.clear(); refresh(); }); stop.addEventListener("click", async () => { if (payload.events.has(node.name, "stop")) await payload.events.dispatch(node.name, "stop", {}); else payload.chat!.stop(); }); element.append(log, input, send, stop, clear); } for (const child of node.children) element.appendChild(renderNode(child)); return element; }; for (const child of payload.tree.children) root.appendChild(renderNode(child)); const unsubscribe = payload.state.subscribe(refreshBoundState); root.__nexuDispose = unsubscribe; document.body.appendChild(root); } }); }',
      'function __nexuResolveHostAdapter(): NexuHostAdapter | null { if (!__nexuHostContract) return null; if (__nexuHostContract.adapter === "console.preview") return __nexuCreateConsolePreviewAdapter(); if (__nexuHostContract.adapter === "web.dom") return __nexuCreateWebDomAdapter(); return null; }',
      'async function __nexuHostConfirm(message: string, signal?: AbortSignal): Promise<boolean> { if (signal?.aborted || !__nexuHostContract || !__nexuHostContract.provides.includes("ui.confirm")) return false; const adapter = __nexuResolveHostAdapter(); if (!adapter || !adapter.capabilities.includes("ui.confirm")) return false; const result = await adapter.invoke(Object.freeze({ capability: "ui.confirm", operation: "ui.confirm", payload: Object.freeze({ message }), signal })); return result === true; }',
      'async function __nexuHostInvoke(capability: string, operation: string, payload: unknown, signal?: AbortSignal): Promise<unknown> { const policy = (__nexuCapabilities as Readonly<Record<string, NexuHostPolicy>>)[capability]; if (!policy) throw new Error(`Host operation ${operation} requires undeclared capability ${capability}`); if (policy === "deny") throw new Error(`Host operation ${operation} is denied by capability ${capability}`); if (!__nexuHostContract) throw new Error(`No host contract is connected for ${operation}`); if (!__nexuHostContract.provides.includes(capability)) throw new Error(`Host ${__nexuHostContract.name} does not provide ${capability}`); const adapter = __nexuResolveHostAdapter(); if (!adapter) throw new Error(`Host adapter ${__nexuHostContract.adapter} is unavailable`); if (!adapter.capabilities.includes(capability)) throw new Error(`Host adapter ${adapter.id} does not implement ${capability}`); const request: NexuHostRequest = Object.freeze({ capability, operation, payload, signal }); if (policy === "confirm") { if (!adapter.approve || !(await adapter.approve(request))) throw new Error(`Host approval was not granted for ${operation}`); } if (signal?.aborted) throw new Error(`Host operation ${operation} was cancelled`); return await adapter.invoke(request); }',
      ''
    ];
  }
  return [
    `const __nexuHostContract = ${contract === 'null' ? 'null' : `Object.freeze(${contract})`};`,
    'function __nexuConsoleOutline(tree, activeScreen) { const parts = []; const walk = nodes => { for (const node of nodes) { if (node.type === "screen" && activeScreen && node.name !== activeScreen) continue; parts.push(`${node.type} ${node.name}${node.feature ? `[${node.feature}]` : ""}`); walk(node.children); } }; walk(tree.children); return `UI ${tree.name}: ${parts.join(" | ")}`; }',
    'function __nexuNodeStorage(operation, payload) { const proc = globalThis.process; if (!proc?.cwd || !proc?.getBuiltinModule) throw new Error("console.preview storage.local requires Node.js"); const fs = proc.getBuiltinModule("fs"); const safe = value => value.replace(/[^A-Za-z0-9_.-]/g, "_"); const dir = `${proc.cwd()}/.nexu-data`; fs.mkdirSync(dir, { recursive: true }); const file = `${dir}/${safe(String(payload.scope ?? "app"))}-${safe(String(payload.key ?? "state"))}.json`; if (operation === "storage.read") { if (!fs.existsSync(file)) return undefined; return JSON.parse(fs.readFileSync(file, "utf8")); } if (operation === "storage.write") { const temp = `${file}.tmp`; fs.writeFileSync(temp, JSON.stringify(payload.value), "utf8"); fs.renameSync(temp, file); return; } throw new Error(`console.preview storage cannot execute ${operation}`); }',
    'function __nexuCreateConsolePreviewAdapter() { return Object.freeze({ id: "console.preview", capabilities: Object.freeze(["ui.render", "ui.confirm", "ui.focus", "storage.local"]), approve: () => false, invoke: request => { if (request.operation === "ui.render") { console.log(__nexuConsoleOutline(request.payload.tree, request.payload.activeScreen)); return; } if (request.operation === "ui.confirm") { console.log(`CONFIRMATION REQUIRED (denied by console.preview): ${request.payload.message ?? "Nexu operation"}`); return false; } if (request.operation === "ui.focus") { console.log(`FOCUS ${request.payload.name ?? "unknown"}`); return; } if (request.operation === "storage.read" || request.operation === "storage.write") return __nexuNodeStorage(request.operation, request.payload); throw new Error(`console.preview cannot execute ${request.operation}`); } }); }',
    'function __nexuCreateWebDomAdapter() { return Object.freeze({ id: "web.dom", capabilities: Object.freeze(["ui.render", "ui.confirm", "ui.focus", "storage.local"]), approve: () => false, invoke: async request => { if (request.operation === "ui.confirm") return typeof globalThis.confirm === "function" ? globalThis.confirm(request.payload.message ?? "Allow this Nexu operation?") : false; if (request.operation === "ui.focus") { const target = Array.from(document.querySelectorAll("[data-nexu-name]")).find(el => el.dataset.nexuName === request.payload.name); if (!target) throw new Error(`Unknown DOM focus target ${request.payload.name ?? ""}`); target.focus(); return; } if (request.operation === "storage.read" || request.operation === "storage.write") { const key = `nexu:${String(request.payload.scope ?? "app")}:${String(request.payload.key ?? "state")}`; if (request.operation === "storage.read") { const raw = localStorage.getItem(key); return raw === null ? undefined : JSON.parse(raw); } localStorage.setItem(key, JSON.stringify(request.payload.value)); return; } if (request.operation !== "ui.render") throw new Error(`web.dom cannot execute ${request.operation}`); if (typeof document === "undefined") throw new Error("web.dom host requires a browser DOM"); const payload = request.payload; const old = document.querySelector(`[data-nexu-root="${payload.tree.name}"]`); old?.__nexuDispose?.(); old?.remove(); const root = document.createElement("main"); root.dataset.nexuRoot = payload.tree.name; root.dataset.nexuLayout = String(payload.tree.properties.layout ?? "stack"); root.setAttribute("aria-label", String(payload.tree.properties.title ?? payload.tree.name)); const refreshBoundState = (name, value) => { for (const el of root.querySelectorAll(`[data-nexu-bind="${name}"]`)) el.textContent = String(value); }; const renderNode = node => { if (node.type === "text") { const el = document.createElement("p"); el.dataset.nexuNode = node.type; el.dataset.nexuName = node.name; const bind = typeof node.properties.bind === "string" ? node.properties.bind : null; if (bind) { el.dataset.nexuBind = bind; el.textContent = String(payload.state.get(bind)); } else el.textContent = String(node.properties.label ?? node.name); if (node.properties.aria_label) el.setAttribute("aria-label", String(node.properties.aria_label)); if (node.properties.focusable === true) el.tabIndex = 0; return el; } if (node.type === "button") { const el = document.createElement("button"); el.type = "button"; el.dataset.nexuName = node.name; el.textContent = String(node.properties.label ?? node.name); el.disabled = node.properties.disabled === true; el.setAttribute("aria-label", String(node.properties.aria_label ?? node.properties.label ?? node.name)); if (payload.events.has(node.name, "click")) el.addEventListener("click", () => void payload.events.dispatch(node.name, "click", {})); return el; } if (node.type === "input") { const wrap = document.createElement("label"); const caption = document.createElement("span"); caption.textContent = String(node.properties.label ?? node.name); const input = document.createElement("input"); input.dataset.nexuName = node.name; input.type = "text"; input.placeholder = String(node.properties.placeholder ?? ""); input.setAttribute("aria-label", String(node.properties.aria_label ?? node.properties.label ?? node.name)); if (payload.events.has(node.name, "change")) input.addEventListener("input", () => void payload.events.dispatch(node.name, "change", { value: input.value })); if (payload.events.has(node.name, "submit")) input.addEventListener("keydown", event => { if (event.key === "Enter") void payload.events.dispatch(node.name, "submit", { value: input.value }); }); wrap.append(caption, input); return wrap; } const element = document.createElement(node.type === "sidebar" || node.type === "dock" ? "aside" : "section"); element.dataset.nexuName = node.name; if (typeof node.properties.width === "number") element.style.width = `${node.properties.width}px`; if (node.properties.hidden === true || (node.type === "screen" && payload.activeScreen && node.name !== payload.activeScreen)) element.hidden = true; if (node.properties.aria_label) element.setAttribute("aria-label", String(node.properties.aria_label)); if (node.properties.focusable === true || node.type === "chat") element.tabIndex = 0; const heading = document.createElement("h2"); heading.textContent = String(node.properties.label ?? node.name); element.appendChild(heading); if (node.type === "chat" && payload.chat) { const log = document.createElement("div"); log.setAttribute("aria-live", "polite"); const input = document.createElement("textarea"); input.rows = 3; input.placeholder = String(node.properties.placeholder ?? "Message Nexu AI"); input.setAttribute("aria-label", input.placeholder); const send = document.createElement("button"); send.type = "button"; send.textContent = "Send"; const clear = document.createElement("button"); clear.type = "button"; clear.textContent = "Clear"; const stop = document.createElement("button"); stop.type = "button"; stop.textContent = "Stop"; const refresh = () => { log.replaceChildren(); for (const message of payload.chat.history()) { const item = document.createElement("p"); item.textContent = `${message.role}: ${message.content}`; log.appendChild(item); } }; send.addEventListener("click", async () => { const prompt = input.value.trim(); if (!prompt) return; send.disabled = true; try { if (payload.events.has(node.name, "send")) await payload.events.dispatch(node.name, "send", { message: prompt }); else await payload.chat.send(prompt); input.value = ""; refresh(); } finally { send.disabled = false; } }); clear.addEventListener("click", async () => { if (payload.events.has(node.name, "clear")) await payload.events.dispatch(node.name, "clear", {}); else payload.chat.clear(); refresh(); }); stop.addEventListener("click", async () => { if (payload.events.has(node.name, "stop")) await payload.events.dispatch(node.name, "stop", {}); else payload.chat.stop(); }); element.append(log, input, send, stop, clear); } for (const child of node.children) element.appendChild(renderNode(child)); return element; }; for (const child of payload.tree.children) root.appendChild(renderNode(child)); const unsubscribe = payload.state.subscribe(refreshBoundState); root.__nexuDispose = unsubscribe; document.body.appendChild(root); } }); }',
    'function __nexuResolveHostAdapter() { if (!__nexuHostContract) return null; if (__nexuHostContract.adapter === "console.preview") return __nexuCreateConsolePreviewAdapter(); if (__nexuHostContract.adapter === "web.dom") return __nexuCreateWebDomAdapter(); return null; }',
    'async function __nexuHostConfirm(message, signal) { if (signal?.aborted || !__nexuHostContract || !__nexuHostContract.provides.includes("ui.confirm")) return false; const adapter = __nexuResolveHostAdapter(); if (!adapter || !adapter.capabilities.includes("ui.confirm")) return false; return (await adapter.invoke(Object.freeze({ capability: "ui.confirm", operation: "ui.confirm", payload: Object.freeze({ message }), signal }))) === true; }',
    'async function __nexuHostInvoke(capability, operation, payload, signal) { const policy = __nexuCapabilities[capability]; if (!policy) throw new Error(`Host operation ${operation} requires undeclared capability ${capability}`); if (policy === "deny") throw new Error(`Host operation ${operation} is denied by capability ${capability}`); if (!__nexuHostContract) throw new Error(`No host contract is connected for ${operation}`); if (!__nexuHostContract.provides.includes(capability)) throw new Error(`Host ${__nexuHostContract.name} does not provide ${capability}`); const adapter = __nexuResolveHostAdapter(); if (!adapter) throw new Error(`Host adapter ${__nexuHostContract.adapter} is unavailable`); if (!adapter.capabilities.includes(capability)) throw new Error(`Host adapter ${adapter.id} does not implement ${capability}`); const request = Object.freeze({ capability, operation, payload, signal }); if (policy === "confirm") { if (!adapter.approve || !(await adapter.approve(request))) throw new Error(`Host approval was not granted for ${operation}`); } if (signal?.aborted) throw new Error(`Host operation ${operation} was cancelled`); return await adapter.invoke(request); }',
    ''
  ];
}
function emitProviderRuntime(providers, target) {
  const contracts = (providers ?? []).map(provider => ({
    name: provider.name,
    adapter: provider.adapter,
    environment: provider.environment,
    route: provider.route,
    operation: provider.operation,
    testOnly: provider.testOnly,
    config: provider.config,
    requirements: provider.requirements.map(x => ({ path: x.path, policy: x.policy }))
  }));
  const json = JSON.stringify(contracts);
  if (target === 'typescript') {
    return [
      'type NexuProviderContract = Readonly<{ name: string; adapter: string; environment: string; route: string; operation: string; testOnly: boolean; config: Readonly<Record<string, unknown>>; requirements: ReadonlyArray<Readonly<{ path: string; policy: NexuHostPolicy }>> }>;',
      `const __nexuProviderContracts = Object.freeze(${json}) as unknown as ReadonlyArray<NexuProviderContract>;`,
      'function __nexuProviderContract(route: string): NexuProviderContract | null { return __nexuProviderContracts.find(provider => provider.route === route) ?? null; }',
      'function __nexuExtractOpenAiText(payload: unknown): string { const data = payload as { output?: Array<{ type?: string; content?: Array<{ type?: string; text?: string }> }> }; const parts: string[] = []; for (const item of data.output ?? []) { if (item.type !== "message") continue; for (const content of item.content ?? []) if (content.type === "output_text" && typeof content.text === "string") parts.push(content.text); } return parts.join("\\n"); }',
      'async function __nexuInvokeProviderAdapter(contract: NexuProviderContract, operation: string, payload: Readonly<Record<string, unknown>>, signal?: AbortSignal): Promise<unknown> {',
      '  if (operation !== contract.operation) throw new Error(`Provider ${contract.name} cannot execute ${operation}`);',
      '  if (contract.adapter === "test.echo") return `${String(contract.config.prefix ?? "Echo")}: ${String(payload.prompt ?? "")}`;',
      '  if (contract.adapter === "ollama.chat") { const baseUrl = String(contract.config.base_url ?? "http://127.0.0.1:11434"); const model = String(contract.config.model ?? "qwen3:8b"); if (/(?:^|[:_-])cloud(?:$|[:_-])/i.test(model)) throw new Error(`Ollama cloud model ${model} is blocked by this local provider contract`); const response = await fetch(`${baseUrl}/api/chat`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model, messages: [{ role: "user", content: String(payload.prompt ?? "") }], stream: false }), signal }); if (!response.ok) throw new Error(`Ollama chat failed with HTTP ${response.status}`); const body = await response.json() as { message?: { content?: string } }; const text = body.message?.content; if (typeof text !== "string" || !text.length) throw new Error("Ollama chat returned no message content"); return text; }',
      '  if (contract.adapter === "openai.responses") {',
      '    const globalWithProcess = globalThis as typeof globalThis & { process?: { env?: Record<string, string | undefined> } }; const keyName = String(contract.config.key_env ?? "OPENAI_API_KEY"); const apiKey = globalWithProcess.process?.env?.[keyName]; if (!apiKey) throw new Error(`OpenAI provider ${contract.name} requires environment variable ${keyName}`);',
      '    const response = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` }, body: JSON.stringify({ model: String(contract.config.model ?? "gpt-5.6"), input: String(payload.prompt ?? "") }), signal });',
      '    if (!response.ok) throw new Error(`OpenAI Responses API failed with HTTP ${response.status}`); const body: unknown = await response.json(); const text = __nexuExtractOpenAiText(body); if (!text) throw new Error("OpenAI Responses API returned no output_text content"); return text;',
      '  }',
      '  throw new Error(`Provider adapter ${contract.adapter} is unavailable`);',
      '}',
      'async function __nexuProviderInvoke(route: string, operation: string, payload: Readonly<Record<string, unknown>>, signal?: AbortSignal): Promise<unknown> {',
      '  const contract = __nexuProviderContract(route); if (!contract) throw new Error(`No provider adapter is connected for route ${route}`); if (signal?.aborted) throw new Error(`Provider operation ${operation} was cancelled`);',
      '  for (const requirement of contract.requirements) { const policy = (__nexuCapabilities as Readonly<Record<string, NexuHostPolicy>>)[requirement.path]; if (!policy) throw new Error(`Provider ${contract.name} requires undeclared capability ${requirement.path}`); if (policy === "deny") throw new Error(`Provider ${contract.name} is denied by capability ${requirement.path}`); if (policy === "confirm") { const approved = await __nexuHostConfirm(`Allow ${contract.name} to use ${requirement.path} for ${operation}?`, signal); if (!approved) throw new Error(`Provider approval was not granted for ${contract.name}`); } }',
      '  return await __nexuInvokeProviderAdapter(contract, operation, payload, signal);',
      '}',
      ''
    ];
  }
  return [
    `const __nexuProviderContracts = Object.freeze(${json});`,
    'function __nexuProviderContract(route) { return __nexuProviderContracts.find(provider => provider.route === route) ?? null; }',
    'function __nexuExtractOpenAiText(payload) { const parts = []; for (const item of payload?.output ?? []) { if (item?.type !== "message") continue; for (const content of item.content ?? []) if (content?.type === "output_text" && typeof content.text === "string") parts.push(content.text); } return parts.join("\\n"); }',
    'async function __nexuInvokeProviderAdapter(contract, operation, payload, signal) { if (operation !== contract.operation) throw new Error(`Provider ${contract.name} cannot execute ${operation}`); if (contract.adapter === "test.echo") return `${String(contract.config.prefix ?? "Echo")}: ${String(payload.prompt ?? "")}`; if (contract.adapter === "ollama.chat") { const baseUrl = String(contract.config.base_url ?? "http://127.0.0.1:11434"); const model = String(contract.config.model ?? "qwen3:8b"); if (/(?:^|[:_-])cloud(?:$|[:_-])/i.test(model)) throw new Error(`Ollama cloud model ${model} is blocked by this local provider contract`); const response = await fetch(`${baseUrl}/api/chat`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model, messages: [{ role: "user", content: String(payload.prompt ?? "") }], stream: false }), signal }); if (!response.ok) throw new Error(`Ollama chat failed with HTTP ${response.status}`); const body = await response.json(); const text = body?.message?.content; if (typeof text !== "string" || !text.length) throw new Error("Ollama chat returned no message content"); return text; } if (contract.adapter === "openai.responses") { const keyName = String(contract.config.key_env ?? "OPENAI_API_KEY"); const apiKey = globalThis.process?.env?.[keyName]; if (!apiKey) throw new Error(`OpenAI provider ${contract.name} requires environment variable ${keyName}`); const response = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` }, body: JSON.stringify({ model: String(contract.config.model ?? "gpt-5.6"), input: String(payload.prompt ?? "") }), signal }); if (!response.ok) throw new Error(`OpenAI Responses API failed with HTTP ${response.status}`); const text = __nexuExtractOpenAiText(await response.json()); if (!text) throw new Error("OpenAI Responses API returned no output_text content"); return text; } throw new Error(`Provider adapter ${contract.adapter} is unavailable`); }',
    'async function __nexuProviderInvoke(route, operation, payload, signal) { const contract = __nexuProviderContract(route); if (!contract) throw new Error(`No provider adapter is connected for route ${route}`); if (signal?.aborted) throw new Error(`Provider operation ${operation} was cancelled`); for (const requirement of contract.requirements) { const policy = __nexuCapabilities[requirement.path]; if (!policy) throw new Error(`Provider ${contract.name} requires undeclared capability ${requirement.path}`); if (policy === "deny") throw new Error(`Provider ${contract.name} is denied by capability ${requirement.path}`); if (policy === "confirm") { const approved = await __nexuHostConfirm(`Allow ${contract.name} to use ${requirement.path} for ${operation}?`, signal); if (!approved) throw new Error(`Provider approval was not granted for ${contract.name}`); } } return await __nexuInvokeProviderAdapter(contract, operation, payload, signal); }',
    ''
  ];
}

function emitStoreRuntime(stores, appName, target) {
  if (!stores?.size) return [];
  const serialisable = Object.fromEntries([...stores].map(([name, store]) => [name, {
    persistence: store.persistence,
    states: Object.fromEntries([...store.states].map(([key, state]) => [key, { type: state.type.name, initial: state.initial }]))
  }]));
  const schema = JSON.stringify(serialisable);
  const scopePrefix = JSON.stringify(appName);
  if (target === 'typescript') {
    return [
      'type NexuStoreScalar = string | number | boolean;',
      'type NexuStoreSchema = Readonly<Record<string, Readonly<{ persistence: string; states: Readonly<Record<string, Readonly<{ type: string; initial: NexuStoreScalar }>>> }>>>;',
      `const __nexuStores = Object.freeze(${schema}) as NexuStoreSchema;`,
      `const __nexuStoreScopePrefix = ${scopePrefix};`,
      'function __nexuStoreState(store: string, key: string): Readonly<{ type: string; initial: NexuStoreScalar }> { const schema = __nexuStores[store]; if (!schema) throw new Error(`Unknown Nexu store ${store}`); const state = schema.states[key]; if (!state) throw new Error(`Unknown Nexu store state ${store}.${key}`); return state; }',
      'function __nexuStoreValueMatches(type: string, value: unknown): value is NexuStoreScalar { return (type === "String" && typeof value === "string") || (type === "Number" && typeof value === "number" && Number.isFinite(value)) || (type === "Bool" && typeof value === "boolean"); }',
      'function __nexuStoreLoad<T extends NexuStoreScalar>(store: string, key: string): NexuTask<T> { return __nexuTask(async signal => { const state = __nexuStoreState(store, key); const value = await __nexuHostInvoke("storage.local", "storage.read", Object.freeze({ scope: `${__nexuStoreScopePrefix}:${store}`, key }), signal); if (value === undefined) return state.initial as T; if (!__nexuStoreValueMatches(state.type, value)) throw new Error(`Persisted Nexu store value ${store}.${key} does not match ${state.type}`); return value as T; }); }',
      'function __nexuStoreSave(store: string, key: string, value: NexuStoreScalar): NexuTask<void> { return __nexuTask(async signal => { const state = __nexuStoreState(store, key); if (!__nexuStoreValueMatches(state.type, value)) throw new Error(`Nexu store write ${store}.${key} does not match ${state.type}`); await __nexuHostInvoke("storage.local", "storage.write", Object.freeze({ scope: `${__nexuStoreScopePrefix}:${store}`, key, value }), signal); }); }',
      ''
    ];
  }
  return [
    `const __nexuStores = Object.freeze(${schema});`,
    `const __nexuStoreScopePrefix = ${scopePrefix};`,
    'function __nexuStoreState(store, key) { const schema = __nexuStores[store]; if (!schema) throw new Error(`Unknown Nexu store ${store}`); const state = schema.states[key]; if (!state) throw new Error(`Unknown Nexu store state ${store}.${key}`); return state; }',
    'function __nexuStoreValueMatches(type, value) { return (type === "String" && typeof value === "string") || (type === "Number" && typeof value === "number" && Number.isFinite(value)) || (type === "Bool" && typeof value === "boolean"); }',
    'function __nexuStoreLoad(store, key) { return __nexuTask(async signal => { const state = __nexuStoreState(store, key); const value = await __nexuHostInvoke("storage.local", "storage.read", Object.freeze({ scope: `${__nexuStoreScopePrefix}:${store}`, key }), signal); if (value === undefined) return state.initial; if (!__nexuStoreValueMatches(state.type, value)) throw new Error(`Persisted Nexu store value ${store}.${key} does not match ${state.type}`); return value; }); }',
    'function __nexuStoreSave(store, key, value) { return __nexuTask(async signal => { const state = __nexuStoreState(store, key); if (!__nexuStoreValueMatches(state.type, value)) throw new Error(`Nexu store write ${store}.${key} does not match ${state.type}`); await __nexuHostInvoke("storage.local", "storage.write", Object.freeze({ scope: `${__nexuStoreScopePrefix}:${store}`, key, value }), signal); }); }',
    ''
  ];
}

function emitFeatureRuntime(featurePlan, target) {
  if (!featurePlan?.length) return [];
  const lines = [];
  const serialisable = featurePlan.map(feature => ({
    id: feature.id,
    title: feature.title,
    explicit: feature.explicit,
    config: feature.config,
    dependencies: feature.dependencies,
    capabilities: feature.capabilities.map(x => ({ path: x.path, policy: x.policy })),
    provides: feature.provides
  }));
  lines.push(`const __nexuFeaturePlan = Object.freeze(${JSON.stringify(serialisable)}${target === 'typescript' ? ' as const' : ''});`, '');

  const chat = featurePlan.find(feature => feature.id === 'ai.chat.full');
  if (chat) {
    const cfg = JSON.stringify(chat.config);
    if (target === 'typescript') {
      lines.push(
        'type NexuChatRole = "system" | "user" | "assistant";',
        'interface NexuChatMessage { readonly role: NexuChatRole; readonly content: string; readonly createdAt: number; }',
        'type NexuFullChatConfig = Readonly<{',
        '  name: string; model: string; fallback: string | null; privacy: string; memory: string;',
        '  streaming: boolean; markdown: boolean; code_blocks: boolean; cancellable: boolean;',
        '}>;',
        'type NexuFullChat = Readonly<{',
        '  readonly config: NexuFullChatConfig;',
        '  history(): ReadonlyArray<NexuChatMessage>;',
        '  send(prompt: string): NexuTask<NexuResult<string, string>>;',
        '  clear(): void;',
        '  stop(): void;',
        '}>;',
        'function __nexuCreateFullChat(config: NexuFullChatConfig): NexuFullChat {',
        '  const messages: NexuChatMessage[] = [];',
        '  let activeTask: NexuTask<NexuResult<string, string>> | null = null;',
        '  const ai = Object.freeze({ model: config.model, ...(config.fallback ? { fallback: config.fallback } : {}), privacy: config.privacy });',
        '  return Object.freeze({',
        '    config,',
        '    history: () => Object.freeze([...messages]),',
        '    send: (prompt: string) => {',
        '      const task = __nexuTask(async signal => {',
        '        messages.push({ role: "user", content: prompt, createdAt: Date.now() });',
        '        const result = await __nexuAwait(__nexuAsk(ai, prompt), signal);',
        '        if (result.kind === "ok") messages.push({ role: "assistant", content: result.value, createdAt: Date.now() });',
        '        return result;',
        '      });',
        '      activeTask = task;',
        '      task.promise.then(() => { if (activeTask === task) activeTask = null; }, () => { if (activeTask === task) activeTask = null; });',
        '      return task;',
        '    },',
        '    clear: () => { messages.length = 0; },',
        '    stop: () => { if (config.cancellable && activeTask) { activeTask.cancel("chat-stop"); activeTask = null; } }',
        '  });',
        '}',
        `const __nexuAiChatFull = __nexuCreateFullChat(Object.freeze(${cfg}));`,
        ''
      );
    } else {
      lines.push(
        'function __nexuCreateFullChat(config) {',
        '  const messages = [];',
        '  let activeTask = null;',
        '  const ai = Object.freeze({ model: config.model, ...(config.fallback ? { fallback: config.fallback } : {}), privacy: config.privacy });',
        '  return Object.freeze({',
        '    config,',
        '    history: () => Object.freeze([...messages]),',
        '    send: (prompt) => {',
        '      const task = __nexuTask(async signal => {',
        '        messages.push({ role: "user", content: prompt, createdAt: Date.now() });',
        '        const result = await __nexuAwait(__nexuAsk(ai, prompt), signal);',
        '        if (result.kind === "ok") messages.push({ role: "assistant", content: result.value, createdAt: Date.now() });',
        '        return result;',
        '      });',
        '      activeTask = task;',
        '      task.promise.then(() => { if (activeTask === task) activeTask = null; }, () => { if (activeTask === task) activeTask = null; });',
        '      return task;',
        '    },',
        '    clear: () => { messages.length = 0; },',
        '    stop: () => { if (config.cancellable && activeTask) { activeTask.cancel("chat-stop"); activeTask = null; } }',
        '  });',
        '}',
        `const __nexuAiChatFull = __nexuCreateFullChat(Object.freeze(${cfg}));`,
        ''
      );
    }
  }
  return lines;
}

export function emit(unit, target = 'typescript') {
  const { container } = unit;
  const moduleMode = container.kind === 'ModuleDeclaration';
  const state = { matchCounter: 0 };
  const lines = [
    '// Generated by Nexu Language 0.6.0 Components, Navigation, Persistence & Local AI Bridge compiler.',
    `// Source ${moduleMode ? 'module' : 'app'}: ${container.name}`,
    ''
  ];

  for (const item of unit.imports) {
    const resolved = item.resolvedSymbols ?? item.names.map(name => ({ name, kind: 'function' }));
    const runtimeNames = resolved.filter(x => x.kind !== 'record').map(x => x.name);
    const typeNames = resolved.filter(x => x.kind === 'record').map(x => x.name);
    const path = JSON.stringify(importedPath(item.source, target));
    if (target === 'typescript' && typeNames.length) lines.push(`import type { ${typeNames.join(', ')} } from ${path};`);
    if (runtimeNames.length) lines.push(`import { ${runtimeNames.join(', ')} } from ${path};`);
  }
  if (unit.imports.length) lines.push('');
  lines.push('export {};', '');
  lines.push(...emitTaskRuntime(target));

  const effectiveCapabilities = unit.analysis?.capabilities ?? new Map();
  const capabilityObject = `{ ${[...effectiveCapabilities].map(([path, policy]) => `${JSON.stringify(path)}: ${JSON.stringify(policy)}`).join(', ')} }`;
  lines.push(`const __nexuCapabilities = Object.freeze(${capabilityObject});`, '');

  lines.push(...emitUiRuntime(unit.analysis?.ui ?? null, target));
  lines.push(...emitHostRuntime(unit.analysis?.host ?? null, target));
  lines.push(...emitStoreRuntime(unit.analysis?.stores ?? new Map(), container.name, target));
  lines.push(...emitProviderRuntime(unit.analysis?.providers ?? [], target));
  lines.push(...emitFeatureRuntime(unit.analysis?.featurePlan ?? [], target));

  const functionEffects = container.declarations
    .filter(d => d.kind === 'FunctionDeclaration' && (d.effects?.length ?? 0) > 0)
    .map(d => [d.name, d.effects]);
  if (functionEffects.length) {
    lines.push(`const __nexuFunctionEffects = Object.freeze(${JSON.stringify(Object.fromEntries(functionEffects))}${target === 'typescript' ? ' as const' : ''});`, '');
  }

  for (const decl of container.declarations) {
    if (decl.kind === 'RecordDeclaration') {
      if (target === 'typescript') {
        lines.push(`${moduleMode ? 'export ' : ''}interface ${decl.name} {`);
        for (const field of decl.fields) lines.push(`  readonly ${field.name}: ${emitType(field.type)};`);
        lines.push('}', '');
      }
    } else if (decl.kind === 'AiDeclaration') {
      const config = {
        kind: 'ai', model: decl.config.model,
        ...(decl.config.fallback ? { fallback: decl.config.fallback } : {}),
        privacy: decl.config.privacy
      };
      lines.push(`const ${decl.name} = Object.freeze(${JSON.stringify(config)}${target === 'typescript' ? ' as const' : ''});`, '');
    } else if (decl.kind === 'AgentDeclaration') {
      const permissions = Object.fromEntries(decl.permissions.map(p => [p.path, p.policy]));
      const tools = Object.fromEntries((decl.tools ?? []).map(t => [t.path, t.policy]));
      const object = `{ kind: "agent", ai: ${decl.ai}, permissions: Object.freeze(${JSON.stringify(permissions)}), tools: Object.freeze(${JSON.stringify(tools)}) }`;
      lines.push(`const ${decl.name} = Object.freeze(${object}${target === 'typescript' ? ' as const' : ''});`, '');
    }
  }

  for (const fn of container.declarations.filter(d => d.kind === 'FunctionDeclaration')) {
    const exportPrefix = moduleMode ? 'export ' : '';
    const params = fn.params.map(p => `${p.name}${target === 'typescript' ? `: ${emitType(p.type)}` : ''}`).join(', ');
    if (fn.async) {
      const returnAnnotation = target === 'typescript' ? `: NexuTask<${emitType(fn.returnType)}>` : '';
      lines.push(`${exportPrefix}function ${fn.name}(${params})${returnAnnotation} {`);
      lines.push(`${indent(1)}return __nexuTask(async (__nexuSignal) => {`);
      lines.push(...emitStatements(fn.body, 2, target, state, { signal: '__nexuSignal' }));
      lines.push(`${indent(1)}});`);
      lines.push('}', '');
    } else {
      const returnAnnotation = target === 'typescript' ? `: ${emitType(fn.returnType)}` : '';
      lines.push(`${exportPrefix}function ${fn.name}(${params})${returnAnnotation} {`);
      lines.push(...emitStatements(fn.body, 1, target, state, {}));
      lines.push('}', '');
    }
  }

  if (!moduleMode) {
    const start = container.declarations.find(d => d.kind === 'FunctionDeclaration' && d.name === 'start');
    lines.push('// Nexu app entry point');
    lines.push(`${start?.async ? 'await __nexuAwait(start());' : 'start();'}`);
    if (unit.analysis?.ui) lines.push('await __nexuRenderUi();');
    lines.push('');
  }
  return lines.join('\n');
}
