import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { dirname, extname, isAbsolute, relative, resolve, sep } from 'node:path';
import { lex } from './lexer.mjs';
import { parse } from './parser.mjs';
import { analyse, collectExports } from './semantic.mjs';
import { emit } from './emitter.mjs';
import { NexuDiagnosticError } from './diagnostics.mjs';

function insideRoot(root, file) {
  const rel = relative(root, file);
  return rel === '' || (!rel.startsWith(`..${sep}`) && rel !== '..' && !isAbsolute(rel));
}

export async function compileProject(entryFile, target = 'typescript') {
  const entryPath = resolve(entryFile);
  const root = dirname(entryPath);
  const units = new Map();
  const visiting = new Set();

  async function load(filePath) {
    const abs = resolve(filePath);
    if (!insideRoot(root, abs)) throw new NexuDiagnosticError(`Imports cannot escape the project root '${root}'`);
    if (units.has(abs)) return units.get(abs);
    if (visiting.has(abs)) throw new NexuDiagnosticError(`Circular Nexu import detected at '${abs}'`);
    visiting.add(abs);
    if (extname(abs).toLowerCase() !== '.nex') throw new NexuDiagnosticError(`Nexu imports must reference .nex files: '${abs}'`);
    const source = await readFile(abs, 'utf8');
    const tokens = lex(source);
    const ast = parse(tokens);
    const record = { path: abs, source, tokens, ast, dependencies: new Map(), exports: collectExports(ast), output: null };
    units.set(abs, record);
    for (const imp of ast.imports) {
      if (!imp.source.startsWith('./') && !imp.source.startsWith('../')) throw new NexuDiagnosticError(`Phase 2 imports must be local relative paths, got '${imp.source}'`, imp.token);
      const depPath = resolve(dirname(abs), imp.source);
      if (!insideRoot(root, depPath)) throw new NexuDiagnosticError(`Import '${imp.source}' escapes the project root`, imp.token);
      record.dependencies.set(imp, await load(depPath));
    }
    visiting.delete(abs);
    return record;
  }

  await load(entryPath);

  const analysed = new Set();
  function analyseUnit(record) {
    if (analysed.has(record.path)) return;
    for (const dep of record.dependencies.values()) analyseUnit(dep);
    const imported = new Map();
    for (const [imp, dep] of record.dependencies) {
      imp.resolvedSymbols = [];
      for (const name of imp.names) {
        const symbol = dep.exports.get(name);
        if (!symbol) throw new NexuDiagnosticError(`Module '${imp.source}' does not export '${name}'`, imp.token);
        if (imported.has(name)) throw new NexuDiagnosticError(`Imported symbol '${name}' is declared more than once`, imp.token);
        imported.set(name, symbol);
        imp.resolvedSymbols.push({ name, kind: symbol.kind });
      }
    }
    analyse(record.ast, imported);
    record.exports = collectExports(record.ast);
    record.output = emit(record.ast, target);
    analysed.add(record.path);
  }
  for (const record of units.values()) analyseUnit(record);

  return { entryPath, root, units, target };
}

export async function writeProjectBuild(project, outDir) {
  const destination = resolve(outDir);
  const ext = project.target === 'typescript' ? '.ts' : '.mjs';
  const written = [];
  for (const record of project.units.values()) {
    const rel = relative(project.root, record.path).replace(/\.nex$/i, ext);
    const outPath = resolve(destination, rel);
    if (!insideRoot(destination, outPath)) throw new Error(`Refusing to write build output outside '${destination}'`);
    await mkdir(dirname(outPath), { recursive: true });
    await writeFile(outPath, record.output, 'utf8');
    written.push({ source: record.path, output: outPath });
  }
  return { outDir: destination, written, entryOutput: resolve(destination, relative(project.root, project.entryPath).replace(/\.nex$/i, ext)) };
}
