import { fileURLToPath } from 'node:url';
import { compileProject } from './project.mjs';
import { renderRecipe } from './recipes.mjs';
import { listHostAdapters } from './host-adapters.mjs';
import { listProviderAdapters } from './provider-adapters.mjs';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major !== 24 || minor < 19) {
  console.error(`FAIL Node.js 24.19.x LTS or newer 24.x is required. Found ${process.versions.node}.`);
  process.exit(1);
}

const entry = fileURLToPath(new URL('../examples/nexu-ai.nex', import.meta.url));
const ts = await compileProject(entry, 'typescript');
const js = await compileProject(entry, 'javascript');
const tsEntry = [...ts.units.values()].find(x => x.ast.container.name === 'NexuAI');
const jsEntry = [...js.units.values()].find(x => x.ast.container.name === 'NexuAI');
const analysis = tsEntry?.ast.analysis;
const featureIds = analysis?.featurePlan?.map(x => x.id) ?? [];

if (!tsEntry?.output.includes('type NexuTask<T>')) throw new Error('Task runtime emitter validation failed.');
if (!tsEntry.output.includes('const Assistant = Object.freeze')) throw new Error('AI declaration emitter validation failed.');
if (!tsEntry.output.includes('const Coder = Object.freeze')) throw new Error('Agent declaration emitter validation failed.');
if (!tsEntry.output.includes('__nexuFeaturePlan')) throw new Error('Feature plan emitter validation failed.');
if (!tsEntry.output.includes('__nexuCreateFullChat')) throw new Error('AI Chat Full runtime emitter validation failed.');
if (!tsEntry.output.includes('__nexuAiChatFull.send')) throw new Error('AI Chat Full call lowering validation failed.');
if (!tsEntry.output.includes('__nexuAiChatFull.stop')) throw new Error('AI Chat Full cancellation lowering validation failed.');
if (!tsEntry.output.includes('const __nexuUiTree')) throw new Error('Declarative UI emitter validation failed.');
if (!tsEntry.output.includes('const __nexuUiState')) throw new Error('Typed UI state runtime validation failed.');
if (!tsEntry.output.includes('const __nexuUiEvents')) throw new Error('Typed UI event runtime validation failed.');
if (!tsEntry.output.includes('__nexuUiState.set("status"')) throw new Error('UI event state mutation lowering validation failed.');
if (!tsEntry.output.includes('async function __nexuHostInvoke')) throw new Error('Host runtime gate emitter validation failed.');
if (!tsEntry.output.includes('async function __nexuHostConfirm')) throw new Error('Host confirmation surface emitter validation failed.');
if (!tsEntry.output.includes('async function __nexuProviderInvoke')) throw new Error('Provider runtime gate emitter validation failed.');
if (!tsEntry.output.includes('https://api.openai.com/v1/responses')) throw new Error('OpenAI Responses provider endpoint validation failed.');
if (!tsEntry.output.includes('OPENAI_API_KEY')) throw new Error('OpenAI environment-key provider validation failed.');
if (!tsEntry.output.includes('await __nexuRenderUi();')) throw new Error('Declarative UI app-entry validation failed.');
if (!tsEntry.output.includes('policy === "confirm"')) throw new Error('Host/provider confirmation policy validation failed.');
if (!tsEntry.output.includes('policy === "deny"')) throw new Error('Host/provider deny policy validation failed.');
if (!tsEntry.output.includes('start();')) throw new Error('Reference app entry validation failed.');
if (!jsEntry?.output.includes('start();')) throw new Error('JavaScript reference app entry validation failed.');
if (!featureIds.includes('ai.chat.full') || !featureIds.includes('agent.coder') || !featureIds.includes('storage.local') || !featureIds.includes('project.workspace')) {
  throw new Error(`Reference feature plan is incomplete: ${featureIds.join(', ')}`);
}
if (analysis?.host?.adapter !== 'console.preview') throw new Error('Reference host adapter contract validation failed.');
if (!analysis?.host?.provides?.includes('ui.render')) throw new Error('Reference host ui.render contract validation failed.');
if (!analysis?.host?.provides?.includes('ui.confirm')) throw new Error('Reference host ui.confirm contract validation failed.');
if (!analysis?.host?.provides?.includes('ui.focus')) throw new Error('Reference host ui.focus contract validation failed.');
if (!analysis?.host?.provides?.includes('storage.local')) throw new Error('Reference host storage.local contract validation failed.');
if (analysis?.ui?.name !== 'Workspace') throw new Error('Reference declarative UI root validation failed.');
if (analysis?.ui?.states?.find(x => x.name === 'status')?.type?.name !== 'String') throw new Error('Reference typed UI state validation failed.');
if (analysis?.capabilities?.get('ui.render') !== 'allow') throw new Error('Derived ui.render capability validation failed.');
if (analysis?.capabilities?.get('ui.confirm') !== 'allow') throw new Error('Derived ui.confirm capability validation failed.');
if (analysis?.capabilities?.get('network.ai') !== 'confirm') throw new Error('Provider network.ai confirmation policy validation failed.');
if (analysis?.capabilities?.get('ai.local') !== 'allow') throw new Error('Local AI capability validation failed.');
if (analysis?.capabilities?.get('storage.local') !== 'allow') throw new Error('Persistent storage capability validation failed.');
if (analysis?.capabilities?.get('ui.focus') !== 'allow') throw new Error('UI focus capability validation failed.');
if (!analysis?.stores?.has('Preferences')) throw new Error('Persistent Preferences store validation failed.');
if (!analysis?.components?.includes('BrandHeader')) throw new Error('Reusable BrandHeader component validation failed.');
if (analysis?.ui?.screens?.join(',') !== 'Home,Settings') throw new Error('Typed screen/navigation contract validation failed.');
const flatNodes = []; const collectNodes = nodes => { for (const node of nodes ?? []) { flatNodes.push(node); collectNodes(node.children); } }; collectNodes(analysis.ui.children);
const chatNode = flatNodes.find(node => node.type === 'chat');
if (chatNode?.feature !== 'ai.chat.full') throw new Error('UI Feature Module binding validation failed.');
if (!chatNode?.events?.some(event => event.name === 'send') || !chatNode.events.some(event => event.name === 'stop')) throw new Error('Reference chat event contract validation failed.');
const localQwen = analysis?.providers?.find(provider => provider.name === 'LocalQwen');
if (localQwen?.adapter !== 'ollama.chat' || localQwen.route !== 'local.qwen' || localQwen.config.model !== 'qwen3:8b') throw new Error('Reference local Qwen/Ollama provider contract validation failed.');
const openAi = analysis?.providers?.find(provider => provider.name === 'OpenAI');
if (openAi?.adapter !== 'openai.responses' || openAi.route !== 'openai') throw new Error('Reference OpenAI provider contract validation failed.');
const recipe = renderRecipe('AI Chat Full');
if (recipe.feature !== 'ai.chat.full' || !recipe.snippet.includes('state status: String') || !recipe.snippet.includes('on send(message: String)') || !recipe.snippet.includes('on stop')) {
  throw new Error('AI Chat Full stateful Recipe Engine expansion validation failed.');
}
const hostIds = listHostAdapters().map(x => x.id);
if (!hostIds.includes('console.preview') || !hostIds.includes('web.dom')) throw new Error('Host adapter catalogue validation failed.');
const providerIds = listProviderAdapters().map(x => x.id);
if (!providerIds.includes('test.echo') || !providerIds.includes('ollama.chat') || !providerIds.includes('openai.responses')) throw new Error('Provider adapter catalogue validation failed.');

console.log(`PASS Node.js ${process.versions.node}`);
console.log('PASS multi-file lexer -> parser -> semantic analysis -> TypeScript emitter');
console.log('PASS cancellable Task<T> + timeout/cancel + effect analysis');
console.log('PASS capability + AI + agent permission/tool policy checks');
console.log('PASS Feature Module dependency/capability resolution');
console.log('PASS reusable static components + checked screens/navigation');
console.log('PASS typed persistent stores + host storage boundary');
console.log('PASS typed UI state + compiler-checked UI events + focus contract');
console.log('PASS chat send/clear/stop event lowering + cancellation');
console.log('PASS runtime host capability + confirmation gate');
console.log('PASS compiler-known console.preview + web.dom host adapters');
console.log('PASS runtime provider capability gate + environment-variable secret contract');
console.log('PASS compiler-known test.echo + ollama.chat + openai.responses provider adapters');
console.log('PASS loopback-only local Qwen/Ollama provider contract');
console.log('PASS AI Chat Full stateful Recipe Engine expansion');
console.log('PASS Nexu AI 0.6.0 reference source');
