import { NexuDiagnosticError } from './diagnostics.mjs';
import { resolveFeaturePlan } from './features.mjs';
import { validateHostDeclaration } from './host-adapters.mjs';
import { validateProviderDeclaration } from './provider-adapters.mjs';

const PRIMITIVES = new Set(['String', 'Number', 'Bool', 'Void']);
const GENERICS = new Map([['List', 1], ['Result', 2], ['Task', 1]]);
const PRIVACY_POLICIES = new Set(['local_only', 'local_first', 'cloud_allowed']);
const POLICY_RANK = new Map([['allow', 0], ['confirm', 1], ['deny', 2]]);

const UI_ROOT_PROPERTIES = Object.freeze({
  layout: Object.freeze({ type: 'Enum', values: ['app_shell', 'stack', 'split'] }),
  title: Object.freeze({ type: 'String' }),
  theme: Object.freeze({ type: 'Enum', values: ['system', 'light', 'dark'] }),
  gap: Object.freeze({ type: 'Number', min: 0 }),
  start_screen: Object.freeze({ type: 'ScreenRef' })
});

const COMMON_UI_PROPERTIES = Object.freeze({
  label: { type: 'String' }, hidden: { type: 'Bool' }, aria_label: { type: 'String' }, focusable: { type: 'Bool' }
});
const UI_NODE_PROPERTIES = Object.freeze({
  surface: Object.freeze({ ...COMMON_UI_PROPERTIES, grow: { type: 'Number', min: 0 }, gap: { type: 'Number', min: 0 } }),
  row: Object.freeze({ ...COMMON_UI_PROPERTIES, grow: { type: 'Number', min: 0 }, gap: { type: 'Number', min: 0 } }),
  column: Object.freeze({ ...COMMON_UI_PROPERTIES, grow: { type: 'Number', min: 0 }, gap: { type: 'Number', min: 0 } }),
  sidebar: Object.freeze({ ...COMMON_UI_PROPERTIES, width: { type: 'Number', min: 1 }, grow: { type: 'Number', min: 0 } }),
  dock: Object.freeze({ ...COMMON_UI_PROPERTIES, width: { type: 'Number', min: 1 }, grow: { type: 'Number', min: 0 } }),
  panel: Object.freeze({ ...COMMON_UI_PROPERTIES, width: { type: 'Number', min: 1 }, grow: { type: 'Number', min: 0 }, gap: { type: 'Number', min: 0 } }),
  screen: Object.freeze({ ...COMMON_UI_PROPERTIES, grow: { type: 'Number', min: 0 }, gap: { type: 'Number', min: 0 } }),
  component: Object.freeze({ ...COMMON_UI_PROPERTIES }),
  chat: Object.freeze({ ...COMMON_UI_PROPERTIES, grow: { type: 'Number', min: 0 }, placeholder: { type: 'String' }, show_model: { type: 'Bool' } }),
  text: Object.freeze({ ...COMMON_UI_PROPERTIES, bind: { type: 'StateRef' } }),
  button: Object.freeze({ ...COMMON_UI_PROPERTIES, disabled: { type: 'Bool' } }),
  input: Object.freeze({ ...COMMON_UI_PROPERTIES, placeholder: { type: 'String' } })
});

const UI_EVENT_SIGNATURES = Object.freeze({
  root: Object.freeze({ ready: Object.freeze([]) }),
  chat: Object.freeze({
    send: Object.freeze(['String']),
    clear: Object.freeze([]),
    stop: Object.freeze([])
  }),
  button: Object.freeze({ click: Object.freeze([]) }),
  input: Object.freeze({ change: Object.freeze(['String']), submit: Object.freeze(['String']) })
});

function normaliseUiProperty(entry, schema, owner, uiStates) {
  if (!schema) throw new NexuDiagnosticError(`UI '${owner}' has no property '${entry.name}'`, entry.token);
  if (schema.type === 'String' && entry.valueKind !== 'String') throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must be a quoted String`, entry.valueToken ?? entry.token);
  if (schema.type === 'Bool' && entry.valueKind !== 'Bool') throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must be Bool`, entry.valueToken ?? entry.token);
  if (schema.type === 'Number') {
    if (entry.valueKind !== 'Number') throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must be Number`, entry.valueToken ?? entry.token);
    if (schema.min !== undefined && entry.value < schema.min) throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must be >= ${schema.min}`, entry.valueToken ?? entry.token);
  }
  if (schema.type === 'Enum') {
    if (entry.valueKind !== 'Name' || !schema.values.includes(entry.value)) throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must be one of: ${schema.values.join(', ')}`, entry.valueToken ?? entry.token);
  }
  if (schema.type === 'ScreenRef') {
    if (entry.valueKind !== 'Name') throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must reference a screen name`, entry.valueToken ?? entry.token);
  }
  if (schema.type === 'StateRef') {
    if (entry.valueKind !== 'Name') throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' must reference a UI state name`, entry.valueToken ?? entry.token);
    if (!uiStates.has(entry.value)) throw new NexuDiagnosticError(`UI '${owner}' property '${entry.name}' references unknown state '${entry.value}'`, entry.valueToken ?? entry.token);
  }
  return entry.value;
}

function uiStateInitializer(decl) {
  const allowed = new Map([
    ['String', 'StringLiteral'], ['Number', 'NumberLiteral'], ['Bool', 'BooleanLiteral']
  ]);
  if (!allowed.has(decl.type.name) || decl.type.args.length) {
    throw new NexuDiagnosticError(`UI state '${decl.name}' must use String, Number, or Bool in Nexu 0.6.0`, decl.token);
  }
  if (decl.initializer.kind !== allowed.get(decl.type.name)) {
    throw new NexuDiagnosticError(`UI state '${decl.name}' initializer must be ${decl.type.name}`, decl.token);
  }
  return decl.initializer.value;
}

function storeStateInitializer(storeName, decl) {
  const allowed = new Map([['String', 'StringLiteral'], ['Number', 'NumberLiteral'], ['Bool', 'BooleanLiteral']]);
  if (!allowed.has(decl.type.name) || decl.type.args.length) throw new NexuDiagnosticError(`Store '${storeName}' state '${decl.name}' must use String, Number, or Bool in Nexu 0.6.0`, decl.token);
  if (decl.initializer.kind !== allowed.get(decl.type.name)) throw new NexuDiagnosticError(`Store '${storeName}' state '${decl.name}' initializer must be ${decl.type.name}`, decl.token);
  return decl.initializer.value;
}

function validateUiEvent(event, owner, nodeType) {
  const allowed = UI_EVENT_SIGNATURES[nodeType ?? 'root'] ?? Object.freeze({});
  const signature = allowed[event.name];
  if (!signature) {
    const names = Object.keys(allowed);
    throw new NexuDiagnosticError(`UI '${owner}' does not support event '${event.name}'${names.length ? `; supported: ${names.join(', ')}` : ''}`, event.token);
  }
  if (event.params.length !== signature.length) {
    throw new NexuDiagnosticError(`UI event '${owner}.${event.name}' expects ${signature.length} parameter(s), got ${event.params.length}`, event.token);
  }
  const seen = new Set();
  for (let i = 0; i < event.params.length; i += 1) {
    const param = event.params[i];
    if (seen.has(param.name)) throw new NexuDiagnosticError(`UI event '${owner}.${event.name}' repeats parameter '${param.name}'`, param.token);
    seen.add(param.name);
    if (param.type.name !== signature[i] || param.type.args.length) {
      throw new NexuDiagnosticError(`UI event '${owner}.${event.name}' parameter ${i + 1} must be ${signature[i]}`, param.token);
    }
  }
  return event;
}

function analyseUiDeclaration(decl, featurePlan, componentDecls = []) {
  const featureIds = new Set(featurePlan.map(feature => feature.id));
  const names = new Set();
  const uiStates = new Map();
  const componentDefs = new Map();
  const validateStaticComponentNode = (componentName, node) => {
    if (node.kind !== 'UiNode') throw new NexuDiagnosticError(`Component '${componentName}' may contain static UI nodes only in Nexu 0.6.0`, node.token);
    for (const entry of node.entries ?? []) {
      if (entry.kind === 'UiProperty') continue;
      if (entry.kind === 'UiNode') { validateStaticComponentNode(componentName, entry); continue; }
      throw new NexuDiagnosticError(`Component '${componentName}' is static in Nexu 0.6.0; state, events, feature bindings, and nested mounts stay app-owned`, entry.token ?? node.token);
    }
  };
  const validateStaticComponentEntries = (componentName, entries) => {
    for (const entry of entries) validateStaticComponentNode(componentName, entry);
  };
  for (const component of componentDecls) {
    if (componentDefs.has(component.name)) throw new NexuDiagnosticError(`Component '${component.name}' is already declared`, component.token);
    validateStaticComponentEntries(component.name, component.entries);
    componentDefs.set(component.name, component);
  }
  for (const entry of decl.entries) {
    if (entry.kind !== 'UiState') continue;
    if (uiStates.has(entry.name)) throw new NexuDiagnosticError(`UI state '${entry.name}' is already declared`, entry.token);
    const initial = uiStateInitializer(entry);
    uiStates.set(entry.name, Object.freeze({ name: entry.name, type: entry.type, initial, token: entry.token }));
  }

  const nodeMap = new Map();
  function splitEntries(entries, owner, schema, nodeType = null, prefix = '') {
    const properties = {};
    const nodes = [];
    const bindings = [];
    const events = [];
    const seenProperties = new Set();
    const seenEvents = new Set();
    for (const entry of entries) {
      if (entry.kind === 'UiState') {
        if (nodeType) throw new NexuDiagnosticError(`UI state '${entry.name}' must be declared at the UI root in Nexu 0.6.0`, entry.token);
        continue;
      }
      if (entry.kind === 'UiEvent') {
        if (seenEvents.has(entry.name)) throw new NexuDiagnosticError(`UI '${owner}' repeats event '${entry.name}'`, entry.token);
        seenEvents.add(entry.name);
        events.push(validateUiEvent(entry, owner, nodeType));
      } else if (entry.kind === 'UiProperty') {
        if (seenProperties.has(entry.name)) throw new NexuDiagnosticError(`UI '${owner}' repeats property '${entry.name}'`, entry.token);
        seenProperties.add(entry.name);
        properties[entry.name] = normaliseUiProperty(entry, schema[entry.name], owner, uiStates);
      } else if (entry.kind === 'UiFeatureBinding') {
        if (!nodeType) throw new NexuDiagnosticError(`UI root '${owner}' cannot bind a feature directly; bind it to a UI node`, entry.token);
        if (!featureIds.has(entry.path)) throw new NexuDiagnosticError(`UI node '${owner}' binds feature '${entry.path}' but the app does not use it`, entry.token);
        if (bindings.includes(entry.path)) throw new NexuDiagnosticError(`UI node '${owner}' repeats feature binding '${entry.path}'`, entry.token);
        bindings.push(entry.path);
      } else if (entry.kind === 'UiComponentMount') {
        if (!componentDefs.has(entry.component)) throw new NexuDiagnosticError(`UI mount '${entry.name}' references unknown component '${entry.component}'`, entry.token);
        const mountName = prefix ? `${prefix}${entry.name}` : entry.name;
        if (names.has(mountName)) throw new NexuDiagnosticError(`UI node name '${mountName}' is already used`, entry.nameToken);
        names.add(mountName);
        const component = componentDefs.get(entry.component);
        const children = component.entries.map(child => normaliseNode(child, `${mountName}_`));
        const mounted = Object.freeze({
          type: 'component', name: mountName,
          properties: Object.freeze({ label: component.name, aria_label: component.name }),
          feature: null, events: Object.freeze([]), children: Object.freeze(children), component: component.name
        });
        nodeMap.set(mountName, mounted);
        nodes.push(mounted);
      } else if (entry.kind === 'UiNode') {
        nodes.push(normaliseNode(entry, prefix));
      }
    }
    if (bindings.length > 1) throw new NexuDiagnosticError(`UI node '${owner}' may bind only one Feature Module in Nexu 0.6.0`);
    if (nodeType === 'chat') {
      if (bindings.length !== 1 || bindings[0] !== 'ai.chat.full') throw new NexuDiagnosticError(`Chat UI node '${owner}' must bind 'use ai.chat.full'`, decl.token);
      if (nodes.length) throw new NexuDiagnosticError(`Chat UI node '${owner}' cannot contain child UI nodes in Nexu 0.6.0`, decl.token);
    }
    return { properties: Object.freeze(properties), nodes, feature: bindings[0] ?? null, events };
  }

  function normaliseNode(node, prefix = '') {
    const schema = UI_NODE_PROPERTIES[node.nodeType];
    if (!schema) throw new NexuDiagnosticError(`Unknown UI node type '${node.nodeType}'. Supported: ${Object.keys(UI_NODE_PROPERTIES).join(', ')}`, node.token);
    const finalName = prefix ? `${prefix}${node.name}` : node.name;
    if (names.has(finalName)) throw new NexuDiagnosticError(`UI node name '${finalName}' is already used`, node.nameToken);
    names.add(finalName);
    const split = splitEntries(node.entries, finalName, schema, node.nodeType, prefix);
    const result = Object.freeze({ type: node.nodeType, name: finalName, properties: split.properties, feature: split.feature, events: Object.freeze(split.events), children: Object.freeze(split.nodes) });
    nodeMap.set(finalName, result);
    return result;
  }

  const root = splitEntries(decl.entries, decl.name, UI_ROOT_PROPERTIES, null);
  const screenNames = [];
  const collectScreens = nodes => { for (const node of nodes) { if (node.type === 'screen') screenNames.push(node.name); collectScreens(node.children ?? []); } };
  collectScreens(root.nodes);
  const properties = { ...root.properties };
  if (screenNames.length && !properties.start_screen) properties.start_screen = screenNames[0];
  if (properties.start_screen && !screenNames.includes(properties.start_screen)) {
    throw new NexuDiagnosticError(`UI '${decl.name}' start_screen '${properties.start_screen}' does not name a declared screen`, decl.token);
  }
  return Object.freeze({
    name: decl.name,
    properties: Object.freeze(properties),
    states: Object.freeze([...uiStates.values()]),
    events: Object.freeze(root.events),
    children: Object.freeze(root.nodes),
    screens: Object.freeze(screenNames),
    nodeMap,
    components: Object.freeze([...componentDefs.keys()])
  });
}

export const typeRef = (name, args = []) => ({ kind: 'TypeRef', name, args });
export const typeName = (type) => type.args?.length ? `${type.name}<${type.args.map(typeName).join(', ')}>` : type.name;
const unknownType = () => typeRef('Unknown');

function cloneType(type) { return typeRef(type.name, (type.args ?? []).map(cloneType)); }
function sameType(a, b) {
  if (!a || !b) return false;
  if (a.name === 'Unknown' || b.name === 'Unknown') return true;
  if (a.name !== b.name || (a.args?.length ?? 0) !== (b.args?.length ?? 0)) return false;
  return (a.args ?? []).every((arg, i) => sameType(arg, b.args[i]));
}
function ensureType(type, records, token, { allowVoid = true } = {}) {
  if (type.name === 'Unknown') return;
  if (PRIMITIVES.has(type.name)) {
    if (type.args.length) throw new NexuDiagnosticError(`Type '${type.name}' does not take type arguments`, token);
    if (!allowVoid && type.name === 'Void') throw new NexuDiagnosticError('Void is not valid here', token);
    return;
  }
  if (GENERICS.has(type.name)) {
    const expected = GENERICS.get(type.name);
    if (type.args.length !== expected) throw new NexuDiagnosticError(`Type '${type.name}' requires ${expected} type argument(s)`, token);
    for (const arg of type.args) ensureType(arg, records, token, { allowVoid: type.name === 'Task' });
    return;
  }
  if (records.has(type.name)) {
    if (type.args.length) throw new NexuDiagnosticError(`Record type '${type.name}' does not take type arguments`, token);
    return;
  }
  throw new NexuDiagnosticError(`Unknown type '${typeName(type)}'`, token);
}

function literalType(expr) {
  if (expr.kind === 'StringLiteral') return typeRef('String');
  if (expr.kind === 'NumberLiteral') return typeRef('Number');
  if (expr.kind === 'BooleanLiteral') return typeRef('Bool');
  return null;
}

function blockAlwaysReturns(statements) {
  for (const stmt of statements) {
    if (stmt.kind === 'ReturnStatement') return true;
    if (stmt.kind === 'IfStatement' && stmt.elseBranch && blockAlwaysReturns(stmt.thenBranch) && blockAlwaysReturns(stmt.elseBranch)) return true;
    if (stmt.kind === 'MatchStatement' && stmt.arms.length === 2 && stmt.arms.every(arm => blockAlwaysReturns(arm.body))) return true;
  }
  return false;
}

export function collectExports(unit) {
  const exports = new Map();
  for (const decl of unit.container.declarations) {
    if (decl.kind === 'FunctionDeclaration') {
      exports.set(decl.name, { kind: 'function', name: decl.name, params: decl.params.map(p => cloneType(p.type)), returnType: cloneType(decl.returnType), async: decl.async, effects: new Set(decl.effects ?? []), token: decl.token });
    } else if (decl.kind === 'RecordDeclaration') {
      exports.set(decl.name, { kind: 'record', name: decl.name, fields: new Map(decl.fields.map(f => [f.name, cloneType(f.type)])), token: decl.token });
    }
  }
  return exports;
}

export function analyse(unit, externalSymbols = new Map()) {
  const { container } = unit;
  const isApp = container.kind === 'AppDeclaration';
  const symbols = new Map(externalSymbols);
  const records = new Map();
  const functions = new Map();
  const ais = new Map();
  const agents = new Map();
  const capabilities = new Map();
  const explicitCapabilities = new Map();
  const featureUses = [];
  const providerDecls = [];
  const componentDecls = [];
  const storeDecls = [];
  const stores = new Map();
  let uiDecl = null;
  let hostDecl = null;

  for (const [name, symbol] of externalSymbols) {
    if (symbol.kind === 'record') records.set(name, symbol);
    if (symbol.kind === 'function') functions.set(name, symbol);
  }

  const reserve = (name, value, token) => {
    if (symbols.has(name)) throw new NexuDiagnosticError(`Duplicate or shadowed top-level symbol '${name}'`, token);
    symbols.set(name, value);
  };

  for (const decl of container.declarations) {
    if (!isApp && ['CapabilityDeclaration', 'FeatureUseDeclaration', 'AiDeclaration', 'AgentDeclaration', 'UiDeclaration', 'HostDeclaration', 'ProviderDeclaration', 'ComponentDeclaration', 'StoreDeclaration'].includes(decl.kind)) {
      throw new NexuDiagnosticError(`${decl.kind.replace('Declaration', '')} declarations are only allowed inside an app`, decl.token);
    }
    if (decl.kind === 'RecordDeclaration') {
      const fieldMap = new Map();
      for (const field of decl.fields) {
        if (fieldMap.has(field.name)) throw new NexuDiagnosticError(`Duplicate field '${field.name}' in record '${decl.name}'`, field.token);
        fieldMap.set(field.name, field.type);
      }
      const symbol = { kind: 'record', name: decl.name, fields: fieldMap, token: decl.token };
      reserve(decl.name, symbol, decl.token); records.set(decl.name, symbol);
    } else if (decl.kind === 'FunctionDeclaration') {
      const symbol = { kind: 'function', name: decl.name, params: decl.params.map(p => p.type), returnType: decl.returnType, async: decl.async, token: decl.token };
      reserve(decl.name, symbol, decl.token); functions.set(decl.name, symbol);
    } else if (decl.kind === 'AiDeclaration') {
      const symbol = { kind: 'ai', name: decl.name, config: decl.config, token: decl.token };
      reserve(decl.name, symbol, decl.token); ais.set(decl.name, symbol);
    } else if (decl.kind === 'AgentDeclaration') {
      const symbol = { kind: 'agent', name: decl.name, decl, token: decl.token };
      reserve(decl.name, symbol, decl.token); agents.set(decl.name, symbol);
    } else if (decl.kind === 'CapabilityDeclaration') {
      if (capabilities.has(decl.path)) throw new NexuDiagnosticError(`Capability '${decl.path}' is already declared`, decl.token);
      capabilities.set(decl.path, decl.policy);
      explicitCapabilities.set(decl.path, decl.policy);
    } else if (decl.kind === 'FeatureUseDeclaration') {
      featureUses.push(decl);
    } else if (decl.kind === 'ProviderDeclaration') {
      providerDecls.push(decl);
      reserve(decl.name, { kind: 'provider', name: decl.name, token: decl.token }, decl.token);
    } else if (decl.kind === 'ComponentDeclaration') {
      componentDecls.push(decl);
      reserve(decl.name, { kind: 'component', name: decl.name, token: decl.token }, decl.token);
    } else if (decl.kind === 'StoreDeclaration') {
      storeDecls.push(decl);
      reserve(decl.name, { kind: 'store', name: decl.name, token: decl.token }, decl.token);
    } else if (decl.kind === 'UiDeclaration') {
      if (uiDecl) throw new NexuDiagnosticError(`App may declare only one UI root; already declared '${uiDecl.name}'`, decl.token);
      uiDecl = decl;
      reserve(decl.name, { kind: 'ui', name: decl.name, token: decl.token }, decl.token);
    } else if (decl.kind === 'HostDeclaration') {
      if (hostDecl) throw new NexuDiagnosticError(`App may declare only one host contract; already declared '${hostDecl.name}'`, decl.token);
      hostDecl = decl;
      reserve(decl.name, { kind: 'host', name: decl.name, token: decl.token }, decl.token);
    }
  }

  const validateComponentStaticShape = (componentName, entries, root = true) => {
    for (const entry of entries ?? []) {
      if (root && entry.kind !== 'UiNode') throw new NexuDiagnosticError(`Component '${componentName}' may contain static UI nodes only in Nexu 0.6.0`, entry.token);
      if (!root && entry.kind === 'UiProperty') continue;
      if (entry.kind === 'UiNode') { validateComponentStaticShape(componentName, entry.entries, false); continue; }
      if (!root) throw new NexuDiagnosticError(`Component '${componentName}' is static in Nexu 0.6.0; state, events, feature bindings, and nested mounts stay app-owned`, entry.token);
    }
  };
  for (const component of componentDecls) validateComponentStaticShape(component.name, component.entries, true);

  for (const record of records.values()) for (const type of record.fields.values()) ensureType(type, records, record.token, { allowVoid: false });
  for (const fn of functions.values()) {
    fn.params.forEach(type => ensureType(type, records, fn.token, { allowVoid: false }));
    ensureType(fn.returnType, records, fn.token);
    if (fn.async && fn.returnType.name === 'Task') throw new NexuDiagnosticError(`Async function '${fn.name}' declares its resolved type; do not wrap it in Task<>`, fn.token);
  }

  for (const decl of storeDecls) {
    if (decl.persistence !== 'local') throw new NexuDiagnosticError(`Store '${decl.name}' persistence must be 'local' in Nexu 0.6.0`, decl.token);
    const stateMap = new Map();
    for (const state of decl.states) {
      if (stateMap.has(state.name)) throw new NexuDiagnosticError(`Store '${decl.name}' repeats state '${state.name}'`, state.token);
      ensureType(state.type, records, state.token, { allowVoid: false });
      const initial = storeStateInitializer(decl.name, state);
      stateMap.set(state.name, Object.freeze({ name: state.name, type: state.type, initial, token: state.token }));
    }
    if (!stateMap.size) throw new NexuDiagnosticError(`Store '${decl.name}' must declare at least one state`, decl.token);
    stores.set(decl.name, Object.freeze({ name: decl.name, persistence: decl.persistence, states: stateMap, token: decl.token }));
  }

  if (isApp) {
    const start = functions.get('start');
    if (!start) throw new NexuDiagnosticError("App must declare a 'start' function", container.token);
    if (start.params.length !== 0) throw new NexuDiagnosticError("'start' cannot have parameters", start.token);
    if (start.returnType.name !== 'Void') throw new NexuDiagnosticError("'start' must return Void", start.token);
  }

  const featurePlan = isApp ? resolveFeaturePlan(featureUses) : [];
  const featureCapabilitySources = new Map();
  for (const feature of featurePlan) {
    for (const requirement of feature.capabilities) {
      const explicit = explicitCapabilities.get(requirement.path);
      if (explicit === 'deny' && requirement.policy !== 'deny') {
        throw new NexuDiagnosticError(`Feature '${feature.id}' requires capability '${requirement.path}' but the app explicitly denies it`, feature.token);
      }
      const current = capabilities.get(requirement.path);
      if (!current || POLICY_RANK.get(requirement.policy) > POLICY_RANK.get(current)) capabilities.set(requirement.path, requirement.policy);
      if (!featureCapabilitySources.has(requirement.path)) featureCapabilitySources.set(requirement.path, []);
      featureCapabilitySources.get(requirement.path).push({ feature: feature.id, policy: requirement.policy, reason: requirement.reason });
    }
  }

  if (stores.size) {
    const explicit = explicitCapabilities.get('storage.local');
    if (explicit === 'deny') throw new NexuDiagnosticError(`Persistent stores require capability 'storage.local' but the app explicitly denies it`, storeDecls[0]?.token);
    const current = capabilities.get('storage.local');
    if (!current || POLICY_RANK.get('allow') > POLICY_RANK.get(current)) capabilities.set('storage.local', 'allow');
    if (!featureCapabilitySources.has('storage.local')) featureCapabilitySources.set('storage.local', []);
    featureCapabilitySources.get('storage.local').push({ feature: 'persistent-store', policy: 'allow', reason: 'Load and save typed persistent application state through the host boundary.' });
  }

  const providers = [];
  const providerRoutes = new Map();
  let providerNeedsConfirmationSurface = false;
  for (const decl of providerDecls) {
    const provider = validateProviderDeclaration(decl);
    if (providerRoutes.has(provider.route)) throw new NexuDiagnosticError(`Provider route '${provider.route}' is already handled by '${providerRoutes.get(provider.route).name}'`, decl.token);
    providerRoutes.set(provider.route, provider);
    providers.push(provider);
    for (const requirement of provider.requirements) {
      const explicit = explicitCapabilities.get(requirement.path);
      if (explicit === 'deny' && requirement.policy !== 'deny') {
        throw new NexuDiagnosticError(`Provider '${provider.name}' requires capability '${requirement.path}' but the app explicitly denies it`, provider.token);
      }
      const current = capabilities.get(requirement.path);
      if (!current || POLICY_RANK.get(requirement.policy) > POLICY_RANK.get(current)) capabilities.set(requirement.path, requirement.policy);
      if (!featureCapabilitySources.has(requirement.path)) featureCapabilitySources.set(requirement.path, []);
      featureCapabilitySources.get(requirement.path).push({ feature: `provider:${provider.name}`, policy: requirement.policy, reason: requirement.reason });
      if (requirement.policy === 'confirm') providerNeedsConfirmationSurface = true;
    }
  }
  if (providerNeedsConfirmationSurface) {
    const explicit = explicitCapabilities.get('ui.confirm');
    if (explicit === 'deny') throw new NexuDiagnosticError(`A provider requires user confirmation but the app explicitly denies capability 'ui.confirm'`, providerDecls[0]?.token);
    const current = capabilities.get('ui.confirm');
    if (!current || POLICY_RANK.get('allow') > POLICY_RANK.get(current)) capabilities.set('ui.confirm', 'allow');
    if (!featureCapabilitySources.has('ui.confirm')) featureCapabilitySources.set('ui.confirm', []);
    featureCapabilitySources.get('ui.confirm').push({ feature: 'provider-confirmation', policy: 'allow', reason: 'Present an explicit user approval surface before a confirm-gated provider operation.' });
  }

  const host = hostDecl ? validateHostDeclaration(hostDecl) : null;
  const ui = uiDecl ? analyseUiDeclaration(uiDecl, featurePlan, componentDecls) : null;
  if (ui) {
    if (!host) throw new NexuDiagnosticError(`Declarative UI '${ui.name}' requires an explicit host contract`, uiDecl.token);
    if (!host.provides.includes('ui.render')) throw new NexuDiagnosticError(`Host '${host.name}' must provide 'ui.render' for declarative UI '${ui.name}'`, hostDecl.token);
    const requiredPolicy = 'allow';
    const explicit = explicitCapabilities.get('ui.render');
    if (explicit === 'deny') throw new NexuDiagnosticError(`Declarative UI '${ui.name}' requires capability 'ui.render' but the app explicitly denies it`, uiDecl.token);
    const current = capabilities.get('ui.render');
    if (!current || POLICY_RANK.get(requiredPolicy) > POLICY_RANK.get(current)) capabilities.set('ui.render', requiredPolicy);
    if (!featureCapabilitySources.has('ui.render')) featureCapabilitySources.set('ui.render', []);
    featureCapabilitySources.get('ui.render').push({ feature: 'ui:' + ui.name, policy: requiredPolicy, reason: 'Render the declarative UI tree through the declared host adapter.' });
  }
  const uiHasFocusAction = (() => {
    if (!ui) return false;
    const statementHasFocus = stmt => stmt.kind === 'FocusStatement' || (stmt.kind === 'IfStatement' && (stmt.thenBranch.some(statementHasFocus) || (stmt.elseBranch ?? []).some(statementHasFocus))) || (stmt.kind === 'MatchStatement' && stmt.arms.some(arm => arm.body.some(statementHasFocus)));
    const eventHasFocus = event => event.body.some(statementHasFocus);
    if ((ui.events ?? []).some(eventHasFocus)) return true;
    const walk = nodes => nodes.some(node => (node.events ?? []).some(eventHasFocus) || walk(node.children ?? []));
    return walk(ui.children ?? []);
  })();
  if (uiHasFocusAction) {
    const explicit = explicitCapabilities.get('ui.focus');
    if (explicit === 'deny') throw new NexuDiagnosticError(`UI focus actions require capability 'ui.focus' but the app explicitly denies it`, uiDecl.token);
    const current = capabilities.get('ui.focus');
    if (!current || POLICY_RANK.get('allow') > POLICY_RANK.get(current)) capabilities.set('ui.focus', 'allow');
    if (!featureCapabilitySources.has('ui.focus')) featureCapabilitySources.set('ui.focus', []);
    featureCapabilitySources.get('ui.focus').push({ feature: 'ui-focus', policy: 'allow', reason: 'Move keyboard focus through the declared host adapter.' });
  }
  if (stores.size) {
    if (!host) throw new NexuDiagnosticError('Persistent stores require an explicit host contract that provides storage.local', storeDecls[0]?.token);
    if (!host.provides.includes('storage.local')) throw new NexuDiagnosticError(`Host '${host.name}' must provide 'storage.local' for persistent stores`, hostDecl.token);
  }
  if (uiHasFocusAction) {
    if (!host) throw new NexuDiagnosticError('UI focus actions require an explicit host contract that provides ui.focus', uiDecl.token);
    if (!host.provides.includes('ui.focus')) throw new NexuDiagnosticError(`Host '${host.name}' must provide 'ui.focus' for focus actions`, hostDecl.token);
  }

  if (providerNeedsConfirmationSurface) {
    if (!host) throw new NexuDiagnosticError('Confirm-gated provider adapters require an explicit host contract that provides ui.confirm', providerDecls[0]?.token);
    if (!host.provides.includes('ui.confirm')) throw new NexuDiagnosticError(`Host '${host.name}' must provide 'ui.confirm' for confirm-gated provider adapters`, hostDecl.token);
  }
  if (host?.environment === 'browser') {
    const nodeProvider = providers.find(provider => provider.environment === 'node');
    if (nodeProvider) throw new NexuDiagnosticError(`Provider '${nodeProvider.name}' uses Node-only adapter '${nodeProvider.adapter}' but host '${host.name}' is browser-only. Nexu 0.6.0 single-host builds do not silently bridge browser UI to Node providers.`, nodeProvider.token);
  }
  if (host) {
    for (const provided of host.provides) {
      if (!capabilities.has(provided)) throw new NexuDiagnosticError(`Host '${host.name}' provides capability '${provided}' but the app never declares or derives it`, hostDecl.token);
    }
  }

  for (const ai of ais.values()) {
    if (!ai.config.model) throw new NexuDiagnosticError(`AI '${ai.name}' must declare a model`, ai.token);
    if (String(ai.config.model).startsWith('local.')) {
      const explicit = explicitCapabilities.get('ai.local');
      if (explicit === 'deny') throw new NexuDiagnosticError(`AI '${ai.name}' declares local model '${ai.config.model}' but capability 'ai.local' is explicitly denied`, ai.token);
      const current = capabilities.get('ai.local');
      if (!current || POLICY_RANK.get('allow') > POLICY_RANK.get(current)) capabilities.set('ai.local', 'allow');
      if (!featureCapabilitySources.has('ai.local')) featureCapabilitySources.set('ai.local', []);
      featureCapabilitySources.get('ai.local').push({ feature: `ai:${ai.name}`, policy: 'allow', reason: `Run local AI model '${ai.config.model}' through a local provider route.` });
    }
    if (!ai.config.privacy) throw new NexuDiagnosticError(`AI '${ai.name}' must declare a privacy policy`, ai.token);
    if (!PRIVACY_POLICIES.has(ai.config.privacy)) throw new NexuDiagnosticError(`Unknown AI privacy policy '${ai.config.privacy}'`, ai.token);
    if (ai.config.privacy === 'local_only' && ai.config.fallback) throw new NexuDiagnosticError(`AI '${ai.name}' is local_only and cannot declare a cloud/provider fallback`, ai.token);
  }
  for (const agent of agents.values()) {
    const decl = agent.decl;
    if (!decl.ai) throw new NexuDiagnosticError(`Agent '${decl.name}' must declare which AI it uses`, decl.token);
    if (!ais.has(decl.ai)) throw new NexuDiagnosticError(`Agent '${decl.name}' references unknown AI '${decl.ai}'`, decl.token);
    const seen = new Set();
    const permissionPolicies = new Map();
    for (const permission of decl.permissions) {
      if (seen.has(permission.path)) throw new NexuDiagnosticError(`Agent '${decl.name}' repeats permission '${permission.path}'`, permission.token);
      seen.add(permission.path);
      if (!capabilities.has(permission.path)) throw new NexuDiagnosticError(`Agent '${decl.name}' requests undeclared app capability '${permission.path}'`, permission.token);
      const appPolicy = capabilities.get(permission.path);
      if (POLICY_RANK.get(permission.policy) < POLICY_RANK.get(appPolicy)) {
        throw new NexuDiagnosticError(`Agent '${decl.name}' cannot weaken '${permission.path}' from app policy '${appPolicy}' to '${permission.policy}'`, permission.token);
      }
      permissionPolicies.set(permission.path, permission.policy);
    }
    const seenTools = new Set();
    for (const tool of decl.tools ?? []) {
      if (seenTools.has(tool.path)) throw new NexuDiagnosticError(`Agent '${decl.name}' repeats tool '${tool.path}'`, tool.token);
      seenTools.add(tool.path);
      if (!permissionPolicies.has(tool.path)) throw new NexuDiagnosticError(`Agent '${decl.name}' tool '${tool.path}' requires a matching permission`, tool.token);
      const permissionPolicy = permissionPolicies.get(tool.path);
      if (POLICY_RANK.get(tool.policy) < POLICY_RANK.get(permissionPolicy)) {
        throw new NexuDiagnosticError(`Agent '${decl.name}' tool '${tool.path}' cannot weaken permission '${permissionPolicy}' to '${tool.policy}'`, tool.token);
      }
    }
  }

  const checkExpression = (expr, scope, context) => {
    const lit = literalType(expr);
    if (lit) { expr.inferredType = lit; return lit; }
    let result;
    switch (expr.kind) {
      case 'Identifier': {
        if (scope.has(expr.name)) { result = scope.get(expr.name); if (context.uiStateNames?.has(expr.name)) expr.uiState = true; }
        else throw new NexuDiagnosticError(`Unknown identifier '${expr.name}'`, expr.token);
        break;
      }
      case 'GroupingExpression': result = checkExpression(expr.expression, scope, context); break;
      case 'ListLiteral': {
        let elementType = unknownType();
        for (const element of expr.elements) {
          const actual = checkExpression(element, scope, context);
          if (elementType.name === 'Unknown') elementType = actual;
          else if (!sameType(elementType, actual)) throw new NexuDiagnosticError(`List elements must share one type; found ${typeName(elementType)} and ${typeName(actual)}`);
        }
        result = typeRef('List', [elementType]); break;
      }
      case 'RecordLiteral': {
        const record = records.get(expr.typeName);
        if (!record) throw new NexuDiagnosticError(`Unknown record type '${expr.typeName}'`, expr.token);
        const provided = new Set();
        for (const field of expr.fields) {
          if (provided.has(field.name)) throw new NexuDiagnosticError(`Record '${expr.typeName}' repeats field '${field.name}'`, field.token);
          provided.add(field.name);
          if (!record.fields.has(field.name)) throw new NexuDiagnosticError(`Record '${expr.typeName}' has no field '${field.name}'`, field.token);
          const actual = checkExpression(field.value, scope, context);
          const expected = record.fields.get(field.name);
          if (!sameType(expected, actual)) throw new NexuDiagnosticError(`Field '${field.name}' of '${expr.typeName}' must be ${typeName(expected)}, got ${typeName(actual)}`, field.token);
        }
        for (const fieldName of record.fields.keys()) if (!provided.has(fieldName)) throw new NexuDiagnosticError(`Record '${expr.typeName}' is missing field '${fieldName}'`, expr.token);
        result = typeRef(expr.typeName); break;
      }
      case 'MemberExpression': {
        const objectType = checkExpression(expr.object, scope, context);
        const record = records.get(objectType.name);
        if (!record) throw new NexuDiagnosticError(`Type '${typeName(objectType)}' has no named fields`, expr.token);
        if (!record.fields.has(expr.member)) throw new NexuDiagnosticError(`Record '${objectType.name}' has no field '${expr.member}'`, expr.token);
        result = record.fields.get(expr.member); break;
      }
      case 'IndexExpression': {
        const objectType = checkExpression(expr.object, scope, context);
        const indexType = checkExpression(expr.index, scope, context);
        if (objectType.name !== 'List') throw new NexuDiagnosticError(`Only List values can be indexed, got ${typeName(objectType)}`);
        if (indexType.name !== 'Number') throw new NexuDiagnosticError('List index must be Number');
        result = objectType.args[0]; break;
      }
      case 'UnaryExpression': {
        const operand = checkExpression(expr.operand, scope, context);
        if (expr.operator === '!' && operand.name !== 'Bool') throw new NexuDiagnosticError("Operator '!' requires Bool", expr.token);
        if (expr.operator === '-' && operand.name !== 'Number') throw new NexuDiagnosticError("Unary '-' requires Number", expr.token);
        result = operand; break;
      }
      case 'AwaitExpression': {
        if (!context.async) throw new NexuDiagnosticError("'await' is only allowed inside async functions", expr.token);
        const operand = checkExpression(expr.operand, scope, context);
        if (operand.name !== 'Task' || operand.args.length !== 1) throw new NexuDiagnosticError(`'await' requires Task<T>, got ${typeName(operand)}`, expr.token);
        result = operand.args[0]; break;
      }
      case 'StoreLoadExpression': {
        const store = stores.get(expr.store);
        if (!store) throw new NexuDiagnosticError(`Unknown store '${expr.store}'`, expr.token);
        const state = store.states.get(expr.key);
        if (!state) throw new NexuDiagnosticError(`Store '${expr.store}' has no state '${expr.key}'`, expr.token);
        if (!capabilities.has('storage.local') || capabilities.get('storage.local') === 'deny') throw new NexuDiagnosticError(`Persistent load '${expr.store}.${expr.key}' requires capability 'storage.local'`, expr.token);
        expr.requiredEffects = ['storage.local'];
        result = typeRef('Task', [state.type]);
        break;
      }
      case 'AiAskExpression': {
        const ai = ais.get(expr.ai);
        if (!ai) throw new NexuDiagnosticError(`Unknown AI '${expr.ai}'`, expr.token);
        const prompt = checkExpression(expr.prompt, scope, context);
        if (prompt.name !== 'String') throw new NexuDiagnosticError(`AI prompt must be String, got ${typeName(prompt)}`, expr.token);
        expr.requiresLocal = String(ai.config.model ?? '').startsWith('local.');
        if (expr.requiresLocal) {
          if (!capabilities.has('ai.local')) throw new NexuDiagnosticError(`AI invocation '${expr.ai}' uses a local model but app capability 'ai.local' is not declared`, expr.token);
          if (capabilities.get('ai.local') === 'deny') throw new NexuDiagnosticError(`AI invocation '${expr.ai}' requires 'ai.local' but the capability is denied`, expr.token);
        }
        expr.requiresNetwork = ai.config.privacy !== 'local_only' || Boolean(ai.config.fallback);
        if (expr.requiresNetwork) {
          if (!capabilities.has('network.ai')) throw new NexuDiagnosticError(`AI invocation '${expr.ai}' may use network access but app capability 'network.ai' is not declared`, expr.token);
          if (capabilities.get('network.ai') === 'deny') throw new NexuDiagnosticError(`AI invocation '${expr.ai}' requires 'network.ai' but the capability is denied`, expr.token);
        }
        result = typeRef('Task', [typeRef('Result', [typeRef('String'), typeRef('String')])]);
        break;
      }
      case 'BinaryExpression': {
        const left = checkExpression(expr.left, scope, context), right = checkExpression(expr.right, scope, context);
        if (['+', '-', '*', '/'].includes(expr.operator)) {
          if (expr.operator === '+' && left.name === 'String' && right.name === 'String') result = typeRef('String');
          else if (left.name === 'Number' && right.name === 'Number') result = typeRef('Number');
          else throw new NexuDiagnosticError(`Operator '${expr.operator}' requires Number operands (or String + String)`, expr.token);
        } else if (['<', '<=', '>', '>='].includes(expr.operator)) {
          if (left.name !== 'Number' || right.name !== 'Number') throw new NexuDiagnosticError(`Operator '${expr.operator}' requires Number operands`, expr.token);
          result = typeRef('Bool');
        } else if (['==', '!='].includes(expr.operator)) {
          if (!sameType(left, right)) throw new NexuDiagnosticError(`Cannot compare ${typeName(left)} with ${typeName(right)}`, expr.token);
          result = typeRef('Bool');
        } else if (['&&', '||'].includes(expr.operator)) {
          if (left.name !== 'Bool' || right.name !== 'Bool') throw new NexuDiagnosticError(`Operator '${expr.operator}' requires Bool operands`, expr.token);
          result = typeRef('Bool');
        } else throw new NexuDiagnosticError(`Unsupported operator '${expr.operator}'`, expr.token);
        break;
      }
      case 'CallExpression': {
        if (expr.callee.kind !== 'Identifier') throw new NexuDiagnosticError('Phase 2 calls must target a named function', expr.callee.token);
        const name = expr.callee.name;
        if (name === 'print') {
          if (expr.args.length !== 1) throw new NexuDiagnosticError(`print expects 1 argument, got ${expr.args.length}`);
          checkExpression(expr.args[0], scope, context); result = typeRef('Void'); break;
        }
        if (name === 'delay') {
          if (expr.args.length !== 1) throw new NexuDiagnosticError(`delay expects 1 argument, got ${expr.args.length}`);
          const arg = checkExpression(expr.args[0], scope, context);
          if (arg.name !== 'Number') throw new NexuDiagnosticError('delay expects Number milliseconds');
          result = typeRef('Task', [typeRef('Void')]); break;
        }
        if (name === 'timeout') {
          if (expr.args.length !== 2) throw new NexuDiagnosticError(`timeout expects 2 arguments, got ${expr.args.length}`);
          const task = checkExpression(expr.args[0], scope, context);
          const milliseconds = checkExpression(expr.args[1], scope, context);
          if (task.name !== 'Task' || task.args.length !== 1) throw new NexuDiagnosticError(`timeout first argument must be Task<T>, got ${typeName(task)}`);
          if (milliseconds.name !== 'Number') throw new NexuDiagnosticError('timeout second argument must be Number milliseconds');
          result = typeRef('Task', [task.args[0]]); break;
        }
        if (name === 'cancel') {
          if (expr.args.length !== 1) throw new NexuDiagnosticError(`cancel expects 1 argument, got ${expr.args.length}`);
          const task = checkExpression(expr.args[0], scope, context);
          if (task.name !== 'Task' || task.args.length !== 1) throw new NexuDiagnosticError(`cancel expects Task<T>, got ${typeName(task)}`);
          result = typeRef('Void'); break;
        }
        if (name === 'chatSend') {
          const chat = featurePlan.find(feature => feature.id === 'ai.chat.full');
          if (!chat) throw new NexuDiagnosticError("chatSend requires 'use ai.chat.full'", expr.callee.token);
          if (expr.args.length !== 1) throw new NexuDiagnosticError(`chatSend expects 1 argument, got ${expr.args.length}`);
          const prompt = checkExpression(expr.args[0], scope, context);
          if (prompt.name !== 'String') throw new NexuDiagnosticError(`chatSend prompt must be String, got ${typeName(prompt)}`);
          expr.requiredEffects = chat.capabilities.filter(x => x.policy !== 'deny').map(x => x.path);
          result = typeRef('Task', [typeRef('Result', [typeRef('String'), typeRef('String')])]); break;
        }
        if (name === 'chatClear') {
          const chat = featurePlan.find(feature => feature.id === 'ai.chat.full');
          if (!chat) throw new NexuDiagnosticError("chatClear requires 'use ai.chat.full'", expr.callee.token);
          if (expr.args.length !== 0) throw new NexuDiagnosticError(`chatClear expects 0 arguments, got ${expr.args.length}`);
          expr.requiredEffects = chat.capabilities.filter(x => x.path === 'storage.local' && x.policy !== 'deny').map(x => x.path);
          result = typeRef('Void'); break;
        }
        if (name === 'chatStop') {
          const chat = featurePlan.find(feature => feature.id === 'ai.chat.full');
          if (!chat) throw new NexuDiagnosticError("chatStop requires 'use ai.chat.full'", expr.callee.token);
          if (expr.args.length !== 0) throw new NexuDiagnosticError(`chatStop expects 0 arguments, got ${expr.args.length}`);
          result = typeRef('Void'); break;
        }
        if (name === 'ok' || name === 'err') {
          if (expr.args.length !== 1) throw new NexuDiagnosticError(`${name} expects 1 argument, got ${expr.args.length}`);
          const inner = checkExpression(expr.args[0], scope, context);
          result = name === 'ok' ? typeRef('Result', [inner, unknownType()]) : typeRef('Result', [unknownType(), inner]);
          break;
        }
        const fn = functions.get(name);
        if (!fn) throw new NexuDiagnosticError(`Unknown function '${name}'`, expr.callee.token);
        if (fn.params.length !== expr.args.length) throw new NexuDiagnosticError(`Function '${name}' expects ${fn.params.length} argument(s), got ${expr.args.length}`);
        expr.args.forEach((arg, i) => {
          const actual = checkExpression(arg, scope, context), expected = fn.params[i];
          if (!sameType(expected, actual)) throw new NexuDiagnosticError(`Argument ${i + 1} to '${name}' must be ${typeName(expected)}, got ${typeName(actual)}`);
        });
        result = fn.async ? typeRef('Task', [fn.returnType]) : fn.returnType; break;
      }
      default: throw new NexuDiagnosticError(`Unknown expression kind '${expr.kind}'`);
    }
    expr.inferredType = result;
    return result;
  };

  const checkStatements = (statements, scope, fn) => {
    const expressionContext = { async: fn.async, uiStateNames: fn.uiStateNames ?? null };
    for (const stmt of statements) {
      if (stmt.kind === 'LetStatement') {
        if (scope.has(stmt.name)) throw new NexuDiagnosticError(`Variable '${stmt.name}' is already declared`, stmt.token);
        const actual = checkExpression(stmt.initializer, scope, expressionContext);
        const declared = stmt.type ?? actual;
        ensureType(declared, records, stmt.token, { allowVoid: false });
        if (!sameType(declared, actual)) throw new NexuDiagnosticError(`Variable '${stmt.name}' is declared ${typeName(declared)} but receives ${typeName(actual)}`, stmt.token);
        stmt.resolvedType = declared; scope.set(stmt.name, declared);
      } else if (stmt.kind === 'SetStatement') {
        if (!fn.uiEvent) throw new NexuDiagnosticError(`'set' is only allowed inside declarative UI event handlers`, stmt.token);
        const stateType = fn.uiStateTypes?.get(stmt.name);
        if (!stateType) throw new NexuDiagnosticError(`Unknown UI state '${stmt.name}'`, stmt.token);
        const actual = checkExpression(stmt.value, scope, expressionContext);
        if (!sameType(stateType, actual)) throw new NexuDiagnosticError(`UI state '${stmt.name}' is ${typeName(stateType)} but receives ${typeName(actual)}`, stmt.token);
      } else if (stmt.kind === 'StoreSaveStatement') {
        if (!fn.async) throw new NexuDiagnosticError(`'save' is only allowed inside async functions or UI events`, stmt.token);
        const store = stores.get(stmt.store);
        if (!store) throw new NexuDiagnosticError(`Unknown store '${stmt.store}'`, stmt.token);
        const state = store.states.get(stmt.key);
        if (!state) throw new NexuDiagnosticError(`Store '${stmt.store}' has no state '${stmt.key}'`, stmt.token);
        const actual = checkExpression(stmt.value, scope, expressionContext);
        if (!sameType(state.type, actual)) throw new NexuDiagnosticError(`Store '${stmt.store}.${stmt.key}' is ${typeName(state.type)} but receives ${typeName(actual)}`, stmt.token);
        if (!capabilities.has('storage.local') || capabilities.get('storage.local') === 'deny') throw new NexuDiagnosticError(`Persistent save '${stmt.store}.${stmt.key}' requires capability 'storage.local'`, stmt.token);
      } else if (stmt.kind === 'NavigateStatement') {
        if (!fn.uiEvent) throw new NexuDiagnosticError(`'navigate' is only allowed inside declarative UI event handlers`, stmt.token);
        if (!fn.screenNames?.has(stmt.target)) throw new NexuDiagnosticError(`Unknown navigation screen '${stmt.target}'`, stmt.token);
      } else if (stmt.kind === 'FocusStatement') {
        if (!fn.uiEvent) throw new NexuDiagnosticError(`'focus' is only allowed inside declarative UI event handlers`, stmt.token);
        const target = fn.uiNodeMap?.get(stmt.target);
        if (!target) throw new NexuDiagnosticError(`Unknown focus target '${stmt.target}'`, stmt.token);
        const intrinsicallyFocusable = new Set(['button', 'input', 'chat']);
        if (!intrinsicallyFocusable.has(target.type) && target.properties.focusable !== true) throw new NexuDiagnosticError(`UI node '${stmt.target}' is not focusable; set focusable: true or focus a button/input/chat`, stmt.token);
        if (!capabilities.has('ui.focus') || capabilities.get('ui.focus') === 'deny') throw new NexuDiagnosticError(`Focus action '${stmt.target}' requires capability 'ui.focus'`, stmt.token);
      } else if (stmt.kind === 'ExpressionStatement') {
        checkExpression(stmt.expression, scope, expressionContext);
      } else if (stmt.kind === 'ReturnStatement') {
        const actual = stmt.value ? checkExpression(stmt.value, scope, expressionContext) : typeRef('Void');
        if (!sameType(actual, fn.returnType)) throw new NexuDiagnosticError(`Return type must be ${typeName(fn.returnType)}, got ${typeName(actual)}`);
      } else if (stmt.kind === 'IfStatement') {
        const condition = checkExpression(stmt.condition, scope, expressionContext);
        if (condition.name !== 'Bool') throw new NexuDiagnosticError('if condition must be Bool');
        checkStatements(stmt.thenBranch, new Map(scope), fn);
        if (stmt.elseBranch) checkStatements(stmt.elseBranch, new Map(scope), fn);
      } else if (stmt.kind === 'MatchStatement') {
        const matched = checkExpression(stmt.value, scope, expressionContext);
        if (matched.name !== 'Result' || matched.args.length !== 2) throw new NexuDiagnosticError(`match requires Result<T, E>, got ${typeName(matched)}`);
        const byVariant = new Map();
        for (const arm of stmt.arms) {
          if (byVariant.has(arm.variant)) throw new NexuDiagnosticError(`Duplicate '${arm.variant}' match arm`, arm.token);
          byVariant.set(arm.variant, arm);
          const armScope = new Map(scope);
          armScope.set(arm.binding, arm.variant === 'ok' ? matched.args[0] : matched.args[1]);
          checkStatements(arm.body, armScope, fn);
        }
        if (!byVariant.has('ok') || !byVariant.has('err')) throw new NexuDiagnosticError("Result match must handle both 'ok' and 'err'");
      }
    }
  };

  for (const decl of container.declarations) {
    if (decl.kind !== 'FunctionDeclaration') continue;
    const fn = functions.get(decl.name);
    const scope = new Map();
    for (const param of decl.params) {
      if (scope.has(param.name)) throw new NexuDiagnosticError(`Duplicate parameter '${param.name}'`, param.token);
      scope.set(param.name, param.type);
    }
    checkStatements(decl.body, scope, fn);
    if (fn.returnType.name !== 'Void' && !blockAlwaysReturns(decl.body)) throw new NexuDiagnosticError(`Function '${fn.name}' may finish without returning ${typeName(fn.returnType)}`, fn.token);
  }

  const uiStateTypes = new Map((ui?.states ?? []).map(state => [state.name, state.type]));
  const uiStateNames = new Set(uiStateTypes.keys());
  const visitUiEvents = (owner, events, children) => {
    for (const event of events ?? []) {
      const scope = new Map(uiStateTypes);
      for (const param of event.params) {
        if (uiStateTypes.has(param.name)) throw new NexuDiagnosticError(`UI event '${owner}.${event.name}' parameter '${param.name}' collides with UI state '${param.name}'`, param.token);
        scope.set(param.name, param.type);
      }
      const eventFn = { name: `${owner}.${event.name}`, async: true, returnType: typeRef('Void'), uiEvent: true, uiStateTypes, uiStateNames, screenNames: new Set(ui?.screens ?? []), uiNodeMap: ui?.nodeMap ?? new Map() };
      checkStatements(event.body, scope, eventFn);
    }
    for (const child of children ?? []) visitUiEvents(child.name, child.events, child.children);
  };
  if (ui) visitUiEvents(ui.name, ui.events, ui.children);

  const effectInfo = new Map();
  const walkExpressionEffects = (expr, info) => {
    if (!expr) return;
    if (expr.kind === 'AiAskExpression') {
      if (expr.requiresLocal) info.direct.add('ai.local');
      if (expr.requiresNetwork) info.direct.add('network.ai');
      walkExpressionEffects(expr.prompt, info); return;
    }
    if (expr.kind === 'StoreLoadExpression') { info.direct.add('storage.local'); return; }
    if (expr.kind === 'CallExpression') {
      for (const effect of expr.requiredEffects ?? []) info.direct.add(effect);
      if (expr.callee.kind === 'Identifier' && functions.has(expr.callee.name)) info.calls.add(expr.callee.name);
      walkExpressionEffects(expr.callee, info);
      for (const arg of expr.args) walkExpressionEffects(arg, info);
      return;
    }
    if (expr.kind === 'GroupingExpression' || expr.kind === 'UnaryExpression' || expr.kind === 'AwaitExpression') return walkExpressionEffects(expr.expression ?? expr.operand, info);
    if (expr.kind === 'BinaryExpression') { walkExpressionEffects(expr.left, info); walkExpressionEffects(expr.right, info); return; }
    if (expr.kind === 'ListLiteral') { for (const item of expr.elements) walkExpressionEffects(item, info); return; }
    if (expr.kind === 'RecordLiteral') { for (const field of expr.fields) walkExpressionEffects(field.value, info); return; }
    if (expr.kind === 'MemberExpression') return walkExpressionEffects(expr.object, info);
    if (expr.kind === 'IndexExpression') { walkExpressionEffects(expr.object, info); walkExpressionEffects(expr.index, info); }
  };
  const walkStatementEffects = (stmt, info) => {
    if (stmt.kind === 'LetStatement') walkExpressionEffects(stmt.initializer, info);
    else if (stmt.kind === 'SetStatement') walkExpressionEffects(stmt.value, info);
    else if (stmt.kind === 'StoreSaveStatement') { info.direct.add('storage.local'); walkExpressionEffects(stmt.value, info); }
    else if (stmt.kind === 'FocusStatement') info.direct.add('ui.focus');
    else if (stmt.kind === 'NavigateStatement') {}
    else if (stmt.kind === 'ExpressionStatement') walkExpressionEffects(stmt.expression, info);
    else if (stmt.kind === 'ReturnStatement') walkExpressionEffects(stmt.value, info);
    else if (stmt.kind === 'IfStatement') { walkExpressionEffects(stmt.condition, info); stmt.thenBranch.forEach(x => walkStatementEffects(x, info)); (stmt.elseBranch ?? []).forEach(x => walkStatementEffects(x, info)); }
    else if (stmt.kind === 'MatchStatement') { walkExpressionEffects(stmt.value, info); stmt.arms.forEach(arm => arm.body.forEach(x => walkStatementEffects(x, info))); }
  };
  for (const decl of container.declarations) {
    if (decl.kind !== 'FunctionDeclaration') continue;
    const info = { direct: new Set(), calls: new Set(), effects: new Set() };
    decl.body.forEach(stmt => walkStatementEffects(stmt, info));
    for (const effect of info.direct) info.effects.add(effect);
    effectInfo.set(decl.name, info);
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const [name, info] of effectInfo) {
      for (const called of info.calls) {
        const local = effectInfo.get(called);
        const imported = functions.get(called)?.effects;
        const source = local?.effects ?? imported ?? new Set();
        for (const effect of source) if (!info.effects.has(effect)) { info.effects.add(effect); changed = true; }
      }
    }
  }
  for (const decl of container.declarations) {
    if (decl.kind !== 'FunctionDeclaration') continue;
    const effects = [...(effectInfo.get(decl.name)?.effects ?? [])].sort();
    decl.effects = effects;
    const fn = functions.get(decl.name);
    fn.effects = new Set(effects);
    if (isApp) {
      for (const effect of effects) {
        if (!capabilities.has(effect)) throw new NexuDiagnosticError(`Function '${decl.name}' requires capability '${effect}' but the app does not declare it`, decl.token);
        if (capabilities.get(effect) === 'deny') throw new NexuDiagnosticError(`Function '${decl.name}' requires capability '${effect}' but the app denies it`, decl.token);
      }
    }
  }

  const resolveUiEventEffects = (owner, events, children) => {
    for (const event of events ?? []) {
      const info = { direct: new Set(), calls: new Set(), effects: new Set() };
      for (const stmt of event.body) walkStatementEffects(stmt, info);
      for (const effect of info.direct) info.effects.add(effect);
      for (const called of info.calls) {
        const local = effectInfo.get(called);
        const imported = functions.get(called)?.effects;
        for (const effect of local?.effects ?? imported ?? new Set()) info.effects.add(effect);
      }
      event.effects = [...info.effects].sort();
      for (const effect of event.effects) {
        if (!capabilities.has(effect)) throw new NexuDiagnosticError(`UI event '${owner}.${event.name}' requires capability '${effect}' but the app does not declare it`, event.token);
        if (capabilities.get(effect) === 'deny') throw new NexuDiagnosticError(`UI event '${owner}.${event.name}' requires capability '${effect}' but the app denies it`, event.token);
      }
    }
    for (const child of children ?? []) resolveUiEventEffects(child.name, child.events, child.children);
  };
  if (ui) resolveUiEventEffects(ui.name, ui.events, ui.children);

  unit.analysis = { symbols, records, functions, ais, agents, providers: Object.freeze(providers), providerRoutes, capabilities, explicitCapabilities, featurePlan, featureCapabilitySources, effects: effectInfo, ui, host, stores, components: Object.freeze(componentDecls.map(component => component.name)) };
  return unit;
}
