export const TokenKind = Object.freeze({
  EOF: 'EOF', Identifier: 'Identifier', Number: 'Number', String: 'String',
  App: 'app', Module: 'module', Import: 'import', From: 'from', Record: 'record',
  Fn: 'fn', Async: 'async', Await: 'await', Ask: 'ask', With: 'with', Let: 'let', Return: 'return', If: 'if', Else: 'else',
  Match: 'match', Ok: 'ok', Err: 'err', True: 'true', False: 'false',
  Capability: 'capability', Ai: 'ai', Agent: 'agent', Ui: 'ui', Host: 'host', Provider: 'provider', State: 'state', On: 'on', Set: 'set', Adapter: 'adapter', Provides: 'provides', Model: 'model', Fallback: 'fallback', Privacy: 'privacy',
  Component: 'component', Mount: 'mount', Store: 'store', Persist: 'persist', Navigate: 'navigate', Focus: 'focus',
  Permission: 'permission', Tool: 'tool', Use: 'use', Allow: 'allow', Confirm: 'confirm', Deny: 'deny',
  LeftBrace: '{', RightBrace: '}', LeftParen: '(', RightParen: ')', LeftBracket: '[', RightBracket: ']',
  Colon: ':', Comma: ',', Dot: '.', Equal: '=', Semicolon: ';',
  Plus: '+', Minus: '-', Star: '*', Slash: '/', Bang: '!',
  EqualEqual: '==', BangEqual: '!=', Less: '<', LessEqual: '<=', Greater: '>', GreaterEqual: '>=',
  AndAnd: '&&', OrOr: '||'
});

export const KEYWORDS = new Map([
  ['app', TokenKind.App], ['module', TokenKind.Module], ['import', TokenKind.Import], ['from', TokenKind.From],
  ['record', TokenKind.Record], ['fn', TokenKind.Fn], ['async', TokenKind.Async], ['await', TokenKind.Await], ['ask', TokenKind.Ask], ['with', TokenKind.With],
  ['let', TokenKind.Let], ['return', TokenKind.Return], ['if', TokenKind.If], ['else', TokenKind.Else],
  ['match', TokenKind.Match], ['ok', TokenKind.Ok], ['err', TokenKind.Err], ['true', TokenKind.True], ['false', TokenKind.False],
  ['capability', TokenKind.Capability], ['ai', TokenKind.Ai], ['agent', TokenKind.Agent], ['ui', TokenKind.Ui], ['host', TokenKind.Host], ['provider', TokenKind.Provider], ['state', TokenKind.State], ['on', TokenKind.On], ['set', TokenKind.Set], ['adapter', TokenKind.Adapter], ['provides', TokenKind.Provides], ['model', TokenKind.Model],
  ['component', TokenKind.Component], ['mount', TokenKind.Mount], ['store', TokenKind.Store], ['persist', TokenKind.Persist], ['navigate', TokenKind.Navigate], ['focus', TokenKind.Focus],
  ['fallback', TokenKind.Fallback], ['privacy', TokenKind.Privacy], ['permission', TokenKind.Permission], ['tool', TokenKind.Tool], ['use', TokenKind.Use],
  ['allow', TokenKind.Allow], ['confirm', TokenKind.Confirm], ['deny', TokenKind.Deny]
]);
