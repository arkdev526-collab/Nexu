import { KEYWORDS, TokenKind } from './token.mjs';
import { NexuDiagnosticError } from './diagnostics.mjs';

export function lex(source) {
  const tokens = [];
  let i = 0, line = 1, column = 1;
  const peek = (offset = 0) => source[i + offset] ?? '\0';
  const advance = () => {
    const ch = source[i++] ?? '\0';
    if (ch === '\n') { line += 1; column = 1; } else column += 1;
    return ch;
  };
  const add = (kind, value, startLine, startColumn) => tokens.push({ kind, value, line: startLine, column: startColumn });

  while (i < source.length) {
    const ch = peek();
    if (/\s/.test(ch)) { advance(); continue; }
    if (ch === '/' && peek(1) === '/') { while (peek() !== '\n' && peek() !== '\0') advance(); continue; }

    const startLine = line, startColumn = column;
    if (/[A-Za-z_]/.test(ch)) {
      let value = '';
      while (/[A-Za-z0-9_]/.test(peek())) value += advance();
      add(KEYWORDS.get(value) ?? TokenKind.Identifier, value, startLine, startColumn);
      continue;
    }
    if (/[0-9]/.test(ch)) {
      let value = '';
      while (/[0-9]/.test(peek())) value += advance();
      if (peek() === '.' && /[0-9]/.test(peek(1))) { value += advance(); while (/[0-9]/.test(peek())) value += advance(); }
      add(TokenKind.Number, value, startLine, startColumn); continue;
    }
    if (ch === '"') {
      advance(); let value = '';
      while (peek() !== '"' && peek() !== '\0') {
        if (peek() === '\n') throw new NexuDiagnosticError('Unterminated string literal', { line: startLine, column: startColumn });
        if (peek() === '\\') { value += advance(); if (peek() !== '\0') value += advance(); } else value += advance();
      }
      if (peek() !== '"') throw new NexuDiagnosticError('Unterminated string literal', { line: startLine, column: startColumn });
      advance(); add(TokenKind.String, value, startLine, startColumn); continue;
    }

    const two = ch + peek(1);
    const twoMap = new Map([['==', TokenKind.EqualEqual], ['!=', TokenKind.BangEqual], ['<=', TokenKind.LessEqual], ['>=', TokenKind.GreaterEqual], ['&&', TokenKind.AndAnd], ['||', TokenKind.OrOr]]);
    if (twoMap.has(two)) { advance(); advance(); add(twoMap.get(two), two, startLine, startColumn); continue; }
    const oneMap = new Map([
      ['{', TokenKind.LeftBrace], ['}', TokenKind.RightBrace], ['(', TokenKind.LeftParen], [')', TokenKind.RightParen],
      ['[', TokenKind.LeftBracket], [']', TokenKind.RightBracket], [':', TokenKind.Colon], [',', TokenKind.Comma], ['.', TokenKind.Dot],
      ['=', TokenKind.Equal], [';', TokenKind.Semicolon], ['+', TokenKind.Plus], ['-', TokenKind.Minus], ['*', TokenKind.Star],
      ['/', TokenKind.Slash], ['!', TokenKind.Bang], ['<', TokenKind.Less], ['>', TokenKind.Greater]
    ]);
    if (oneMap.has(ch)) { advance(); add(oneMap.get(ch), ch, startLine, startColumn); continue; }
    throw new NexuDiagnosticError(`Unexpected character '${ch}'`, { line: startLine, column: startColumn });
  }
  tokens.push({ kind: TokenKind.EOF, value: '', line, column });
  return tokens;
}
