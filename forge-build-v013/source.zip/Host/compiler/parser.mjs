import { TokenKind } from './token.mjs';
import { NexuDiagnosticError } from './diagnostics.mjs';

export function parse(tokens) {
  let current = 0;
  const peek = () => tokens[current];
  const previous = () => tokens[current - 1];
  const isAtEnd = () => peek().kind === TokenKind.EOF;
  const check = (kind) => peek().kind === kind;
  const advance = () => { if (!isAtEnd()) current += 1; return previous(); };
  const match = (...kinds) => {
    for (const kind of kinds) if (check(kind)) { advance(); return true; }
    return false;
  };
  const consume = (kind, message) => {
    if (check(kind)) return advance();
    throw new NexuDiagnosticError(message, peek());
  };
  const optionalSemicolon = () => { if (check(TokenKind.Semicolon)) advance(); };
  const isWord = token => /^[A-Za-z_][A-Za-z0-9_]*$/.test(token?.value ?? '');
  const consumeWord = message => {
    const token = peek();
    if (isWord(token)) return advance();
    throw new NexuDiagnosticError(message, token);
  };

  function parseType() {
    const name = consume(TokenKind.Identifier, 'Expected a type name');
    const args = [];
    if (match(TokenKind.Less)) {
      do { args.push(parseType()); } while (match(TokenKind.Comma));
      consume(TokenKind.Greater, "Expected '>' after generic type arguments");
    }
    return { kind: 'TypeRef', name: name.value, args, token: name };
  }

  function parsePath() {
    const first = consumeWord('Expected path');
    const parts = [first.value];
    while (match(TokenKind.Dot)) parts.push(consumeWord("Expected name after '.'").value);
    return { value: parts.join('.'), token: first };
  }

  function parseAtom() {
    if (match(TokenKind.String)) return { kind: 'StringLiteral', value: previous().value, token: previous() };
    if (match(TokenKind.Number)) return { kind: 'NumberLiteral', value: Number(previous().value), token: previous() };
    if (match(TokenKind.True)) return { kind: 'BooleanLiteral', value: true, token: previous() };
    if (match(TokenKind.False)) return { kind: 'BooleanLiteral', value: false, token: previous() };
    if (match(TokenKind.LeftBracket)) {
      const elements = [];
      if (!check(TokenKind.RightBracket)) {
        do { elements.push(parseExpression()); } while (match(TokenKind.Comma));
      }
      consume(TokenKind.RightBracket, "Expected ']' after list literal");
      return { kind: 'ListLiteral', elements };
    }
    if (match(TokenKind.Identifier, TokenKind.Ok, TokenKind.Err)) {
      const token = previous();
      const name = token.value;
      if (check(TokenKind.LeftBrace) && /^[A-Z]/.test(name)) {
        advance();
        const fields = [];
        if (!check(TokenKind.RightBrace)) {
          do {
            const field = consume(TokenKind.Identifier, 'Expected record field name');
            consume(TokenKind.Colon, "Expected ':' after record field name");
            fields.push({ name: field.value, value: parseExpression(), token: field });
          } while (match(TokenKind.Comma));
        }
        consume(TokenKind.RightBrace, "Expected '}' after record literal");
        return { kind: 'RecordLiteral', typeName: name, fields, token };
      }
      return { kind: 'Identifier', name, token };
    }
    if (match(TokenKind.LeftParen)) {
      const expression = parseExpression();
      consume(TokenKind.RightParen, "Expected ')' after expression");
      return { kind: 'GroupingExpression', expression };
    }
    throw new NexuDiagnosticError('Expected expression', peek());
  }

  function parsePostfix() {
    let expr = parseAtom();
    for (;;) {
      if (match(TokenKind.LeftParen)) {
        const args = [];
        if (!check(TokenKind.RightParen)) do { args.push(parseExpression()); } while (match(TokenKind.Comma));
        consume(TokenKind.RightParen, "Expected ')' after arguments");
        expr = { kind: 'CallExpression', callee: expr, args };
      } else if (match(TokenKind.Dot)) {
        const member = consume(TokenKind.Identifier, "Expected member name after '.'");
        expr = { kind: 'MemberExpression', object: expr, member: member.value, token: member };
      } else if (match(TokenKind.LeftBracket)) {
        const index = parseExpression();
        consume(TokenKind.RightBracket, "Expected ']' after index expression");
        expr = { kind: 'IndexExpression', object: expr, index };
      } else break;
    }
    return expr;
  }

  function parseUnary() {
    if (match(TokenKind.Await)) return { kind: 'AwaitExpression', operand: parseUnary(), token: previous() };
    if (check(TokenKind.Identifier) && peek().value === 'load' && tokens[current + 1]?.kind === TokenKind.Identifier && tokens[current + 2]?.kind === TokenKind.Dot) {
      const token = advance();
      const store = consume(TokenKind.Identifier, "Expected store name after 'load'");
      consume(TokenKind.Dot, "Expected '.' after store name");
      const key = consume(TokenKind.Identifier, 'Expected store state name after dot');
      return { kind: 'StoreLoadExpression', store: store.value, key: key.value, token };
    }
    if (match(TokenKind.Ask)) {
      const token = previous();
      const ai = consume(TokenKind.Identifier, "Expected AI declaration name after 'ask'");
      consume(TokenKind.With, "Expected 'with' after AI declaration name");
      return { kind: 'AiAskExpression', ai: ai.value, prompt: parseUnary(), token };
    }
    if (match(TokenKind.Bang, TokenKind.Minus)) return { kind: 'UnaryExpression', operator: previous().value, operand: parseUnary(), token: previous() };
    return parsePostfix();
  }
  function parseBinary(next, operators) {
    let expr = next();
    while (operators.includes(peek().kind)) {
      const operator = advance();
      expr = { kind: 'BinaryExpression', left: expr, operator: operator.value, right: next(), token: operator };
    }
    return expr;
  }
  const parseFactor = () => parseBinary(parseUnary, [TokenKind.Star, TokenKind.Slash]);
  const parseTerm = () => parseBinary(parseFactor, [TokenKind.Plus, TokenKind.Minus]);
  const parseComparison = () => parseBinary(parseTerm, [TokenKind.Less, TokenKind.LessEqual, TokenKind.Greater, TokenKind.GreaterEqual]);
  const parseEquality = () => parseBinary(parseComparison, [TokenKind.EqualEqual, TokenKind.BangEqual]);
  const parseAnd = () => parseBinary(parseEquality, [TokenKind.AndAnd]);
  const parseOr = () => parseBinary(parseAnd, [TokenKind.OrOr]);
  function parseExpression() { return parseOr(); }

  function parseBlock() {
    consume(TokenKind.LeftBrace, "Expected '{'");
    const statements = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) statements.push(parseStatement());
    consume(TokenKind.RightBrace, "Expected '}'");
    return statements;
  }
  function parseLet() {
    const name = consume(TokenKind.Identifier, 'Expected variable name');
    let type = null;
    if (match(TokenKind.Colon)) type = parseType();
    consume(TokenKind.Equal, "Expected '=' after variable declaration");
    const initializer = parseExpression(); optionalSemicolon();
    return { kind: 'LetStatement', name: name.value, type, initializer, token: name };
  }
  function parseReturn() {
    if (check(TokenKind.Semicolon) || check(TokenKind.RightBrace)) { optionalSemicolon(); return { kind: 'ReturnStatement', value: null }; }
    const value = parseExpression(); optionalSemicolon();
    return { kind: 'ReturnStatement', value };
  }
  function parseIf() {
    const condition = parseExpression();
    const thenBranch = parseBlock();
    let elseBranch = null;
    if (match(TokenKind.Else)) elseBranch = parseBlock();
    return { kind: 'IfStatement', condition, thenBranch, elseBranch };
  }
  function parseMatch() {
    const value = parseExpression();
    consume(TokenKind.LeftBrace, "Expected '{' after match value");
    const arms = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      let variant;
      if (match(TokenKind.Ok)) variant = 'ok';
      else if (match(TokenKind.Err)) variant = 'err';
      else throw new NexuDiagnosticError("Expected 'ok' or 'err' match arm", peek());
      consume(TokenKind.LeftParen, "Expected '(' after match arm");
      const binding = consume(TokenKind.Identifier, 'Expected match binding name');
      consume(TokenKind.RightParen, "Expected ')' after match binding");
      const body = parseBlock();
      arms.push({ variant, binding: binding.value, body, token: binding });
    }
    consume(TokenKind.RightBrace, "Expected '}' after match arms");
    return { kind: 'MatchStatement', value, arms };
  }
  function parseSet() {
    const name = consume(TokenKind.Identifier, 'Expected UI state name after set');
    consume(TokenKind.Equal, "Expected '=' after UI state name");
    const value = parseExpression(); optionalSemicolon();
    return { kind: 'SetStatement', name: name.value, value, token: name };
  }
  function parseStatement() {
    if (match(TokenKind.Let)) return parseLet();
    if (match(TokenKind.Set)) return parseSet();
    if (check(TokenKind.Identifier) && peek().value === 'save' && tokens[current + 1]?.kind === TokenKind.Identifier && tokens[current + 2]?.kind === TokenKind.Dot) {
      const token = advance();
      const store = consume(TokenKind.Identifier, "Expected store name after 'save'");
      consume(TokenKind.Dot, "Expected '.' after store name");
      const key = consume(TokenKind.Identifier, 'Expected store state name after dot');
      consume(TokenKind.Equal, "Expected '=' after persistent store state");
      const value = parseExpression(); optionalSemicolon();
      return { kind: 'StoreSaveStatement', store: store.value, key: key.value, value, token };
    }
    if (match(TokenKind.Navigate)) {
      const token = previous();
      const target = consume(TokenKind.Identifier, "Expected screen name after 'navigate'");
      optionalSemicolon();
      return { kind: 'NavigateStatement', target: target.value, token };
    }
    if (match(TokenKind.Focus)) {
      const token = previous();
      const target = consume(TokenKind.Identifier, "Expected UI node name after 'focus'");
      optionalSemicolon();
      return { kind: 'FocusStatement', target: target.value, token };
    }
    if (match(TokenKind.Return)) return parseReturn();
    if (match(TokenKind.If)) return parseIf();
    if (match(TokenKind.Match)) return parseMatch();
    const expression = parseExpression(); optionalSemicolon();
    return { kind: 'ExpressionStatement', expression };
  }

  function parseFunction(asyncFlag = false) {
    const name = consume(TokenKind.Identifier, 'Expected function name');
    consume(TokenKind.LeftParen, "Expected '(' after function name");
    const params = [];
    if (!check(TokenKind.RightParen)) {
      do {
        const paramName = consume(TokenKind.Identifier, 'Expected parameter name');
        consume(TokenKind.Colon, "Expected ':' after parameter name");
        params.push({ name: paramName.value, type: parseType(), token: paramName });
      } while (match(TokenKind.Comma));
    }
    consume(TokenKind.RightParen, "Expected ')' after parameters");
    let returnType = { kind: 'TypeRef', name: 'Void', args: [], token: name };
    if (match(TokenKind.Colon)) returnType = parseType();
    const body = parseBlock();
    return { kind: 'FunctionDeclaration', name: name.value, params, returnType, body, async: asyncFlag, token: name };
  }
  function parseRecord() {
    const name = consume(TokenKind.Identifier, 'Expected record name');
    consume(TokenKind.LeftBrace, "Expected '{' after record name");
    const fields = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      const field = consume(TokenKind.Identifier, 'Expected record field name');
      consume(TokenKind.Colon, "Expected ':' after record field name");
      fields.push({ name: field.value, type: parseType(), token: field });
      match(TokenKind.Comma, TokenKind.Semicolon);
    }
    consume(TokenKind.RightBrace, "Expected '}' after record fields");
    return { kind: 'RecordDeclaration', name: name.value, fields, token: name };
  }
  function parsePolicy() {
    if (match(TokenKind.Allow)) return 'allow';
    if (match(TokenKind.Confirm)) return 'confirm';
    if (match(TokenKind.Deny)) return 'deny';
    throw new NexuDiagnosticError("Expected permission policy 'allow', 'confirm', or 'deny'", peek());
  }
  function parseCapability() {
    const path = parsePath();
    const policy = parsePolicy(); optionalSemicolon();
    return { kind: 'CapabilityDeclaration', path: path.value, policy, token: path.token };
  }

  function parseFeatureValue() {
    if (match(TokenKind.String)) return { value: previous().value, valueKind: 'String', token: previous() };
    if (match(TokenKind.Number)) return { value: Number(previous().value), valueKind: 'Number', token: previous() };
    if (match(TokenKind.True)) return { value: true, valueKind: 'Bool', token: previous() };
    if (match(TokenKind.False)) return { value: false, valueKind: 'Bool', token: previous() };
    const token = peek();
    if (isWord(token)) { advance(); return { value: token.value, valueKind: 'Name', token }; }
    throw new NexuDiagnosticError('Expected feature config value', token);
  }
  function parseFeatureUse() {
    const path = parsePath();
    const config = [];
    if (match(TokenKind.LeftBrace)) {
      while (!check(TokenKind.RightBrace) && !isAtEnd()) {
        const key = consumeWord('Expected feature config name');
        const parsed = parseFeatureValue();
        config.push({ key: key.value, ...parsed, token: key });
        optionalSemicolon();
      }
      consume(TokenKind.RightBrace, "Expected '}' after feature config");
    }
    optionalSemicolon();
    return { kind: 'FeatureUseDeclaration', path: path.value, config, token: path.token };
  }

  function parseAi() {
    const name = consume(TokenKind.Identifier, 'Expected AI declaration name');
    consume(TokenKind.LeftBrace, "Expected '{' after AI name");
    const config = {};
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      if (match(TokenKind.Model)) config.model = consume(TokenKind.String, 'Expected model string').value;
      else if (match(TokenKind.Fallback)) config.fallback = consume(TokenKind.String, 'Expected fallback model/provider string').value;
      else if (match(TokenKind.Privacy)) config.privacy = consumeWord('Expected privacy policy name').value;
      else throw new NexuDiagnosticError("AI blocks allow only 'model', 'fallback', and 'privacy'", peek());
      optionalSemicolon();
    }
    consume(TokenKind.RightBrace, "Expected '}' after AI block");
    return { kind: 'AiDeclaration', name: name.value, config, token: name };
  }
  function parseAgent() {
    const name = consume(TokenKind.Identifier, 'Expected agent declaration name');
    consume(TokenKind.LeftBrace, "Expected '{' after agent name");
    let ai = null;
    const permissions = [];
    const tools = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      if (match(TokenKind.Use)) ai = consume(TokenKind.Identifier, 'Expected AI declaration name after use').value;
      else if (match(TokenKind.Permission)) {
        const path = parsePath();
        permissions.push({ path: path.value, policy: parsePolicy(), token: path.token });
      } else if (match(TokenKind.Tool)) {
        const path = parsePath();
        tools.push({ path: path.value, policy: parsePolicy(), token: path.token });
      } else throw new NexuDiagnosticError("Agent blocks allow only 'use', 'permission', and 'tool'", peek());
      optionalSemicolon();
    }
    consume(TokenKind.RightBrace, "Expected '}' after agent block");
    return { kind: 'AgentDeclaration', name: name.value, ai, permissions, tools, token: name };
  }

  function parseUiValue() {
    if (match(TokenKind.String)) return { kind: 'String', value: previous().value, token: previous() };
    if (match(TokenKind.Number)) return { kind: 'Number', value: Number(previous().value), token: previous() };
    if (match(TokenKind.True)) return { kind: 'Bool', value: true, token: previous() };
    if (match(TokenKind.False)) return { kind: 'Bool', value: false, token: previous() };
    const path = parsePath();
    return { kind: 'Name', value: path.value, token: path.token };
  }
  function parseUiState() {
    const name = consume(TokenKind.Identifier, 'Expected UI state name');
    consume(TokenKind.Colon, "Expected ':' after UI state name");
    const type = parseType();
    consume(TokenKind.Equal, "Expected '=' after UI state type");
    const initializer = parseExpression();
    optionalSemicolon();
    return { kind: 'UiState', name: name.value, type, initializer, token: name };
  }
  function parseUiEvent() {
    const name = consumeWord('Expected UI event name after on');
    const params = [];
    if (match(TokenKind.LeftParen)) {
      if (!check(TokenKind.RightParen)) {
        do {
          const paramName = consume(TokenKind.Identifier, 'Expected UI event parameter name');
          consume(TokenKind.Colon, "Expected ':' after UI event parameter name");
          params.push({ name: paramName.value, type: parseType(), token: paramName });
        } while (match(TokenKind.Comma));
      }
      consume(TokenKind.RightParen, "Expected ')' after UI event parameters");
    }
    const body = parseBlock();
    return { kind: 'UiEvent', name: name.value, params, body, token: name };
  }
  function parseUiEntries() {
    const entries = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      if (match(TokenKind.Use)) {
        const path = parsePath();
        optionalSemicolon();
        entries.push({ kind: 'UiFeatureBinding', path: path.value, token: path.token });
        continue;
      }
      if (match(TokenKind.State)) { entries.push(parseUiState()); continue; }
      if (match(TokenKind.On)) { entries.push(parseUiEvent()); continue; }
      if (match(TokenKind.Mount)) {
        const component = consume(TokenKind.Identifier, 'Expected component name after mount');
        const name = consume(TokenKind.Identifier, 'Expected mount instance name after component name');
        optionalSemicolon();
        entries.push({ kind: 'UiComponentMount', component: component.value, name: name.value, token: component, nameToken: name });
        continue;
      }
      const first = consumeWord('Expected UI property or node kind');
      if (match(TokenKind.Colon)) {
        const parsed = parseUiValue();
        optionalSemicolon();
        entries.push({ kind: 'UiProperty', name: first.value, value: parsed.value, valueKind: parsed.kind, token: first, valueToken: parsed.token });
        continue;
      }
      const name = consumeWord(`Expected UI node name after '${first.value}'`);
      consume(TokenKind.LeftBrace, "Expected '{' after UI node name");
      const children = parseUiEntries();
      consume(TokenKind.RightBrace, "Expected '}' after UI node");
      optionalSemicolon();
      entries.push({ kind: 'UiNode', nodeType: first.value, name: name.value, entries: children, token: first, nameToken: name });
    }
    return entries;
  }
  function parseUi() {
    const name = consume(TokenKind.Identifier, 'Expected UI declaration name');
    consume(TokenKind.LeftBrace, "Expected '{' after UI name");
    const entries = parseUiEntries();
    consume(TokenKind.RightBrace, "Expected '}' after UI declaration");
    return { kind: 'UiDeclaration', name: name.value, entries, token: name };
  }

  function parseComponent() {
    const name = consume(TokenKind.Identifier, 'Expected component name');
    consume(TokenKind.LeftBrace, "Expected '{' after component name");
    const entries = parseUiEntries();
    consume(TokenKind.RightBrace, "Expected '}' after component declaration");
    return { kind: 'ComponentDeclaration', name: name.value, entries, token: name };
  }

  function parseStore() {
    const name = consume(TokenKind.Identifier, 'Expected store name');
    consume(TokenKind.LeftBrace, "Expected '{' after store name");
    let persistence = null;
    const states = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      if (match(TokenKind.Persist)) {
        if (persistence !== null) throw new NexuDiagnosticError(`Store '${name.value}' repeats persist`, previous());
        persistence = consumeWord("Expected persistence mode after 'persist'").value;
        optionalSemicolon();
        continue;
      }
      if (match(TokenKind.State)) {
        const stateName = consume(TokenKind.Identifier, 'Expected store state name');
        consume(TokenKind.Colon, "Expected ':' after store state name");
        const type = parseType();
        consume(TokenKind.Equal, "Expected '=' after store state type");
        const initializer = parseExpression();
        optionalSemicolon();
        states.push({ kind: 'StoreState', name: stateName.value, type, initializer, token: stateName });
        continue;
      }
      throw new NexuDiagnosticError("Store blocks allow only 'persist' and 'state'", peek());
    }
    consume(TokenKind.RightBrace, "Expected '}' after store declaration");
    if (!persistence) throw new NexuDiagnosticError(`Store '${name.value}' must declare 'persist local'`, name);
    return { kind: 'StoreDeclaration', name: name.value, persistence, states, token: name };
  }

  function parseProvider() {
    const name = consume(TokenKind.Identifier, 'Expected provider declaration name');
    consume(TokenKind.LeftBrace, "Expected '{' after provider name");
    let adapter = null;
    const config = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      if (match(TokenKind.Adapter)) {
        if (adapter !== null) throw new NexuDiagnosticError(`Provider '${name.value}' repeats adapter`, previous());
        adapter = consume(TokenKind.String, 'Expected quoted provider adapter id').value;
      } else {
        const key = consumeWord(`Expected provider config name in '${name.value}'`);
        const parsed = parseFeatureValue();
        config.push({ key: key.value, ...parsed, token: key });
      }
      optionalSemicolon();
    }
    consume(TokenKind.RightBrace, "Expected '}' after provider declaration");
    if (!adapter) throw new NexuDiagnosticError(`Provider '${name.value}' must declare an adapter`, name);
    return { kind: 'ProviderDeclaration', name: name.value, adapter, config, token: name };
  }
  function parseHost() {
    const name = consume(TokenKind.Identifier, 'Expected host declaration name');
    consume(TokenKind.LeftBrace, "Expected '{' after host name");
    let adapter = null;
    const provides = [];
    while (!check(TokenKind.RightBrace) && !isAtEnd()) {
      if (match(TokenKind.Adapter)) {
        if (adapter !== null) throw new NexuDiagnosticError(`Host '${name.value}' repeats adapter`, previous());
        adapter = consume(TokenKind.String, 'Expected quoted host adapter id').value;
      } else if (match(TokenKind.Provides)) {
        const path = parsePath();
        provides.push({ path: path.value, token: path.token });
      } else {
        throw new NexuDiagnosticError("Host blocks allow only 'adapter' and 'provides'", peek());
      }
      optionalSemicolon();
    }
    consume(TokenKind.RightBrace, "Expected '}' after host declaration");
    if (!adapter) throw new NexuDiagnosticError(`Host '${name.value}' must declare an adapter`, name);
    return { kind: 'HostDeclaration', name: name.value, adapter, provides, token: name };
  }

  const imports = [];
  while (match(TokenKind.Import)) {
    consume(TokenKind.LeftBrace, "Expected '{' after import");
    const names = [];
    if (!check(TokenKind.RightBrace)) do { names.push(consume(TokenKind.Identifier, 'Expected imported symbol name').value); } while (match(TokenKind.Comma));
    consume(TokenKind.RightBrace, "Expected '}' after imported symbols");
    consume(TokenKind.From, "Expected 'from' after imported symbols");
    const source = consume(TokenKind.String, 'Expected import source string');
    optionalSemicolon();
    imports.push({ kind: 'ImportDeclaration', names, source: source.value, token: source });
  }

  let containerKind;
  if (match(TokenKind.App)) containerKind = 'AppDeclaration';
  else if (match(TokenKind.Module)) containerKind = 'ModuleDeclaration';
  else throw new NexuDiagnosticError("A Nexu source file must declare an 'app' or 'module'", peek());
  const containerName = consume(TokenKind.Identifier, 'Expected app/module name');
  consume(TokenKind.LeftBrace, "Expected '{' after app/module name");
  const declarations = [];
  while (!check(TokenKind.RightBrace) && !isAtEnd()) {
    if (match(TokenKind.Record)) declarations.push(parseRecord());
    else if (match(TokenKind.Async)) { consume(TokenKind.Fn, "Expected 'fn' after 'async'"); declarations.push(parseFunction(true)); }
    else if (match(TokenKind.Fn)) declarations.push(parseFunction(false));
    else if (match(TokenKind.Capability)) declarations.push(parseCapability());
    else if (match(TokenKind.Use)) declarations.push(parseFeatureUse());
    else if (match(TokenKind.Ai)) declarations.push(parseAi());
    else if (match(TokenKind.Agent)) declarations.push(parseAgent());
    else if (match(TokenKind.Ui)) declarations.push(parseUi());
    else if (match(TokenKind.Component)) declarations.push(parseComponent());
    else if (match(TokenKind.Store)) declarations.push(parseStore());
    else if (match(TokenKind.Host)) declarations.push(parseHost());
    else if (match(TokenKind.Provider)) declarations.push(parseProvider());
    else throw new NexuDiagnosticError('Unexpected declaration in app/module body', peek());
  }
  consume(TokenKind.RightBrace, "Expected '}' after app/module body");
  consume(TokenKind.EOF, 'Unexpected content after declaration');

  return {
    kind: 'CompilationUnit', imports,
    container: { kind: containerKind, name: containerName.value, declarations, token: containerName }
  };
}
