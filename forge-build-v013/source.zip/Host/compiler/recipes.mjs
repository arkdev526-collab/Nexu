import { copyFile, readFile, rm, writeFile } from 'node:fs/promises';
import { basename, dirname, join, resolve } from 'node:path';
import { compileProject } from './project.mjs';
import { getFeature } from './features.mjs';
import { lex } from './lexer.mjs';
import { parse } from './parser.mjs';
import { NexuDiagnosticError } from './diagnostics.mjs';

const AI_CHAT_FEATURE = `use ai.chat.full {
  name "Nexu AI"
  model "local.qwen"
  fallback "openai"
  privacy local_first
  memory conversation
  streaming true
  markdown true
  code_blocks true
  cancellable true
}`;

const AI_CHAT_HOST = `host NexuChatHost {
  adapter "console.preview"
  provides ui.render
}`;

const AI_CHAT_UI = `ui NexuChat {
  layout: app_shell
  title: "Nexu AI"
  theme: dark
  gap: 16
  state status: String = "Ready"

  text ChatStatus {
    bind: status
  }

  chat AssistantChat {
    use ai.chat.full
    label: "Nexu AI"
    grow: 1
    placeholder: "Message Nexu AI"
    show_model: true

    on send(message: String) {
      set status = "Thinking"
      let answer: Result<String, String> = await chatSend(message)
      match answer {
        ok(value) { set status = "Ready" }
        err(reason) { set status = "AI unavailable" }
      }
    }

    on clear { chatClear() set status = "Ready" }
    on stop { chatStop() set status = "Stopped" }
  }
}`;

const RECIPES = [
  {
    id: 'ai-chat-full',
    feature: 'ai.chat.full',
    title: 'AI Chat Full',
    aliases: ['ai chat full', 'add ai chat full', 'full nexu ai chat', 'add full nexu ai chat', 'nexu ai chat full'],
    mode: 'full-ui',
    snippet: `${AI_CHAT_FEATURE}\n\n${AI_CHAT_HOST}\n\n${AI_CHAT_UI}`
  },
  {
    id: 'ai-chat-core',
    feature: 'ai.chat.full',
    title: 'AI Chat Core',
    aliases: ['ai chat core', 'headless ai chat', 'add ai chat core'],
    mode: 'feature',
    snippet: AI_CHAT_FEATURE
  },
  {
    id: 'coding-agent',
    feature: 'agent.coder',
    title: 'Coding Agent',
    aliases: ['coding agent', 'add coding agent', 'agent coder', 'add agent coder'],
    mode: 'feature',
    snippet: `use agent.coder {\n  writes confirm\n  tests true\n}`
  },
  {
    id: 'project-workspace',
    feature: 'project.workspace',
    title: 'Project Workspace',
    aliases: ['project workspace', 'add project workspace', 'workspace full'],
    mode: 'feature',
    snippet: `use project.workspace {\n  read true\n  write true\n}`
  },
  {
    id: 'local-storage',
    feature: 'storage.local',
    title: 'Local Storage',
    aliases: ['local storage', 'add local storage', 'storage local'],
    mode: 'feature',
    snippet: `use storage.local {\n  encrypted false\n  scope app\n}`
  },
  {
    id: 'local-auth',
    feature: 'auth.local',
    title: 'Local Authentication',
    aliases: ['local auth', 'local authentication', 'add local auth', 'add local authentication'],
    mode: 'feature',
    snippet: `use auth.local {\n  method pin\n  lock_on_start true\n}`
  }
];

function normalise(text) {
  return text.trim().toLowerCase().replace(/[^a-z0-9.]+/g, ' ').trim().replace(/\s+/g, ' ');
}

export function listRecipes() {
  return RECIPES.map(({ id, feature, title, aliases, mode }) => ({ id, feature, title, aliases: [...aliases], mode }));
}

export function resolveRecipe(input) {
  const key = normalise(input);
  const recipe = RECIPES.find(item => item.id === key || item.feature === key || item.aliases.some(alias => normalise(alias) === key));
  if (!recipe) throw new NexuDiagnosticError(`Unknown Nexu recipe '${input}'. Use 'recipe list' to see available recipes.`);
  if (!getFeature(recipe.feature)) throw new NexuDiagnosticError(`Recipe '${recipe.title}' references missing feature '${recipe.feature}'`);
  return recipe;
}

export function renderRecipe(input) {
  const recipe = resolveRecipe(input);
  return { ...recipe, snippet: recipe.snippet };
}

function indentSnippet(snippet, spaces = 2) {
  const prefix = ' '.repeat(spaces);
  return snippet.split('\n').map(line => prefix + line).join('\n');
}

function uiBindsFeature(entries, featureId) {
  for (const entry of entries ?? []) {
    if (entry.kind === 'UiFeatureBinding' && entry.path === featureId) return true;
    if (entry.kind === 'UiNode' && uiBindsFeature(entry.entries, featureId)) return true;
  }
  return false;
}

function applyAiChatFullRecipe(source, recipe) {
  const ast = parse(lex(source));
  if (ast.container.kind !== 'AppDeclaration') throw new NexuDiagnosticError('AI Chat Full recipe requires a Nexu app source file');
  const declarations = ast.container.declarations;
  const hasFeature = declarations.some(decl => decl.kind === 'FeatureUseDeclaration' && decl.path === 'ai.chat.full');
  const host = declarations.find(decl => decl.kind === 'HostDeclaration');
  const ui = declarations.find(decl => decl.kind === 'UiDeclaration');

  if (host && !host.provides.some(item => item.path === 'ui.render')) {
    throw new NexuDiagnosticError(`AI Chat Full found existing host '${host.name}' without 'provides ui.render'. Nexu will not silently broaden an existing host contract.` , host.token);
  }
  if (ui && !uiBindsFeature(ui.entries, 'ai.chat.full')) {
    throw new NexuDiagnosticError(`AI Chat Full found existing UI '${ui.name}' without an ai.chat.full chat binding. Automatic UI merging is intentionally blocked; add a chat node explicitly.`, ui.token);
  }

  const missing = [];
  if (!hasFeature) missing.push(AI_CHAT_FEATURE);
  if (!host) missing.push(AI_CHAT_HOST);
  if (!ui) missing.push(AI_CHAT_UI);
  if (!missing.length) return { changed: false, source, recipe, reason: 'AI Chat Full feature, host contract, and declarative UI are already present.' };

  const match = /\bapp\s+[A-Za-z_][A-Za-z0-9_]*\s*\{/.exec(source);
  if (!match) throw new NexuDiagnosticError('Recipe application requires a Nexu app source file');
  const insertion = `\n${missing.map(block => indentSnippet(block)).join('\n\n')}\n`;
  const index = match.index + match[0].length;
  return { changed: true, source: source.slice(0, index) + insertion + source.slice(index), recipe };
}

export function applyRecipeToSource(input, source) {
  const recipe = resolveRecipe(input);
  if (recipe.mode === 'full-ui') return applyAiChatFullRecipe(source, recipe);
  const escaped = recipe.feature.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  if (new RegExp(`\\buse\\s+${escaped}(?:\\s|\\{|;|$)`).test(source)) {
    return { changed: false, source, recipe, reason: `Feature '${recipe.feature}' is already present.` };
  }
  const match = /\bapp\s+[A-Za-z_][A-Za-z0-9_]*\s*\{/.exec(source);
  if (!match) throw new NexuDiagnosticError('Recipe application requires a Nexu app source file');
  const insertion = `\n${indentSnippet(recipe.snippet)}\n`;
  const index = match.index + match[0].length;
  return { changed: true, source: source.slice(0, index) + insertion + source.slice(index), recipe };
}

export async function previewRecipeForFile(input, filePath) {
  const abs = resolve(filePath);
  const source = await readFile(abs, 'utf8');
  await compileProject(abs, 'typescript');
  const result = applyRecipeToSource(input, source);
  if (!result.changed) return { ...result, file: abs, backup: null };
  const temp = join(dirname(abs), `.nexu-recipe-${process.pid}-${Date.now()}.nex`);
  try {
    await writeFile(temp, result.source, 'utf8');
    await compileProject(temp, 'typescript');
  } finally {
    await rm(temp, { force: true });
  }
  return { ...result, file: abs, backup: null };
}

export async function applyRecipeToFile(input, filePath) {
  const preview = await previewRecipeForFile(input, filePath);
  if (!preview.changed) return preview;
  const abs = preview.file;
  const slug = preview.recipe.id;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backup = join(dirname(abs), `${basename(abs)}.before-${slug}-${stamp}.bak`);
  await copyFile(abs, backup);
  try {
    await writeFile(abs, preview.source, 'utf8');
    await compileProject(abs, 'typescript');
  } catch (error) {
    await copyFile(backup, abs);
    throw error;
  }
  return { ...preview, backup };
}
