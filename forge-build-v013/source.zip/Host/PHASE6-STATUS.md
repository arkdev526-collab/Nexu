# Nexu Language 0.6.0 — Phase 6 Status

## Status

**Implementation and release QA complete. The final archive is sealed by the release workflow.**

## Goal

Add reusable declarative UI, checked multi-screen navigation, typed persistent application state and a real local AI provider boundary while preserving the local/cloud permission split.

## Delivered

- static reusable components + mounts;
- screens + checked navigation;
- focus/accessibility host contract;
- typed persistent stores + load/save;
- runtime primitive store validation;
- `storage.local` host implementations;
- `ai.local` capability;
- loopback-only Ollama chat provider;
- local Qwen first / OpenAI fallback reference route;
- Local AI Doctor;
- updated explain/metrics/docs/scripts;
- preserved 0.5 syntax compatibility, including user functions named `load`/`save`.

## Reference Nexu AI

The `.nex` reference app now contains:

- `ai.chat.full` using `local.qwen` first with `openai` fallback;
- `LocalQwen` `ollama.chat` provider (`qwen3:8b`, loopback);
- OpenAI `openai.responses` provider;
- persistent `Preferences` store;
- reusable `BrandHeader` component;
- Home and Settings screens;
- checked navigation and focus;
- AI Chat Full event/cancellation flow.

The standard demo intentionally makes no AI-provider call. Local model presence is checked by the Local AI Doctor.

## Known limitations

- components are static in 0.6, without props/state/events/lifecycle;
- persistent values are primitive String/Number/Bool only;
- persistence is not encrypted and is not suitable for secrets;
- no persistence schema migrations/transactions;
- `ollama.chat` is non-streaming in this phase;
- no browser/server provider bridge;
- no local embeddings/RAG provider yet;
- no native/WASM backend or self-hosting compiler.

## Remaining external-machine verification

- Node.js 24.19.x production verifier on a matching runtime;
- TypeScript 7.0.2 execution/strict checking on the target toolchain;
- actual Windows Ollama + configured Qwen model execution through the generated provider;
- optional real OpenAI request only when user credentials/approval are intentionally supplied.
