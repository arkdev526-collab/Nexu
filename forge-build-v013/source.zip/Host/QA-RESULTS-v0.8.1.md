# Nexu AI 3D Forge v0.8.1 — QA Results

## Repair scope
Windows build entry-point reliability under restrictive PowerShell execution policy.

## Passed in the available build environment
- Windows builder implementation (`packaging/build-windows-candidate.go`) compiles with Go syntax/type checking.
- Full Forge + Nexu Language deterministic suite: 122/122 PASS.
- Builder no longer invokes any `.ps1` file.
- Builder contains no `-ExecutionPolicy Bypass`, `Unrestricted`, or `Set-ExecutionPolicy` instruction.
- Official Go 1.26.6 Windows x64 archive SHA-256 remains pinned.
- Bootstrap validates the Go archive with Windows `certutil.exe` before extraction.
- Exact Go 1.26.6 runtime is required before compiling launcher/Setup.
- Existing v0.8 Asset Intelligence & Learning tests remain green.

## Still requires physical Windows qualification
- Download/extract Go 1.26.6 using Windows inbox curl/tar.
- Build native launcher with exact Go 1.26.6.
- Build v0.8.1 Setup.exe with exact Go 1.26.6.
- Run update/repair over the installed v0.7/v0.8 lineage.
- Launch Forge and perform a real Blender generation.

Status: Candidate, not Qualified Release.
