# Nexu AI 3D Forge v0.10.0 — Architecture

**Milestone:** Universal Creation Intelligence, Fast Cache & Full Studio UX Candidate  
**Protected predecessor:** v0.9.0 Creation Intelligence & Creature Foundation Candidate

## Release thesis

Make Forge easier to speak to, faster on repeated work, lighter on storage/memory pressure, and more coherent as a complete creator application without replacing the proven Nexu3D → trusted Blender worker architecture.

## Creation path

```text
Natural user wording
  ↓
Prompt Intelligence
  - action normalization
  - typo repair
  - subject aliases
  - styles/materials/condition/colour/scale/shape/detail recognition
  ↓
Existing Creation Intelligence / grammars
  ↓
Nexu3D schema 1.2 recipe
  ↓
FastForge exact-recipe fingerprint
  ├─ HIT  → reuse existing validated asset; Blender is not launched
  └─ MISS → trusted Blender worker
                 ↓
         generation-mode policy
                 ↓
         validation + exports
```

## Creation knowledge

v0.10 has 43 permanent local grammars: the v0.9 31 grammars plus door, window frame, sword, shield, axe, hammer, spear, bucket, pot, book, torch and wagon wheel.

Prompt Intelligence recognises 269 subject phrases, 118 modifier phrases, 23 action prefixes and 29 common typo repairs. It does not execute prompt text or claim arbitrary unknown concepts are supported.

## Generation modes

- **Fast:** 256px-or-lower material generation, coarser organic voxel pass, no training-dataset capture, 512px preview, uncompressed `.blend` save to favour generation/save speed.
- **Balanced:** existing production-oriented defaults, dataset capture, 768px preview, compressed `.blend` to reduce storage.
- **Maximum Quality:** denser organic pass, 1K-or-higher material generation, larger previews/dataset views, compressed `.blend`.

Requested triangle targets are never silently lowered by the speed mode.

## FastForge cache

The recipe cache contains metadata only. Canonical recipe JSON is SHA-256 fingerprinted. A hit resolves to an already-existing validated asset directory.

Safety rules:
- no editable `.blend`, FBX or GLB hard links;
- no duplicate user-asset copy on a cache hit;
- stale entries are removed when `validation.json` is missing;
- at most 96 recent fingerprints;
- cache index is Brotli-compressed JSON;
- clearing cache never deletes generated assets.

## Storage policy

Balanced/Maximum Quality ask Blender to save the master `.blend` with Blender file compression enabled. Fast mode favours speed and leaves the master uncompressed. Primary GLB is deliberately left compatible with the built-in viewer; Draco/Meshopt export is deferred until the viewer owns a verified decoder path.

## Studio UX

v0.10 adds a real Home surface with recent assets, creation-language metrics, FastForge status and generation-mode explanations. The Create flow adds live Prompt Coaching and a "What can I say?" guide. System Centre adds FastForge/storage status and a safe cache-clear action. All declared UI text remains at least 14px.
