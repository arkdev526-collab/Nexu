# Nexu Language 0.1.0 Phase 1 Status

## Completed

- Working `.nex` lexer.
- Parser and AST.
- Semantic/type analyser.
- TypeScript emitter.
- JavaScript execution emitter for bootstrap demos.
- CLI commands: `check`, `build`, `run`.
- Nexu AI reference source.
- Hello-world reference source.
- Windows setup/verify and demo launchers.
- Automated compiler tests.
- ES-module isolation for generated output.

## Verified in the build workspace

- Automated Node test suite passes.
- Nexu AI source passes language checks.
- Nexu AI source emits TypeScript.
- Generated TypeScript compiles using the TypeScript compiler available in this workspace (5.8.3).
- JavaScript bootstrap target executes and prints `Nexu AI online`.
- Multiple generated apps compile together without global-name collisions.

## Verification gap

The build workspace currently provides Node.js 22.16.0, not the production baseline Node.js 24.19.0 LTS. The included `compiler/verify.mjs` deliberately fails on the wrong major/minor baseline. Final Node 24.19.x runtime verification must therefore run on a machine with that baseline installed.
