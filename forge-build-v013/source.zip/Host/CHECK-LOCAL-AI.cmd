@echo off
setlocal
cd /d "%~dp0"
echo Nexu Language 0.6.0 - Local AI Doctor
echo.
where node >nul 2>nul || (
  echo ERROR: Node.js is not available on PATH.
  echo Run SETUP-AND-VERIFY.cmd first.
  exit /b 1
)
node compiler\cli.mjs local-ai doctor examples\nexu-ai.nex
if errorlevel 1 exit /b %errorlevel%
echo.
echo Local Qwen provider is ready for the Nexu AI reference app.
endlocal
