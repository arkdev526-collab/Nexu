import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { compile } from '../compiler/compiler.mjs';
import { compileProject } from '../compiler/project.mjs';
import { listFeatures } from '../compiler/features.mjs';
import { applyRecipeToFile, applyRecipeToSource, renderRecipe } from '../compiler/recipes.mjs';

const minimal = `app Demo {
  fn start() {
    let message: String = "ready"
    print(message)
  }
}`;

test('keeps Phase 1 source compatible', () => {
  const { output } = compile(minimal, 'typescript');
  assert.match(output, /function start\(\): void/);
  assert.match(output, /const message: string = "ready";/);
});

test('supports records, lists, fields and indexing', () => {
  const source = `app Demo {
    record Context { name: String files: List<String> }
    fn start() {
      let ctx: Context = Context { name: "Nexu", files: ["a", "b"] }
      print(ctx.name)
      print(ctx.files[0])
    }
  }`;
  const { output } = compile(source, 'typescript');
  assert.match(output, /interface Context/);
  assert.match(output, /ReadonlyArray<string>/);
  assert.match(output, /ctx\.files\[0\]/);
});

test('rejects heterogeneous lists', () => {
  const bad = `app Demo { fn start() { let x = [1, "two"] print(x) } }`;
  assert.throws(() => compile(bad), /List elements must share one type/);
});

test('supports Result and exhaustive match', () => {
  const source = `app Demo {
    fn result(flag: Bool): Result<String, String> {
      if flag { return ok("yes") } else { return err("no") }
    }
    fn start() {
      let value: Result<String, String> = result(true)
      match value {
        ok(message) { print(message) }
        err(reason) { print(reason) }
      }
    }
  }`;
  const { output } = compile(source, 'typescript');
  assert.match(output, /NexuResult<string, string>/);
  assert.match(output, /\.kind === "ok"/);
});

test('requires both Result match arms', () => {
  const bad = `app Demo {
    fn result(): Result<String, String> { return ok("yes") }
    fn start() { let value = result() match value { ok(x) { print(x) } } }
  }`;
  assert.throws(() => compile(bad), /must handle both 'ok' and 'err'/);
});

test('supports async functions and await', () => {
  const source = `app Demo {
    async fn load(): String { await delay(1) return "ready" }
    async fn start() { let value: String = await load() print(value) }
  }`;
  const { output } = compile(source, 'typescript');
  assert.match(output, /function load\(\): NexuTask<string>/);
  assert.match(output, /await __nexuAwait\(load\(\), __nexuSignal\)/);
  assert.match(output, /await __nexuAwait\(start\(\)\);/);
});

test('rejects await in non-async functions', () => {
  const bad = `app Demo { fn start() { await delay(1) } }`;
  assert.throws(() => compile(bad), /only allowed inside async functions/);
});

test('validates AI declarations', () => {
  const source = `app Demo {
    ai Assistant { model "local.qwen" privacy local_only }
    agent Coder { use Assistant }
    fn start() { print("ready") }
  }`;
  const { output } = compile(source, 'typescript');
  assert.match(output, /const Assistant = Object\.freeze/);
  assert.match(output, /const Coder = Object\.freeze/);
});

test('blocks fallback when AI privacy is local_only', () => {
  const bad = `app Demo {
    ai Assistant { model "local.qwen" fallback "openai" privacy local_only }
    fn start() { print("ready") }
  }`;
  assert.throws(() => compile(bad), /local_only and cannot declare/);
});

test('blocks undeclared agent capabilities', () => {
  const bad = `app Demo {
    ai Assistant { model "local.qwen" privacy local_first }
    agent Coder { use Assistant permission project.write confirm }
    fn start() { print("ready") }
  }`;
  assert.throws(() => compile(bad), /undeclared app capability 'project.write'/);
});

test('blocks agent permission escalation', () => {
  const bad = `app Demo {
    capability project.write confirm
    ai Assistant { model "local.qwen" privacy local_first }
    agent Coder { use Assistant permission project.write allow }
    fn start() { print("ready") }
  }`;
  assert.throws(() => compile(bad), /cannot weaken 'project.write'/);
});

test('accepts stricter agent permissions', () => {
  const source = `app Demo {
    capability project.write allow
    ai Assistant { model "local.qwen" privacy local_first }
    agent Coder { use Assistant permission project.write confirm }
    fn start() { print("ready") }
  }`;
  assert.doesNotThrow(() => compile(source));
});

test('non-Void functions must return on all paths', () => {
  const bad = `app Demo { fn choose(flag: Bool): String { if flag { return "yes" } } fn start() {} }`;
  assert.throws(() => compile(bad), /may finish without returning String/);
});

test('compiles local modules and imports', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'nexu-lang-'));
  try {
    await writeFile(join(dir, 'core.nex'), `module Core { fn greet(name: String): String { return "Hi " + name } }`);
    await writeFile(join(dir, 'app.nex'), `import { greet } from "./core.nex" app Demo { fn start() { print(greet("Nexu")) } }`);
    const project = await compileProject(join(dir, 'app.nex'), 'javascript');
    assert.equal(project.units.size, 2);
    const app = [...project.units.values()].find(x => x.ast.container.kind === 'AppDeclaration');
    assert.match(app.output, /import \{ greet \} from "\.\/core\.mjs"/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('rejects missing imported symbols', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'nexu-lang-'));
  try {
    await writeFile(join(dir, 'core.nex'), `module Core { fn greet(): String { return "hi" } }`);
    await writeFile(join(dir, 'app.nex'), `import { missing } from "./core.nex" app Demo { fn start() {} }`);
    await assert.rejects(() => compileProject(join(dir, 'app.nex')), /does not export 'missing'/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('emits strict equality for Nexu equality operators', () => {
  const source = `app Demo { fn same(a: String, b: String): Bool { return a == b } fn start() { print(same("a", "a")) } }`;
  const { output } = compile(source, 'typescript');
  assert.match(output, /return a === b;/);
});

test('rejects imports that escape the entry project root', async () => {
  const parent = await mkdtemp(join(tmpdir(), 'nexu-lang-root-'));
  const appDir = join(parent, 'app');
  const { mkdir } = await import('node:fs/promises');
  try {
    await mkdir(appDir, { recursive: true });
    await writeFile(join(parent, 'outside.nex'), `module Outside { fn hidden(): String { return "no" } }`);
    await writeFile(join(appDir, 'app.nex'), `import { hidden } from "../outside.nex" app Demo { fn start() { print(hidden()) } }`);
    await assert.rejects(() => compileProject(join(appDir, 'app.nex')), /escapes the project root/);
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});


test('supports cancellable Task handles with timeout and cancel', () => {
  const source = `app Demo {
    async fn work(): String { await delay(1) return "done" }
    async fn start() {
      let task: Task<String> = timeout(work(), 50)
      cancel(task)
    }
  }`;
  const { output } = compile(source, 'typescript');
  assert.match(output, /type NexuTask<T>/);
  assert.match(output, /__nexuTimeout\(work\(\), 50\)/);
  assert.match(output, /__nexuCancel\(task\)/);
});

test('supports safe AI ask expressions and tracks network effects', () => {
  const source = `app Demo {
    capability network.ai confirm
    ai Assistant { model "local.qwen" fallback "openai" privacy local_first }
    async fn askUser(): Result<String, String> { return await ask Assistant with "hello" }
    async fn start() { let answer = await askUser() print("done") }
  }`;
  const { ast, output } = compile(source, 'typescript');
  const askUser = ast.container.declarations.find(x => x.kind === 'FunctionDeclaration' && x.name === 'askUser');
  const start = ast.container.declarations.find(x => x.kind === 'FunctionDeclaration' && x.name === 'start');
  assert.deepEqual(askUser.effects, ['ai.local', 'network.ai']);
  assert.deepEqual(start.effects, ['ai.local', 'network.ai']);
  assert.match(output, /__nexuAsk\(Assistant, "hello"\)/);
  assert.match(output, /__nexuProviderInvoke\(route, "ai\.ask"/);
  assert.match(output, /__nexuFunctionEffects/);
});

test('blocks network AI invocation without capability', () => {
  const source = `app Demo {
    ai Assistant { model "local.qwen" fallback "openai" privacy local_first }
    async fn start() { let result = await ask Assistant with "hello" print("done") }
  }`;
  assert.throws(() => compile(source), /network\.ai.*not declared/);
});

test('local-only AI ask uses ai.local without requiring network capability', () => {
  const source = `app Demo {
    ai Assistant { model "local.qwen" privacy local_only }
    async fn start() { let result = await ask Assistant with "hello" print("done") }
  }`;
  const { ast } = compile(source);
  const start = ast.container.declarations.find(x => x.kind === 'FunctionDeclaration' && x.name === 'start');
  assert.deepEqual(start.effects, ['ai.local']);
});

test('agent tools require matching permission and cannot weaken approval', () => {
  const good = `app Demo {
    capability project.write confirm
    ai Assistant { model "local.qwen" privacy local_only }
    agent Coder {
      use Assistant
      permission project.write confirm
      tool project.write confirm
    }
    fn start() { print("ready") }
  }`;
  assert.doesNotThrow(() => compile(good));

  const missing = `app Demo {
    capability project.write confirm
    ai Assistant { model "local.qwen" privacy local_only }
    agent Coder { use Assistant tool project.write confirm }
    fn start() { print("ready") }
  }`;
  assert.throws(() => compile(missing), /requires a matching permission/);

  const weak = `app Demo {
    capability project.write allow
    ai Assistant { model "local.qwen" privacy local_only }
    agent Coder { use Assistant permission project.write confirm tool project.write allow }
    fn start() { print("ready") }
  }`;
  assert.throws(() => compile(weak), /cannot weaken permission 'confirm' to 'allow'/);
});


test('resolves AI Chat Full with dependency and effective capabilities', () => {
  const source = `app Demo {
    use ai.chat.full {
      model "local.qwen"
      fallback "openai"
      privacy local_first
      memory conversation
    }
    fn start() { print("ready") }
  }`;
  const { ast, output } = compile(source, 'typescript');
  assert.deepEqual(ast.analysis.featurePlan.map(x => x.id), ['storage.local', 'ai.chat.full']);
  assert.equal(ast.analysis.capabilities.get('storage.local'), 'allow');
  assert.equal(ast.analysis.capabilities.get('network.ai'), 'confirm');
  assert.match(output, /__nexuFeaturePlan/);
  assert.match(output, /__nexuCreateFullChat/);
});

test('feature capability requirements become stricter rather than weaker', () => {
  const source = `app Demo {
    capability network.ai allow
    use ai.chat.full { fallback "openai" privacy local_first }
    fn start() { print("ready") }
  }`;
  const { ast } = compile(source);
  assert.equal(ast.analysis.capabilities.get('network.ai'), 'confirm');
});

test('explicit deny blocks an incompatible feature requirement', () => {
  const source = `app Demo {
    capability network.ai deny
    use ai.chat.full { fallback "openai" privacy local_first }
    fn start() { print("ready") }
  }`;
  assert.throws(() => compile(source), /requires capability 'network\.ai'.*explicitly denies/);
});

test('validates feature config names, types and privacy', () => {
  assert.throws(() => compile(`app Demo { use ai.chat.full { mystery true } fn start() {} }`), /has no config 'mystery'/);
  assert.throws(() => compile(`app Demo { use ai.chat.full { streaming "yes" } fn start() {} }`), /streaming.*must be Bool/);
  assert.throws(() => compile(`app Demo { use ai.chat.full { privacy local_only fallback "openai" } fn start() {} }`), /local_only and cannot declare a fallback/);
});

test('chatSend requires AI Chat Full and inherits its effects', () => {
  const missing = `app Demo { async fn start() { let result = await chatSend("hi") print("done") } }`;
  assert.throws(() => compile(missing), /chatSend requires 'use ai\.chat\.full'/);

  const source = `app Demo {
    use ai.chat.full { fallback "openai" privacy local_first memory conversation }
    async fn send(prompt: String): Result<String, String> { return await chatSend(prompt) }
    fn start() { print("ready") }
  }`;
  const { ast, output } = compile(source, 'typescript');
  const send = ast.container.declarations.find(x => x.kind === 'FunctionDeclaration' && x.name === 'send');
  assert.deepEqual(send.effects, ['ai.local', 'network.ai', 'storage.local']);
  assert.match(output, /__nexuAiChatFull\.send\(prompt\)/);
});

test('agent.coder resolves high-level dependencies', () => {
  const source = `app Demo { use agent.coder { writes confirm tests true } fn start() { print("ready") } }`;
  const { ast } = compile(source);
  assert.deepEqual(ast.analysis.featurePlan.map(x => x.id), ['storage.local', 'ai.chat.full', 'project.workspace', 'agent.coder']);
  assert.equal(ast.analysis.capabilities.get('project.write'), 'confirm');
});

test('standard feature catalogue contains the baseline feature modules', () => {
  assert.deepEqual(listFeatures().map(x => x.id), ['storage.local', 'project.workspace', 'ai.chat.full', 'agent.coder', 'auth.local']);
});

test('AI Chat Full recipe resolves natural aliases', () => {
  const recipe = renderRecipe('Add AI Chat Full');
  assert.equal(recipe.feature, 'ai.chat.full');
  assert.match(recipe.snippet, /use ai\.chat\.full/);
});

test('recipe source application is idempotent', () => {
  const initial = `app Demo { fn start() { print("ready") } }`;
  const first = applyRecipeToSource('AI Chat Full', initial);
  assert.equal(first.changed, true);
  assert.match(first.source, /use ai\.chat\.full/);
  const second = applyRecipeToSource('AI Chat Full', first.source);
  assert.equal(second.changed, false);
});

test('recipe apply writes a backup and leaves a compilable app', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'nexu-recipe-'));
  try {
    const file = join(dir, 'app.nex');
    await writeFile(file, `app Demo { fn start() { print("ready") } }`);
    const result = await applyRecipeToFile('AI Chat Full', file);
    assert.equal(result.changed, true);
    assert.ok(result.backup);
    assert.match(await readFile(file, 'utf8'), /use ai\.chat\.full/);
    assert.equal(await readFile(result.backup, 'utf8'), `app Demo { fn start() { print("ready") } }`);
    await assert.doesNotReject(() => compileProject(file, 'typescript'));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('supports declarative UI bound to Feature Modules through an explicit host contract', () => {
  const source = `app Demo {
    use ai.chat.full { privacy local_only memory conversation }
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace {
      layout: app_shell
      title: "Demo"
      sidebar Projects { width: 216 }
      chat AssistantChat { use ai.chat.full placeholder: "Ask" grow: 1 }
      dock Context { width: 320 }
    }
    fn start() { print("ready") }
  }`;
  const { ast, output } = compile(source, 'typescript');
  assert.equal(ast.analysis.host.adapter, 'console.preview');
  assert.equal(ast.analysis.ui.name, 'Workspace');
  assert.equal(ast.analysis.capabilities.get('ui.render'), 'allow');
  assert.equal(ast.analysis.ui.children[1].feature, 'ai.chat.full');
  assert.match(output, /const __nexuUiTree/);
  assert.match(output, /async function __nexuHostInvoke/);
  assert.match(output, /await __nexuRenderUi\(\)/);
});

test('declarative UI fails closed without a host contract', () => {
  const bad = `app Demo {
    use ai.chat.full { privacy local_only }
    ui Workspace { chat Chat { use ai.chat.full } }
    fn start() {}
  }`;
  assert.throws(() => compile(bad), /requires an explicit host contract/);
});

test('chat UI requires AI Chat Full and an explicit feature binding', () => {
  const missingFeature = `app Demo {
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace { chat Chat { } }
    fn start() {}
  }`;
  assert.throws(() => compile(missingFeature), /must bind 'use ai\.chat\.full'/);

  const unusedFeature = `app Demo {
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace { chat Chat { use ai.chat.full } }
    fn start() {}
  }`;
  assert.throws(() => compile(unusedFeature), /app does not use it/);
});

test('host contracts are compiler-known and cannot claim unsupported capabilities', () => {
  const unknown = `app Demo { capability ui.render allow host H { adapter "mystery.host" provides ui.render } fn start() {} }`;
  assert.throws(() => compile(unknown), /Unknown host adapter 'mystery\.host'/);

  const unsupported = `app Demo { capability network.ai confirm host H { adapter "console.preview" provides network.ai } fn start() {} }`;
  assert.throws(() => compile(unsupported), /does not implement capability 'network\.ai'/);
});

test('explicit ui.render deny remains authoritative', () => {
  const bad = `app Demo {
    capability ui.render deny
    use ai.chat.full { privacy local_only }
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace { chat Chat { use ai.chat.full } }
    fn start() {}
  }`;
  assert.throws(() => compile(bad), /requires capability 'ui\.render'.*explicitly denies/);
});

test('runtime host gate requires approval for confirm policies and fails closed', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'nexu-host-gate-'));
  try {
    const file = join(dir, 'app.nex');
    await writeFile(file, `app Demo {
      capability ui.render confirm
      use ai.chat.full { privacy local_only }
      host Preview { adapter "console.preview" provides ui.render }
      ui Workspace { chat Chat { use ai.chat.full } }
      fn start() { print("ready") }
    }`);
    const project = await compileProject(file, 'javascript');
    const { writeProjectBuild } = await import('../compiler/project.mjs');
    const result = await writeProjectBuild(project, join(dir, 'build'));
    const { pathToFileURL } = await import('node:url');
    await assert.rejects(() => import(`${pathToFileURL(result.entryOutput).href}?v=${Date.now()}`), /Host approval was not granted for ui\.render/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('host adapter catalogue exposes safe baseline adapters', async () => {
  const { listHostAdapters } = await import('../compiler/host-adapters.mjs');
  assert.deepEqual(listHostAdapters().map(x => x.id), ['console.preview', 'web.dom']);
});

test('AI Chat Full recipe now composes feature, host contract and declarative UI', () => {
  const initial = `app Demo { fn start() { print("ready") } }`;
  const result = applyRecipeToSource('AI Chat Full', initial);
  assert.equal(result.changed, true);
  assert.match(result.source, /use ai\.chat\.full/);
  assert.match(result.source, /host NexuChatHost/);
  assert.match(result.source, /provides ui\.render/);
  assert.match(result.source, /ui NexuChat/);
  assert.match(result.source, /chat AssistantChat/);
  assert.doesNotThrow(() => compile(result.source, 'typescript'));
});

test('AI Chat Full recipe upgrades a headless 0.3 app without duplicating the feature', () => {
  const headless = `app Demo {
    use ai.chat.full { privacy local_only }
    fn start() { print("ready") }
  }`;
  const result = applyRecipeToSource('AI Chat Full', headless);
  assert.equal(result.changed, true);
  assert.equal((result.source.match(/use ai\.chat\.full/g) ?? []).length, 2); // one feature use + one UI binding
  assert.match(result.source, /host NexuChatHost/);
  assert.match(result.source, /ui NexuChat/);
  assert.doesNotThrow(() => compile(result.source, 'typescript'));
});

test('AI Chat Full recipe refuses to silently broaden an existing host contract', () => {
  const source = `app Demo {
    capability ui.render allow
    host Preview { adapter "console.preview" provides ui.render }
    ui Existing { layout: stack }
    fn start() {}
  }`;
  assert.throws(() => applyRecipeToSource('AI Chat Full', source), /existing UI 'Existing'.*Automatic UI merging is intentionally blocked/);
});

test('supports typed declarative UI state and state bindings', () => {
  const source = `app Demo {
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace {
      state status: String = "Ready"
      text Status { bind: status }
    }
    fn start() {}
  }`;
  const { ast, output } = compile(source, 'typescript');
  assert.equal(ast.analysis.ui.states[0].name, 'status');
  assert.match(output, /__nexuUiState/);
  assert.match(output, /data-nexu-bind/);
});

test('rejects UI state initialisers with the wrong type', () => {
  const source = `app Demo {
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace { state status: String = 1 text Status { bind: status } }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /UI state 'status'.*String/);
});

test('rejects unknown UI state bindings', () => {
  const source = `app Demo {
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace { text Status { bind: missing } }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /references unknown state 'missing'/i);
});

test('set is restricted to declarative UI event handlers', () => {
  const source = `app Demo { fn start() { set status = "bad" } }`;
  assert.throws(() => compile(source), /set.*only allowed inside declarative UI event handlers/i);
});

test('validates typed UI event signatures', () => {
  const source = `app Demo {
    use ai.chat.full { model "local.qwen" privacy local_only memory conversation }
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace {
      state status: String = "Ready"
      chat Chat {
        use ai.chat.full
        on send(message: Number) { set status = "bad" }
      }
    }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /event 'Chat\.send'.*String/i);
});

test('chat UI events can await chatSend, update state, and stop active chat work', () => {
  const source = `app Demo {
    use ai.chat.full { model "echo" privacy local_only memory conversation cancellable true }
    provider Echo { adapter "test.echo" route "echo" prefix "Nexu" }
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace {
      state status: String = "Ready"
      text Status { bind: status }
      chat Chat {
        use ai.chat.full
        on send(message: String) {
          set status = "Thinking"
          let answer: Result<String, String> = await chatSend(message)
          match answer {
            ok(value) { set status = value }
            err(reason) { set status = reason }
          }
        }
        on stop { chatStop() set status = "Stopped" }
        on clear { chatClear() set status = "Ready" }
      }
    }
    fn start() {}
  }`;
  const { output, ast } = compile(source, 'typescript');
  const chat = ast.analysis.ui.children.find(x => x.type === 'chat');
  assert.deepEqual(chat.events.map(x => x.name), ['send', 'stop', 'clear']);
  assert.match(output, /__nexuUiState\.set\("status", "Thinking"\)/);
  assert.match(output, /__nexuAiChatFull\.stop\(\)/);
  assert.match(output, /stop\(\): void/);
});

test('provider adapter catalogue contains test and OpenAI provider contracts', async () => {
  const { listProviderAdapters } = await import('../compiler/provider-adapters.mjs');
  const adapters = listProviderAdapters();
  assert.ok(adapters.some(x => x.id === 'test.echo' && x.testOnly));
  assert.ok(adapters.some(x => x.id === 'openai.responses' && x.operation === 'ai.ask'));
});

test('OpenAI provider derives network confirmation and requires a host confirmation surface', () => {
  const missingHost = `app Demo {
    provider Cloud { adapter "openai.responses" route "openai" }
    fn start() {}
  }`;
  assert.throws(() => compile(missingHost), /require an explicit host contract.*ui\.confirm/i);

  const source = `app Demo {
    provider Cloud { adapter "openai.responses" route "openai" model "gpt-5.6" key_env "OPENAI_API_KEY" }
    host ConfirmHost { adapter "console.preview" provides ui.confirm }
    fn start() {}
  }`;
  const { ast, output } = compile(source, 'typescript');
  assert.equal(ast.analysis.capabilities.get('network.ai'), 'confirm');
  assert.equal(ast.analysis.capabilities.get('ui.confirm'), 'allow');
  assert.match(output, /https:\/\/api\.openai\.com\/v1\/responses/);
  assert.match(output, /OPENAI_API_KEY/);
  assert.doesNotMatch(output, /sk-[A-Za-z0-9]/);
});

test('explicit network deny blocks a provider that requires network AI', () => {
  const source = `app Demo {
    capability network.ai deny
    provider Cloud { adapter "openai.responses" route "openai" }
    host ConfirmHost { adapter "console.preview" provides ui.confirm }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /Provider 'Cloud'.*explicitly denies/i);
});

test('rejects duplicate provider routes and unknown provider adapters', () => {
  const duplicate = `app Demo {
    provider One { adapter "test.echo" route "echo" }
    provider Two { adapter "test.echo" route "echo" }
    fn start() {}
  }`;
  assert.throws(() => compile(duplicate), /Provider route 'echo'.*already handled/i);
  const unknown = `app Demo { provider Bad { adapter "magic.cloud" route "x" } fn start() {} }`;
  assert.throws(() => compile(unknown), /Unknown provider adapter 'magic\.cloud'/);
});

test('test.echo provider executes through the provider runtime without network access', async () => {
  const source = `app Demo {
    ai Assistant { model "echo" privacy local_only }
    provider Echo { adapter "test.echo" route "echo" prefix "Nexu" }
    async fn start() {
      let answer: Result<String, String> = await ask Assistant with "hello"
      match answer {
        ok(value) { print(value) }
        err(reason) { print(reason) }
      }
    }
  }`;
  const { output } = compile(source, 'javascript');
  const dir = await mkdtemp(join(tmpdir(), 'nexu-provider-'));
  const file = join(dir, 'demo.mjs');
  const logs = [];
  const original = console.log;
  try {
    await writeFile(file, output, 'utf8');
    console.log = (...args) => logs.push(args.join(' '));
    const { pathToFileURL } = await import('node:url');
    await import(`${pathToFileURL(file).href}?v=${Date.now()}`);
  } finally {
    console.log = original;
    await rm(dir, { recursive: true, force: true });
  }
  assert.deepEqual(logs, ['Nexu: hello']);
});

test('confirm-gated OpenAI provider fails closed before any network call on console.preview', async () => {
  const source = `app Demo {
    ai Assistant { model "openai" privacy cloud_allowed }
    provider Cloud { adapter "openai.responses" route "openai" }
    host ConfirmHost { adapter "console.preview" provides ui.confirm }
    async fn start() {
      let answer: Result<String, String> = await ask Assistant with "hello"
      match answer {
        ok(value) { print(value) }
        err(reason) { print(reason) }
      }
    }
  }`;
  const { output } = compile(source, 'javascript');
  const dir = await mkdtemp(join(tmpdir(), 'nexu-provider-confirm-'));
  const file = join(dir, 'demo.mjs');
  const logs = [];
  const original = console.log;
  try {
    await writeFile(file, output, 'utf8');
    console.log = (...args) => logs.push(args.join(' '));
    const { pathToFileURL } = await import('node:url');
    await import(`${pathToFileURL(file).href}?v=${Date.now()}`);
  } finally {
    console.log = original;
    await rm(dir, { recursive: true, force: true });
  }
  assert.match(logs[0], /CONFIRMATION REQUIRED.*network\.ai/);
  assert.equal(logs[1], 'Provider approval was not granted for Cloud');
});


test('browser hosts cannot silently bind Node-only provider adapters in a 0.6 single-host build', () => {
  const source = `app Demo {
    provider Cloud { adapter "openai.responses" route "openai" }
    host Browser { adapter "web.dom" provides ui.confirm }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /Node-only adapter 'openai\.responses'.*browser-only/i);
});


test('OpenAI provider cannot redirect arbitrary environment secrets', () => {
  const source = `app Demo {
    provider Cloud { adapter "openai.responses" route "openai" key_env "AWS_SECRET_ACCESS_KEY" }
    host ConfirmHost { adapter "console.preview" provides ui.confirm }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /must use key_env.*OPENAI_API_KEY/i);
});

test('0.6 mounts reusable static components without duplicating app logic', () => {
  const source = `app Demo {
    component BrandHeader {
      column Brand {
        text Title { label: "Demo" aria_label: "Demo title" }
      }
    }
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace { mount BrandHeader Header }
    fn start() {}
  }`;
  const { ast, output } = compile(source, 'typescript');
  assert.deepEqual(ast.analysis.components, ['BrandHeader']);
  assert.equal(ast.analysis.ui.children[0].type, 'component');
  assert.equal(ast.analysis.ui.children[0].component, 'BrandHeader');
  assert.match(output, /"type":"component"/);
});

test('0.6 components stay static and cannot hide events or feature bindings', () => {
  const source = `app Demo {
    component Bad { button Action { label: "Go" on click { print("x") } } }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /Component 'Bad' is static.*events/i);
});

test('0.6 checks screens and navigation targets at compile time', () => {
  const good = `app Demo {
    host Preview { adapter "console.preview" provides ui.render }
    ui Workspace {
      start_screen: Home
      screen Home { button Go { label: "Go" on click { navigate Settings } } }
      screen Settings { text Title { label: "Settings" } }
    }
    fn start() {}
  }`;
  const { ast } = compile(good);
  assert.deepEqual(ast.analysis.ui.screens, ['Home', 'Settings']);
  assert.equal(ast.analysis.ui.properties.start_screen, 'Home');
  const bad = good.replace('navigate Settings', 'navigate Missing');
  assert.throws(() => compile(bad), /unknown navigation screen 'Missing'/i);
});

test('0.6 focus is capability-gated and target checked for focusability', () => {
  const good = `app Demo {
    host Preview { adapter "console.preview" provides ui.render provides ui.focus }
    ui Workspace {
      input Search { label: "Search" }
      button Go { label: "Go" on click { focus Search } }
    }
    fn start() {}
  }`;
  const { ast, output } = compile(good, 'typescript');
  assert.equal(ast.analysis.capabilities.get('ui.focus'), 'allow');
  assert.match(output, /__nexuHostInvoke\("ui\.focus", "ui\.focus"/);
  const bad = `app Demo {
    host Preview { adapter "console.preview" provides ui.render provides ui.focus }
    ui Workspace {
      text Label { label: "Not focusable" }
      button Go { label: "Go" on click { focus Label } }
    }
    fn start() {}
  }`;
  assert.throws(() => compile(bad), /UI node 'Label'.*not focusable/i);
});

test('0.6 typed persistent stores round-trip through the Node host boundary', async () => {
  const source = `app Demo {
    store Preferences { persist local state count: Number = 0 }
    host Preview { adapter "console.preview" provides storage.local }
    async fn start() {
      let value: Number = await load Preferences.count
      print(value)
      save Preferences.count = 7
    }
  }`;
  const { output } = compile(source, 'javascript');
  const dir = await mkdtemp(join(tmpdir(), 'nexu-store-'));
  const file = join(dir, 'demo.mjs');
  await writeFile(file, output, 'utf8');
  const { spawnSync } = await import('node:child_process');
  try {
    // Node may propagate terminal colour settings (for example FORCE_COLOR=1)
    // into spawned programs when the test suite runs in an interactive TTY.
    // Keep the generated-program assertion deterministic without disabling
    // colour for the parent test reporter.
    const childEnv = { ...process.env, FORCE_COLOR: '0' };
    const first = spawnSync(process.execPath, [file], { cwd: dir, encoding: 'utf8', env: childEnv });
    assert.equal(first.status, 0, first.stderr);
    assert.match(first.stdout, /^0\s*$/m);
    const second = spawnSync(process.execPath, [file], { cwd: dir, encoding: 'utf8', env: childEnv });
    assert.equal(second.status, 0, second.stderr);
    assert.match(second.stdout, /^7\s*$/m);
    const persisted = await readFile(join(dir, '.nexu-data', 'Demo_Preferences-count.json'), 'utf8');
    assert.equal(JSON.parse(persisted), 7);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('0.6 persistent stores respect explicit storage denial', () => {
  const source = `app Demo {
    capability storage.local deny
    store Preferences { persist local state theme: String = "dark" }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /Persistent stores require capability 'storage\.local'.*explicitly denies/i);
});

test('0.6 rejects storage.local encrypted true until encryption is actually implemented', () => {
  const source = `app Demo {
    use storage.local { encrypted true scope app }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /cannot set encrypted true.*not encrypted/i);
});

test('0.6 provider catalogue includes production loopback Ollama chat', async () => {
  const { listProviderAdapters } = await import('../compiler/provider-adapters.mjs');
  const adapter = listProviderAdapters().find(x => x.id === 'ollama.chat');
  assert.ok(adapter);
  assert.equal(adapter.testOnly, false);
  assert.equal(adapter.operation, 'ai.ask');
  assert.deepEqual(adapter.requirements.map(x => `${x.path}:${x.policy}`), ['ai.local:allow']);
});

test('0.6 Ollama provider rejects non-loopback endpoints', () => {
  const source = `app Demo {
    provider Local { adapter "ollama.chat" route "local.qwen" model "qwen3:8b" base_url "https://example.com" }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /ollama\.chat base_url must be plain HTTP on localhost/i);
});

test('0.6 Ollama provider executes a local AI request through the provider runtime', async () => {
  const { createServer } = await import('node:http');
  let requestBody = null;
  const server = createServer(async (req, res) => {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    requestBody = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ message: { role: 'assistant', content: 'local qwen reply' }, done: true }));
  });
  await new Promise((resolvePromise, reject) => server.listen(0, '127.0.0.1', error => error ? reject(error) : resolvePromise()));
  const address = server.address();
  const source = `app Demo {
    ai Assistant { model "local.qwen" privacy local_only }
    provider Local { adapter "ollama.chat" route "local.qwen" model "qwen3:8b" base_url "http://127.0.0.1:${address.port}" }
    async fn start() {
      let result: Result<String, String> = await ask Assistant with "ping"
      match result { ok(value) { print(value) } err(reason) { print(reason) } }
    }
  }`;
  const { output } = compile(source, 'javascript');
  const dir = await mkdtemp(join(tmpdir(), 'nexu-ollama-'));
  const file = join(dir, 'demo.mjs');
  const logs = [];
  const original = console.log;
  try {
    await writeFile(file, output, 'utf8');
    console.log = (...args) => logs.push(args.join(' '));
    const { pathToFileURL } = await import('node:url');
    await import(`${pathToFileURL(file).href}?v=${Date.now()}`);
    assert.equal(logs.at(-1), 'local qwen reply');
    assert.equal(requestBody.model, 'qwen3:8b');
    assert.equal(requestBody.messages[0].content, 'ping');
    assert.equal(requestBody.stream, false);
  } finally {
    console.log = original;
    await new Promise(resolvePromise => server.close(() => resolvePromise()));
    await rm(dir, { recursive: true, force: true });
  }
});

test('0.6 browser host cannot silently bind the Node-only Ollama bridge', () => {
  const source = `app Demo {
    provider Local { adapter "ollama.chat" route "local.qwen" }
    host Browser { adapter "web.dom" provides ui.render }
    ui Workspace { text Label { label: "Hi" } }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /Node-only adapter 'ollama\.chat'.*browser-only/i);
});

test('0.6 local Ollama provider blocks cloud-model routes', () => {
  const source = `app Demo {
    provider Local { adapter "ollama.chat" route "local.qwen" model "gemma4:cloud" }
    fn start() {}
  }`;
  assert.throws(() => compile(source), /cannot use Ollama cloud model.*local-only provider/i);
});

test('0.6 persistent stores reject corrupted runtime values instead of weakening types', async () => {
  const source = `app Demo {
    store Preferences { persist local state count: Number = 0 }
    host Preview { adapter "console.preview" provides storage.local }
    async fn start() { let value: Number = await load Preferences.count print(value) }
  }`;
  const { output } = compile(source, 'javascript');
  const dir = await mkdtemp(join(tmpdir(), 'nexu-store-corrupt-'));
  const file = join(dir, 'demo.mjs');
  const dataDir = join(dir, '.nexu-data');
  const { mkdir } = await import('node:fs/promises');
  const { spawnSync } = await import('node:child_process');
  try {
    await mkdir(dataDir, { recursive: true });
    await writeFile(join(dataDir, 'Demo_Preferences-count.json'), JSON.stringify('wrong-type'), 'utf8');
    await writeFile(file, output, 'utf8');
    const result = spawnSync(process.execPath, [file], { cwd: dir, encoding: 'utf8', env: { ...process.env, FORCE_COLOR: '0' } });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /Persisted Nexu store value Preferences\.count does not match Number/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('0.6 Local AI Doctor verifies Ollama version and configured model through loopback', async () => {
  const { createServer } = await import('node:http');
  const server = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    if (req.url === '/api/version') res.end(JSON.stringify({ version: 'test-ollama' }));
    else if (req.url === '/api/tags') res.end(JSON.stringify({ models: [{ name: 'qwen3:8b', model: 'qwen3:8b' }] }));
    else { res.statusCode = 404; res.end('{}'); }
  });
  await new Promise((resolvePromise, reject) => server.listen(0, '127.0.0.1', error => error ? reject(error) : resolvePromise()));
  const address = server.address();
  const dir = await mkdtemp(join(tmpdir(), 'nexu-doctor-'));
  const sourceFile = join(dir, 'demo.nex');
  const source = `app Demo {
    provider Local { adapter "ollama.chat" route "local.qwen" model "qwen3:8b" base_url "http://127.0.0.1:${address.port}" }
    fn start() {}
  }`;
  const { spawn } = await import('node:child_process');
  try {
    await writeFile(sourceFile, source, 'utf8');
    const child = spawn(process.execPath, [join(process.cwd(), 'compiler', 'cli.mjs'), 'local-ai', 'doctor', sourceFile], { cwd: process.cwd(), stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk; });
    child.stderr.on('data', chunk => { stderr += chunk; });
    const code = await new Promise(resolvePromise => child.on('close', resolvePromise));
    assert.equal(code, 0, stderr);
    assert.match(stdout, /OLLAMA Local .*version=test-ollama/);
    assert.match(stdout, /MODEL qwen3:8b READY/);
    assert.match(stdout, /PASS Local AI provider doctor/);
  } finally {
    await new Promise(resolvePromise => server.close(() => resolvePromise()));
    await rm(dir, { recursive: true, force: true });
  }
});
