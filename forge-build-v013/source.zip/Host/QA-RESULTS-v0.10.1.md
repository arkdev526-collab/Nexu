# QA Results — v0.10.1 Android Prerequisite Auto-Repair

## Automated regression
- Nexu AI 3D Forge + protected Nexu Language: 141 / 141 PASS.
- New v0.10.1 tests cover official dependency-target use, read-only Doctor behaviour, ADB stderr handling and coherent Android versioning.

## Static gates
- Android project targets `net10.0-android`.
- Android app version: 0.10.1, version code 101.
- `InstallAndroidDependencies` is present only in the explicit build/repair workflow, not the read-only Doctor.
- Android SDK directory and Java SDK directory are explicit.
- API 36 is revalidated by Doctor.
- The previous direct `& $adbPath devices 2>$null` failure pattern is removed.
- ADB daemon stderr is informational unless the native process exits non-zero.

## Environment boundary
This Linux/container build environment cannot execute Windows PowerShell, the Windows Android SDK manager, ADB against a physical Android device, or the final .NET MAUI Android build. The real Windows run remains the qualification gate for the new auto-repair path.
