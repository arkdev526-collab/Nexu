# Full Pack Status — v0.10.1

**Product:** Nexu AI 3D Forge
**Patch:** Android Prerequisite Auto-Repair
**Status:** Candidate

The full pack contains the v0.10 Universal Creation / FastForge / Studio source plus the v0.10.1 Android build repair. It is intended to replace the v0.10.0 handoff for subsequent Windows/Android build testing.

## Primary Android entry point
`2-BUILD-INSTALL-ANDROID-v0.10.1.cmd`

The workflow now checks prerequisites, repairs JDK/API dependencies when needed, builds the APK and installs it if exactly one authorised Android device is connected.
