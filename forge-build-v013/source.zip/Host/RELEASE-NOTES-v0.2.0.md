# Nexu AI 3D Forge v0.2.0 — Asset Quality Foundation Candidate

v0.2.0 promotes model quality over adding a large catalogue of shallow primitive templates. The first deep asset family is the wooden barrel/cask, selected because the target-PC v0.1.3 barrel proved the entire generation/export pipeline but exposed clear silhouette, construction, material, collision and budget-quality gaps.

The new barrel is generated from individual staves around a curved belly profile, separate plank ends, metal hoops and rivets. A deterministic geometry-budget controller can adjust bounded construction detail towards the requested triangle count. The editable `.blend` retains source pieces while exported FBX geometry is combined and triangulated as one Static Mesh plus custom `UCX_` collision.

Every build can now create five automatic inspection renders and a scored quality report. This is the deterministic foundation for a later visual self-critique loop; v0.2.0 does not falsely claim that the local text model can see and judge those images yet.
