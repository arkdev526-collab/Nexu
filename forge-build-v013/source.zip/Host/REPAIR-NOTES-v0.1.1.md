# Nexu AI 3D Forge v0.1.1 — Terminal Colour Regression Repair

**Date:** 17 August 2026  
**Parent language:** Nexu Language 0.6.0 remains protected and unchanged in version.

## Symptom

`SETUP-AND-VERIFY.cmd` could report 69/70 tests on an interactive coloured terminal. The failing persistence test received `\x1B[33m0\x1B[39m\n` instead of plain `0\n`.

## Root cause

The test launches generated JavaScript with `spawnSync()` and previously inherited all terminal environment variables from the Node test runner. With colour forced/enabled, Node formats numeric `console.log()` values using ANSI sequences. The test then matched the raw bytes against a plain-number expression.

This was a test-harness regression, not a persistent-store data failure.

## Repair

Only generated child processes used by persistence runtime assertions now run with `FORCE_COLOR=0`. Parent test output remains coloured when the terminal supports it.

## Why this repair

Node documents `FORCE_COLOR=0` as the supported way to disable colour for a process. The repair controls the exact child whose stdout is machine-asserted instead of globally disabling colour or weakening the assertion.

## Regression gate

The suite must pass both normally and when the parent is explicitly launched with `FORCE_COLOR=1`.
