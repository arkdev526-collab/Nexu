# Nexu AI 3D Forge v0.4.0 — Windows App Foundation Candidate

## Headline

Forge is now packaged as an installed Windows product rather than a folder of launch scripts.

## Delivered

- DCC-inspired Forge / Assets / Activity / System / Preferences workspace;
- dedicated creation brief, central inspection viewport and evidence inspector;
- persistent local asset library outside the application install directory;
- per-user Windows installation with Start-menu/Desktop shortcuts;
- hidden normal launcher with no persistent command window;
- Windows Installed Apps / uninstall registration;
- one-file setup package that performs install, repair and update-in-place;
- update-safe versioned application directories with previous-version retention;
- graceful shutdown of the prior local Studio service during updates;
- optional import of previous portable Forge Desktop output;
- Blender and Node dependency checks without weakening security or changing the protected runtime pins.

## Update boundary

v0.4.0 deliberately uses installer-based updates. A network background updater is not enabled until Sumero Studio has a verified HTTPS release feed and release-signing path. This avoids inventing or trusting an unverified update endpoint.
