# Nexu AI 3D Forge v0.10.0 — QA Results

**Status:** automated/structural candidate QA

## Passed

- Full Forge + protected Nexu Language deterministic test suite: 138/138 PASS.
- Nexu AI semantic check: PASS.
- Nexu AI TypeScript generation: PASS.
- JavaScript/ESM syntax checks: PASS.
- Blender worker Python compile: PASS.
- Go source formatting: PASS.
- 43 grammar catalogue gate: PASS.
- 12 new object grammar planner gate: PASS.
- 387 recognised creation phrases/modifiers gate: PASS.
- typo/action normalisation gate: PASS.
- Fast/Balanced/Maximum Quality policy gate: PASS.
- exact-recipe SHA-256 cache fingerprint gate: PASS.
- stale-cache invalidation: PASS.
- Brotli cache-index round trip: PASS.
- minimum 14px desktop CSS gate: PASS.
- prompt-as-data / arbitrary-code gate: PASS.
- runtime payload includes new modules: PASS.

## Not physically verified in this environment

- Blender 5.2 execution of the 12 new grammars.
- actual FastForge cache-hit elapsed time on Windows.
- `.blend` compressed vs uncompressed byte savings.
- Windows installer/update/repair cycle for v0.10.0.
- visual/high-DPI/accessibility inspection of the installed Home/Prompt Coach surfaces.

These remain target-machine release gates and prevent a Qualified Release claim.
