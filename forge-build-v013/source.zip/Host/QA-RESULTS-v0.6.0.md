# QA Results — Nexu AI 3D Forge v0.6.0

## Passed in the available build environment
- Nexu Language regression suite: 70 / 70 PASS.
- Nexu AI 3D Forge suite: 36 / 36 PASS.
- Total deterministic tests: 106 / 106 PASS.
- Nexu AI semantic check: PASS.
- Nexu AI TypeScript generation: PASS.
- JavaScript syntax checks: PASS.
- Blender worker Python compile: PASS.
- Material request validation/security tests: PASS.
- Minimum 14 px declared UI typography gate: PASS.
- Generation progress UI contract: PASS.
- PBR texture-output worker contract: PASS.

## Still requires Windows target verification
- v0.6.0 installer update from installed v0.5.1;
- actual Blender 5.2 material texture generation;
- rendered material appearance and texture-map linkage;
- normal/roughness/metallic export behaviour through real FBX/GLB;
- Windows 100–200% display scaling and keyboard accessibility;
- ASA DevKit import/material check.
