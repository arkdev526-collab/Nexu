@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>&1
if errorlevel 1 (
  echo [FAIL] Node.js was not found.
  echo Run SETUP-AND-VERIFY.cmd first.
  pause
  exit /b 2
)
node.exe "3d-forge\studio-launcher.mjs"
if errorlevel 1 (
  echo.
  echo [FAIL] Nexu AI 3D Forge Studio could not start.
  echo See 3d-forge\logs\studio-server.log
  pause
  exit /b 1
)
exit /b 0
