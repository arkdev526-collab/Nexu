@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ===============================================================
echo NEXU AI 3D FORGE v0.13.0 - WINDOWS BUILD + INSTALL
echo Execution-policy-safe builder - no unsigned PowerShell scripts
echo ===============================================================
echo.

set "GO_VERSION=1.26.6"
set "GO_SHA256=5b6c5b556525810463b5c897b50dc7a82d6a3dc0bfaf55d990a7e9f31d6b2318"
set "GO_URL=https://go.dev/dl/go1.26.6.windows-amd64.zip"
set "TOOLS=%LOCALAPPDATA%\Sumero Studio\BuildTools"
set "GO_ROOT=%TOOLS%\go%GO_VERSION%"
set "GO_ZIP=%TOOLS%\go%GO_VERSION%.windows-amd64.zip"
set "GO_EXE=%GO_ROOT%\go\bin\go.exe"

if not exist "%TOOLS%" mkdir "%TOOLS%" >nul 2>nul

if not exist "%GO_EXE%" goto :bootstrap_go
call :verify_go
if errorlevel 1 goto :bootstrap_go
goto :build

:bootstrap_go
where curl.exe >nul 2>nul || (echo ERROR: Windows curl.exe was not found.& exit /b 20)
where tar.exe >nul 2>nul || (echo ERROR: Windows tar.exe was not found.& exit /b 21)

echo Downloading official Go %GO_VERSION% x64 from go.dev...
if exist "%GO_ZIP%.part" del /q "%GO_ZIP%.part" >nul 2>nul
curl.exe --fail --location --proto "=https" --tlsv1.2 --retry 2 --output "%GO_ZIP%.part" "%GO_URL%"
if errorlevel 1 (echo ERROR: Go download failed.& exit /b 22)
move /y "%GO_ZIP%.part" "%GO_ZIP%" >nul
call :verify_zip
if errorlevel 1 (del /q "%GO_ZIP%" >nul 2>nul& exit /b 23)
if exist "%GO_ROOT%" rmdir /s /q "%GO_ROOT%"
mkdir "%GO_ROOT%" >nul 2>nul

echo Extracting verified Go toolchain...
tar.exe -xf "%GO_ZIP%" -C "%GO_ROOT%"
if errorlevel 1 (echo ERROR: Go extraction failed.& exit /b 24)
call :verify_go
if errorlevel 1 exit /b 25
goto :build

:verify_zip
if not exist "%GO_ZIP%" (echo ERROR: Go archive is missing.& exit /b 1)
for /f "usebackq delims=" %%H in (`certutil.exe -hashfile "%GO_ZIP%" SHA256 ^| findstr /i /c:"%GO_SHA256%"`) do set "HASH_OK=1"
if not defined HASH_OK (echo ERROR: Go archive SHA-256 verification failed.& exit /b 1)
echo PASS: Go archive SHA-256 verified.
exit /b 0

:verify_go
if not exist "%GO_EXE%" exit /b 1
for /f "delims=" %%V in ('"%GO_EXE%" version 2^>nul') do set "GO_ACTUAL=%%V"
echo %GO_ACTUAL% | findstr /i /c:"go1.26.6" >nul
if errorlevel 1 (echo ERROR: Expected Go 1.26.6, found %GO_ACTUAL%& exit /b 1)
echo PASS: %GO_ACTUAL%
exit /b 0

:build
set "NEXU_GO_EXE=%GO_EXE%"
set "GOTOOLCHAIN=local"
"%GO_EXE%" run "%~dp0packaging\build-windows-candidate.go" -install
set "CODE=%ERRORLEVEL%"
echo.
if not "%CODE%"=="0" echo BUILD FAILED. See the message above.
if "%CODE%"=="0" echo Windows candidate built and Setup launched.
pause
exit /b %CODE%
