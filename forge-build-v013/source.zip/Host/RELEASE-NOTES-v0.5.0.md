# Nexu AI 3D Forge v0.5.0 — Release Notes

**Status:** Creator Intelligence & Reference Workflow Candidate

## New

- Live interactive GLB viewport with DCC-style inspection controls.
- Brief Interpreter with explicit period/style conflict reporting.
- Structured conversational refinement with previewable recipe diffs.
- Non-destructive asset versions, undo/redo, duplicate, favourites, display names, tags, trash and restore.
- Local reference board for PNG/JPEG/WebP with view classification, opacity, rotate/zoom/remove and bounded local palette evidence.
- Expanded READY / READY WITH WARNINGS / BLOCKED game-ready inspector.
- Geometry diagnostics for vertices/faces/edges, non-manifold, loose and isolated geometry, UV/material counts and transforms.
- Collision GLB and LOD GLB generation for viewport inspection.
- Stage-based queue progress and real cancellation; no invented percentages.
- System/Update Centre with local fixture feed plus production HTTPS/SHA contract.
- Rollback support to a retained previous installed version.
- Real Windows GUI launcher/Setup source and one-click Windows candidate builder pinned to Go 1.26.5.

## Preserved

- Proven Nexu3D → Blender architecture.
- Node 24.19.x / Blender 5.2.x runtime baseline.
- Unreal/ASA profile, FBX/GLB/BLEND exports, LODs and UCX collision.
- Local-first operation and explicit cloud separation.
- User assets outside the installed application directory.

## Deferred

- Full native WinUI/WebView2-owned shell.
- Neural image-to-3D model installation.
- Live production update endpoint.
- Character/rigging/animation suite.
- Physical ASA DevKit import qualification.
