# Nexu AI 3D Forge v0.9.0 — Technology Verification

**Verification date:** 23 August 2026

## Preserved production pins
- Node.js: 24.19.x production line retained; no runtime migration required by v0.9.
- Blender: 5.2.0 LTS retained. Blender Foundation lists Blender 5.2 LTS as released 14 July 2026 and supported until July 2028.
- Windows native build: Go 1.26.6; official Windows x64 ZIP SHA-256 `5b6c5b556525810463b5c897b50dc7a82d6a3dc0bfaf55d990a7e9f31d6b2318`.

## Organic generation decision
v0.9 uses Blender's supported remeshing capabilities rather than introducing a new external geometry dependency. Blender's Remesh modifier supports `VOXEL` mode and a `voxel_size`; Blender documentation describes voxel remesh as producing a manifold mesh from source volume, with lower voxel sizes preserving more detail at higher density.

## Why this is appropriate
- no new paid dependency;
- no cloud service;
- no model-weight licence/provenance problem;
- uses the existing trusted Blender worker;
- deterministic recipe inputs remain inspectable and reversible;
- external technology surface does not expand merely to support the new asset class.

## Neural provider decision
No external neural 3D provider is shipped in v0.9. The user requirement is final/free/local technology only. A provider remains blocked until its complete Windows runtime, model provenance/licence, versioning, hashes, installer/remove path and hardware behaviour can be qualified reproducibly.

## Source references
- Blender 5.2 LTS: https://www.blender.org/releases/5-2/
- Blender Remesh / voxel behaviour: https://docs.blender.org/manual/en/5.2/modeling/modifiers/generate/remesh.html
- Go downloads: https://go.dev/dl/
