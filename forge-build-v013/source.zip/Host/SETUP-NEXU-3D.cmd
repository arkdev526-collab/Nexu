@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Nexu AI 3D Forge - Blender Setup
node 3d-forge\setup-windows.mjs
set "NEXU_EXIT=%ERRORLEVEL%"
echo.
if "%NEXU_EXIT%"=="0" (
  echo ============================================================
  echo  NEXU 3D SETUP FINISHED
  echo ============================================================
) else (
  echo ============================================================
  echo  NEXU 3D SETUP STOPPED - ERROR CODE %NEXU_EXIT%
  echo ============================================================
)
echo.
pause
exit /b %NEXU_EXIT%
