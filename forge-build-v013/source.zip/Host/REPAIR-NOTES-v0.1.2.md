# Nexu AI 3D Forge v0.1.2 — Interactive Build Diagnostics Repair

## Trigger
On the target Windows PC, the v0.1.1 interactive `BUILD-NEXU-3D.cmd` window disappeared immediately after the user entered the recommended first model prompt.

## Root issue
The v0.1.1 CMD launcher propagated any non-zero Blender/build exit code immediately and had no terminal hold or durable build log. A legitimate worker/runtime error therefore appeared to the user as a crash and destroyed the diagnostic evidence needed for the next repair.

## Repair
- CMD launcher now keeps the console open on both success and failure.
- Prompt capture moved from CMD `set /p` into Node's `readline/promises`, avoiding shell interpretation of prompt characters.
- Interactive build performs its own Node + Blender preflight before accepting work.
- Planner summary is shown before Blender starts.
- Every build writes `3d-forge/logs/last-build.log` plus a timestamped log.
- Error text and Blender worker stderr are preserved in the log.
- Existing non-interactive `build` command also writes diagnostics.
- No arbitrary shell execution or AI-generated Python was introduced.

## Verification boundary
The build workspace does not contain Blender, so real Blender export remains target-PC verification. The repair can prove that missing/failed Blender execution is captured and reported rather than causing a disappearing terminal.
