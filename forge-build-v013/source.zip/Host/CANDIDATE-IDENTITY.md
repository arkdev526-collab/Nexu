# Candidate identity

**Product:** Nexu AI 3D Forge  
**Version:** 0.10.1  
**Milestone:** Android Prerequisite Auto-Repair  
**State:** Candidate implementation — automated regression passed; physical Windows Android dependency repair/build/install qualification pending.  
**Protected predecessor:** v0.10.0 Universal Creation Intelligence, Fast Cache & Full Studio UX Candidate.  
**Parent language baseline:** Nexu Language 0.6.0 unchanged.
