using Microsoft.Extensions.DependencyInjection;
using NexuAI3DForge.Android.Services;

namespace NexuAI3DForge.Android;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        builder.Services.AddSingleton<ForgeSession>();
        return builder.Build();
    }
}
