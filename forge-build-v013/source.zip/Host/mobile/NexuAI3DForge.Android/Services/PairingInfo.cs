using System.Net;

namespace NexuAI3DForge.Android.Services;

public sealed record PairingInfo(string Host, int Port, string OfferCode, string SecretCode)
{
    public static PairingInfo Parse(string host, string? portText, string pairingCode)
    {
        host = host.Trim();
        if (!IPAddress.TryParse(host, out var ip) || ip.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork || !IsPrivate(ip))
            throw new InvalidOperationException("Use the private IPv4 address shown by Windows Forge, for example 192.168.1.20.");
        var port = int.TryParse(portText, out var parsed) ? parsed : 53971;
        if (port is < 1024 or > 65535) throw new InvalidOperationException("Companion port is invalid.");
        var compact = new string(pairingCode.ToUpperInvariant().Where(char.IsLetterOrDigit).ToArray());
        if (compact.Length != 24) throw new InvalidOperationException("Pairing code should contain the 8-character offer code plus the 16-character secret.");
        return new(host, port, compact[..8], compact[8..]);
    }

    public static PairingInfo ParseUri(string value)
    {
        if (!Uri.TryCreate(value.Trim(), UriKind.Absolute, out var uri) || !uri.Scheme.Equals("nexuforge", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("This is not a Nexu Forge pairing link.");
        var q = uri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries)
            .Select(p => p.Split('=', 2)).Where(p => p.Length == 2)
            .ToDictionary(p => Uri.UnescapeDataString(p[0]), p => Uri.UnescapeDataString(p[1]), StringComparer.OrdinalIgnoreCase);
        if (!q.TryGetValue("host", out var host) || !q.TryGetValue("offer", out var offer) || !q.TryGetValue("secret", out var secret))
            throw new InvalidOperationException("Pairing link is incomplete.");
        return Parse(host, q.GetValueOrDefault("port", "53971"), offer + secret);
    }

    private static bool IsPrivate(IPAddress ip)
    {
        var b = ip.GetAddressBytes();
        return b[0] == 10 || (b[0] == 192 && b[1] == 168) || (b[0] == 172 && b[1] is >= 16 and <= 31) || (b[0] == 169 && b[1] == 254) || IPAddress.IsLoopback(ip);
    }
}
