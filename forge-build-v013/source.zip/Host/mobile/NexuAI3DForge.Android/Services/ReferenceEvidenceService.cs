using Android.Graphics;
using NexuAI3DForge.Android.Models;

namespace NexuAI3DForge.Android.Services;

public static class ReferenceEvidenceService
{
    public static async Task<(byte[] Bytes, string Mime, ReferenceEvidence Evidence)> ReadAsync(FileResult file, string view)
    {
        await using var stream = await file.OpenReadAsync();
        using var ms = new MemoryStream();
        await stream.CopyToAsync(ms);
        var bytes = ms.ToArray();
        if (bytes.Length is 0 or > 12 * 1024 * 1024) throw new InvalidOperationException("Reference images are limited to 12 MB.");
        using var bitmap = BitmapFactory.DecodeByteArray(bytes, 0, bytes.Length) ?? throw new InvalidOperationException("Android could not decode this reference image.");
        long r = 0, g = 0, b = 0, count = 0;
        var step = Math.Max(1, Math.Max(bitmap.Width, bitmap.Height) / 96);
        for (var y = 0; y < bitmap.Height; y += step)
        for (var x = 0; x < bitmap.Width; x += step)
        {
            var pixel = bitmap.GetPixel(x, y); r += (pixel >> 16) & 0xff; g += (pixel >> 8) & 0xff; b += pixel & 0xff; count++;
        }
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var mime = ext switch { ".png" => "image/png", ".webp" => "image/webp", ".jpg" or ".jpeg" => "image/jpeg", _ => throw new InvalidOperationException("Use PNG, JPEG or WebP references.") };
        return (bytes, mime, new ReferenceEvidence { MeanRgb = [r / (255d * count), g / (255d * count), b / (255d * count)], Width = bitmap.Width, Height = bitmap.Height, View = view });
    }
}
