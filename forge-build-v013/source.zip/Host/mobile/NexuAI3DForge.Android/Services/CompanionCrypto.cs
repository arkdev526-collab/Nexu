using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace NexuAI3DForge.Android.Services;

public sealed class CompanionEnvelope
{
    [JsonPropertyName("v")] public int Version { get; set; } = 1;
    [JsonPropertyName("ts")] public long Timestamp { get; set; }
    [JsonPropertyName("nonce")] public string Nonce { get; set; } = string.Empty;
    [JsonPropertyName("iv")] public string Iv { get; set; } = string.Empty;
    [JsonPropertyName("ciphertext")] public string Ciphertext { get; set; } = string.Empty;
    [JsonPropertyName("tag")] public string Tag { get; set; } = string.Empty;
}

public static class CompanionCrypto
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public static byte[] DerivePairingKey(string secretCode)
    {
        var normalized = new string(secretCode.ToUpperInvariant().Where(c => char.IsLetterOrDigit(c)).ToArray());
        if (normalized.Length != 16) throw new InvalidOperationException("Pairing secret must contain 16 characters.");
        return SHA256.HashData(Encoding.UTF8.GetBytes($"nexu-forge-pair-v1:{normalized}"));
    }

    public static CompanionEnvelope Seal(byte[] key, object payload, string context)
    {
        if (key.Length != 32) throw new InvalidOperationException("Companion key must be 32 bytes.");
        var env = new CompanionEnvelope
        {
            Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            Nonce = Base64Url(RandomNumberGenerator.GetBytes(16)),
            Iv = Base64Url(RandomNumberGenerator.GetBytes(12))
        };
        var plain = JsonSerializer.SerializeToUtf8Bytes(payload, Json);
        var cipher = new byte[plain.Length];
        var tag = new byte[16];
        using var aes = new AesGcm(key, 16);
        aes.Encrypt(FromBase64Url(env.Iv), plain, cipher, tag, Aad(context, env));
        env.Ciphertext = Base64Url(cipher);
        env.Tag = Base64Url(tag);
        return env;
    }

    public static T Open<T>(byte[] key, CompanionEnvelope env, string context)
    {
        if (env.Version != 1 || Math.Abs(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - env.Timestamp) > 5 * 60 * 1000)
            throw new InvalidOperationException("Companion response expired.");
        var cipher = FromBase64Url(env.Ciphertext);
        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(key, 16);
        aes.Decrypt(FromBase64Url(env.Iv), cipher, FromBase64Url(env.Tag), plain, Aad(context, env));
        return JsonSerializer.Deserialize<T>(plain, Json) ?? throw new InvalidOperationException("Companion response was empty.");
    }

    public static string Base64Url(byte[] bytes) => Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    public static byte[] FromBase64Url(string value)
    {
        var s = value.Replace('-', '+').Replace('_', '/');
        s += s.Length % 4 switch { 2 => "==", 3 => "=", _ => string.Empty };
        return Convert.FromBase64String(s);
    }
    private static byte[] Aad(string context, CompanionEnvelope e) => Encoding.UTF8.GetBytes($"{context}|{e.Version}|{e.Timestamp}|{e.Nonce}");
}
