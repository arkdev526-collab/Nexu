using System.Collections.ObjectModel;
using System.Text.Json;
using NexuAI3DForge.Android.Models;

namespace NexuAI3DForge.Android.Services;

public sealed class ForgeSession
{
    public ForgeCompanionClient Client { get; } = new();
    public ObservableCollection<ForgeAsset> Assets { get; } = [];
    public ObservableCollection<ForgeJob> Jobs { get; } = [];
    public ForgeAsset? SelectedAsset { get; set; }
    public event EventHandler? StateChanged;

    public async Task InitialiseAsync() { await Client.RestoreAsync(); await RefreshAsync(); }
    public async Task RefreshAsync(CancellationToken token = default)
    {
        if (!Client.IsPaired) { StateChanged?.Invoke(this, EventArgs.Empty); return; }
        try { await Task.WhenAll(RefreshAssetsAsync(token), RefreshJobsAsync(token)); } catch { }
        StateChanged?.Invoke(this, EventArgs.Empty);
    }
    public async Task RefreshAssetsAsync(CancellationToken token = default)
    {
        var result = await Client.RpcAsync("assets", cancellationToken: token);
        var list = new List<ForgeAsset>();
        foreach (var x in result.GetProperty("assets").EnumerateArray())
        {
            list.Add(new ForgeAsset
            {
                Id = S(x,"id"), Directory = S(x,"directory"), AssetName = S(x,"assetName"), DisplayName = S(x,"displayName", S(x,"assetName")), Profile = S(x,"profile"),
                Triangles = I(x,"triangles"), Vertices = I(x,"vertices"), TargetTriangles = I(x,"targetTriangles"), LodCount = I(x,"lodCount"), QualityScore = D(x,"qualityScore"), QaLabel = S(x,"qaLabel"), CollisionCreated = B(x,"collisionCreated"),
                ModifiedAt = DateTimeOffset.TryParse(S(x,"modifiedAt"), out var d) ? d : null
            });
        }
        MainThread.BeginInvokeOnMainThread(() => { Assets.Clear(); foreach (var a in list) Assets.Add(a); SelectedAsset ??= Assets.FirstOrDefault(); });
    }
    public async Task RefreshJobsAsync(CancellationToken token = default)
    {
        var result = await Client.RpcAsync("jobs", cancellationToken: token); var list = new List<ForgeJob>();
        foreach (var x in result.GetProperty("jobs").EnumerateArray())
        {
            var p = x.TryGetProperty("progress", out var progress) ? progress : default;
            list.Add(new ForgeJob { Id=S(x,"id"), AssetName=S(x,"assetName",S(x,"prompt")), Prompt=S(x,"prompt"), Status=S(x,"status"), Stage=S(x,"stage"), ProgressPercent=p.ValueKind==JsonValueKind.Object?I(p,"percent"):0, StageIndex=p.ValueKind==JsonValueKind.Object?I(p,"index"):0, StageTotal=p.ValueKind==JsonValueKind.Object?I(p,"total",7):7, QueuePosition=I(x,"queuePosition") });
        }
        MainThread.BeginInvokeOnMainThread(() => { Jobs.Clear(); foreach (var j in list) Jobs.Add(j); });
    }
    private static string S(JsonElement e,string p,string d="")=>e.TryGetProperty(p,out var v)&&v.ValueKind==JsonValueKind.String?v.GetString()??d:d;
    private static int I(JsonElement e,string p,int d=0)=>e.TryGetProperty(p,out var v)&&v.TryGetInt32(out var n)?n:d;
    private static double? D(JsonElement e,string p)=>e.TryGetProperty(p,out var v)&&v.TryGetDouble(out var n)?n:null;
    private static bool B(JsonElement e,string p)=>e.TryGetProperty(p,out var v) && (v.ValueKind is JsonValueKind.True or JsonValueKind.False) && v.GetBoolean();
}
