using System.Net.Http.Json;
using System.Text.Json;

namespace NexuAI3DForge.Android.Services;

public sealed class ForgeCompanionClient
{
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);
    private HttpClient? _http;
    private byte[]? _deviceSecret;
    private string? _deviceId;
    public string? Host { get; private set; }
    public int Port { get; private set; }
    public bool IsPaired => _http is not null && _deviceSecret is { Length: 32 } && !string.IsNullOrWhiteSpace(_deviceId);

    public async Task RestoreAsync()
    {
        var host = await SecureStorage.Default.GetAsync("forge.host");
        var port = await SecureStorage.Default.GetAsync("forge.port");
        var id = await SecureStorage.Default.GetAsync("forge.deviceId");
        var secret = await SecureStorage.Default.GetAsync("forge.deviceSecret");
        if (string.IsNullOrWhiteSpace(host) || !int.TryParse(port, out var p) || string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(secret)) return;
        Configure(host, p); _deviceId = id; _deviceSecret = CompanionCrypto.FromBase64Url(secret);
    }

    public async Task PairAsync(PairingInfo info, string deviceName)
    {
        Configure(info.Host, info.Port);
        var key = CompanionCrypto.DerivePairingKey(info.SecretCode);
        var deviceId = "android-" + Guid.NewGuid().ToString("N");
        var envelope = CompanionCrypto.Seal(key, new { deviceId, name = deviceName }, $"pair:{info.OfferCode}");
        using var response = await _http!.PostAsJsonAsync("companion/v1/pair", new { offer = info.OfferCode, envelope }, _json);
        var root = await ReadRootAsync(response);
        var responseEnvelope = root.GetProperty("envelope").Deserialize<CompanionEnvelope>(_json) ?? throw new InvalidOperationException("Pairing response was invalid.");
        var result = CompanionCrypto.Open<JsonElement>(key, responseEnvelope, $"pair:{info.OfferCode}:{envelope.Nonce}");
        _deviceId = result.GetProperty("deviceId").GetString() ?? deviceId;
        _deviceSecret = CompanionCrypto.FromBase64Url(result.GetProperty("deviceSecret").GetString() ?? throw new InvalidOperationException("Pairing secret missing."));
        await SecureStorage.Default.SetAsync("forge.host", info.Host);
        await SecureStorage.Default.SetAsync("forge.port", info.Port.ToString());
        await SecureStorage.Default.SetAsync("forge.deviceId", _deviceId);
        await SecureStorage.Default.SetAsync("forge.deviceSecret", CompanionCrypto.Base64Url(_deviceSecret));
    }

    public async Task<JsonElement> RpcAsync(string method, object? parameters = null, CancellationToken cancellationToken = default)
    {
        EnsurePaired();
        var envelope = CompanionCrypto.Seal(_deviceSecret!, new { method, @params = parameters ?? new { } }, $"rpc:{_deviceId}");
        using var response = await _http!.PostAsJsonAsync("companion/v1/rpc", new { deviceId = _deviceId, envelope }, _json, cancellationToken);
        var root = await ReadRootAsync(response, cancellationToken);
        var responseEnvelope = root.GetProperty("envelope").Deserialize<CompanionEnvelope>(_json) ?? throw new InvalidOperationException("Companion response was invalid.");
        var opened = CompanionCrypto.Open<JsonElement>(_deviceSecret!, responseEnvelope, $"rpc:{_deviceId}:{envelope.Nonce}");
        return opened.GetProperty("result").Clone();
    }

    public async Task<bool> HealthAsync(CancellationToken cancellationToken = default)
    {
        if (_http is null) return false;
        try { using var response = await _http.GetAsync("companion/v1/health", cancellationToken); return response.IsSuccessStatusCode; }
        catch { return false; }
    }

    public async Task ForgetAsync()
    {
        _http?.Dispose(); _http = null; _deviceSecret = null; _deviceId = null; Host = null; Port = 0;
        foreach (var key in new[] { "forge.host", "forge.port", "forge.deviceId", "forge.deviceSecret" }) SecureStorage.Default.Remove(key);
        await Task.CompletedTask;
    }

    private void Configure(string host, int port)
    {
        Host = host; Port = port;
        _http?.Dispose();
        _http = new HttpClient { BaseAddress = new Uri($"http://{host}:{port}/"), Timeout = TimeSpan.FromSeconds(35) };
    }
    private void EnsurePaired() { if (!IsPaired) throw new InvalidOperationException("Pair this Android device with Windows Forge first."); }
    private async Task<JsonElement> ReadRootAsync(HttpResponseMessage response, CancellationToken token = default)
    {
        var text = await response.Content.ReadAsStringAsync(token);
        using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(text) ? "{}" : text);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException(doc.RootElement.TryGetProperty("error", out var error) ? error.GetString() : $"Forge Companion request failed ({(int)response.StatusCode}).");
        return doc.RootElement.Clone();
    }
}
