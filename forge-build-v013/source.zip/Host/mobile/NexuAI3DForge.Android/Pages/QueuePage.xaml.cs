using NexuAI3DForge.Android.Services;

namespace NexuAI3DForge.Android.Pages;

public partial class QueuePage : ContentPage
{
    private readonly ForgeSession _session;
    private CancellationTokenSource? _poll;
    public QueuePage(ForgeSession session){InitializeComponent();_session=session;JobList.ItemsSource=_session.Jobs;}
    protected override void OnAppearing(){base.OnAppearing();_poll?.Cancel();_poll=new CancellationTokenSource();_ = PollAsync(_poll.Token);}
    protected override void OnDisappearing(){_poll?.Cancel();base.OnDisappearing();}
    private async Task PollAsync(CancellationToken token){while(!token.IsCancellationRequested){if(_session.Client.IsPaired)try{await _session.RefreshJobsAsync(token);}catch{};try{await Task.Delay(1400,token);}catch(OperationCanceledException){break;}}}
    private async void OnCancel(object? sender,EventArgs e){if(sender is not Button b||b.CommandParameter is not string id)return;try{await _session.Client.RpcAsync("job.cancel",new{id});await _session.RefreshJobsAsync();}catch(Exception ex){await DisplayAlertAsync("Cancel failed",ex.Message,"OK");}}
}
