using Android.OS;
using NexuAI3DForge.Android.Services;

namespace NexuAI3DForge.Android.Pages;

public partial class SettingsPage : ContentPage
{
    private readonly ForgeSession _session;
    public SettingsPage(ForgeSession session){InitializeComponent();_session=session;Loaded+=async(_,_)=>{await _session.Client.RestoreAsync();Render();};}
    private void Render(){HostEntry.Text=_session.Client.Host??HostEntry.Text;PortEntry.Text=_session.Client.Port>0?_session.Client.Port.ToString():PortEntry.Text;PairStatus.Text=_session.Client.IsPaired?$"Paired · {_session.Client.Host}:{_session.Client.Port}":"Not paired";PairStatus.TextColor=_session.Client.IsPaired?Color.FromArgb("#72DEA7"):Color.FromArgb("#FF7D85");}
    private async void OnPair(object? sender,EventArgs e){try{PairStatus.Text="Pairing…";var info=PairingInfo.Parse(HostEntry.Text??"",PortEntry.Text,PairCodeEntry.Text??"");var name=$"{Build.Manufacturer} {Build.Model}".Trim();await _session.Client.PairAsync(info,name);await _session.RefreshAsync();Render();await DisplayAlertAsync("Paired","This Android device is now trusted by Windows Forge.","OK");}catch(Exception ex){Render();await DisplayAlertAsync("Pairing failed",ex.Message,"OK");}}
    private async void OnTest(object? sender,EventArgs e){var ok=await _session.Client.HealthAsync();await DisplayAlertAsync("Windows Forge",ok?"Companion service is reachable on your local network.":"Windows Forge is not reachable. Confirm both devices are on the same private network and Forge is running.","OK");}
    private async void OnForget(object? sender,EventArgs e){var yes=await DisplayAlertAsync("Forget pairing?","This removes the local Android key. You can pair again from Windows Forge at any time.","Forget","Cancel");if(!yes)return;await _session.Client.ForgetAsync();Render();}
}
