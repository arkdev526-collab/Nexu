using NexuAI3DForge.Android.Models;
using NexuAI3DForge.Android.Services;

namespace NexuAI3DForge.Android.Pages;

public partial class LibraryPage : ContentPage
{
    private readonly ForgeSession _session;
    public LibraryPage(ForgeSession session){InitializeComponent();_session=session;AssetList.ItemsSource=_session.Assets;}
    protected override async void OnAppearing(){base.OnAppearing();if(_session.Client.IsPaired)try{await _session.RefreshAssetsAsync();}catch{} }
    private async void OnRefresh(object? sender,EventArgs e){if(!_session.Client.IsPaired){await DisplayAlertAsync("Pair Windows Forge","Use the Pair tab first.","OK");return;}try{await _session.RefreshAssetsAsync();}catch(Exception ex){await DisplayAlertAsync("Library unavailable",ex.Message,"OK");}}
    private async void OnSelected(object? sender,SelectionChangedEventArgs e){if(e.CurrentSelection.FirstOrDefault() is not ForgeAsset asset)return;_session.SelectedAsset=asset;await Shell.Current.GoToAsync("//Create");}
}
