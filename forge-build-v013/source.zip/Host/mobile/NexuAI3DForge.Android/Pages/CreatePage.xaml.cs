using System.Text.Json;
using NexuAI3DForge.Android.Models;
using NexuAI3DForge.Android.Services;

namespace NexuAI3DForge.Android.Pages;

public partial class CreatePage : ContentPage
{
    private readonly ForgeSession _session;
    private readonly List<ReferenceEvidence> _references = [];
    private bool _viewerReady;
    private bool _collision;
    private string? _activeJobId;
    private CancellationTokenSource? _pollCts;

    public CreatePage(ForgeSession session)
    {
        InitializeComponent();
        _session = session;
        ProfilePicker.SelectedIndex = 0;
        _session.StateChanged += (_, _) => MainThread.BeginInvokeOnMainThread(UpdateConnection);
        Loaded += async (_, _) => await InitialiseAsync();
    }

    private async Task InitialiseAsync()
    {
        await _session.InitialiseAsync();
        await LoadViewerShellAsync();
        await LoadMaterialPresetsAsync();
        UpdateConnection();
        if (_session.SelectedAsset is not null) await ShowAssetAsync(_session.SelectedAsset);
    }

    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);
        CreatorGrid.ColumnDefinitions.Clear();
        CreatorGrid.RowDefinitions.Clear();
        if (width < 850)
        {
            CreatorGrid.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            CreatorGrid.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            CreatorGrid.RowDefinitions.Add(new RowDefinition(new GridLength(430)));
            Grid.SetColumn(ControlPanel, 0); Grid.SetRow(ControlPanel, 0);
            Grid.SetColumn(ViewerPanel, 0); Grid.SetRow(ViewerPanel, 1);
        }
        else
        {
            CreatorGrid.ColumnDefinitions.Add(new ColumnDefinition(new GridLength(360)));
            CreatorGrid.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            CreatorGrid.RowDefinitions.Add(new RowDefinition(GridLength.Star));
            Grid.SetColumn(ControlPanel, 0); Grid.SetRow(ControlPanel, 0);
            Grid.SetColumn(ViewerPanel, 1); Grid.SetRow(ViewerPanel, 0);
        }
    }

    private void UpdateConnection()
    {
        ConnectionLabel.Text = _session.Client.IsPaired ? $"PC paired · {_session.Client.Host}" : "PC Offline · pair first";
        ConnectionLabel.TextColor = _session.Client.IsPaired ? Color.FromArgb("#72DEA7") : Color.FromArgb("#FF7D85");
    }

    private string Profile => ProfilePicker.SelectedIndex == 0 ? "unreal-asa" : "generic";
    private object EvidencePayload() => _references.Select(x => new { meanRgb = x.MeanRgb, x.Width, x.Height, x.View }).ToArray();

    private async void OnInterpret(object? sender, EventArgs e)
    {
        if (!EnsurePaired()) return;
        try
        {
            var result = await _session.Client.RpcAsync("plan", new { prompt = PromptEditor.Text?.Trim(), profile = Profile, referenceEvidence = EvidencePayload() });
            var recipe = result.GetProperty("recipe");
            PlanSummary.Text = $"{S(recipe,"assetName")} · {I(recipe,"targetTriangles"):N0} target tris · {I(recipe,"lods") + 1} LOD level(s) · {Profile}";
            StatusLabel.Text = "Brief interpreted · review then Generate";
        }
        catch (Exception ex) { await ShowErrorAsync("Could not interpret brief", ex); }
    }

    private async void OnGenerate(object? sender, EventArgs e)
    {
        if (!EnsurePaired()) return;
        try
        {
            SetBusy("Queued", 0);
            var result = await _session.Client.RpcAsync("build", new { prompt = PromptEditor.Text?.Trim(), profile = Profile, referenceEvidence = EvidencePayload() });
            var job = result.GetProperty("job");
            _activeJobId = S(job, "id");
            await WatchJobAsync(_activeJobId);
        }
        catch (Exception ex) { SetIdle(); await ShowErrorAsync("Generation stopped", ex); }
    }

    private async Task WatchJobAsync(string jobId)
    {
        _pollCts?.Cancel(); _pollCts = new CancellationTokenSource(); var token = _pollCts.Token;
        while (!token.IsCancellationRequested)
        {
            var result = await _session.Client.RpcAsync("job.get", new { id = jobId }, token);
            var job = result.GetProperty("job");
            var status = S(job, "status"); var stage = S(job, "stage");
            var progress = job.TryGetProperty("progress", out var p) ? I(p, "percent") : 0;
            var index = job.TryGetProperty("progress", out p) ? I(p, "index") : 0;
            var total = job.TryGetProperty("progress", out p) ? I(p, "total", 7) : 7;
            MainThread.BeginInvokeOnMainThread(() => SetBusy(stage, progress, status == "queued" ? $"Waiting in queue · position {I(job,"queuePosition",1)}" : $"Stage {Math.Max(1,index)} of {Math.Max(1,total)} · previous successful version is safe"));
            if (status.StartsWith("completed", StringComparison.Ordinal) || status is "failed" or "cancelled")
            {
                if (!status.StartsWith("completed", StringComparison.Ordinal)) throw new InvalidOperationException(S(job, "error", $"Build {status}."));
                await _session.RefreshAssetsAsync(token);
                var directory = S(job, "outputRelative");
                _session.SelectedAsset = _session.Assets.FirstOrDefault(a => a.Directory == directory) ?? _session.Assets.FirstOrDefault();
                if (_session.SelectedAsset is not null) await MainThread.InvokeOnMainThreadAsync(() => ShowAssetAsync(_session.SelectedAsset));
                MainThread.BeginInvokeOnMainThread(() => { GenerationProgress.Progress = 1; GenerationStage.Text = stage; StatusLabel.Text = $"{S(job,"assetName")} · {stage}"; });
                return;
            }
            await Task.Delay(850, token);
        }
    }

    private async void OnAddReference(object? sender, EventArgs e)
    {
        if (!EnsurePaired()) return;
        try
        {
            var types = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>> { [DevicePlatform.Android] = ["image/png", "image/jpeg", "image/webp"] });
            var file = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Choose a local reference image", FileTypes = types }); if (file is null) return;
            var read = await ReferenceEvidenceService.ReadAsync(file, "reference");
            _references.Add(read.Evidence);
            await _session.Client.RpcAsync("reference.upload", new { base64 = Convert.ToBase64String(read.Bytes), mime = read.Mime, fileName = file.FileName, view = read.Evidence.View });
            ReferenceSummary.Text = $"{_references.Count} local reference image(s) · {_references.Sum(x => x.Width * x.Height):N0} total pixels sampled locally";
        }
        catch (Exception ex) { await ShowErrorAsync("Reference could not be added", ex); }
    }

    private async void OnPreviewRefine(object? sender, EventArgs e) => await RefineAsync(false);
    private async void OnApplyRefine(object? sender, EventArgs e) => await RefineAsync(true);
    private async Task RefineAsync(bool apply)
    {
        if (!EnsureAsset()) return;
        try
        {
            var method = apply ? "refine.apply" : "refine.plan";
            var result = await _session.Client.RpcAsync(method, new { directory = _session.SelectedAsset!.Directory, request = RefineEditor.Text?.Trim() });
            var plan = result.GetProperty("plan"); RefineSummary.Text = ChangeSummary(plan);
            if (apply) { var job = result.GetProperty("job"); await WatchJobAsync(S(job,"id")); }
        }
        catch (Exception ex) { await ShowErrorAsync("Refinement could not be applied", ex); }
    }

    private async void OnPreviewMaterial(object? sender, EventArgs e) => await MaterialAsync(false);
    private async void OnApplyMaterial(object? sender, EventArgs e) => await MaterialAsync(true);
    private async Task MaterialAsync(bool apply)
    {
        if (!EnsureAsset()) return;
        try
        {
            var preset = MaterialPresetPicker.SelectedItem as string;
            var method = apply ? "material.apply" : "material.plan";
            var result = await _session.Client.RpcAsync(method, new { directory = _session.SelectedAsset!.Directory, request = MaterialEditor.Text?.Trim(), preset = PresetId(preset), resolution = 512 });
            var plan = result.GetProperty("plan"); MaterialSummary.Text = S(plan,"summary",ChangeSummary(plan));
            if (apply) { var job = result.GetProperty("job"); await WatchJobAsync(S(job,"id")); }
        }
        catch (Exception ex) { await ShowErrorAsync("Material generation could not continue", ex); }
    }

    private async Task LoadMaterialPresetsAsync()
    {
        if (!_session.Client.IsPaired) return;
        try { var r = await _session.Client.RpcAsync("material.presets"); MaterialPresetPicker.ItemsSource = r.GetProperty("presets").EnumerateArray().Select(x => S(x,"label")).ToList(); }
        catch { }
    }

    public async Task ShowAssetAsync(ForgeAsset asset)
    {
        _session.SelectedAsset = asset; ViewerEmpty.IsVisible = false; LodPicker.ItemsSource = Enumerable.Range(0, asset.LodCount + 1).Select(i => $"LOD{i}").ToList(); LodPicker.SelectedIndex = 0;
        if (!_viewerReady) return;
        try
        {
            var model = await _session.Client.RpcAsync("asset.glb", new { directory = asset.Directory, lod = 0, collision = false });
            JsonElement? collision = null; if (asset.CollisionCreated) try { collision = await _session.Client.RpcAsync("asset.glb", new { directory = asset.Directory, lod = 0, collision = true }); } catch { }
            await LoadViewerAsync(S(model,"base64"), collision is JsonElement c ? S(c,"base64") : null);
            StatusLabel.Text = $"{asset.DisplayName} · {asset.Triangles:N0} tris · {asset.QaLabel}";
        }
        catch (Exception ex) { await ShowErrorAsync("3D preview unavailable", ex); }
    }

    private async void OnLodChanged(object? sender, EventArgs e)
    {
        if (!_viewerReady || _session.SelectedAsset is null || LodPicker.SelectedIndex < 0) return;
        try { var model = await _session.Client.RpcAsync("asset.glb", new { directory = _session.SelectedAsset.Directory, lod = LodPicker.SelectedIndex, collision = false }); await LoadViewerAsync(S(model,"base64"), null); }
        catch (Exception ex) { await ShowErrorAsync("LOD preview unavailable", ex); }
    }

    private async Task LoadViewerShellAsync()
    {
        await using var stream = await FileSystem.OpenAppPackageFileAsync("viewer.html"); using var reader = new StreamReader(stream); Viewer.Source = new HtmlWebViewSource { Html = await reader.ReadToEndAsync() };
    }
    private void OnViewerNavigated(object? sender, WebNavigatedEventArgs e) { _viewerReady = e.Result == WebNavigationResult.Success; if (_viewerReady && _session.SelectedAsset is not null) _ = ShowAssetAsync(_session.SelectedAsset); }
    private async Task LoadViewerAsync(string modelBase64, string? collisionBase64)
    {
        if (!_viewerReady) return;
        await Viewer.EvaluateJavaScriptAsync("window.forgeTransferBegin()");
        await TransferViewerBase64Async("model", modelBase64);
        if (!string.IsNullOrEmpty(collisionBase64)) await TransferViewerBase64Async("collision", collisionBase64);
        await Viewer.EvaluateJavaScriptAsync("window.forgeTransferCommit()");
    }

    private async Task TransferViewerBase64Async(string channel, string payload)
    {
        const int chunkSize = 128 * 1024;
        for (var offset = 0; offset < payload.Length; offset += chunkSize)
        {
            var count = Math.Min(chunkSize, payload.Length - offset);
            var chunk = payload.Substring(offset, count);
            await Viewer.EvaluateJavaScriptAsync($"window.forgeTransferChunk('{channel}','{chunk}')");
        }
    }
    private async void OnMaterialView(object? s,EventArgs e)=>await Viewer.EvaluateJavaScriptAsync("window.forgeSetMode('material')");
    private async void OnSolidView(object? s,EventArgs e)=>await Viewer.EvaluateJavaScriptAsync("window.forgeSetMode('solid')");
    private async void OnWireView(object? s,EventArgs e)=>await Viewer.EvaluateJavaScriptAsync("window.forgeSetMode('wireframe')");
    private async void OnCollision(object? s,EventArgs e){_collision=!_collision;await Viewer.EvaluateJavaScriptAsync($"window.forgeCollision({(_collision?"true":"false")})");}
    private async void OnFrame(object? s,EventArgs e)=>await Viewer.EvaluateJavaScriptAsync("window.forgeFrame()");

    private bool EnsurePaired(){if(_session.Client.IsPaired)return true;_ = DisplayAlertAsync("Pair Windows Forge", "Open the Pair tab and enter the host and pairing code shown by Windows Forge.", "OK");return false;}
    private bool EnsureAsset(){if(EnsurePaired()&&_session.SelectedAsset is not null)return true;_ = DisplayAlertAsync("Select an asset", "Generate or choose an asset from the Library first.", "OK");return false;}
    private void SetBusy(string stage,int percent,string? detail=null){GenerationProgress.Progress=Math.Clamp(percent/100d,0,1);GenerationStage.Text=detail is null?stage:$"{stage} · {detail}";StatusLabel.Text=$"Generating · {stage}";}
    private void SetIdle(){GenerationProgress.Progress=0;GenerationStage.Text="Ready to create.";}
    private string ChangeSummary(JsonElement plan){if(!plan.TryGetProperty("changes",out var c)||c.GetArrayLength()==0)return "No structured changes.";return string.Join(" · ",c.EnumerateArray().Take(4).Select(x=>$"{S(x,"path")}: {Value(x,"before")} → {Value(x,"after")}"));}
    private static string Value(JsonElement e,string p)=>e.TryGetProperty(p,out var v)?v.ToString():"—";
    private static string PresetId(string? label)=>string.IsNullOrWhiteSpace(label)?string.Empty:label.ToLowerInvariant().Replace(' ','-');
    private static string S(JsonElement e,string p,string d="")=>e.TryGetProperty(p,out var v)&&v.ValueKind==JsonValueKind.String?v.GetString()??d:d;
    private static int I(JsonElement e,string p,int d=0)=>e.TryGetProperty(p,out var v)&&v.TryGetInt32(out var n)?n:d;
    private Task ShowErrorAsync(string title,Exception ex)=>DisplayAlertAsync(title,ex.Message,"OK");
}
