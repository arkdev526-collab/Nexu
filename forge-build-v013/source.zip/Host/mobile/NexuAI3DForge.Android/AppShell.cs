using NexuAI3DForge.Android.Pages;
using NexuAI3DForge.Android.Services;

namespace NexuAI3DForge.Android;

public sealed class AppShell : Shell
{
    public AppShell(ForgeSession session)
    {
        FlyoutBehavior = FlyoutBehavior.Disabled;
        BackgroundColor = Color.FromArgb("#090D13");
        ForegroundColor = Colors.White;
        TitleColor = Colors.White;
        TabBarBackgroundColor = Color.FromArgb("#0E141D");
        TabBarForegroundColor = Color.FromArgb("#74DFF2");
        TabBarUnselectedColor = Color.FromArgb("#91A0B5");

        var tabs = new TabBar();
        tabs.Items.Add(Page("Create", new CreatePage(session)));
        tabs.Items.Add(Page("Library", new LibraryPage(session)));
        tabs.Items.Add(Page("Queue", new QueuePage(session)));
        tabs.Items.Add(Page("Pair", new SettingsPage(session)));
        Items.Add(tabs);
    }

    private static ShellContent Page(string title, ContentPage page)
        => new() { Title = title, Route = title, Content = page };
}
