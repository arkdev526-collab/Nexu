namespace NexuAI3DForge.Android.Models;

public sealed class ReferenceEvidence
{
    public required double[] MeanRgb { get; init; }
    public required int Width { get; init; }
    public required int Height { get; init; }
    public string View { get; init; } = "reference";
}
