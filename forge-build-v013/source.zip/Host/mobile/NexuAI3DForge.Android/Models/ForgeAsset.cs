namespace NexuAI3DForge.Android.Models;

public sealed class ForgeAsset
{
    public string Id { get; init; } = string.Empty;
    public string Directory { get; init; } = string.Empty;
    public string AssetName { get; init; } = string.Empty;
    public string DisplayName { get; init; } = string.Empty;
    public string Profile { get; init; } = string.Empty;
    public int Triangles { get; init; }
    public int Vertices { get; init; }
    public int TargetTriangles { get; init; }
    public int LodCount { get; init; }
    public double? QualityScore { get; init; }
    public string QaLabel { get; init; } = string.Empty;
    public bool CollisionCreated { get; init; }
    public DateTimeOffset? ModifiedAt { get; init; }
    public string Summary => $"{Triangles:N0} tris · {QaLabel}";
}
