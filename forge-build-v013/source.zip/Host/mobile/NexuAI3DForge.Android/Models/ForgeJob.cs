namespace NexuAI3DForge.Android.Models;

public sealed class ForgeJob
{
    public string Id { get; init; } = string.Empty;
    public string AssetName { get; init; } = string.Empty;
    public string Prompt { get; init; } = string.Empty;
    public string Status { get; init; } = string.Empty;
    public string Stage { get; init; } = string.Empty;
    public int ProgressPercent { get; init; }
    public int StageIndex { get; init; }
    public int StageTotal { get; init; } = 7;
    public int QueuePosition { get; init; }
    public double ProgressValue => Math.Clamp(ProgressPercent / 100d, 0, 1);
    public bool IsCancellable => Status is "queued" or "running";
    public string Detail => Status == "queued" ? $"Queue position {Math.Max(1, QueuePosition)}" : $"Stage {Math.Max(1, StageIndex)} of {Math.Max(1, StageTotal)}";
}
