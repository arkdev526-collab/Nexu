namespace NexuAI3DForge.Android;

public partial class App : Application
{
    private readonly ForgeSession _session;
    public App(ForgeSession session)
    {
        InitializeComponent();
        _session = session;
    }

    protected override Window CreateWindow(IActivationState? activationState)
        => new(new AppShell(_session));
}
