# Nexu AI 3D Forge v0.7.0 — Security & Privacy

## Preserved execution boundary
User text and Android messages never become executable Python, shell commands or arbitrary native calls. Companion RPC methods map only to existing trusted Forge operations, which continue through validated Nexu3D schemas into package-owned workers.

## Android pairing
- explicit user action on Windows and Android;
- one-use 10-minute offer;
- 16-character high-entropy display secret;
- 32-byte random per-device key after pairing;
- Android key held in Secure Storage;
- Windows exposes paired-device list and revoke action.

## Message protection
- AES-256-GCM authenticated encryption;
- random 96-bit IV per message;
- random nonce and five-minute time window;
- replay cache on Windows requests;
- server response is bound to the initiating request nonce.

## Network boundary
Windows Companion listens on the LAN but rejects sources outside private/local ranges. Android refuses pairing to non-private IPv4 hosts. v0.7 uses HTTP as a carrier because the endpoint address is dynamic; sensitive application payloads are encrypted separately. HTTP metadata remains visible and this is documented as a narrow technology override rather than represented as TLS.

## Reference privacy
Reference images are selected explicitly. Basic mean-colour evidence is calculated locally on Android. When the actual image is sent to paired Windows Forge it is inside the encrypted RPC payload and is not sent to a cloud provider. v0.7 introduces no telemetry/account/credit service.
