# Architecture — v0.8.0 Asset Intelligence & Learning

```text
Prompt / reference
      |
      v
Brief Interpreter
      |
      v
Asset Grammar Library (23 local families)
      |
      v
Validated Nexu3D recipe
      |
      v
Trusted Blender worker
  |       |        |
  |       |        +--> PBR materials
  |       +-----------> Safe Mesh Repair v1
  +-------------------> UV / collision / LOD / export
      |
      +--> 7-view local Dataset Record
      |
      +--> QA / quality evidence
      |
User explicit Good / Needs Work
      |
      v
Local Preference Learning Ledger
      |
      +--> accepted-result statistics
      +--> bounded per-grammar target suggestion
                 |
                 +--> applied only when the prompt has no explicit triangle target
```

The dataset/feedback path is a permanent local learning foundation, not a claim that v0.8 trains a neural foundation model. No data is uploaded automatically. Explicit user constraints always override learned defaults.
