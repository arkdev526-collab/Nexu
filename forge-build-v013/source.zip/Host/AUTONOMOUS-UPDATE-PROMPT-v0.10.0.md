# Nexu AI 3D Forge v0.10.0 — Autonomous Build Brief

Goal: expand natural-language creation, reduce repeated generation/storage cost, improve generation-speed control, and mature Forge into a complete creator application without weakening local-first security or replacing the proven Nexu3D → Blender pipeline.

Required outcomes implemented in this candidate:
- broad prompt-normalisation/alias/typo vocabulary;
- permanent grammar expansion rather than fake arbitrary generation;
- Fast/Balanced/Maximum Quality policies;
- deterministic exact-build reuse;
- compressed metadata and compressed master files where compatible;
- no compression that breaks the built-in viewer;
- Forge Home, prompt guidance and system/storage UX;
- 14px minimum text;
- no paid/temp provider;
- full regression and honest Windows/Blender qualification boundary.
