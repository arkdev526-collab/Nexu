@echo off
setlocal
cd /d "%~dp0"
set "TARGET=%~1"
if "%TARGET%"=="" (
  set /p "TARGET=Enter the path to the Nexu .nex app file: "
)
if "%TARGET%"=="" (
  echo [FAIL] No target file supplied.
  pause
  exit /b 1
)
echo.
echo === Preview full AI chat feature + host + declarative UI ===
node compiler\cli.mjs recipe preview "AI Chat Full" "%TARGET%" || goto :fail
echo.
choice /M "Apply AI Chat Full to this file"
if errorlevel 2 exit /b 0
node compiler\cli.mjs recipe apply "AI Chat Full" "%TARGET%" || goto :fail
echo.
echo [PASS] AI Chat Full recipe complete and validated.
pause
exit /b 0
:fail
echo.
echo [FAIL] Recipe operation failed. No unvalidated change should be retained.
pause
exit /b 1
