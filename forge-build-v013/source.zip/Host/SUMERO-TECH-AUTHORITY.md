# Sumero Studio Technology Authority

**Document:** `SUMERO-TECH-AUTHORITY.md`  
**Authority version:** 1.0.0  
**Status:** Mandatory  
**Scope:** All Sumero Studio software, applications, games, tools, websites, services, scripts, installers, build systems, Unreal/ASA work, AI systems and future technical projects.

---

# 1. Purpose

This document prevents Sumero Studio projects from accidentally using:

- outdated frameworks;
- unsupported SDKs;
- obsolete APIs;
- deprecated packages;
- preview or prerelease technology in production;
- old command syntax;
- obsolete PowerShell/CMD techniques;
- superseded installation methods;
- abandoned libraries;
- incorrect build procedures;
- stale online examples;
- incompatible dependency combinations;
- outdated Unreal or ASA DevKit workflows;
- obsolete Windows development patterns;
- technology selected merely because an AI model remembers it.

The objective is:

> **Use the strongest current stable, supported and maintainable technology that is appropriate for the project, while preserving compatible working project baselines.**

---

# 2. Authority Rule

Before selecting, introducing, replacing or upgrading any:

- framework;
- runtime;
- SDK;
- compiler;
- programming language version;
- package;
- library;
- build tool;
- CLI;
- API;
- development kit;
- operating-system integration;
- installer technology;
- deployment system;
- AI runtime;
- database;
- browser technology;
- Android tooling;
- Windows tooling;
- Unreal/ASA workflow;
- shell command;
- PowerShell technique;
- CMD technique;

the technology must be checked against the **current official primary source**.

Do not rely only on remembered knowledge.

Do not rely on old tutorials, Stack Overflow answers, blog posts or generated code when an authoritative vendor source exists.

---

# 3. Stable-First Policy

For production and normal development, use:

**Current stable and supported technology.**

Do not use:

- Alpha
- Beta
- Preview
- Canary
- Experimental
- Insider-only
- Release Candidate

unless there is an explicit, documented project reason.

A newer version is not automatically better if it is prerelease, unsupported by required dependencies, or unsuitable for production.

---

# 4. Support Policy

A technology must normally be:

1. actively maintained;
2. officially supported;
3. receiving security updates;
4. compatible with the project's dependencies;
5. appropriate for production use;
6. available through an official distribution channel.

Do not start new Sumero Studio projects on End-of-Life technology.

Do not introduce a dependency whose maintenance status is uncertain without investigation.

---

# 5. Existing Project Protection

**Do not blindly upgrade working projects simply because a newer release exists.**

For an existing project:

1. Identify its protected/current-good baseline.
2. Read its pinned versions.
3. Check whether those versions remain supported.
4. Check compatibility with the proposed change.
5. Determine whether upgrading provides a material security, compatibility, performance or maintenance benefit.
6. Test the upgrade separately.
7. Preserve a rollback point.
8. Promote the upgrade only after validation.

A supported pinned version may remain in use when upgrading creates unnecessary risk.

---

# 6. Version Verification Gate

Before beginning substantial implementation, record:

| Field | Required |
|---|---|
| Technology | Yes |
| Selected version | Yes |
| Release channel | Stable/LTS/etc. |
| Support status | Yes |
| Official source | Yes |
| Verification date | Yes |
| Compatibility checked | Yes |
| Version pinned where appropriate | Yes |

For longer projects, repeat verification before:

- major upgrades;
- releases;
- installer creation;
- platform migrations;
- dependency refreshes;
- significant new subsystems.

---

# 7. Version Pinning

Production projects should pin reproducible versions where technically appropriate.

Avoid uncontrolled dependency declarations equivalent to:

- latest-anything;
- unrestricted wildcards;
- preview channels;
- floating major versions.

Lock files should normally be committed where the ecosystem expects them.

Version pinning must not become version abandonment.

Pinned dependencies must still be checked for:

- security problems;
- loss of support;
- compatibility problems;
- critical fixes.

---

# 8. Command Authority

Commands are versioned technology too.

Before providing or adding an important command:

1. Identify the shell.
2. Identify the shell/tool version.
3. Verify current official syntax where uncertainty exists.
4. Ensure flags have not been deprecated.
5. Ensure the command is appropriate for the installed version.
6. Check exit codes.
7. Handle failure.
8. Avoid destructive behaviour by default.

Never mix syntax from:

- CMD;
- Windows PowerShell;
- PowerShell 7;
- Bash;
- WSL;
- Git Bash;

without explicitly identifying the intended environment.

---

# 9. PowerShell Standard

For new modern cross-platform or Windows automation, prefer the **current supported PowerShell 7 LTS line** unless a project requirement dictates otherwise.

Windows PowerShell 5.1 may be used where:

- Windows itself requires it;
- a legacy module genuinely requires it;
- an existing supported project depends on it.

Its use must not occur merely because an old script or tutorial uses it.

Scripts should include appropriate:

- error handling;
- exit codes;
- path handling;
- quoting;
- elevation checks;
- architecture checks;
- logging;
- validation.

For Sumero Studio packaged PowerShell projects, syntax parsing/preflight should be used where practical.

Warnings and parser failures must be fixed rather than hidden.

---

# 10. CMD Standard

CMD files should primarily act as thin launchers where CMD remains useful.

Complex application/setup logic should not be forced into batch scripts when PowerShell or the project's native implementation provides a safer and more maintainable solution.

CMD launchers should:

- quote paths;
- preserve exit codes;
- detect failure;
- avoid hidden destructive operations;
- invoke the intended runtime explicitly;
- work from paths containing spaces.

---

# 11. Windows Application Baseline

For new native Sumero Studio Windows applications, evaluate the current supported Microsoft stack first.

Preferred direction:

- current supported .NET LTS where .NET is appropriate;
- current stable Windows App SDK;
- WinUI 3 for suitable modern native Windows UI applications;
- native Windows APIs where they provide a material advantage;
- current stable Visual Studio/toolchain;
- supported Windows SDK;
- x64 as the normal desktop baseline unless requirements differ.

Do not introduce old Windows UI frameworks into new projects simply because examples are easier to find.

Existing WPF/Win32/etc. projects may remain on their architecture when migration provides insufficient benefit.

---

# 12. Web Application Baseline

For new Sumero Studio web applications, the preferred baseline is:

- current stable Next.js;
- App Router;
- TypeScript;
- current stable supported React version required by Next.js;
- Tailwind CSS where appropriate;
- semantic HTML;
- CSS Grid/Flexbox;
- accessible components;
- responsive design;
- strong performance;
- minimal dependency count.

Use the framework's **current official installation method**.

Do not copy setup commands from an older major release without verification.

Do not default new Next.js applications to the Pages Router unless project requirements justify it.

---

# 13. TypeScript and JavaScript

Prefer TypeScript for substantial Sumero Studio web/application development.

Requirements:

- strict typing where practical;
- avoid unnecessary `any`;
- current supported compiler;
- compatible module system;
- current ecosystem conventions;
- no obsolete transpilation setup without a compatibility reason.

The exact TypeScript version must follow compatibility with the selected framework/toolchain rather than being selected independently.

---

# 14. CSS and UI Tooling

Prefer platform capabilities before adding dependencies.

For Sumero Studio interfaces:

- follow SSDL;
- implement through SSDS;
- preserve approved product-specific systems;
- semantic accessible structure;
- responsive layout;
- restrained animation;
- reduced-motion support;
- appropriate contrast;
- keyboard accessibility;
- predictable focus behaviour.

Do not install a UI framework simply to solve a problem that modern CSS handles cleanly.

Bootstrap is not the default for new Sumero Studio projects.

---

# 15. Android Baseline

For new Android-capable Sumero Studio projects:

- verify the current production Android API level;
- use the current supported Android SDK tooling;
- use officially supported build tools;
- use the correct supported Java/JDK version for the toolchain;
- use current Android application security practices;
- validate behaviour changes when raising target SDK;
- use ADB commands matching the installed platform tools.

Where the application architecture permits it, Sumero Studio's standard build should produce:

- Windows output/installer;
- Android APK for direct installation/testing;
- Android AAB when store distribution is relevant.

Do not force Windows-specific implementation into Android.

Use:

**shared core + platform-specific implementation/shell**

where appropriate.

---

# 16. Unreal Engine / ARK: Survival Ascended

For ASA work, the **current ASA DevKit and its supported Unreal workflow are authoritative**.

Never assume standard Unreal Engine instructions apply unchanged to ASA.

Before suggesting:

- editor procedures;
- Blueprint nodes;
- cooking;
- packaging;
- mod/plugin structure;
- World Partition procedures;
- asset migration;
- cloud cooking;
- map settings;
- DevKit command-line operations;

verify against current official ASA/Unreal documentation when there is material uncertainty.

Protect:

- source assets;
- maps;
- levels;
- World Partition data;
- working baselines;
- source control.

Prefer reversible diagnostic actions before destructive fixes.

---

# 17. AI / Local AI

AI technology must be selected according to the project's actual requirements.

Evaluate:

- model licence;
- commercial-use rights;
- model size;
- quantisation;
- memory requirements;
- GPU support;
- runtime maintenance;
- privacy;
- offline capability;
- API stability;
- structured-output support;
- context requirements;
- security implications.

Do not select an AI model simply because it is currently fashionable.

Local/private projects must not silently send private data to cloud providers.

---

# 18. Packages and Dependencies

Before introducing a dependency, ask:

**Can the platform already do this well without another dependency?**

Prefer fewer high-quality dependencies.

Check:

- official project;
- maintenance activity;
- release status;
- security history;
- licence;
- compatibility;
- bundle/runtime cost;
- necessity.

Avoid abandoned packages.

Avoid dependency chains for trivial functionality.

---

# 19. Official Sources

Technical verification should normally prioritise:

1. vendor documentation;
2. official lifecycle/support documentation;
3. official release notes;
4. official repository;
5. official package registry;
6. standards body documentation.

Secondary sources may help diagnosis but should not override current primary documentation.

---

# 20. Search-Date Rule

Technology verification must state or internally establish the date it was checked.

Example:

`Verified: 15 August 2026`

This prevents an old answer from masquerading as current advice months later.

---

# 21. Deprecated Technology

When official documentation marks something as:

- deprecated;
- obsolete;
- retired;
- EOL;
- unsupported;
- replaced;

do not use it for a new implementation unless an approved compatibility exception exists.

Find the officially recommended successor.

---

# 22. Warnings Policy

Compiler, analyser, linter and build warnings are engineering information.

Default policy:

> **Fix the cause. Do not hide the warning.**

Suppression is allowed only when:

1. the warning is proven incorrect or unavoidable;
2. the reason is documented;
3. the suppression scope is minimal.

Never disable entire warning classes merely to obtain a green build.

---

# 23. Security Policy

Do not solve development problems by disabling:

- UAC;
- Defender;
- SmartScreen;
- certificate checking;
- TLS validation;
- browser security;
- code-signing verification;
- firewall protection;
- application sandboxing;

unless a narrowly controlled development exception has been explicitly approved.

Never normalise insecure workarounds into production setup instructions.

---

# 24. Installer and Download Policy

Where software or tooling must be downloaded:

Prefer:

1. official package manager;
2. official vendor download;
3. official repository release.

Where feasible, verify:

- publisher;
- version;
- digital signature;
- checksum;
- download success.

Never silently download executables from arbitrary mirrors.

---

# 25. Architecture First

Do not choose technology purely because it makes the first prototype easier.

Consider:

- maintainability;
- security;
- privacy;
- support lifetime;
- accessibility;
- performance;
- deployment;
- testing;
- installer/update requirements;
- cross-platform requirements;
- solo-developer maintenance cost.

The smallest dependable architecture is preferred over unnecessary complexity.

---

# 26. One-Click Workflow

Where practical, projects should provide clear entry points such as:

- `SETUP`
- `BUILD`
- `RUN`
- `TEST`
- `DOCTOR`
- `RELEASE`

These may be scripts or application commands appropriate to the platform.

The implementation must still use the correct modern tooling underneath.

One-click convenience must not hide errors.

---

# 27. Build Reproducibility

A fresh compatible development machine should be able to determine:

- required SDKs;
- required runtimes;
- required workloads;
- required dependencies;
- expected versions;
- build command;
- test command;
- packaging command.

Do not rely on undocumented machine-specific state.

---

# 28. Doctor / Environment Validation

Larger Sumero Studio projects should provide a Doctor or equivalent environment check where worthwhile.

It should detect rather than guess:

- installed SDKs;
- versions;
- executable paths;
- missing tools;
- architecture;
- dependencies;
- relevant platform services;
- required environment variables.

Doctor must be read-only unless the user explicitly selects a repair/install action.

---

# 29. Project Overrides

A project may contain:

`TECH-OVERRIDES.md`

Overrides must be explicit.

Example:

```text
Technology: .NET X
Normal Sumero baseline: .NET Y
Project override: remain on .NET X
Reason: dependency ABC does not yet support Y
Status: .NET X remains officially supported
Review date: YYYY-MM-DD
```

An override must not legitimise unsupported technology indefinitely.

---

# 30. Project Inheritance

Every Sumero Studio software repository should contain:

```text
/
├─ SUMERO-TECH-AUTHORITY.md
├─ TECH-OVERRIDES.md          # only when required
├─ README.md
└─ ...
```

Recommended header:

```text
Technology Authority:
Sumero Studio Technology Authority v1.0.0

Project overrides:
None
```

---

# 31. Mandatory AI Rule

When an AI assistant, coding agent or automated system works on a Sumero Studio project, it must:

1. read the project's technology authority;
2. identify the current project baseline;
3. preserve approved architecture;
4. verify unstable/current technology information;
5. use primary official sources for technical version decisions;
6. not assume remembered package versions are current;
7. not silently migrate technologies;
8. not introduce deprecated methods;
9. not use prerelease technology without approval;
10. identify compatibility conflicts;
11. fix warnings rather than conceal them;
12. report uncertainty instead of inventing compatibility.

---

# 32. New Project Gate

Before implementation of a new project begins:

### Technology check

- [ ] Product requirements understood
- [ ] Target platforms identified
- [ ] Existing Sumero components evaluated
- [ ] Framework verified
- [ ] Runtime verified
- [ ] SDK verified
- [ ] Compiler/toolchain verified
- [ ] Major dependencies verified
- [ ] Release channels confirmed stable
- [ ] Support lifecycle checked
- [ ] Compatibility checked
- [ ] Official setup method checked
- [ ] Build method checked
- [ ] Test strategy selected
- [ ] Installer/deployment path considered
- [ ] Security/privacy requirements considered
- [ ] Accessibility requirements considered
- [ ] Versions pinned where required
- [ ] Verification date recorded

Only then should the project baseline be considered selected.

---

# 33. Upgrade Gate

Before changing important technology in an existing project:

- [ ] Reason for upgrade identified
- [ ] Current baseline backed up/protected
- [ ] New release stable
- [ ] New release supported
- [ ] Dependencies compatible
- [ ] Migration notes reviewed
- [ ] Breaking changes reviewed
- [ ] Deprecated APIs identified
- [ ] Build tested
- [ ] Automated tests pass
- [ ] Runtime tested
- [ ] Installer/package tested
- [ ] Rollback available

---

# 34. Golden Rule

> **Never use a technology, command or implementation merely because it worked in an old project or appears in an old example. Verify that it remains the correct supported way today.**

And equally:

> **Never replace a known-good supported project baseline simply because something newer exists.**

Current, stable, supported, compatible and tested wins.

---

# 35. Sumero Studio Decision Order

When choosing technology, optimise in this order:

1. Correctness
2. Security
3. Privacy
4. Official support
5. Compatibility
6. Maintainability
7. Accessibility
8. Performance
9. Reliability
10. Solo-builder practicality
11. Deployment quality
12. Development convenience

Convenience does not override correctness.

---

**End of Sumero Studio Technology Authority v1.0.0**