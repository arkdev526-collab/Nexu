# Host Adapter Contracts — Nexu Language 0.6.0

Hosts implement narrowly declared application-host capabilities. They are not general native/JavaScript escape hatches.

## Catalogue

```text
console.preview  node     ui.render, ui.confirm, ui.focus, storage.local
web.dom          browser  ui.render, ui.confirm, ui.focus, storage.local
```

## `ui.render`

Renders the normalised declarative UI. With screens, only the active screen is rendered.

## `ui.confirm`

Provides the approval surface used by `confirm` policies. It does not grant the capability being confirmed.

The console preview host fails confirmation closed by default. The browser host may use the browser confirmation surface.

## `ui.focus`

Moves focus only to compiler-checked focus targets. Source code does not receive raw DOM/native focus access.

## `storage.local`

- console preview: project-working-directory `.nexu-data` JSON values;
- web DOM: scoped browser `localStorage` values.

This storage is **not encrypted** and must not contain secrets.

## Runtime gate

Host calls verify:

1. capability exists;
2. deny/confirm/allow policy;
3. host declaration;
4. host provides capability;
5. adapter implements operation;
6. approval where required;
7. cancellation;
8. invocation.

## Boundary

0.6 does not include unrestricted file-system/native/Windows/Android adapters or an implicit browser/server bridge.
