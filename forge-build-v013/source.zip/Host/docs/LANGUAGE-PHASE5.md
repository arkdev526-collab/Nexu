# Nexu Language Phase 5 — 0.5.0 State, Events & Provider Adapters

## Goal

Turn 0.4's static declarative UI into a reactive application surface and replace placeholder network routing with explicit, capability-scoped provider contracts.

## Delivered

- typed root UI state;
- event signatures and handler semantic analysis;
- event-only `set` mutation;
- state binding;
- text/button/input nodes;
- chat send/clear/stop events;
- active chat-task cancellation;
- provider declarations and compiler-known adapter catalogue;
- OpenAI Responses Node provider;
- offline deterministic provider test adapter;
- host `ui.confirm` surface;
- provider runtime gate;
- Node/browser environment compatibility guard;
- provider CLI inspection;
- stateful AI Chat Full recipe.

## Non-goals

0.5 does not add arbitrary network endpoints, arbitrary third-party adapters, browser/server split deployment, persistent state, general mutation, or a real local-Qwen runtime adapter.
