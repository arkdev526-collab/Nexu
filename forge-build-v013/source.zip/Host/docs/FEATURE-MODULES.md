# Nexu Standard Feature Modules — 0.6.0

## `storage.local`

Purpose: local persistence contract.

Defaults:

```text
encrypted false
scope app
```

Capability:

```text
storage.local allow
```

`encrypted true` is rejected in 0.6 because the built-in persistence hosts do not provide encryption. This prevents an intent flag being mistaken for an implemented security property.

## `project.workspace`

Purpose: project context with guarded write intent.

Defaults:

```text
read true
write true
```

Capabilities:

```text
project.read allow
project.write confirm
```

## `ai.chat.full`

Purpose: headless full-chat foundation.

Defaults:

```text
name "Nexu AI"
model "local.qwen"
fallback none
privacy local_first
memory conversation
streaming true
markdown true
code_blocks true
cancellable true
```

Dependencies:

- `storage.local` when memory is enabled.

Capabilities:

- `storage.local allow` when memory is enabled.
- `ai.local allow` when the primary model route starts with `local.`.
- `network.ai confirm` when configuration may use network/cloud AI.

Provides:

- conversation history
- cancellable send task
- model/fallback/privacy metadata
- streaming/markdown/code-block intent
- `chatSend()`
- `chatClear()`
- `chatStop()`

## `agent.coder`

Purpose: high-level coding-agent contract.

Defaults:

```text
writes confirm
tests true
```

Dependencies:

```text
ai.chat.full
project.workspace
```

`writes` may be `confirm` or `deny`; `allow` is intentionally not part of the current standard feature config.

## `auth.local`

Purpose: local authentication intent without silently adding a remote identity service.

Defaults:

```text
method pin
lock_on_start true
```

Dependency:

```text
storage.local
```

Supported methods:

```text
pin
passkey
```


## 0.5.0 UI relationship

Feature Modules remain capability/runtime contracts. Declarative UI consumes them rather than replacing them.

Example:

```nex
chat AssistantChat {
  use ai.chat.full
}
```

The `chat` node is therefore a presentation binding to the existing `ai.chat.full` feature. The feature itself remains usable headlessly.
