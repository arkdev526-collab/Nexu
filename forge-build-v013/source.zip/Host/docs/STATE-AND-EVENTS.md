# State & Events — Nexu Language 0.5.0

## State

State is declared at the UI root:

```nex
state status: String = "Ready"
state count: Number = 0
state connected: Bool = false
```

Only `String`, `Number`, and `Bool` are supported in 0.5. Initialisers must be matching literals.

## Binding

```nex
text Status {
  bind: status
}
```

The `web.dom` host subscribes bound text nodes to state updates. The console preview renders the structural outline only.

## Events

```nex
button Reset {
  on click {
    set status = "Ready"
  }
}
```

Supported event signatures are compiler-known. Parameter count and type mismatches are compile errors.

## Mutation boundary

`set` is not general variable assignment. It is a UI-state operation and is legal only in declarative UI event handlers.

This keeps ordinary `let` immutable and postpones a broad ownership/mutation model until the language can define one safely.

## Event effects

Handlers participate in the same effect analysis as functions. Calling `chatSend()` inside `on send` propagates the Feature Module's storage/network effects and therefore cannot bypass application capabilities.

## Cancellation

`chatStop()` cancels the currently active `ai.chat.full` task when that feature is configured as cancellable.
