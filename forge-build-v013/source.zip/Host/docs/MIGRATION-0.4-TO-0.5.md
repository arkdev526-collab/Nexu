# Migration — Nexu Language 0.4.0 to 0.5.0

0.4 source remains compatible unless it relied on UI properties that were previously not being validated correctly.

## Intentional changes

### Host capabilities

Host adapter catalogues now expose `ui.confirm` as well as `ui.render`. Do not add `provides ui.confirm` unless the effective application capability plan actually needs it, normally because a confirm-gated provider is declared.

### AI runtime route

Network-capable AI no longer expects a generic host `network.ai` implementation. It resolves named `provider` routes.

A fallback such as:

```nex
fallback "openai"
```

needs a matching provider to perform real inference:

```nex
provider OpenAI {
  adapter "openai.responses"
  route "openai"
  model "gpt-5.6"
  key_env "OPENAI_API_KEY"
}
```

Without a matching provider, Nexu returns a typed error instead of silently networking.

### UI property validation fix

0.5 fixes per-property schema lookup. Invalid UI property types or invalid `bind` state references that slipped through earlier builds are now compile errors.

## New optional language surface

Existing static UI may remain static. Add `state`, `on` and `set` only where reactive behaviour is needed.
