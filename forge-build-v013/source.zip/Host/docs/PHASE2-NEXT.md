# Nexu Language — next Phase 2 increment

Recommended next version: **0.2.1 Task & Effect Foundation**.

Order:

1. Define `Task<T>` as a real language/runtime abstraction rather than a Promise-shaped bootstrap type.
2. Add cancellation handles, timeouts, and deterministic cancellation propagation.
3. Derive function effects from declared capabilities.
4. Prevent functions/agents from invoking effects outside their declared scope.
5. Add safe AI invocation expressions bound to named `ai` declarations.
6. Add agent action/tool declarations with explicit approval requirements.
7. Add first-class `ui` declarations only after the task/effect rules are testable.

Do not add arbitrary host JavaScript escape hatches to make implementation easier.
