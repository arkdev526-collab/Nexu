# Nexu Language 0.6.0 — Components, Navigation, Persistence & Local AI Bridge

## Goal

Move Nexu from a stateful single-surface application language into a reusable multi-screen application language with persistent typed state and a real local-model provider boundary.

## Delivered

- static reusable `component` declarations and `mount`;
- `screen` nodes and checked `navigate`;
- host-gated `focus` with compiler-checked targets;
- typed persistent `store` declarations;
- contextual `load` and `save`;
- runtime primitive type validation for persisted values;
- `storage.local` host support for console and browser previews;
- `ollama.chat` compiler-known loopback provider;
- local-AI capability `ai.local`;
- hybrid local-first provider routing with separately gated online fallback;
- Local AI Doctor command and Windows launcher;
- updated explain/metrics output.

## Deliberately not delivered

- encrypted persistence;
- secret storage;
- general mutable variables;
- reactive component props/state/events;
- dynamic route parameters/history;
- browser/server bridge;
- arbitrary local/remote provider URLs;
- local inference benchmark claims;
- self-hosting compiler.

## Reference application

Nexu AI now demonstrates:

- `local.qwen` routed through `ollama.chat`;
- `openai` as a separately gated fallback;
- a persistent Preferences store;
- reusable BrandHeader component;
- Home and Settings screens;
- focus movement between screens;
- AI Chat Full and agent.coder Feature Modules.

The normal demo does not call either AI provider. Actual local inference is checked separately by the Local AI Doctor and later live testing on a machine with Ollama/Qwen installed.
