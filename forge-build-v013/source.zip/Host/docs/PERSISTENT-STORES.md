# Persistent Stores — Nexu Language 0.6.0

## Declaration

```nex
store Preferences {
  persist local
  state last_screen: String = "Home"
  state launch_count: Number = 0
}
```

0.6 supports String, Number and Bool store keys with literal defaults.

## Read

```nex
let savedScreen: String = await load Preferences.last_screen
```

`load` returns a `Task<T>`, therefore reads are awaited.

## Write

```nex
save Preferences.last_screen = "Settings"
```

`save` is permitted in async functions/UI event handlers and is type checked against the declared key.

## Runtime validation

The generated runtime validates String/Number/Bool persisted values during both load and save. Corrupted or incompatible values fail rather than silently changing the declared type.

## Capability boundary

Persistent stores derive/use:

```text
storage.local
```

An explicit application `deny` remains authoritative. A compatible host must explicitly provide `storage.local`.

## Current host implementations

### console.preview

Stores scoped JSON values under:

```text
<working-directory>/.nexu-data/
```

Writes use a temporary file followed by rename.

### web.dom

Uses scoped browser `localStorage` keys.

## Security warning

**0.6 persistence is not encrypted.** Do not store API keys, passwords, tokens, private keys or other secrets in Nexu stores.

The OpenAI provider continues to use `OPENAI_API_KEY` from the process environment. A future secret-store contract must be designed separately from ordinary persistent application state.

## Deferred

- records/lists as persisted values;
- schema versioning/migrations;
- transactions;
- encrypted stores;
- multi-process locking;
- cloud sync.
