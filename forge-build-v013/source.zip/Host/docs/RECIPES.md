# Nexu Recipes — 0.6.0

Recipes are deterministic, validated source transformations. They are not arbitrary AI-generated patches.

## Baseline recipes

```text
AI Chat Full
AI Chat Core
Coding Agent
Project Workspace
Local Storage
Local Authentication
```

`AI Chat Full` composes the chat Feature Module, a safe preview host and a stateful declarative chat UI. It does not inject credentials or silently install a production provider.

`Local Storage` now emits:

```nex
use storage.local {
  encrypted false
  scope app
}
```

`encrypted true` is intentionally rejected in 0.6 because built-in persistence is not encrypted.

## Application safety

Recipe apply:

1. parses current source;
2. prepares proposed source;
3. validates proposed source;
4. writes a backup;
5. writes the change;
6. recompiles;
7. rolls back on failure;
8. remains idempotent where the recipe semantics allow it.

Recipes refuse ambiguous destructive host/UI merges rather than guessing.
