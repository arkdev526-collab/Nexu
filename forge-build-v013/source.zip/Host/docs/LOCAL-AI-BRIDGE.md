# Local AI Bridge — Nexu Language 0.6.0

## Goal

Make the local model path real without weakening the distinction between local/offline AI and online providers.

## Ollama local provider

```nex
provider LocalQwen {
  adapter "ollama.chat"
  route "local.qwen"
  model "qwen3:8b"
  base_url "http://127.0.0.1:11434"
}
```

The compiler-known `ollama.chat` adapter:

- runs in Node/server environments;
- supports `ai.ask`;
- requires `ai.local allow`;
- accepts HTTP loopback only;
- calls Ollama's local chat API;
- currently uses a non-streaming request;
- rejects cloud-tagged model routes in the Nexu local provider.

## Hybrid reference policy

```nex
ai Assistant {
  model "local.qwen"
  fallback "openai"
  privacy local_first
}
```

The primary route is local. If it returns a typed provider failure, Nexu may attempt the configured fallback. The OpenAI fallback still requires its independent `network.ai confirm` gate.

## Strict offline mode

At the Nexu application level:

```nex
capability network.ai deny
```

prevents cloud provider execution.

For an Ollama-wide local-only policy, configure the external Ollama service to disable its Cloud capability as well. Nexu cannot truthfully guarantee an external Ollama installation's global cloud configuration merely from the loopback URL.

## Local AI Doctor

Run:

```text
node compiler/cli.mjs local-ai doctor examples/nexu-ai.nex
```

or on Windows:

```text
CHECK-LOCAL-AI.cmd
```

The doctor:

1. compiles the Nexu project;
2. locates `ollama.chat` providers;
3. checks the loopback Ollama version endpoint;
4. reads the installed model list;
5. verifies each configured local model is present.

If Ollama is not reachable, the doctor fails with an actionable message. It does not silently fall back to OpenAI.

## Verification boundary for this release

The 0.6 automated suite proves the generated Ollama adapter against a controlled local HTTP server, including request route, model, prompt, `stream:false` and response extraction.

The build workspace itself has no reachable Ollama service, therefore this release does **not** claim that a real Qwen model executed on the build machine. That is a Windows/local-machine verification step.
