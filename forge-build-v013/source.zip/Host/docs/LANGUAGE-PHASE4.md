# Nexu Language Phase 4 — Declarative UI & Host Adapter Contracts

## Goal

Phase 4 connects Nexu's intent-level features to visible application surfaces without giving generated code unrestricted access to the host platform.

## New syntax

### Host contract

```nex
host PreviewHost {
  adapter "console.preview"
  provides ui.render
}
```

### Declarative UI

```nex
ui Workspace {
  layout: app_shell
  title: "Nexu AI"
  theme: dark
  gap: 16

  sidebar Projects {
    width: 216
  }

  chat AssistantChat {
    use ai.chat.full
    grow: 1
    placeholder: "Message Nexu AI"
  }

  dock Context {
    width: 320
  }
}
```

## Semantic rules

- one UI root per application;
- one host contract per application;
- UI/host declarations are app-only;
- node names are unique in a UI tree;
- node/property schemas are compiler-known;
- unknown node/property names fail compilation;
- a chat node must bind `ai.chat.full`;
- the bound feature must be present in the resolved feature plan;
- UI requires a host that provides `ui.render`;
- explicit capability `deny` is authoritative.

## Generated runtime

The emitter creates an inspectable UI descriptor, a host contract descriptor and a capability-gated host invocation path. The UI tree does not directly call platform APIs.

## Bootstrap hosts

`console.preview` is the default Node-safe demonstration host.

`web.dom` is the first browser host. It renders the initial supported UI tree with semantic DOM elements and safe textual insertion. CLI `run` intentionally refuses browser-host apps; they are built for a browser host instead.

## AI integration

The `chat` UI node receives the `ai.chat.full` runtime bridge rather than implementing a second chat engine. This preserves the architecture:

```text
Feature Module -> runtime capability -> UI binding -> host render
```

Network-capable AI requests route through the host capability gate. No 0.4.0 host adapter provides `network.ai`, so there is no hidden cloud call path.
