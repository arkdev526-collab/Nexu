# Components & Navigation — Nexu Language 0.6.0

## Static components

Declare reusable UI structure once:

```nex
component BrandHeader {
  column Brand {
    gap: 4
    text ProductName { label: "Nexu AI" }
    text ProductMode { label: "Local-first AI" }
  }
}
```

Mount it into a UI/screen:

```nex
mount BrandHeader Header
```

Mounted descendant names are instance-prefixed so the normalised UI tree remains deterministic.

### 0.6 limits

A component may contain nested declarative UI nodes/properties. It may not own:

- `state`;
- `on` event handlers;
- Feature Module `use` bindings;
- nested `mount` operations.

These limits avoid inventing an incomplete component ownership/lifecycle model.

## Screens

```nex
ui Workspace {
  start_screen: Home

  screen Home {
    label: "Assistant"
  }

  screen Settings {
    label: "Settings"
  }
}
```

`start_screen` must name a declared screen. If omitted, the first declared screen becomes the initial screen.

## Navigation

Inside UI events:

```nex
navigate Settings
```

The compiler rejects unknown targets. Navigation is currently in-memory screen switching, not URL routing or navigation history.

## Focus

```nex
focus ThemeInput
```

Focus is allowed only from UI event handlers. The target must exist and be focusable. `focus` derives the `ui.focus` effect/capability and executes through the selected host adapter.

This keeps focus/accessibility behaviour host-aware instead of exposing raw DOM/native APIs to source code.
