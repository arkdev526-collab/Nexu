# Provider Adapters — Nexu Language 0.6.0

Providers are compiler-known service/inference boundaries and remain separate from UI hosts.

## Catalogue

### `test.echo`

- environment: any
- operation: `ai.ask`
- capabilities: none
- deterministic/offline
- **test-only**, not a model

### `ollama.chat`

- environment: Node/server
- operation: `ai.ask`
- capability: `ai.local allow`
- endpoint: HTTP loopback only
- default model: `qwen3:8b`
- runtime API: local Ollama `/api/chat`
- cloud-tagged Ollama model routes rejected by Nexu's local-only adapter

```nex
provider LocalQwen {
  adapter "ollama.chat"
  route "local.qwen"
  model "qwen3:8b"
  base_url "http://127.0.0.1:11434"
}
```

### `openai.responses`

- environment: Node/server
- operation: `ai.ask`
- capability: `network.ai confirm`
- endpoint: compiler-fixed OpenAI Responses API
- credential: `OPENAI_API_KEY` only

```nex
provider OpenAI {
  adapter "openai.responses"
  route "openai"
  model "gpt-5.6"
  key_env "OPENAI_API_KEY"
}
```

## Runtime provider gate

Before adapter invocation Nexu checks route, operation, cancellation, capability policy, confirmation when required, and adapter implementation.

## Local/cloud split

`ai.local` does not imply `network.ai`. An app can allow the local provider and deny cloud AI entirely.

A local-first fallback configuration does not silently grant the fallback. The cloud route still crosses its own capability/confirmation boundary.

## Browser boundary

0.6 has no implicit browser-to-Node provider bridge. `web.dom` cannot silently bind Node-only Ollama/OpenAI adapters.
