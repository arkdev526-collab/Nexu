# Nexu Language Baseline — v0.6.0

## Purpose

This is the working language contract for **0.6.0 Components, Navigation, Persistence & Local AI Bridge**. Breaking changes require an explicit versioned migration.

## Product thesis

> **Express application intent once while the compiler safely and transparently supplies repeatable infrastructure.**

Nexu is not justified by shorter punctuation alone. Its value is reducing repeated application plumbing while keeping types, dependencies, permissions, UI behaviour, persistence, host boundaries and AI-provider routes inspectable.

## Design ancestry

Nexu borrows principles rather than splicing grammars:

- Python: readability and low ceremony;
- TypeScript: pragmatic app-scale types/tooling and bootstrap output;
- Rust: explicit failure handling and reluctance to make dangerous behaviour implicit.

## Baseline rules

1. Easy things are short.
2. Advanced things remain possible.
3. High-level does not mean hidden.
4. Safety policy is compiler-understood data.
5. AI, agents, UI, providers, stores and screens are first-class concepts.
6. Feature Modules compose systems, not pasted text.
7. Recipes are deterministic source transformations.
8. UI consumes Feature Modules rather than cloning logic.
9. `let` remains immutable until a broader ownership/mutation model exists.
10. UI mutation remains typed and event-scoped.
11. Components are reusable declarative UI contracts, not hidden code injection.
12. Navigation targets are compiler-checked.
13. Persistent state is typed and host-boundary gated.
14. Hosts and providers remain separate authorities.
15. Local AI and cloud AI remain separate provider routes/capabilities.
16. No silent cloud fallback.
17. No arbitrary host JavaScript/native escape hatch.
18. No runtime-speed or manual-code-reduction claim without a fair benchmark.

## 0.6 bootstrap architecture

```text
.nex project
  -> lexer
  -> parser
  -> AST + import graph
  -> semantic/type analysis
  -> Task/effect analysis
  -> Feature Module resolution
  -> component/screen/store resolution
  -> capability resolution
  -> UI state/event/focus analysis
  -> host contract validation
  -> provider contract validation
  -> TypeScript / bootstrap JavaScript
  -> runtime host gate
  -> runtime provider gate
  -> compiler-known adapters
```

The Nexu AI reference application is authored in Nexu Language. The compiler itself remains JavaScript `.mjs` modules and is not self-hosting yet.

## Foundation surface preserved

0.6 preserves the accepted 0.1→0.5 foundation:

- `app`, `module`, project-root-constrained local `.nex` imports;
- immutable `let`;
- String/Number/Bool/Void, records, lists and generics used by the language;
- functions, `if/else`, expressions and strict equality;
- `Result<T,E>` with exhaustive `match`;
- cancellable `Task<T>`, timeout/cancel and parent cancellation propagation;
- `async fn` / `await`;
- capability/effect analysis;
- AI and agent declarations;
- Feature Modules and Recipes;
- declarative UI, typed state/events and host contracts;
- provider contracts and provider runtime gates.

## 0.6 additions

### Reusable declarative components

```nex
component BrandHeader {
  column Brand {
    text ProductName { label: "Nexu AI" }
  }
}
```

Mount with:

```nex
mount BrandHeader Header
```

0.6 components are intentionally **static declarative components**. They may contain nested UI nodes and properties, but not component-owned state, events, Feature Module bindings or nested mounts. Those richer component semantics are deferred until typed props/state/lifecycle rules are designed.

### Checked screens and navigation

```nex
ui Workspace {
  start_screen: Home

  screen Home { ... }
  screen Settings { ... }
}
```

Inside a UI event:

```nex
navigate Settings
```

Screen targets are resolved at compile time. Unknown screens are errors.

### Focus contract

```nex
focus ThemeInput
```

Focus targets must exist and be inherently focusable (`button`, `input`, `chat`) or declare `focusable: true`. Focus derives `ui.focus` and crosses the host runtime capability gate.

### Typed persistent stores

```nex
store Preferences {
  persist local
  state last_screen: String = "Home"
  state launch_count: Number = 0
}
```

Read and write from async/event contexts:

```nex
let saved: String = await load Preferences.last_screen
save Preferences.last_screen = "Settings"
```

0.6 store values are restricted to primitive String/Number/Bool state with literal defaults. Runtime load/save validates the declared primitive type.

`load` and `save` are contextual syntax, not globally reserved identifiers, preserving valid older user functions named `load` or `save`.

The preview host persistence implementation is **not encrypted**. It is for ordinary application preferences/state, not secrets.

### Local AI provider bridge

0.6 adds the compiler-known `ollama.chat` provider:

```nex
provider LocalQwen {
  adapter "ollama.chat"
  route "local.qwen"
  model "qwen3:8b"
  base_url "http://127.0.0.1:11434"
}
```

The adapter:

- supports `ai.ask`;
- derives/requires `ai.local allow`;
- accepts only HTTP loopback (`127.0.0.1`, `localhost`, `[::1]`);
- refuses credentials/query/hash/API subpaths in `base_url`;
- POSTs to the local `/api/chat` route with streaming disabled for the 0.6 bridge;
- rejects model names marked as Ollama Cloud routes in the Nexu local-only adapter.

`ollama.chat` is intentionally a **local provider**. Cloud AI remains a separate provider such as `openai.responses`, which requires `network.ai confirm`.

Because the Ollama server itself can be configured with cloud capability outside Nexu, users who require an Ollama-wide offline guarantee should also disable Ollama Cloud at the Ollama service level. Nexu does not claim it can introspect or enforce the external server's global configuration.

### Local AI Doctor

```text
node compiler/cli.mjs local-ai doctor examples/nexu-ai.nex
```

The doctor checks configured `ollama.chat` providers, reaches the loopback Ollama service, reads its version/model catalogue and confirms the configured model is installed.

Doctor success proves reachability/model presence. It is not a benchmark of model quality or speed.

## Hybrid model contract

The intended Nexu AI reference route is:

```text
local.qwen (ollama.chat / ai.local)
        -> on typed local-provider failure
openai    (openai.responses / network.ai confirm)
```

This is **local first**, not silent cloud. The fallback provider still crosses its own runtime gate and confirmation requirement.

A truly offline application can explicitly deny network AI:

```nex
capability network.ai deny
```

That policy remains authoritative over Feature Module/provider requirements.

## Persistence host implementations

0.6 compiler-known hosts currently implement `storage.local` as:

- `console.preview`: JSON files under project-local `.nexu-data`, written via temporary file + rename;
- `web.dom`: browser `localStorage` with scoped Nexu keys.

These are application-state stores, not secret stores and not an encrypted database.

## Host/provider separation

Host capabilities in the 0.6 built-in hosts include:

```text
ui.render
ui.confirm
ui.focus
storage.local
```

Providers declare their own inference/service capabilities. UI rendering does not grant AI/network access. Local AI does not grant cloud AI. Confirmation surfaces do not grant the capability being confirmed.

Browser-only `web.dom` builds still cannot silently bind Node-only providers. An explicit browser/server bridge remains deferred.

## Measurements

The compiler reports authored Nexu lines, generated TypeScript lines, features, components, screens, stores, UI nodes/events/state and provider contracts.

These are **compiler expansion metrics only**. They do not prove equivalent hand-written TypeScript line count, runtime performance, memory use or startup speed.

## Security boundary

0.6 is not an OS sandbox. Compiler-known host/provider adapters are trusted runtime code and require review/testing. The compiler and runtime gates reduce implicit authority but do not replace OS isolation, process sandboxing, encrypted secret storage or network policy enforcement outside the application.

## Deferred by design

- reactive component props/state/events/lifecycle;
- dynamic/parameterised component composition;
- navigation history/deep links/route parameters;
- persistent schema migration/versioning;
- encrypted persistent stores and secret vaults;
- browser-to-server provider bridge;
- local-model streaming through `ollama.chat`;
- local embedding/RAG provider adapters;
- arbitrary third-party adapters or provider endpoints;
- native/WASM backend;
- self-hosting compiler;
- package registry.

## Next evidence target

Exercise 0.6 through real Nexu AI usage, especially actual Windows Ollama/Qwen execution. The strongest next major line should address **reactive components, explicit secure browser/server bridges and local RAG/embeddings**, without weakening the 0.6 local/cloud capability split.
