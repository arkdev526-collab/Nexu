# Nexu Language 0.3.0 — Feature Modules & Recipes

## Feature declaration syntax

```nex
use ai.chat.full {
  model "local.qwen"
  privacy local_first
}
```

Feature paths are dotted identifiers. Config values currently support quoted strings, numbers, booleans and bare enum-like names.

## Feature resolution

The compiler:

1. validates the feature ID;
2. validates configuration names and types;
3. fills documented defaults;
4. resolves dependencies;
5. resolves capability requirements;
6. rejects explicit capability conflicts;
7. emits an inspectable feature plan;
8. emits feature-specific runtime foundations where implemented.

## Capability resolution

The effective policy is never weaker than either the app's explicit policy or the feature's required policy.

An explicit `deny` wins by rejecting an incompatible feature rather than silently overriding the user's denial.

## AI Chat Full

`ai.chat.full` currently emits a headless chat runtime foundation. It does not yet emit the final visual chat UI.

Available Nexu calls when the feature is present:

```nex
await chatSend("Hello")
chatClear()
```

`chatSend` returns:

```text
Task<Result<String, String>>
```

Its capability effects are derived from the resolved feature configuration.

## Recipe engine

Recipes are deterministic aliases to known Feature Modules. They can be inspected, previewed or applied.

`recipe apply` edits only a Nexu `app` source file, creates a backup, and validates the result.

## Standard feature catalogue

See `FEATURE-MODULES.md`.
