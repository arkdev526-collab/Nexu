# Migration — Nexu Language 0.5.0 to 0.6.0

## Compatibility intent

0.6 preserves accepted 0.5 syntax and behaviour unless a change is explicitly listed here.

## AI effects

Local model routes now have a distinct `ai.local` capability/effect. A local-first AI with online fallback may therefore report both:

```text
ai.local
network.ai
```

This is intentional. Local inference should not be represented as network authority.

## `load` and `save`

Persistent store syntax introduces:

```nex
await load Store.key
save Store.key = value
```

`load` and `save` are contextual syntax rather than globally reserved keywords. Existing functions such as `fn load()` remain valid.

## Host capabilities

Built-in 0.6 preview hosts add:

```text
ui.focus
storage.local
```

Declare them when your UI uses focus or a persistent store.

## Local provider

Use:

```nex
provider LocalQwen {
  adapter "ollama.chat"
  route "local.qwen"
  model "qwen3:8b"
  base_url "http://127.0.0.1:11434"
}
```

Do not use remote URLs with `ollama.chat`. The adapter is deliberately loopback-only.

## Components/screens

New syntax is additive:

```nex
component Header { ... }
mount Header MainHeader
screen Home { ... }
navigate Settings
focus SearchInput
```

0.6 components are static. Move state/events to the owning UI/screen rather than placing them inside components.

## Persistence warning

The 0.6 built-in local store is not encrypted. Keep secrets in provider/environment/secret mechanisms, not `store` declarations.
