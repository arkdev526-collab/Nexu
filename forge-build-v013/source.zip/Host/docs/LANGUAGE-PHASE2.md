# Nexu Language 0.2.0 — Phase 2 Language Reference

## Compilation units

An executable entry file declares one `app`:

```nex
app Demo {
  fn start() {
    print("ready")
  }
}
```

Reusable source declares one `module`:

```nex
module Core {
  fn greet(name: String): String {
    return "Hello " + name
  }
}
```

## Imports

```nex
import { greet } from "./core.nex"
```

Phase 2 imports are local, relative, selective, and restricted to `.nex` source beneath the entry project's root.

## Types

Primitive types:

- `String`
- `Number`
- `Bool`
- `Void`

Generic types:

- `List<T>`
- `Result<T, E>`
- `Task<T>` (produced by async functions and bootstrap task primitives)

## Bindings

`let` creates an immutable binding in 0.2.0. Mutation syntax is intentionally absent until ownership/effect rules are designed. Generated TypeScript/JavaScript therefore uses `const`.

Equality operators `==` and `!=` use typed Nexu semantics and emit strict JavaScript/TypeScript equality (`===` and `!==`).

## Records

Record type names use PascalCase in 0.2.0 so the parser can unambiguously distinguish record construction from block syntax.

```nex
record Project {
  name: String
  files: List<String>
}

let project: Project = Project {
  name: "Nexu",
  files: ["README.md"]
}
```

Field access and indexing:

```nex
print(project.name)
print(project.files[0])
```

## Result handling

```nex
fn connect(flag: Bool): Result<String, String> {
  if flag {
    return ok("connected")
  } else {
    return err("offline")
  }
}
```

`Result` matches must handle both variants:

```nex
match connect(true) {
  ok(value) {
    print(value)
  }
  err(reason) {
    print(reason)
  }
}
```

## Async

```nex
async fn load(): String {
  await delay(1)
  return "ready"
}

async fn start() {
  let value: String = await load()
  print(value)
}
```

An async function's declared return type is its resolved value type. Do not write `async fn load(): Task<String>`.

## Capabilities

```nex
capability project.read allow
capability project.write confirm
capability network.ai deny
```

Policies are explicit and ordered by restrictiveness:

```text
allow < confirm < deny
```

## AI declarations

```nex
ai Assistant {
  model "local.qwen"
  fallback "openai"
  privacy local_first
}
```

Allowed privacy policies:

- `local_only`
- `local_first`
- `cloud_allowed`

`local_only` cannot declare a fallback.

## Agents

```nex
agent Coder {
  use Assistant
  permission project.read allow
  permission project.write confirm
}
```

Every agent permission must be declared as an app capability. An agent may make the policy stricter but never weaker.

## Deliberately absent in 0.2.0

- arbitrary host JavaScript
- mutation/assignment syntax
- classes/inheritance
- unrestricted package imports
- first-class UI blocks
- real model/provider invocation
- cancellable task handles
- native/WASM backend

These omissions are intentional while the core effect, capability, and task semantics mature.
