# Nexu Language Phase 1

## Status

Experimental bootstrap language, version `0.1.0-phase1`.

## Purpose

Create a readable, strongly typed application language that can later make AI, UI, data, permissions and cross-platform application concepts first-class. Nexu AI is the first reference application.

## Phase 1 grammar surface

Supported today:

- One `app Name { ... }` declaration per source file.
- `fn` functions with typed parameters and optional return types.
- Primitive types: `String`, `Number`, `Bool`, `Void`.
- `let` local variables with explicit or inferred types.
- String, number and boolean literals.
- Function calls and built-in `print(...)`.
- `if` / `else`.
- `return`.
- Arithmetic, comparison, equality and boolean operators.
- `//` comments.
- Optional semicolons.
- Required `start()` app entry point.

Not yet supported:

- Modules/imports.
- Objects, lists or user-defined types.
- Async/await.
- Error/result types and `match`.
- UI, AI, agents, permissions, storage or networking keywords.
- Generics.
- Native/WASM backends.
- Language server/editor integration.

## Compiler pipeline

`source.nex -> lexer -> parser -> AST -> semantic analyser -> TypeScript emitter`

A JavaScript emitter is also included only so Phase 1 programs can be executed immediately while TypeScript remains the primary bootstrap target.

## Safety rule

The language does not permit arbitrary host JavaScript injection in Phase 1. Source code must pass parsing and semantic checks before output is emitted.
