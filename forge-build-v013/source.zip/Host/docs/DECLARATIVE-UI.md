# Declarative UI — Nexu Language 0.6.0

## Root

```nex
ui Workspace {
  layout: app_shell
  title: "Nexu AI"
  theme: dark
  gap: 16
  start_screen: Home
  state status: String = "Ready"
}
```

## Node catalogue

```text
surface row column sidebar dock panel chat text button input screen component
```

`component` entries appear in the normalised tree when a declared component is mounted.

## State/events

Root state remains typed String/Number/Bool with literal initialisers. `set` is restricted to UI event handlers.

Compiler-known events remain:

```text
root    ready()
chat    send(String), clear(), stop()
button  click()
input   change(String), submit(String)
```

## Screens

Use `screen` and `start_screen`. `navigate` is event-scoped and target checked.

## Components

Use top-level static `component` declarations and `mount`. 0.6 deliberately does not add component-owned state/events/props/lifecycle yet.

## Focus/accessibility

Nodes support accessibility-oriented properties including `aria_label` and `focusable`. `focus Target` is compiler checked and host-gated via `ui.focus`.

## Feature binding

A `chat` node that uses AI Chat Full must explicitly bind:

```nex
chat AssistantChat {
  use ai.chat.full
}
```

This keeps UI presentation separate from the underlying Feature Module/provider implementation.
