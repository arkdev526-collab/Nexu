# Nexu AI 3D Forge v0.9.0 — Creation Intelligence & Creature Foundation

## Release thesis
Forge now understands a first set of organic creature classes instead of treating every unknown prompt as a rigid primitive. The implementation remains local, deterministic, editable and bounded by Nexu3D validation.

## Added
- Creation Intelligence router for object vs creature intent.
- Eight permanent local creature grammars: Dragon, Wyvern, Griffin, Wolf, Giant Spider, Snake, Bird and Fish.
- Seven reusable style profiles: medieval fantasy, dark fantasy, ancient beast, realistic, stylised game, skeletal and corrupted.
- Organic Creature Builder using package-owned Blender operations: guide volumes, connected segments, Blender voxel remesh and explicit controllable detail parts.
- Anatomy validation for limbs/wings before Blender execution.
- Dragon/Wyvern wings, membranes, horns, claws, tails and dorsal spikes.
- Avian beak, fish fins, spider eight-leg construction and serpent body path.
- Creature PBR material families: scales, membrane, horn/bone, fur, feather, chitin and skin.
- Non-destructive morphology refinement for wing span, neck/tail length, horn scale, body bulk, spikes and wing damage.
- Creature-specific QA evidence and organic-remesh verification.
- Creature learning evidence: accepted morphology medians remain bounded/local and explicit prompt constraints always win.
- Static creature triangle-budget calibration that preserves separate silhouette/detail parts while reducing the remeshed body where necessary.
- Flagship deterministic recipe fixture: `3d-forge/examples/medieval-dragon.n3d.json`.
- Studio prompt presets for Dragon, Wyvern, Wolf and Giant Spider.

## Preserved
- Existing 23 rigid asset grammars.
- Material Intelligence.
- Safe Mesh Repair.
- seven-view dataset capture.
- local Good / Needs Work learning.
- Android Creator Companion protocol.
- Windows per-user Install / Update / Repair / Rollback model.
- user-created assets outside the application directory.
- AI text never becomes arbitrary Python/shell/native code.

## Deliberately deferred
- humanoid generation.
- animation rigs and skeletal animation.
- sculpting replacement.
- paid/cloud generation providers.
- unqualified neural 3D dependencies.

## Candidate boundary
Automated source/regression validation passes in the available environment. A real Blender 5.2 dragon generation and at least one non-dragon creature generation on Windows remain mandatory before release promotion.
