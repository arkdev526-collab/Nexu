@echo off
setlocal
cd /d "%~dp0"
start "" "NEXU-LANGUAGE-CHEAT-SHEET.md"
