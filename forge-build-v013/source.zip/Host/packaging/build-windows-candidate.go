package main

import (
	"archive/zip"
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
)

const expectedVersion = "0.13.0"
const expectedGoVersion = "go1.26.6"

type manifestRow struct{ rel, hash string }

func failf(format string, a ...any) { fmt.Fprintf(os.Stderr, "ERROR: "+format+"\n", a...); os.Exit(1) }
func must(err error) {
	if err != nil {
		failf("%v", err)
	}
}

func rootFromExecutable() string {
	wd, err := os.Getwd()
	must(err)
	if _, err := os.Stat(filepath.Join(wd, "3d-forge")); err == nil {
		return wd
	}
	failf("run this builder from the Nexu AI 3D Forge source root")
	return ""
}

func exactGo() string {
	p := strings.TrimSpace(os.Getenv("NEXU_GO_EXE"))
	if p == "" {
		failf("NEXU_GO_EXE was not supplied by BUILD-WINDOWS-CANDIDATE.cmd")
	}
	out, err := exec.Command(p, "version").CombinedOutput()
	must(err)
	if !strings.Contains(string(out), expectedGoVersion) {
		failf("expected Go 1.26.6, found %s", strings.TrimSpace(string(out)))
	}
	return p
}

func goBuild(goexe, dir, out string) {
	fmt.Printf("Building %s...\n", filepath.Base(out))
	cmd := exec.Command(goexe, "build", "-trimpath", "-buildvcs=false", "-ldflags", "-s -w -H=windowsgui", "-o", out, ".")
	cmd.Dir = dir
	cmd.Env = append(os.Environ(), "GOOS=windows", "GOARCH=amd64", "CGO_ENABLED=0", "GOTOOLCHAIN=local")
	cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
	if err := cmd.Run(); err != nil {
		failf("Go build failed in %s: %v", dir, err)
	}
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	if err = os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	_, cp := io.Copy(out, in)
	ce := out.Close()
	if cp != nil {
		return cp
	}
	return ce
}

func copyTree(src, dst string) error {
	return filepath.WalkDir(src, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)
		if d.IsDir() {
			return os.MkdirAll(target, 0755)
		}
		return copyFile(path, target)
	})
}

func shaFile(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func writeManifest(root string) error {
	var rows []manifestRow
	err := filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			return nil
		}
		if filepath.Base(path) == "PACKAGE-MANIFEST.sha256" {
			return nil
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		rel = filepath.ToSlash(rel)
		h, err := shaFile(path)
		if err != nil {
			return err
		}
		rows = append(rows, manifestRow{rel, h})
		return nil
	})
	if err != nil {
		return err
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].rel < rows[j].rel })
	if len(rows) < 10 {
		return fmt.Errorf("payload manifest unexpectedly small: %d", len(rows))
	}
	f, err := os.Create(filepath.Join(root, "PACKAGE-MANIFEST.sha256"))
	if err != nil {
		return err
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	for _, r := range rows {
		fmt.Fprintf(w, "%s *%s\n", r.hash, r.rel)
	}
	return w.Flush()
}

func zipTree(src, out string) error {
	f, err := os.Create(out)
	if err != nil {
		return err
	}
	zw := zip.NewWriter(f)
	walkErr := filepath.WalkDir(src, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			return nil
		}
		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		rel = filepath.ToSlash(rel)
		hdr := &zip.FileHeader{Name: rel, Method: zip.Deflate}
		hdr.SetMode(0644)
		w, err := zw.CreateHeader(hdr)
		if err != nil {
			return err
		}
		in, err := os.Open(path)
		if err != nil {
			return err
		}
		_, cp := io.Copy(w, in)
		in.Close()
		return cp
	})
	ze := zw.Close()
	fe := f.Close()
	if walkErr != nil {
		return walkErr
	}
	if ze != nil {
		return ze
	}
	return fe
}

func main() {
	install := flag.Bool("install", false, "launch Setup after successful build")
	flag.Parse()
	root := rootFromExecutable()
	goexe := exactGo()
	vb, err := os.ReadFile(filepath.Join(root, "VERSION.txt"))
	must(err)
	version := strings.TrimSpace(string(vb))
	if version != expectedVersion {
		failf("VERSION.txt must be %s, found %s", expectedVersion, version)
	}

	artifacts := filepath.Join(root, "artifacts", "windows-candidate")
	payload := filepath.Join(artifacts, "payload")
	launcherOut := filepath.Join(artifacts, "Nexu AI 3D Forge.exe")
	setupOut := filepath.Join(artifacts, "Nexu-AI-3D-Forge-Setup-"+version+"-x64.exe")
	must(os.MkdirAll(artifacts, 0755))
	goBuild(goexe, filepath.Join(root, "packaging", "native-launcher"), launcherOut)

	fmt.Println("Assembling verified application payload...")
	must(os.RemoveAll(payload))
	forgePayload := filepath.Join(payload, "3d-forge")
	must(os.MkdirAll(forgePayload, 0755))
	runtimeFiles := []string{"blender-worker.py", "blender.mjs", "brief.mjs", "screen-share.mjs", "pairing-qr.mjs", "companion-crypto.mjs", "companion-server.mjs", "cli.mjs", "planner.mjs", "asset-grammar.mjs", "learning-ledger.mjs", "creature-grammar.mjs", "creation-intelligence.mjs", "prompt-intelligence.mjs", "compact-cache.mjs", "qa.mjs", "reference-guidance.mjs", "reference-providers.mjs", "refine.mjs", "material-intelligence.mjs", "schema.mjs", "setup-windows.mjs", "studio-server.mjs", "update-client.mjs", "update-manifest.fixture.json", "VERSION.txt", "README.md", "TECH-BASELINE.md"}
	for _, name := range runtimeFiles {
		must(copyFile(filepath.Join(root, "3d-forge", name), filepath.Join(forgePayload, name)))
	}
	must(copyTree(filepath.Join(root, "3d-forge", "vendor"), filepath.Join(forgePayload, "vendor")))
	must(copyTree(filepath.Join(root, "3d-forge", "studio"), filepath.Join(forgePayload, "studio")))
	must(copyFile(filepath.Join(root, "SUMERO-TECH-AUTHORITY.md"), filepath.Join(payload, "SUMERO-TECH-AUTHORITY.md")))
	must(writeManifest(payload))

	setupDir := filepath.Join(root, "packaging", "setup-native")
	payloadZip := filepath.Join(setupDir, "payload.zip")
	embeddedLauncher := filepath.Join(setupDir, "app-launcher.exe")
	defer os.Remove(payloadZip)
	defer os.Remove(embeddedLauncher)
	must(zipTree(payload, payloadZip))
	must(copyFile(launcherOut, embeddedLauncher))
	goBuild(goexe, setupDir, setupOut)
	h, err := shaFile(setupOut)
	must(err)
	hashUpper := strings.ToUpper(h)
	must(os.WriteFile(setupOut+".sha256.txt", []byte(hashUpper+"  "+filepath.Base(setupOut)+"\r\n"), 0644))
	fmt.Printf("PASS: %s\nSHA-256: %s\n", setupOut, hashUpper)
	if *install {
		cmd := exec.Command(setupOut)
		if err := cmd.Start(); err != nil {
			failf("Setup was built but could not be launched: %v", err)
		}
		fmt.Println("Setup launched.")
	}
}
