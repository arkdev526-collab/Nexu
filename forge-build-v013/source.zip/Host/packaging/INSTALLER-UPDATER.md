# Nexu AI 3D Forge v0.9.0 — Installer / Updater

## Windows candidate build
Run `BUILD-WINDOWS-CANDIDATE.cmd`.

The build route does not invoke PowerShell and does not alter execution policy. It obtains the official Go 1.26.6 Windows x64 archive from go.dev, verifies SHA-256 `5b6c5b556525810463b5c897b50dc7a82d6a3dc0bfaf55d990a7e9f31d6b2318`, then runs the package-owned Go builder.

Expected output:

`artifacts\windows-candidate\Nexu-AI-3D-Forge-Setup-0.9.0-x64.exe`

## Lifecycle
The Setup executable preserves the established per-user lifecycle:
- fresh install when no supported Forge install exists;
- update when an older supported version exists;
- repair for the same version;
- rollback retention through the installed version model;
- uninstall through Windows Installed Apps;
- user-created assets remain outside the application directory and are preserved by default.

## Release boundary
The Setup executable must be built and exercised on Windows before v0.9 can advance beyond Candidate. Do not substitute an EXE built with the older container Go toolchain.
