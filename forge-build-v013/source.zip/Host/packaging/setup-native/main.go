package main

import (
	"archive/zip"
	"bufio"
	"bytes"
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

const version = "0.13.0"
const product = "Nexu AI 3D Forge"

//go:embed payload.zip app-launcher.exe
var embedded embed.FS
var user32 = syscall.NewLazyDLL("user32.dll")
var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var messageBox = user32.NewProc("MessageBoxW")
var moveFileEx = kernel32.NewProc("MoveFileExW")

func wptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func message(text string, flags uintptr) int {
	r, _, _ := messageBox.Call(0, uintptr(unsafe.Pointer(wptr(text))), uintptr(unsafe.Pointer(wptr(product+" Setup"))), flags)
	return int(r)
}
func info(text string)       { message(text, 0x40) }
func yesno(text string) bool { return message(text, 0x24) == 6 }
func installRoot() string {
	return filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "Sumero Studio", product)
}
func docsRoot() string {
	h := os.Getenv("USERPROFILE")
	if h == "" {
		h, _ = os.UserHomeDir()
	}
	return filepath.Join(h, "Documents", product)
}
func safeJoin(root, name string) (string, error) {
	name = filepath.Clean(filepath.FromSlash(name))
	if name == "." || filepath.IsAbs(name) || strings.HasPrefix(name, ".."+string(os.PathSeparator)) || name == ".." {
		return "", fmt.Errorf("unsafe payload path: %s", name)
	}
	p := filepath.Join(root, name)
	r, _ := filepath.Abs(root)
	a, _ := filepath.Abs(p)
	if a != r && !strings.HasPrefix(strings.ToLower(a), strings.ToLower(r+string(os.PathSeparator))) {
		return "", fmt.Errorf("payload path escaped install root")
	}
	return p, nil
}
func extractPayload(dest string) error {
	b, e := embedded.ReadFile("payload.zip")
	if e != nil {
		return e
	}
	zr, e := zip.NewReader(bytes.NewReader(b), int64(len(b)))
	if e != nil {
		return e
	}
	for _, f := range zr.File {
		p, e := safeJoin(dest, f.Name)
		if e != nil {
			return e
		}
		if f.FileInfo().IsDir() {
			if e = os.MkdirAll(p, 0755); e != nil {
				return e
			}
			continue
		}
		if e = os.MkdirAll(filepath.Dir(p), 0755); e != nil {
			return e
		}
		r, e := f.Open()
		if e != nil {
			return e
		}
		w, e := os.OpenFile(p, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
		if e != nil {
			r.Close()
			return e
		}
		_, ce := io.Copy(w, r)
		we := w.Close()
		r.Close()
		if ce != nil {
			return ce
		}
		if we != nil {
			return we
		}
	}
	return verifyManifest(dest)
}
func verifyManifest(root string) error {
	p := filepath.Join(root, "PACKAGE-MANIFEST.sha256")
	f, e := os.Open(p)
	if e != nil {
		return e
	}
	defer f.Close()
	s := bufio.NewScanner(f)
	count := 0
	for s.Scan() {
		line := strings.TrimSpace(s.Text())
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, " *", 2)
		if len(parts) != 2 {
			return fmt.Errorf("invalid package manifest")
		}
		target, e := safeJoin(root, parts[1])
		if e != nil {
			return e
		}
		b, e := os.ReadFile(target)
		if e != nil {
			return fmt.Errorf("manifest file missing: %s", parts[1])
		}
		sum := sha256.Sum256(b)
		if !strings.EqualFold(hex.EncodeToString(sum[:]), parts[0]) {
			return fmt.Errorf("integrity check failed: %s", parts[1])
		}
		count++
	}
	if e = s.Err(); e != nil {
		return e
	}
	if count < 10 {
		return fmt.Errorf("package manifest is unexpectedly small")
	}
	return nil
}
func readCurrent(root string) string {
	b, e := os.ReadFile(filepath.Join(root, "current-version.txt"))
	if e != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}
func semver(v string) [3]int {
	var o [3]int
	for i, p := range strings.Split(v, ".") {
		if i > 2 {
			break
		}
		o[i], _ = strconv.Atoi(p)
	}
	return o
}
func compare(a, b string) int {
	x, y := semver(a), semver(b)
	for i := 0; i < 3; i++ {
		if x[i] < y[i] {
			return -1
		}
		if x[i] > y[i] {
			return 1
		}
	}
	return 0
}
func run(name string, args ...string) error {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	return c.Run()
}
func nodeOK() bool {
	c := exec.Command("node.exe", "--version")
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	b, e := c.Output()
	return e == nil && strings.HasPrefix(strings.TrimSpace(string(b)), "v24.19.")
}
func blenderOK() bool {
	candidates := []string{"blender.exe", filepath.Join(os.Getenv("ProgramFiles"), "Blender Foundation", "Blender 5.2", "blender.exe")}
	for _, p := range candidates {
		c := exec.Command(p, "--version")
		c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
		if b, e := c.Output(); e == nil && strings.Contains(string(b), "Blender 5.2.") {
			return true
		}
	}
	return false
}
func installDependencies() {
	if nodeOK() && blenderOK() {
		return
	}
	if !yesno("Forge requires Node.js 24.19.x LTS and Blender 5.2.x.\n\nOne or both were not detected. Install the missing components now from the official WinGet source?\n\nNothing will be installed if you choose No.") {
		return
	}
	if _, e := exec.LookPath("winget.exe"); e != nil {
		info("WinGet is not available. Forge itself is installed, but generation requires Node.js 24.19.x LTS and Blender 5.2.x. Install them from their official sources, then reopen Forge.")
		return
	}
	if !nodeOK() {
		if e := run("winget.exe", "install", "--id", "OpenJS.NodeJS.LTS", "--exact", "--version", "24.19.0", "--source", "winget", "--architecture", "x64", "--accept-source-agreements", "--accept-package-agreements", "--disable-interactivity"); e != nil {
			info("Node.js installation did not complete. Forge remains installed. Open System Centre after launch for diagnostics.")
		}
	}
	if !blenderOK() {
		if e := run("winget.exe", "install", "--id", "BlenderFoundation.Blender", "--exact", "--version", "5.2.0", "--source", "winget", "--architecture", "x64", "--accept-source-agreements", "--accept-package-agreements", "--disable-interactivity"); e != nil {
			info("Blender installation did not complete. Forge remains installed. Open System Centre after launch for diagnostics.")
		}
	}
}
func psQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }
func shortcut(path, target, icon string) error {
	script := fmt.Sprintf("$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut(%s);$s.TargetPath=%s;$s.WorkingDirectory=%s;$s.IconLocation=%s;$s.Save()", psQuote(path), psQuote(target), psQuote(filepath.Dir(target)), psQuote(icon+",0"))
	return run("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script)
}
func startMenuPath() string {
	return filepath.Join(os.Getenv("APPDATA"), "Microsoft", "Windows", "Start Menu", "Programs", "Sumero Studio", product+".lnk")
}
func desktopPath() string { return filepath.Join(os.Getenv("USERPROFILE"), "Desktop", product+".lnk") }
func installShortcuts(root string, desktop bool) error {
	target := filepath.Join(root, product+".exe")
	icon := filepath.Join(root, "NexuAI3DForge.ico")
	if e := os.MkdirAll(filepath.Dir(startMenuPath()), 0755); e != nil {
		return e
	}
	if e := shortcut(startMenuPath(), target, icon); e != nil {
		return e
	}
	if desktop {
		return shortcut(desktopPath(), target, icon)
	}
	return nil
}

func register(root string) error { return registerVersion(root, version) }

func rollback() {
	root := installRoot()
	current := readCurrent(root)
	entries, err := os.ReadDir(filepath.Join(root, "versions"))
	if err != nil {
		info("Rollback is unavailable because no previous installed versions were found.")
		return
	}
	candidates := make([]string, 0)
	for _, entry := range entries {
		if !entry.IsDir() || entry.Name() == current {
			continue
		}
		name := entry.Name()
		if _, err := strconv.Atoi(strings.Split(name, ".")[0]); err == nil && strings.Count(name, ".") == 2 && compare(name, current) < 0 {
			candidates = append(candidates, name)
		}
	}
	if len(candidates) == 0 {
		info("Rollback is unavailable because no previous installed Forge version is retained.")
		return
	}
	previous := candidates[0]
	for _, candidate := range candidates[1:] {
		if compare(candidate, previous) > 0 {
			previous = candidate
		}
	}
	if !yesno(fmt.Sprintf("Roll back Nexu AI 3D Forge from v%s to v%s?\n\nYour generated assets in Documents will be preserved.", current, previous)) {
		return
	}
	if err := verifyManifest(filepath.Join(root, "versions", previous)); err != nil {
		info("Rollback was blocked because the retained version failed its integrity check.\n\n" + err.Error())
		return
	}
	if err := os.WriteFile(filepath.Join(root, "current-version.txt"), []byte(previous+"\n"), 0644); err != nil {
		info("Rollback could not update the active version.\n\n" + err.Error())
		return
	}
	_ = registerVersion(root, previous)
	info(fmt.Sprintf("Nexu AI 3D Forge rolled back to v%s.\n\nYour user-created assets were preserved.", previous))
	launcher := exec.Command(filepath.Join(root, product+".exe"))
	launcher.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	_ = launcher.Start()
}

func registerVersion(root, displayVersion string) error {
	setup := filepath.Join(root, "Nexu-AI-3D-Forge-Setup.exe")
	launcher := filepath.Join(root, product+".exe")
	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\NexuAI3DForge`
	vals := [][]string{
		{"/v", "DisplayName", "/t", "REG_SZ", "/d", product, "/f"},
		{"/v", "DisplayVersion", "/t", "REG_SZ", "/d", displayVersion, "/f"},
		{"/v", "Publisher", "/t", "REG_SZ", "/d", "Sumero Studio", "/f"},
		{"/v", "DisplayIcon", "/t", "REG_SZ", "/d", launcher, "/f"},
		{"/v", "InstallLocation", "/t", "REG_SZ", "/d", root, "/f"},
		{"/v", "UninstallString", "/t", "REG_SZ", "/d", `"` + setup + `" --uninstall`, "/f"},
		{"/v", "NoModify", "/t", "REG_DWORD", "/d", "1", "/f"},
	}
	for _, v := range vals {
		args := append([]string{"add", key}, v...)
		if e := run("reg.exe", args...); e != nil {
			return e
		}
	}
	return nil
}

func deploy() error {
	root := installRoot()
	if root == "" {
		return fmt.Errorf("LOCALAPPDATA is unavailable")
	}
	cur := readCurrent(root)
	if cur != "" && compare(cur, version) > 0 {
		return fmt.Errorf("a newer Forge version (%s) is already installed; this candidate will not downgrade it", cur)
	}
	action := "Install"
	if cur == version {
		action = "Repair"
	} else if cur != "" {
		action = "Update"
	}
	if !yesno(fmt.Sprintf("%s %s v%s?\n\n%s keeps generated assets in Documents\\%s and never overwrites them during install, repair or update.", action, product, version, product, product)) {
		return nil
	}
	versions := filepath.Join(root, "versions")
	if e := os.MkdirAll(versions, 0755); e != nil {
		return e
	}
	stage := filepath.Join(versions, ".staging-"+version)
	_ = os.RemoveAll(stage)
	if e := os.MkdirAll(stage, 0755); e != nil {
		return e
	}
	if e := extractPayload(stage); e != nil {
		_ = os.RemoveAll(stage)
		return e
	}
	target := filepath.Join(versions, version)
	backup := target + ".backup"
	_ = os.RemoveAll(backup)
	if _, e := os.Stat(target); e == nil {
		if e = os.Rename(target, backup); e != nil {
			return e
		}
	}
	if e := os.Rename(stage, target); e != nil {
		if _, be := os.Stat(backup); be == nil {
			_ = os.Rename(backup, target)
		}
		return e
	}
	_ = os.RemoveAll(backup)
	launcher, e := embedded.ReadFile("app-launcher.exe")
	if e != nil {
		return e
	}
	if e = os.WriteFile(filepath.Join(root, product+".exe"), launcher, 0755); e != nil {
		return e
	}
	iconSrc := filepath.Join(target, "3d-forge", "studio", "NexuAI3DForge.ico")
	if b, e := os.ReadFile(iconSrc); e == nil {
		_ = os.WriteFile(filepath.Join(root, "NexuAI3DForge.ico"), b, 0644)
	}
	self, e := os.Executable()
	if e == nil {
		if b, e := os.ReadFile(self); e == nil {
			_ = os.WriteFile(filepath.Join(root, "Nexu-AI-3D-Forge-Setup.exe"), b, 0755)
		}
	}
	if e = os.WriteFile(filepath.Join(root, "current-version.txt"), []byte(version+"\n"), 0644); e != nil {
		return e
	}
	desktop := yesno("Create a Desktop shortcut for Nexu AI 3D Forge?\n\nA Start menu shortcut is always created.")
	if e = installShortcuts(root, desktop); e != nil {
		return e
	}
	if e = register(root); e != nil {
		return e
	}
	_ = os.MkdirAll(docsRoot(), 0755)
	installDependencies()
	info(fmt.Sprintf("%s v%s is installed.\n\nYour assets are stored separately in:\n%s\n\nThe application is an unsigned engineering candidate.", product, version, docsRoot()))
	launcherPath := filepath.Join(root, product+".exe")
	c := exec.Command(launcherPath)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	_ = c.Start()
	return nil
}
func uninstall() {
	root := installRoot()
	if !yesno("Uninstall Nexu AI 3D Forge?\n\nYour generated assets in Documents will be preserved.") {
		return
	}
	_ = os.Remove(startMenuPath())
	_ = os.Remove(desktopPath())
	_ = run("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\NexuAI3DForge`, "/f")
	for _, n := range []string{"versions", product + ".exe", "NexuAI3DForge.ico", "current-version.txt"} {
		_ = os.RemoveAll(filepath.Join(root, n))
	}
	self, _ := os.Executable()
	if strings.EqualFold(filepath.Dir(self), root) {
		moveFileEx.Call(uintptr(unsafe.Pointer(wptr(self))), 0, 0x4)
		moveFileEx.Call(uintptr(unsafe.Pointer(wptr(root))), 0, 0x4)
	}
	info("Nexu AI 3D Forge was uninstalled.\n\nYour user-created assets remain in:\n" + docsRoot())
}
func main() {
	if runtime.GOOS != "windows" {
		return
	}
	for _, a := range os.Args[1:] {
		if a == "--uninstall" {
			uninstall()
			return
		}
		if a == "--rollback" {
			rollback()
			return
		}
	}
	if e := deploy(); e != nil {
		info("Setup could not complete.\n\n" + e.Error() + "\n\nYour previous installed version and user-created assets were left in place.")
	}
}
