module sumero.studio/nexu-forge-setup

go 1.26.0

toolchain go1.26.6
