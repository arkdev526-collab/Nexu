package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

type session struct {
	PID  int    `json:"pid"`
	Port int    `json:"port"`
	URL  string `json:"url"`
}

var user32 = syscall.NewLazyDLL("user32.dll")
var messageBox = user32.NewProc("MessageBoxW")

func ptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func msg(title, text string) {
	messageBox.Call(0, uintptr(unsafe.Pointer(ptr(text))), uintptr(unsafe.Pointer(ptr(title))), 0x40)
}
func installRoot() (string, error) {
	x, err := os.Executable()
	if err != nil {
		return "", err
	}
	return filepath.Dir(x), nil
}
func dataRoot() string {
	home := os.Getenv("USERPROFILE")
	if home == "" {
		home, _ = os.UserHomeDir()
	}
	return filepath.Join(home, "Documents", "Nexu AI 3D Forge")
}
func findNode() string {
	if p, e := exec.LookPath("node.exe"); e == nil {
		return p
	}
	for _, p := range []string{filepath.Join(os.Getenv("ProgramFiles"), "nodejs", "node.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "nodejs", "node.exe")} {
		if st, e := os.Stat(p); e == nil && !st.IsDir() {
			return p
		}
	}
	return ""
}
func findEdge() string {
	for _, p := range []string{filepath.Join(os.Getenv("ProgramFiles(x86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("ProgramFiles"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Microsoft", "Edge", "Application", "msedge.exe")} {
		if st, e := os.Stat(p); e == nil && !st.IsDir() {
			return p
		}
	}
	return ""
}
func loadSession(path string) (session, error) {
	var s session
	b, e := os.ReadFile(path)
	if e != nil {
		return s, e
	}
	e = json.Unmarshal(b, &s)
	return s, e
}
func healthy(s session) bool {
	if s.Port <= 0 {
		return false
	}
	c := http.Client{Timeout: 700 * time.Millisecond}
	r, e := c.Get(fmt.Sprintf("http://127.0.0.1:%d/health", s.Port))
	if e != nil {
		return false
	}
	defer r.Body.Close()
	return r.StatusCode == 200
}
func launchEdge(url string) error {
	edge := findEdge()
	if edge == "" {
		return fmt.Errorf("Microsoft Edge was not found. Windows 11 normally includes Edge; repair Edge and relaunch Forge")
	}
	cmd := exec.Command(edge, "--app="+url, "--start-maximized", "--disable-features=msEdgeSidebarV2")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	return cmd.Start()
}
func main() {
	root, err := installRoot()
	if err != nil {
		msg("Nexu AI 3D Forge", "Could not locate the installed application.\n\n"+err.Error())
		return
	}
	verBytes, err := os.ReadFile(filepath.Join(root, "current-version.txt"))
	if err != nil {
		msg("Nexu AI 3D Forge", "Forge installation is incomplete. Run the Nexu AI 3D Forge Setup and choose Repair.")
		return
	}
	ver := strings.TrimSpace(string(verBytes))
	server := filepath.Join(root, "versions", ver, "3d-forge", "studio-server.mjs")
	if _, err = os.Stat(server); err != nil {
		msg("Nexu AI 3D Forge", "Forge version "+ver+" is incomplete. Run Setup and choose Repair.")
		return
	}
	node := findNode()
	if node == "" {
		msg("Nexu AI 3D Forge", "Node.js 24.19.x LTS is required and was not found.\n\nRun Nexu AI 3D Forge Setup to install or repair required components.")
		return
	}
	data := dataRoot()
	_ = os.MkdirAll(filepath.Join(data, ".runtime"), 0755)
	sp := filepath.Join(data, ".runtime", ".studio-session.json")
	if s, e := loadSession(sp); e == nil && healthy(s) {
		if e = launchEdge(s.URL); e != nil {
			msg("Nexu AI 3D Forge", e.Error())
		}
		return
	}
	_ = os.Remove(sp)
	cmd := exec.Command(node, server, "--no-open")
	cmd.Dir = filepath.Join(root, "versions", ver)
	cmd.Env = append(os.Environ(), "NEXU_FORGE_DATA_DIR="+data)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	if err = cmd.Start(); err != nil {
		msg("Nexu AI 3D Forge", "Could not start the local Forge engine.\n\n"+err.Error())
		return
	}
	deadline := time.Now().Add(12 * time.Second)
	for time.Now().Before(deadline) {
		if s, e := loadSession(sp); e == nil && healthy(s) {
			if e = launchEdge(s.URL); e != nil {
				msg("Nexu AI 3D Forge", e.Error())
			}
			return
		}
		time.Sleep(120 * time.Millisecond)
	}
	msg("Nexu AI 3D Forge", "Forge started, but the local workspace did not become ready within 12 seconds.\n\nRun Setup → Repair, then check the Forge Logs folder in Documents.")
}
