@echo off
setlocal
cd /d "%~dp0"
echo === Nexu Language Features ===
node compiler\cli.mjs feature list || goto :fail
echo.
echo === Nexu Recipes ===
node compiler\cli.mjs recipe list || goto :fail
echo.
echo === Nexu Host Adapters ===
node compiler\cli.mjs host list || goto :fail
echo.
echo === Nexu Provider Adapters ===
node compiler\cli.mjs provider list || goto :fail
echo.
pause
exit /b 0
:fail
echo.
echo [FAIL] Could not list Nexu catalogues.
pause
exit /b 1
