@echo off
setlocal
cd /d "%~dp0"
title Nexu AI 3D Forge v0.10.1 - Android Build + Auto-Repair
cls
echo ============================================================
echo  NEXU AI 3D FORGE v0.10.1 - ANDROID BUILD + AUTO-REPAIR
echo ============================================================
echo.
echo This workflow will:
echo   - check .NET 10 / MAUI Android
echo   - automatically provision a private JDK 21 if needed
echo   - automatically install Android API 36 if needed
echo   - start ADB safely
echo   - build the APK
echo   - install it when one authorised Android device is connected
echo.
where pwsh.exe >nul 2>nul
if %ERRORLEVEL%==0 (
  pwsh.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-ANDROID-AND-INSTALL.ps1"
) else (
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-ANDROID-AND-INSTALL.ps1"
)
set "EC=%ERRORLEVEL%"
echo.
if not "%EC%"=="0" echo [FAIL] Android build/install stopped. See artifacts\android\android-build.log
if "%EC%"=="0" echo [PASS] Android build/install workflow completed.
pause
exit /b %EC%
