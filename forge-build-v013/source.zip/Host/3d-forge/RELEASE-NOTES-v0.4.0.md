# Nexu AI 3D Forge v0.4.0 — Windows App Foundation

## Product shift

v0.4.0 promotes Forge from a portable Studio workspace into an installable Windows product while preserving the working Nexu3D → trusted Blender worker architecture.

## Studio UX

- professional DCC-inspired three-pane workspace without cloning Blender;
- dedicated creation brief, inspection viewport and evidence inspector;
- persistent activity rail for Forge, Assets, Activity, System and Preferences;
- compact title/status bar with local runtime and Blender health;
- inspection views for perspective, front, side, wireframe and collision;
- quality evidence, master/export actions and generated-file access;
- responsive collapse for smaller windows;
- keyboard focus and reduced-motion support preserved.

## Windows application behaviour

- per-user application install under LocalAppData Programs;
- user assets under Documents\\Nexu AI 3D Forge, outside the install tree;
- Start-menu and optional desktop shortcuts;
- Installed Apps / uninstall registration under HKCU;
- hidden launcher: no persistent command window during normal use;
- same one-file setup package supports fresh install, repair and update-in-place;
- current and previous application versions are separated for rollback;
- updates stop the old local Studio session before activating the new version;
- previous portable Desktop output can be imported with explicit user approval.

## Update policy

This candidate implements installer-based offline updates. An online background updater is deliberately not enabled until Sumero Studio has a verified HTTPS release feed and signing/release infrastructure. Running a newer one-file setup is the supported update action and never deletes the Documents asset library.
