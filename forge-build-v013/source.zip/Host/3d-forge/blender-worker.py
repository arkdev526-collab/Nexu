from __future__ import annotations
import json, math, os, sys, traceback

try:
    import bpy
    import bmesh
    from mathutils import Vector
except Exception as exc:
    raise SystemExit(f"NEXU3D_ERROR: This worker must run inside Blender Python: {exc}")


def args_after_double_dash():
    if "--" not in sys.argv:
        return []
    return sys.argv[sys.argv.index("--") + 1:]


def parse_args():
    args = args_after_double_dash()
    result = {}
    i = 0
    while i < len(args):
        token = args[i]
        if token in ("--recipe", "--output") and i + 1 < len(args):
            result[token[2:]] = args[i + 1]
            i += 2
        else:
            i += 1
    if "recipe" not in result or "output" not in result:
        raise ValueError("Required arguments: --recipe <json> --output <directory>")
    return result


def clean_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for datablock in list(datablocks):
            if datablock.users == 0:
                datablocks.remove(datablock)


def set_principled_input(bsdf, name, value):
    socket = bsdf.inputs.get(name) if bsdf else None
    if socket is not None:
        socket.default_value = value


def clamp01(value):
    return max(0.0, min(1.0, float(value)))


def save_image(path, name, size, pixels, non_color=False):
    image = bpy.data.images.new(name=name, width=size, height=size, alpha=True, float_buffer=False)
    image.pixels.foreach_set(pixels)
    if non_color:
        try: image.colorspace_settings.name = 'Non-Color'
        except Exception: pass
    image.filepath_raw = path
    image.file_format = 'PNG'
    image.save()
    return image


def generate_pbr_texture_set(spec, output_dir):
    if not spec.get('pbrGenerate', True):
        return {}, []
    size = int(spec.get('textureResolution', 512))
    if size not in (256, 512, 1024): size = 512
    style = spec.get('style', 'flat')
    base = spec.get('baseColor', [0.5, 0.5, 0.5, 1])
    variation = clamp01(spec.get('variation', 0.25))
    wear = clamp01(spec.get('wear', 0.15))
    normal_strength = clamp01(spec.get('normalStrength', 0.2))
    metallic_base = clamp01(spec.get('metallic', 0.0))
    rough_base = clamp01(spec.get('roughness', 0.5))
    tex_dir = os.path.join(output_dir, 'Textures')
    os.makedirs(tex_dir, exist_ok=True)
    bc=[]; rough=[]; metal=[]; normal=[]
    tau=math.pi*2.0
    for y in range(size):
        v=(y/size)*tau
        for x in range(size):
            u=(x/size)*tau
            # Fully periodic functions keep opposite edges aligned for tileable defaults.
            broad=(math.sin(u*3.0+math.sin(v*2.0)*0.7)+math.cos(v*4.0+math.sin(u)*0.5))*0.25
            fine=(math.sin(u*13.0+v*5.0)+math.cos(v*17.0-u*3.0))*0.125
            if style in ('wood','aged_wood','leather','fur','feather'):
                grain=math.sin(u*9.0 + 1.8*math.sin(v*2.0))*0.42 + math.sin(u*23.0)*0.10
                h=grain*0.7+fine*0.3
            elif style in ('iron','worn_iron','rusted_iron','brushed_metal','painted_metal'):
                brush=math.sin(v*28.0)*0.10 if style=='brushed_metal' else 0.0
                h=broad*0.35+fine*0.65+brush
            elif style in ('stone','mossy_stone'):
                h=broad*0.65+fine*0.55
            elif style=='scales':
                cells=math.sin(u*7.0+math.sin(v*3.0))*math.cos(v*9.0-math.sin(u*2.0)); h=abs(cells)*0.55+fine*0.18
            elif style=='membrane':
                veins=abs(math.sin(u*2.0+v*1.5))*0.34; h=veins+broad*0.12
            elif style=='bone':
                h=broad*0.18+fine*0.12
            elif style=='chitin':
                plates=abs(math.sin(u*5.0)*math.cos(v*4.0)); h=plates*0.44+fine*0.20
            elif style=='skin':
                h=broad*0.20+fine*0.18
            elif style=='ceramic':
                h=broad*0.12+fine*0.05
            else:
                h=broad*0.12
            factor=clamp01(0.82 + h*variation*0.75)
            r,g,b=clamp01(base[0]*factor),clamp01(base[1]*factor),clamp01(base[2]*factor)
            if style=='rusted_iron':
                rust=clamp01(0.35 + broad*0.9 + wear*0.4)
                r=clamp01(r*(1-rust)+0.32*rust); g=clamp01(g*(1-rust)+0.085*rust); b=clamp01(b*(1-rust)+0.025*rust)
            elif style=='mossy_stone':
                moss=clamp01(0.28+broad*0.8+wear*0.3)
                r=clamp01(r*(1-moss)+0.12*moss); g=clamp01(g*(1-moss)+0.24*moss); b=clamp01(b*(1-moss)+0.08*moss)
            elif style=='aged_wood':
                age=clamp01(0.18+wear*0.45+fine*0.3); r*=1-age*0.22; g*=1-age*0.34; b*=1-age*0.42
            bc.extend((r,g,b,1.0))
            rv=clamp01(rough_base + (-h*0.12) + wear*0.08)
            mv=metallic_base
            if style=='rusted_iron': mv=clamp01(metallic_base-(0.18+wear*0.28)*clamp01(0.5+broad))
            if style=='painted_metal': mv=clamp01(metallic_base*0.35 + wear*0.15*clamp01(0.5+broad))
            rough.extend((rv,rv,rv,1.0)); metal.extend((mv,mv,mv,1.0))
            # Analytic-ish periodic derivative from nearby periodic samples.
            du=(math.cos(u*3.0+math.sin(v*2.0)*0.7)*3.0 - math.sin(v*4.0+math.sin(u)*0.5)*math.cos(u))*0.25
            dv=(math.cos(u*3.0+math.sin(v*2.0)*0.7)*math.cos(v*2.0)*1.4 - math.sin(v*4.0+math.sin(u)*0.5)*4.0)*0.25
            nx=-du*normal_strength; ny=-dv*normal_strength; nz=1.0; ln=max(1e-6,math.sqrt(nx*nx+ny*ny+nz*nz)); nx/=ln; ny/=ln; nz/=ln
            normal.extend((nx*0.5+0.5,ny*0.5+0.5,nz*0.5+0.5,1.0))
    stem=spec['name']
    paths={
        'baseColor':os.path.join(tex_dir,stem+'_BaseColor.png'),
        'roughness':os.path.join(tex_dir,stem+'_Roughness.png'),
        'metallic':os.path.join(tex_dir,stem+'_Metallic.png'),
        'normal':os.path.join(tex_dir,stem+'_Normal.png')
    }
    images={
        'baseColor':save_image(paths['baseColor'],stem+'_BaseColor',size,bc,False),
        'roughness':save_image(paths['roughness'],stem+'_Roughness',size,rough,True),
        'metallic':save_image(paths['metallic'],stem+'_Metallic',size,metal,True),
        'normal':save_image(paths['normal'],stem+'_Normal',size,normal,True)
    }
    outputs=[os.path.relpath(path,output_dir).replace('\\','/') for path in paths.values()]
    return images, outputs


def material_from_spec(spec, output_dir):
    mat = bpy.data.materials.new(name=spec['name'])
    mat.diffuse_color = tuple(spec['baseColor'])
    mat.use_nodes = True
    tree = mat.node_tree
    if not tree:
        return mat, []
    bsdf = tree.nodes.get('Principled BSDF')
    if not bsdf:
        return mat, []
    set_principled_input(bsdf, 'Base Color', tuple(spec['baseColor']))
    set_principled_input(bsdf, 'Metallic', spec['metallic'])
    set_principled_input(bsdf, 'Roughness', spec['roughness'])
    outputs=[]
    try:
        images, outputs = generate_pbr_texture_set(spec, output_dir)
        if images:
            nodes={}
            for key,image in images.items():
                n=tree.nodes.new('ShaderNodeTexImage'); n.name=f'Nexu_{key}'; n.label=key; n.image=image; nodes[key]=n
            tree.links.new(nodes['baseColor'].outputs.get('Color'), bsdf.inputs.get('Base Color'))
            tree.links.new(nodes['roughness'].outputs.get('Color'), bsdf.inputs.get('Roughness'))
            tree.links.new(nodes['metallic'].outputs.get('Color'), bsdf.inputs.get('Metallic'))
            normal_node=tree.nodes.new('ShaderNodeNormalMap'); normal_node.inputs.get('Strength').default_value=float(spec.get('normalStrength',0.2))
            tree.links.new(nodes['normal'].outputs.get('Color'), normal_node.inputs.get('Color')); tree.links.new(normal_node.outputs.get('Normal'), bsdf.inputs.get('Normal'))
            return mat, outputs
    except Exception as exc:
        print(f"NEXU3D_WARN material texture generation failed for {spec['name']}: {exc}", flush=True)
    # Procedural node fallback remains useful if a texture set cannot be generated.
    style = spec.get('style', 'flat')
    if style == 'flat':
        return mat, outputs
    try:
        tex = tree.nodes.new('ShaderNodeTexCoord'); mapping = tree.nodes.new('ShaderNodeMapping'); noise = tree.nodes.new('ShaderNodeTexNoise'); ramp = tree.nodes.new('ShaderNodeValToRGB'); bump = tree.nodes.new('ShaderNodeBump')
        tree.links.new(tex.outputs.get('Generated'), mapping.inputs.get('Vector')); tree.links.new(mapping.outputs.get('Vector'), noise.inputs.get('Vector')); tree.links.new(noise.outputs.get('Fac'), ramp.inputs.get('Fac')); tree.links.new(ramp.outputs.get('Color'), bsdf.inputs.get('Base Color')); tree.links.new(noise.outputs.get('Fac'), bump.inputs.get('Height')); tree.links.new(bump.outputs.get('Normal'), bsdf.inputs.get('Normal'))
        noise.inputs.get('Scale').default_value = 5.0; noise.inputs.get('Detail').default_value = 4.0; bump.inputs.get('Strength').default_value=float(spec.get('normalStrength',0.2))
    except Exception: pass
    return mat, outputs


def mesh_object(name, vertices, faces):
    mesh = bpy.data.meshes.new(name + '_Mesh')
    mesh.from_pydata(vertices, [], faces)
    mesh.update(calc_edges=True)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def assign_material(obj, mat):
    if obj.type == 'MESH' and mat is not None:
        obj.data.materials.append(mat)


def add_primitive(part):
    dims = part['dimensions']
    ptype = part['type']
    if ptype == 'box':
        bpy.ops.mesh.primitive_cube_add(size=1)
    elif ptype == 'cylinder':
        bpy.ops.mesh.primitive_cylinder_add(vertices=int(part.get('segments',24)), radius=0.5, depth=1)
    elif ptype == 'sphere':
        seg = max(8, int(part.get('segments',24)))
        bpy.ops.mesh.primitive_uv_sphere_add(segments=seg, ring_count=max(6, seg//2), radius=0.5)
    elif ptype == 'ico_sphere':
        subdivisions = max(1, min(5, int(part.get('segments',3))))
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=subdivisions, radius=0.5)
    elif ptype == 'cone':
        bpy.ops.mesh.primitive_cone_add(vertices=int(part.get('segments',24)), radius1=0.5, radius2=0.0, depth=1)
    else:
        raise ValueError(f"Unsupported primitive: {ptype}")
    obj = bpy.context.object
    obj.name = part['name']
    obj.dimensions = dims
    obj.location = part['location']
    obj.rotation_euler = [math.radians(v) for v in part['rotationDeg']]
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bevel = float(part.get('bevel',0))
    if bevel > 0:
        mod = obj.modifiers.new(name='NexuBevel', type='BEVEL')
        mod.width = bevel
        mod.segments = 2
    return obj


def apply_modifiers(obj):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    for modifier in list(obj.modifiers):
        try:
            bpy.ops.object.modifier_apply(modifier=modifier.name)
        except Exception:
            pass


def smart_uv(obj):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    if obj.type == 'MESH':
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project(angle_limit=math.radians(66.0), island_margin=0.02)
        bpy.ops.object.mode_set(mode='OBJECT')


def repair_meshes(objects):
    summary={'objectsChecked':0,'objectsChanged':0,'verticesRemoved':0,'facesRemoved':0,'normalRepairs':0,'errors':[]}
    for obj in objects:
        if obj.type!='MESH':
            continue
        summary['objectsChecked']+=1
        try:
            apply_modifiers(obj)
            mesh=obj.data
            before_v=len(mesh.vertices); before_f=len(mesh.polygons)
            bm=bmesh.new()
            try:
                bm.from_mesh(mesh)
                if bm.verts:
                    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7)
                if bm.edges:
                    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=1e-9)
                if bm.faces:
                    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces)); summary['normalRepairs']+=1
                bm.to_mesh(mesh)
            finally:
                bm.free()
            try: mesh.validate(verbose=False,clean_customdata=False)
            except TypeError: mesh.validate(verbose=False)
            mesh.update(calc_edges=True)
            removed_v=max(0,before_v-len(mesh.vertices)); removed_f=max(0,before_f-len(mesh.polygons))
            summary['verticesRemoved']+=removed_v; summary['facesRemoved']+=removed_f
            if removed_v or removed_f: summary['objectsChanged']+=1
        except Exception as exc:
            summary['errors'].append(f"{obj.name}: {exc}")
    return summary


def triangle_count(objects):
    total = 0
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for obj in objects:
        if obj.type != 'MESH':
            continue
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            total += sum(max(0, len(poly.vertices)-2) for poly in mesh.polygons)
        finally:
            evaluated.to_mesh_clear()
    return total



def mesh_diagnostics(objects):
    result={
        'vertices':0,'faces':0,'edges':0,'nonManifoldEdges':0,'looseEdges':0,'isolatedVertices':0,
        'uvLayers':0,'materialSlots':0,'unappliedScaleObjects':0,'unappliedRotationObjects':0
    }
    for obj in objects:
        if obj.type!='MESH': continue
        result['vertices'] += len(obj.data.vertices)
        result['faces'] += len(obj.data.polygons)
        result['edges'] += len(obj.data.edges)
        result['uvLayers'] = max(result['uvLayers'], len(obj.data.uv_layers))
        result['materialSlots'] += len(obj.material_slots)
        if any(abs(float(v)-1.0)>1e-5 for v in obj.scale): result['unappliedScaleObjects'] += 1
        if any(abs(float(v))>1e-5 for v in obj.rotation_euler): result['unappliedRotationObjects'] += 1
        bm=bmesh.new()
        try:
            bm.from_mesh(obj.data)
            result['nonManifoldEdges'] += sum(1 for e in bm.edges if not e.is_manifold)
            result['looseEdges'] += sum(1 for e in bm.edges if len(e.link_faces)==0)
            result['isolatedVertices'] += sum(1 for v in bm.verts if len(v.link_edges)==0)
        finally:
            bm.free()
    return result

def export_collision_glb(path, collision):
    if collision is None: return None
    bpy.ops.object.select_all(action='DESELECT'); collision.hide_render=False; collision.select_set(True); bpy.context.view_layer.objects.active=collision
    bpy.ops.export_scene.gltf(filepath=path,export_format='GLB',use_selection=True)
    collision.hide_render=True
    return os.path.basename(path)

def bounds_for(objects):
    points=[]
    for obj in objects:
        if obj.type != 'MESH':
            continue
        for corner in obj.bound_box:
            points.append(obj.matrix_world @ Vector(corner))
    if not points:
        return None
    mins=[min(p[i] for p in points) for i in range(3)]
    maxs=[max(p[i] for p in points) for i in range(3)]
    return mins,maxs


def radius_profile(end_radius, belly_radius, t):
    return end_radius + (belly_radius - end_radius) * (math.sin(math.pi * max(0.0, min(1.0, t))) ** 0.82)


def estimate_barrel_triangles(details):
    staves = int(details['staveCount'])
    vertical = int(details['verticalSegments'])
    hoops = int(details['hoopCount'])
    hoop_segments = int(details['hoopSegments'])
    end_planks = int(details['endPlanks'])
    rivets = int(details['rivetsPerHoop'])
    return staves * (8 * vertical + 4) + hoops * (8 * hoop_segments) + (2 * end_planks * 12) + (hoops * rivets * 32)


def calibrate_barrel_details(details, target, tolerance_pct):
    current = dict(details)
    before = estimate_barrel_triangles(current)
    if target <= 0 or abs(before-target) <= target*tolerance_pct:
        return current, before, before, False
    preferred = current
    best = None
    for staves in range(18, 37):
        for vertical in range(4, 9):
            for hoop_segments in range(18, 41):
                for end_planks in range(5, 9):
                    for rivets in range(0, 3):
                        candidate = dict(current)
                        candidate.update(staveCount=staves, verticalSegments=vertical, hoopSegments=hoop_segments, endPlanks=end_planks, rivetsPerHoop=rivets)
                        estimate = estimate_barrel_triangles(candidate)
                        diff = abs(estimate-target)
                        aesthetic = abs(staves-int(preferred['staveCount']))*1.5 + abs(vertical-int(preferred['verticalSegments']))*3.0 + abs(hoop_segments-staves)*0.5 + abs(end_planks-int(preferred['endPlanks']))*2.0 + abs(rivets-int(preferred['rivetsPerHoop']))*2.0
                        score = (diff, aesthetic)
                        if best is None or score < best[0]:
                            best = (score, candidate, estimate)
    if best is None or abs(best[2]-target) >= abs(before-target):
        return current, before, before, False
    return best[1], before, best[2], True


def add_barrel_stave(name, index, count, height, end_radius, belly_radius, thickness, gap_ratio, vertical_segments, material):
    centre = (2.0 * math.pi * index) / count
    angular = (2.0 * math.pi / count) * (1.0-gap_ratio)
    left = centre-angular/2.0
    right = centre+angular/2.0
    verts=[]
    for ring in range(vertical_segments+1):
        t=ring/vertical_segments
        z=height*t
        outer=radius_profile(end_radius, belly_radius, t)
        inner=max(0.001, outer-thickness)
        verts.extend([
            (math.cos(left)*outer, math.sin(left)*outer, z),
            (math.cos(right)*outer, math.sin(right)*outer, z),
            (math.cos(right)*inner, math.sin(right)*inner, z),
            (math.cos(left)*inner, math.sin(left)*inner, z)
        ])
    faces=[]
    for ring in range(vertical_segments):
        a=ring*4; b=(ring+1)*4
        faces.extend([
            (a,b,b+1,a+1),
            (a+3,a+2,b+2,b+3),
            (a,a+3,b+3,b),
            (a+1,b+1,b+2,a+2)
        ])
    faces.append((0,1,2,3))
    top=vertical_segments*4
    faces.append((top+3,top+2,top+1,top))
    obj=mesh_object(name,verts,faces)
    assign_material(obj,material)
    return obj


def add_rectangular_ring(name, radius, z, width, depth, segments, material):
    outer=radius+depth
    inner=max(0.001,radius-depth*0.35)
    z0=z-width/2.0; z1=z+width/2.0
    verts=[]
    for i in range(segments):
        a=2*math.pi*i/segments
        ca,sa=math.cos(a),math.sin(a)
        verts.extend([(ca*outer,sa*outer,z0),(ca*outer,sa*outer,z1),(ca*inner,sa*inner,z0),(ca*inner,sa*inner,z1)])
    faces=[]
    for i in range(segments):
        n=(i+1)%segments; a=i*4; b=n*4
        faces.extend([(a,b,b+1,a+1),(a+2,a+3,b+3,b+2),(a+1,b+1,b+3,a+3),(a,b,a+2,b+2)])
    obj=mesh_object(name,verts,faces)
    assign_material(obj,material)
    return obj


def add_rivet(name, radius, depth, position, direction, material):
    segments=8
    verts=[]
    for z,scale in ((0.0,1.0),(depth*0.55,0.82)):
        for i in range(segments):
            a=2*math.pi*i/segments
            verts.append((math.cos(a)*radius,math.sin(a)*radius,z))
    tip=len(verts); verts.append((0,0,depth))
    base=len(verts); verts.append((0,0,0))
    faces=[]
    for i in range(segments):
        n=(i+1)%segments
        faces.append((i,n,segments+n,segments+i))
        faces.append((segments+i,segments+n,tip))
        faces.append((base,n,i))
    obj=mesh_object(name,verts,faces)
    obj.location=position
    obj.rotation_euler=Vector(direction).to_track_quat('Z','Y').to_euler()
    assign_material(obj,material)
    return obj


def add_end_planks(prefix, height, radius, count, material):
    created=[]
    r=radius*0.94
    strip=(2*r)/count
    thickness=max(0.012,height*0.026)
    for side,z in (('Bottom',thickness/2.0),('Top',height-thickness/2.0)):
        for i in range(count):
            y0=-r+i*strip; y1=y0+strip
            max_abs=max(abs(y0),abs(y1))
            xhalf=math.sqrt(max(0.0001,r*r-max_abs*max_abs))
            width=max(0.02,2*xhalf)
            bpy.ops.mesh.primitive_cube_add(size=1,location=(0,(y0+y1)/2.0,z))
            obj=bpy.context.object
            obj.name=f'{prefix}_{side}Plank_{i+1:02d}'
            obj.dimensions=(width,strip*0.92,thickness)
            bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
            assign_material(obj,material)
            created.append(obj)
    return created


def create_procedural_barrel(part, mats, target, quality):
    h=float(part['dimensions'][2])
    details=dict(part['details'])
    details,before_estimate,after_estimate,repaired=calibrate_barrel_details(details,target,float(quality.get('targetTolerancePct',0.03))) if quality.get('autoRepair',True) else (details,estimate_barrel_triangles(details),estimate_barrel_triangles(details),False)
    wood=mats[details['woodMaterial']]; metal=mats[details['metalMaterial']]
    created=[]
    for i in range(int(details['staveCount'])):
        created.append(add_barrel_stave(f'Stave_{i+1:02d}',i,int(details['staveCount']),h,float(details['endRadius']),float(details['bellyRadius']),float(details['staveThickness']),float(details['staveGapRatio']),int(details['verticalSegments']),wood))
    created.extend(add_end_planks('End',h,float(details['endRadius']),int(details['endPlanks']),wood))
    hoop_count=int(details['hoopCount'])
    for i in range(hoop_count):
        t=0.08 if hoop_count==1 else 0.08+i*(0.84/max(1,hoop_count-1))
        z=h*t
        radius=radius_profile(float(details['endRadius']),float(details['bellyRadius']),t)+float(details['hoopDepth'])*0.2
        created.append(add_rectangular_ring(f'IronBand_{i+1}',radius,z,float(details['hoopWidth']),float(details['hoopDepth']),int(details['hoopSegments']),metal))
        rivets=int(details['rivetsPerHoop'])
        for r_index in range(rivets):
            offset=(r_index-(rivets-1)/2.0)*0.13
            theta=-math.pi/2.0+offset
            rr=radius+float(details['hoopDepth'])+max(0.002,h*0.002)
            pos=(math.cos(theta)*rr,math.sin(theta)*rr,z)
            direction=(math.cos(theta),math.sin(theta),0)
            created.append(add_rivet(f'Band_{i+1}_Rivet_{r_index+1}',max(0.004,h*0.008),max(0.003,h*0.006),pos,direction,metal))
    return created, {'kind':'barrel','details':details,'estimatedBefore':before_estimate,'estimatedAfter':after_estimate,'autoRepairApplied':repaired}


def create_procedural_drum(part, mats):
    h=float(part['dimensions'][2]); details=part['details']; radius=float(details['radius']); segments=int(details['segments']); mat=mats[details['material']]
    created=[]
    bpy.ops.mesh.primitive_cylinder_add(vertices=segments,radius=radius,depth=h,location=(0,0,h/2.0))
    body=bpy.context.object; body.name='DrumBody'; assign_material(body,mat); created.append(body)
    rim=float(details['rimWidth'])
    for i,z in enumerate((rim*0.55,h-rim*0.55),start=1):
        created.append(add_rectangular_ring(f'DrumRim_{i}',radius,z,rim,rim*0.32,segments,mat))
    ribs=int(details['ribCount'])
    for i in range(ribs):
        t=(i+1)/(ribs+1)
        created.append(add_rectangular_ring(f'DrumRib_{i+1}',radius,h*t,rim*0.72,rim*0.2,segments,mat))
    return created, {'kind':'drum','details':dict(details),'autoRepairApplied':False}




def add_ellipsoid(name, location, dimensions, material, segments=24):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=max(12,int(segments)), ring_count=max(8,int(segments)//2), radius=0.5, location=location)
    obj=bpy.context.object; obj.name=name; obj.dimensions=dimensions
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    assign_material(obj,material)
    return obj


def add_segment_between(name, start, end, radius, material, segments=16):
    a=Vector(start); b=Vector(end); direction=b-a; length=max(0.001,direction.length); midpoint=(a+b)*0.5
    bpy.ops.mesh.primitive_cylinder_add(vertices=max(8,int(segments)),radius=max(0.002,float(radius)),depth=length,location=midpoint)
    obj=bpy.context.object; obj.name=name; obj.rotation_euler=direction.to_track_quat('Z','Y').to_euler()
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    assign_material(obj,material)
    return obj


def add_oriented_cone(name, base, tip, radius, material, segments=12):
    a=Vector(base); b=Vector(tip); direction=b-a; length=max(0.001,direction.length); midpoint=(a+b)*0.5
    bpy.ops.mesh.primitive_cone_add(vertices=max(6,int(segments)),radius1=max(0.002,float(radius)),radius2=0.0,depth=length,location=midpoint)
    obj=bpy.context.object; obj.name=name; obj.rotation_euler=direction.to_track_quat('Z','Y').to_euler(); assign_material(obj,material)
    return obj


def add_membrane(name, points, material, thickness):
    # Fan-like local surface used for wings/fins. It is deterministic geometry, never remote code.
    faces=[]
    for i in range(1,len(points)-1): faces.append((0,i,i+1))
    obj=mesh_object(name,[tuple(p) for p in points],faces); assign_material(obj,material)
    mod=obj.modifiers.new(name='NexuMembraneSolidify',type='SOLIDIFY'); mod.thickness=max(0.001,float(thickness)); apply_modifiers(obj)
    return obj


def join_voxel_body(name, objects, voxel_size, material):
    body=[o for o in objects if o and o.type=='MESH']
    if not body: raise ValueError('Creature body has no mesh volumes')
    bpy.ops.object.select_all(action='DESELECT')
    for o in body: o.select_set(True)
    bpy.context.view_layer.objects.active=body[0]
    if len(body)>1: bpy.ops.object.join()
    joined=bpy.context.object; joined.name=name
    # Blender 5.2 LTS supports the Voxel Remesh modifier. This regularises overlapping guide volumes into one manifold surface.
    mod=joined.modifiers.new(name='NexuOrganicVoxel',type='REMESH'); mod.mode='VOXEL'; mod.voxel_size=max(0.005,min(0.5,float(voxel_size))); mod.use_smooth_shade=True; mod.use_remove_disconnected=True; mod.threshold=0.015
    apply_modifiers(joined)
    if material and joined.type=='MESH':
        joined.data.materials.clear(); joined.data.materials.append(material)
    for poly in joined.data.polygons: poly.use_smooth=True
    return joined


def quadruped_core(d, body_mat):
    L=float(d['bodyLength']); W=float(d['bodyWidth']); H=float(d['bodyHeight']); bulk=float(d['bodyBulk']); core=[]
    core.append(add_ellipsoid('Torso',(0,0,H*.60),(L*.46,W*.92*bulk,H*.46*bulk),body_mat,28))
    core.append(add_ellipsoid('Chest',(L*.13,0,H*.66),(L*.29,W*1.00*bulk,H*.52*bulk),body_mat,26))
    core.append(add_ellipsoid('Pelvis',(-L*.17,0,H*.56),(L*.29,W*.78*bulk,H*.40*bulk),body_mat,24))
    neck=float(d['neckLength']); head_x=L*.36+neck*.34; head_z=H*.82+min(H*.18,neck*.18)
    if neck>0:
        p0=(L*.20,0,H*.70); p1=(L*.27+neck*.20,0,H*.78); p2=(head_x-L*.08,0,head_z-H*.04)
        core.append(add_segment_between('Neck_01',p0,p1,max(W*.18,H*.09),body_mat,18)); core.append(add_segment_between('Neck_02',p1,p2,max(W*.15,H*.075),body_mat,18))
    core.append(add_ellipsoid('Head',(head_x,0,head_z),(L*.18,W*.54,H*.25),body_mat,22))
    core.append(add_ellipsoid('Snout',(head_x+L*.085,0,head_z-H*.025),(L*.13,W*.42,H*.14),body_mat,18))
    limb_count=int(d['limbCount']); positions=[]
    if limb_count==4: positions=[(L*.13,-W*.32),(L*.13,W*.32),(-L*.16,-W*.28),(-L*.16,W*.28)]
    elif limb_count==2: positions=[(-L*.13,-W*.28),(-L*.13,W*.28)]
    for i,(x,y) in enumerate(positions,1):
        hip=(x,y,H*.54); knee=(x+(L*.035 if x>0 else -L*.025),y*1.08,H*.29); ankle=(x+(L*.06 if x>0 else -L*.04),y*1.13,H*.075)
        core.append(add_segment_between(f'Limb_{i}_Upper',hip,knee,max(H*.055,W*.085)*bulk,body_mat,14)); core.append(add_segment_between(f'Limb_{i}_Lower',knee,ankle,max(H*.038,W*.06)*bulk,body_mat,14)); core.append(add_ellipsoid(f'Foot_{i}',(ankle[0]+L*.025,ankle[1],H*.045),(L*.10,W*.16,H*.075),body_mat,14))
    tail=float(d['tailLength'])
    if tail>0:
        start=Vector((-L*.28,0,H*.54)); previous=start
        for i in range(5):
            t=(i+1)/5; nxt=Vector((-L*.28-tail*t,0,H*(.52-.25*t)+math.sin(t*math.pi)*H*.06)); core.append(add_segment_between(f'Tail_{i+1}',previous,nxt,max(H*.025,H*.10*(1-t*.72)),body_mat,14)); previous=nxt
    return core,(head_x,0,head_z)


def create_procedural_creature(part,mats,target_triangles):
    d=dict(part['details']); kind=d['creatureKind']; body=mats[d['bodyMaterial']]; membrane=mats.get(d['membraneMaterial'],body); horn=mats.get(d['hornMaterial'],body)
    L=float(d['bodyLength']); W=float(d['bodyWidth']); H=float(d['bodyHeight']); core=[]; details=[]; head=(L*.35,0,H*.8)
    if kind in ('dragon','wyvern','griffin','wolf'):
        core,head=quadruped_core(d,body)
    elif kind=='spider':
        core=[add_ellipsoid('Abdomen',(-L*.13,0,H*.45),(L*.55,W*.72,H*.62),body,26),add_ellipsoid('Cephalothorax',(L*.20,0,H*.42),(L*.35,W*.58,H*.46),body,22)]
        for i in range(8):
            side=-1 if i<4 else 1; row=i%4; x=L*(.22-row*.13); y0=side*W*.22; mid=(x-L*.04,y0+side*W*(.42+.06*row),H*(.34+.03*row)); tip=(x-L*.10,y0+side*W*(.78+.08*row),H*.06)
            core.append(add_segment_between(f'Leg_{i+1}_A',(x,y0,H*.40),mid,H*.045,body,12)); core.append(add_segment_between(f'Leg_{i+1}_B',mid,tip,H*.032,body,12))
        head=(L*.27,0,H*.42)
    elif kind=='snake':
        previous=None
        for i in range(11):
            t=i/10; x=L*(.50-t); y=math.sin(t*math.pi*2)*W*.22; z=H*(.30+.08*math.sin(t*math.pi)); r=max(H*.10,H*(.28-.14*abs(t-.42)))
            obj=add_ellipsoid(f'Body_{i+1}',(x,y,z),(L*.13,r*1.65,r*1.65),body,16); core.append(obj)
            if previous is not None: core.append(add_segment_between(f'BodyLink_{i}',previous,(x,y,z),r*.72,body,12))
            previous=(x,y,z)
        head=(L*.53,0,H*.34); core.append(add_ellipsoid('Head',head,(L*.18,W*.58,H*.38),body,18))
    elif kind=='bird':
        core=[add_ellipsoid('Body',(0,0,H*.52),(L*.55,W*.78,H*.60),body,24),add_ellipsoid('Chest',(L*.12,0,H*.58),(L*.34,W*.82,H*.68),body,22),add_segment_between('Neck',(L*.18,0,H*.62),(L*.30,0,H*.76),H*.08,body,14),add_ellipsoid('Head',(L*.34,0,H*.78),(L*.20,W*.48,H*.30),body,18)]
        head=(L*.34,0,H*.78)
        for i,side in enumerate((-1,1),1): core.append(add_segment_between(f'Leg_{i}',(-L*.03,side*W*.17,H*.40),(-L*.02,side*W*.19,H*.06),H*.028,body,10))
    elif kind=='fish':
        core=[add_ellipsoid('Body',(0,0,H*.42),(L*.72,W*.90,H*.82),body,28),add_ellipsoid('Head',(L*.31,0,H*.43),(L*.30,W*.78,H*.70),body,22)]
        head=(L*.36,0,H*.44)
    else: raise ValueError(f'Unsupported creature kind: {kind}')
    joined=join_voxel_body(f'{kind.title()}Body',core,float(d['voxelSize']),body); created=[joined]
    # Wings / fins are separate authored surfaces so their silhouettes remain controllable after body remesh.
    if int(d['wingCount'])==2:
        span=float(d['wingSpan']); root_x=L*.08; root_z=H*.70; torn=bool(d.get('tornWings',False))
        for side in (-1,1):
            sy=side
            pts=[(root_x,sy*W*.28,root_z),(L*.03,sy*span*.34,H*.98),(-L*.18,sy*span*.50,H*.80),(-L*.13,sy*span*.34,H*(.62 if not torn else .70)),(L*.10,sy*W*.38,H*.58)]
            wing=add_membrane(f'Wing_{"L" if side>0 else "R"}',pts,membrane,max(.004,H*.008)); created.append(wing)
            created.append(add_segment_between(f'WingBone_{"L" if side>0 else "R"}',pts[0],pts[1],H*.025,horn,10))
    if kind=='fish':
        tail_x=-L*.43; created.append(add_membrane('TailFin',[(tail_x,0,H*.43),(-L*.64,0,H*.78),(-L*.61,0,H*.10)],body,max(.003,H*.01)))
        created.append(add_membrane('DorsalFin',[(-L*.10,0,H*.72),(L*.08,0,H*1.05),(L*.20,0,H*.72)],body,max(.003,H*.008)))
    if kind in ('bird','griffin'):
        # Beak distinguishes avian heads while staying a separate controllable part.
        created.append(add_oriented_cone('Beak',(head[0]+L*.06,0,head[2]),(head[0]+L*.18,0,head[2]-H*.015),max(H*.035,W*.05),horn,10))
    horn_scale=float(d['hornScale'])
    if horn_scale>0 and kind in ('dragon','wyvern'):
        for side in (-1,1):
            base=(head[0]-L*.025,side*W*.16,head[2]+H*.09); tip=(head[0]-L*.12,side*W*.22,head[2]+H*(.12+.18*horn_scale)); created.append(add_oriented_cone(f'Horn_{"L" if side>0 else "R"}',base,tip,max(H*.022,H*.055*horn_scale),horn,12))
    spikes=int(d.get('dorsalSpikes',0))
    for i in range(spikes):
        t=(i+1)/(spikes+1); x=L*(.24-.55*t); z=H*(.84-.20*t); created.append(add_oriented_cone(f'DorsalSpike_{i+1}',(x,0,z),(x,0,z+H*(.08+.03*(1-t))),H*.025,horn,8))
    # Deterministic claws on terrestrial limbs. These remain separate so later creature-detail systems can replace them non-destructively.
    if int(d['limbCount'])>0 and kind not in ('spider',):
        n=int(d['limbCount'])
        for i in range(n):
            side=-1 if i%2==0 else 1; fore=1 if i<2 else -1; x=L*(.18 if fore>0 else -.15); y=side*W*.34; base=(x,y,H*.055); tip=(x+L*.055,y,H*.035); created.append(add_oriented_cone(f'Claw_{i+1}',base,tip,H*.018,horn,8))
    # Keep the static creature near the requested game budget without destroying authored detail parts.
    # Only the remeshed body is decimated; wings, horns, claws and silhouette details stay explicit.
    target=max(500,int(target_triangles or 12000)); before_triangles=triangle_count(created); body_triangles=triangle_count([joined]); detail_triangles=max(0,before_triangles-body_triangles)
    target_calibration={'requested':target,'before':before_triangles,'after':before_triangles,'bodyBefore':body_triangles,'detailTriangles':detail_triangles,'ratio':1.0,'applied':False}
    if before_triangles>target*1.08 and body_triangles>200:
        desired_body=max(200,target-detail_triangles); ratio=max(0.05,min(1.0,desired_body/max(1,body_triangles)))
        if ratio<0.985:
            mod=joined.modifiers.new(name='NexuCreatureBudget',type='DECIMATE'); mod.ratio=ratio; apply_modifiers(joined)
            target_calibration.update({'after':triangle_count(created),'ratio':ratio,'applied':True})
    meta={'kind':'creature','creatureKind':kind,'archetype':d['archetype'],'styleProfile':d['styleProfile'],'limbCount':int(d['limbCount']),'wingCount':int(d['wingCount']),'tailPresent':float(d['tailLength'])>0,'hornScale':horn_scale,'dorsalSpikes':spikes,'tornWings':bool(d.get('tornWings',False)),'organicRemesh':True,'voxelSize':float(d['voxelSize']),'bodyObjects':1,'detailObjects':max(0,len(created)-1),'targetCalibration':target_calibration}
    return created,meta


def create_recipe_objects(recipe, mats):
    created=[]; construction=[]
    for part in recipe['parts']:
        if part['type']=='procedural_barrel':
            objs,meta=create_procedural_barrel(part,mats,int(recipe.get('targetTriangles',2500)),recipe.get('quality',{})); created.extend(objs); construction.append(meta)
        elif part['type']=='procedural_drum':
            objs,meta=create_procedural_drum(part,mats); created.extend(objs); construction.append(meta)
        elif part['type']=='procedural_creature':
            objs,meta=create_procedural_creature(part,mats,int(recipe.get('targetTriangles',12000))); created.extend(objs); construction.append(meta)
        else:
            obj=add_primitive(part)
            if part.get('material') and part['material'] in mats: assign_material(obj,mats[part['material']])
            apply_modifiers(obj); created.append(obj)
    repair={'objectsChecked':0,'objectsChanged':0,'verticesRemoved':0,'facesRemoved':0,'normalRepairs':0,'errors':[]}
    if recipe.get('quality',{}).get('autoMeshRepair',True):
        repair=repair_meshes(created)
    for obj in created:
        if recipe.get('uv',True): smart_uv(obj)
    return created,construction,repair


def add_barrel_collision(asset_name, part):
    h=float(part['dimensions'][2]); d=part['details']; segments=12
    rings=[(0.0,float(d['endRadius'])*1.015),(h*0.5,float(d['bellyRadius'])*1.015),(h,float(d['endRadius'])*1.015)]
    verts=[]
    for z,radius in rings:
        for i in range(segments):
            a=2*math.pi*i/segments; verts.append((math.cos(a)*radius,math.sin(a)*radius,z))
    faces=[]
    for ring in range(2):
        a0=ring*segments; b0=(ring+1)*segments
        for i in range(segments): faces.append((a0+i,a0+(i+1)%segments,b0+(i+1)%segments,b0+i))
    faces.append(tuple(range(segments-1,-1,-1)))
    faces.append(tuple(2*segments+i for i in range(segments)))
    col=mesh_object(f'UCX_{asset_name}_00',verts,faces); col.display_type='WIRE'; col.hide_render=True
    return col,'convex-barrel'


def add_collision(asset_name, objects, recipe):
    for part in recipe['parts']:
        if part['type']=='procedural_barrel': return add_barrel_collision(asset_name,part)
    bounds=bounds_for(objects)
    if not bounds: return None,'none'
    mins,maxs=bounds; dims=[maxs[i]-mins[i] for i in range(3)]; loc=[(maxs[i]+mins[i])/2 for i in range(3)]
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    col=bpy.context.object; col.name=f"UCX_{asset_name}_00"; col.dimensions=dims
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); col.display_type='WIRE'; col.hide_render=True
    return col,'bounding-box'


def duplicate_joined(asset_name, originals):
    clones=[]; bpy.ops.object.select_all(action='DESELECT')
    for src in originals:
        if src.type!='MESH': continue
        clone=src.copy(); clone.data=src.data.copy(); bpy.context.collection.objects.link(clone); clone.select_set(True); clones.append(clone)
    if not clones: raise ValueError('No mesh geometry available for export')
    bpy.context.view_layer.objects.active=clones[0]
    if len(clones)>1: bpy.ops.object.join()
    joined=bpy.context.object; joined.name=asset_name
    tri=joined.modifiers.new(name='NexuTriangulate',type='TRIANGULATE'); apply_modifiers(joined)
    return joined


def delete_objects(objects):
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        if obj and obj.name in bpy.data.objects: obj.select_set(True)
    if any(obj and obj.name in bpy.data.objects for obj in objects): bpy.ops.object.delete(use_global=False)


def export_fbx(path, profile, asset_name, originals, collision):
    joined=duplicate_joined(asset_name,originals)
    bpy.ops.object.select_all(action='DESELECT'); joined.select_set(True)
    if collision is not None: collision.select_set(True)
    kwargs=dict(filepath=path,use_selection=True,apply_unit_scale=True,bake_space_transform=False,add_leaf_bones=False,use_mesh_modifiers=True,path_mode='COPY',embed_textures=True)
    if profile=='unreal-asa': kwargs.update(axis_forward='-Y',axis_up='Z')
    bpy.ops.export_scene.fbx(**kwargs)
    delete_objects([joined])


def export_glb(path, asset_name, originals):
    joined=duplicate_joined(asset_name,originals)
    bpy.ops.object.select_all(action='DESELECT'); joined.select_set(True)
    bpy.ops.export_scene.gltf(filepath=path,export_format='GLB',use_selection=True)
    delete_objects([joined])


def create_lods(asset_name, originals, count, output_dir, profile):
    outputs=[]
    for level in range(1,count+1):
        joined=duplicate_joined(f'{asset_name}_LOD{level}',originals)
        ratio=max(0.08,0.5**level)
        mod=joined.modifiers.new(name='NexuLOD',type='DECIMATE'); mod.ratio=ratio; apply_modifiers(joined)
        tri=triangle_count([joined])
        lod_path=os.path.join(output_dir,f'{asset_name}_LOD{level}.fbx')
        glb_path=os.path.join(output_dir,f'{asset_name}_LOD{level}.glb')
        bpy.ops.object.select_all(action='DESELECT'); joined.select_set(True)
        bpy.ops.export_scene.fbx(filepath=lod_path,use_selection=True,apply_unit_scale=True,axis_forward='-Y' if profile=='unreal-asa' else '-Z',axis_up='Z' if profile=='unreal-asa' else 'Y',add_leaf_bones=False,use_mesh_modifiers=True,path_mode='COPY',embed_textures=True)
        bpy.ops.export_scene.gltf(filepath=glb_path,export_format='GLB',use_selection=True)
        outputs.append({'file':os.path.basename(lod_path),'glbFile':os.path.basename(glb_path),'triangles':tri,'ratio':ratio})
        delete_objects([joined])
    return outputs


def simple_preview_material(name,color,emission=False):
    mat=bpy.data.materials.new(name=name); mat.use_nodes=True
    bsdf=mat.node_tree.nodes.get('Principled BSDF') if mat.node_tree else None
    if bsdf:
        set_principled_input(bsdf,'Base Color',color)
        set_principled_input(bsdf,'Roughness',0.55)
        if emission:
            set_principled_input(bsdf,'Emission Color',color)
            set_principled_input(bsdf,'Emission Strength',2.5)
    return mat


def look_at(obj,target):
    direction=Vector(target)-obj.location
    obj.rotation_euler=direction.to_track_quat('-Z','Y').to_euler()


def render_one(scene,camera,path,position,target):
    camera.location=position; look_at(camera,target); scene.render.filepath=path; bpy.ops.render.render(write_still=True)


def render_previews(output_dir,asset_name,objects,collision,size):
    preview_dir=os.path.join(output_dir,'Preview'); os.makedirs(preview_dir,exist_ok=True)
    bounds=bounds_for(objects)
    if not bounds: return [],['no geometry bounds available']
    mins,maxs=bounds; centre=Vector([(mins[i]+maxs[i])/2 for i in range(3)]); dims=[maxs[i]-mins[i] for i in range(3)]; span=max(dims)
    support=[]; outputs=[]; errors=[]
    try:
        scene=bpy.context.scene
        try: scene.render.engine='BLENDER_EEVEE_NEXT'
        except Exception: scene.render.engine='BLENDER_WORKBENCH'
        scene.render.resolution_x=int(size); scene.render.resolution_y=int(size); scene.render.resolution_percentage=100
        scene.render.image_settings.file_format='PNG'; scene.render.film_transparent=False
        if scene.world is None: scene.world=bpy.data.worlds.new('NexuWorld')
        scene.world.color=(0.012,0.015,0.022)
        scene.camera=None
        bpy.ops.object.camera_add(); camera=bpy.context.object; camera.name='NexuPreviewCamera'; camera.data.lens=52; scene.camera=camera; support.append(camera)
        for name,loc,energy,size_light in [
            ('Key',(span*1.6,-span*1.7,span*2.2),1000,span*2.0),
            ('Fill',(-span*1.7,-span*0.8,span*1.1),500,span*1.5),
            ('Rim',(span*0.4,span*1.8,span*2.0),800,span*1.2)]:
            bpy.ops.object.light_add(type='AREA',location=(centre.x+loc[0],centre.y+loc[1],centre.z+loc[2]))
            light=bpy.context.object; light.name=f'Nexu{name}'; light.data.energy=energy; light.data.shape='DISK'; light.data.size=max(0.25,size_light); look_at(light,centre); support.append(light)
        bpy.ops.mesh.primitive_plane_add(size=max(2.0,span*5.0),location=(centre.x,centre.y,mins[2]-0.002))
        ground=bpy.context.object; ground.name='NexuPreviewGround'; ground_mat=simple_preview_material('NexuGround',(0.035,0.042,0.052,1)); assign_material(ground,ground_mat); support.append(ground)
        dist=span*2.15
        views=[
            ('perspective.png',(centre.x+dist*0.85,centre.y-dist,centre.z+dist*0.55)),
            ('front.png',(centre.x,centre.y-dist,centre.z+span*0.12)),
            ('side.png',(centre.x+dist,centre.y,centre.z+span*0.12))]
        for filename,pos in views:
            path=os.path.join(preview_dir,filename); render_one(scene,camera,path,pos,centre); outputs.append(os.path.join('Preview',filename))
        # Wireframe inspection image.
        wiremat=simple_preview_material('NexuWire',(0.20,0.72,1.0,1),True)
        clones=[]
        for src in objects:
            if src.type!='MESH': continue
            clone=src.copy(); clone.data=src.data.copy(); bpy.context.collection.objects.link(clone); clone.data.materials.clear(); clone.data.materials.append(wiremat)
            mod=clone.modifiers.new(name='NexuPreviewWire',type='WIREFRAME'); mod.thickness=max(0.0008,span*0.0015); mod.use_even_offset=True; apply_modifiers(clone); clones.append(clone)
            src.hide_render=True
        path=os.path.join(preview_dir,'wireframe.png'); render_one(scene,camera,path,(centre.x+dist*0.85,centre.y-dist,centre.z+dist*0.55),centre); outputs.append(os.path.join('Preview','wireframe.png'))
        for src in objects: src.hide_render=False
        delete_objects(clones)
        # Collision inspection image overlays a bright wire collision over the asset.
        if collision is not None:
            c=collision.copy(); c.data=collision.data.copy(); bpy.context.collection.objects.link(c); c.hide_render=False; c.data.materials.clear(); c.data.materials.append(simple_preview_material('NexuCollision',(1.0,0.18,0.07,1),True))
            mod=c.modifiers.new(name='NexuCollisionWire',type='WIREFRAME'); mod.thickness=max(0.001,span*0.002); mod.use_even_offset=True; apply_modifiers(c)
            path=os.path.join(preview_dir,'collision.png'); render_one(scene,camera,path,(centre.x+dist*0.85,centre.y-dist,centre.z+dist*0.55),centre); outputs.append(os.path.join('Preview','collision.png')); delete_objects([c])
    except Exception as exc:
        errors.append(str(exc))
    finally:
        for obj in objects: obj.hide_render=False
        delete_objects([o for o in support if o and o.name in bpy.data.objects])
    return outputs,errors



def render_dataset_views(output_dir,objects,size):
    dataset_dir=os.path.join(output_dir,'Dataset','Views'); os.makedirs(dataset_dir,exist_ok=True)
    bounds=bounds_for(objects)
    if not bounds: return [],['no geometry bounds available']
    mins,maxs=bounds; centre=Vector([(mins[i]+maxs[i])/2 for i in range(3)]); dims=[maxs[i]-mins[i] for i in range(3)]; span=max(dims)
    support=[]; outputs=[]; errors=[]
    try:
        scene=bpy.context.scene
        try: scene.render.engine='BLENDER_EEVEE_NEXT'
        except Exception: scene.render.engine='BLENDER_WORKBENCH'
        scene.render.resolution_x=int(size); scene.render.resolution_y=int(size); scene.render.resolution_percentage=100
        scene.render.image_settings.file_format='PNG'; scene.render.film_transparent=True
        if scene.world is None: scene.world=bpy.data.worlds.new('NexuDatasetWorld')
        scene.world.color=(0.0,0.0,0.0)
        scene.camera=None
        bpy.ops.object.camera_add(); camera=bpy.context.object; camera.name='NexuDatasetCamera'; camera.data.lens=55; scene.camera=camera; support.append(camera)
        for name,loc,energy,size_light in [
            ('DatasetKey',(span*1.7,-span*1.8,span*2.2),900,span*2.0),
            ('DatasetFill',(-span*1.6,-span*0.7,span*1.0),420,span*1.4),
            ('DatasetRim',(span*0.4,span*1.8,span*1.8),650,span*1.2)]:
            bpy.ops.object.light_add(type='AREA',location=(centre.x+loc[0],centre.y+loc[1],centre.z+loc[2]))
            light=bpy.context.object; light.name=name; light.data.energy=energy; light.data.shape='DISK'; light.data.size=max(0.25,size_light); look_at(light,centre); support.append(light)
        dist=max(span*2.35,0.5)
        views=[
            ('perspective.png',(centre.x+dist*0.85,centre.y-dist,centre.z+dist*0.55)),
            ('front.png',(centre.x,centre.y-dist,centre.z)),
            ('back.png',(centre.x,centre.y+dist,centre.z)),
            ('left.png',(centre.x-dist,centre.y,centre.z)),
            ('right.png',(centre.x+dist,centre.y,centre.z)),
            ('top.png',(centre.x,centre.y,centre.z+dist)),
            ('bottom.png',(centre.x,centre.y,centre.z-dist))]
        for filename,pos in views:
            path=os.path.join(dataset_dir,filename); render_one(scene,camera,path,pos,centre); outputs.append(os.path.join('Dataset','Views',filename))
    except Exception as exc:
        errors.append(str(exc))
    finally:
        delete_objects([o for o in support if o and o.name in bpy.data.objects])
        try: bpy.context.scene.render.film_transparent=False
        except Exception: pass
    return outputs,errors

def quality_report(recipe,tri_count,collision_kind,preview_outputs,preview_errors,construction):
    target=max(1,int(recipe.get('targetTriangles',tri_count)))
    delta=abs(tri_count-target)/target
    budget_score=30 if delta<=0.05 else 26 if delta<=0.10 else 18 if delta<=0.20 else 8
    uv_score=15 if recipe.get('uv',True) else 0
    collision_score=15 if collision_kind not in ('none','bounding-box') else 10 if collision_kind=='bounding-box' else 0
    material_score=15 if any(m.get('style','flat')!='flat' for m in recipe.get('materials',[])) else 9
    expected_previews=5 if recipe.get('quality',{}).get('previews',True) else 0
    preview_score=15 if expected_previews and len(preview_outputs)>=expected_previews and not preview_errors else 7 if preview_outputs else (15 if expected_previews==0 else 0)
    construction_score=10 if any(c.get('kind') in ('barrel','drum','creature') for c in construction) else 7
    score=budget_score+uv_score+collision_score+material_score+preview_score+construction_score
    checks={
        'triangleBudget': {'ok':delta<=0.10,'deltaPct':round(delta*100,2),'score':budget_score},
        'uv': {'ok':bool(recipe.get('uv',True)),'score':uv_score},
        'collision': {'ok':collision_kind!='none','kind':collision_kind,'score':collision_score},
        'materials': {'ok':material_score>=15,'score':material_score},
        'previews': {'ok':preview_score>=15,'files':preview_outputs,'errors':preview_errors,'score':preview_score},
        'construction': {'ok':construction_score>=10,'score':construction_score}
    }
    return score,('pass' if score>=85 and delta<=0.15 else 'warn'),checks,round(delta*100,2)


def main():
    parsed=parse_args(); recipe_path=os.path.abspath(parsed['recipe']); output_dir=os.path.abspath(parsed['output']); os.makedirs(output_dir,exist_ok=True)
    with open(recipe_path,'r',encoding='utf-8') as f: recipe=json.load(f)
    clean_scene(); scene=bpy.context.scene; scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1.0
    print('NEXU3D_STAGE materials', flush=True)
    mats={}; material_outputs=[]
    print('NEXU3D_STAGE texturing', flush=True)
    for spec in recipe.get('materials',[]):
        mat, produced = material_from_spec(spec, output_dir); mats[spec['name']]=mat; material_outputs.extend(produced)
    print('NEXU3D_STAGE modelling', flush=True)
    created,construction,repair=create_recipe_objects(recipe,mats)
    print('NEXU3D_STAGE collision', flush=True)
    collision=None; collision_kind='none'
    if recipe.get('collision',True): collision,collision_kind=add_collision(recipe['assetName'],created,recipe)
    tri_count=triangle_count(created)
    diagnostics=mesh_diagnostics(created)
    print('NEXU3D_STAGE validation', flush=True)
    preview_outputs=[]; preview_errors=[]
    if recipe.get('quality',{}).get('previews',True):
        preview_outputs,preview_errors=render_previews(output_dir,recipe['assetName'],created,collision,int(recipe.get('quality',{}).get('previewSize',768)))
    print('NEXU3D_STAGE dataset', flush=True)
    dataset_outputs=[]; dataset_errors=[]
    if recipe.get('quality',{}).get('datasetCapture',True):
        dataset_outputs,dataset_errors=render_dataset_views(output_dir,created,int(recipe.get('quality',{}).get('datasetViewSize',512)))
    print('NEXU3D_STAGE exporting', flush=True)
    blend_path=os.path.join(output_dir,recipe['assetName']+'.blend'); fbx_path=os.path.join(output_dir,recipe['assetName']+'.fbx'); glb_path=os.path.join(output_dir,recipe['assetName']+'.glb'); outputs=[]
    blend_compressed=recipe.get('quality',{}).get('generationMode','balanced')!='fast'
    if 'blend' in recipe['exports']:
        bpy.ops.wm.save_as_mainfile(filepath=blend_path,compress=blend_compressed); outputs.append(os.path.basename(blend_path))
    if 'fbx' in recipe['exports']:
        export_fbx(fbx_path,recipe.get('profile','generic'),recipe['assetName'],created,collision); outputs.append(os.path.basename(fbx_path))
    if 'glb' in recipe['exports']:
        export_glb(glb_path,recipe['assetName'],created); outputs.append(os.path.basename(glb_path))
    collision_glb=None
    if collision is not None and 'glb' in recipe['exports']:
        collision_glb=export_collision_glb(os.path.join(output_dir,recipe['assetName']+'_COLLISION.glb'),collision)
        if collision_glb: outputs.append(collision_glb)
    lod_records=[]
    if recipe.get('lods',0)>0 and 'fbx' in recipe['exports']:
        lod_records=create_lods(recipe['assetName'],created,int(recipe['lods']),output_dir,recipe.get('profile','generic'))
    quality_score,quality_status,quality_checks,budget_delta=quality_report(recipe,tri_count,collision_kind,preview_outputs,preview_errors,construction)
    report={
        'schemaVersion':'1.4','assetName':recipe['assetName'],'assetClass':recipe.get('assetClass','GenericProp'),'grammarId':recipe.get('grammarId','generic-prop'),'profile':recipe.get('profile','generic'),'triangles':tri_count,'targetTriangles':recipe.get('targetTriangles'),'triangleBudgetDeltaPct':budget_delta,
        'recipePartCount':len(recipe['parts']),'generatedObjectCount':len(created),'materialCount':len(mats),'uvRequested':bool(recipe.get('uv',True)),'collisionCreated':collision is not None,'collisionKind':collision_kind,
        'outputs':outputs,'blendCompressed':blend_compressed,'materialOutputs':material_outputs,'lodOutputs':[r['file'] for r in lod_records],'lodDetails':lod_records,'previewOutputs':preview_outputs,'previewErrors':preview_errors,
        'construction':construction,'meshRepair':repair,'geometryDiagnostics':diagnostics,'collisionGlb':collision_glb,'qualityScore':quality_score,'qualityStatus':quality_status,'qualityChecks':quality_checks,'status':'generated'
    }
    if recipe.get('quality',{}).get('datasetCapture',True):
        dataset_dir=os.path.join(output_dir,'Dataset'); os.makedirs(dataset_dir,exist_ok=True)
        training_views=list(dataset_outputs)
        dataset={
            'schema':'nexu.forge.dataset.v1','assetName':recipe['assetName'],'assetClass':recipe.get('assetClass','GenericProp'),'grammarId':recipe.get('grammarId','generic-prop'),
            'sourcePrompt':recipe.get('sourcePrompt',''),'profile':recipe.get('profile','generic'),'targetTriangles':recipe.get('targetTriangles'),'triangles':tri_count,
            'qualityScore':quality_score,'qualityStatus':quality_status,'views':training_views,'viewErrors':dataset_errors,'materials':[m.get('name') for m in recipe.get('materials',[])],
            'outputs':outputs,'lodOutputs':[r['file'] for r in lod_records],'construction':construction,'localOnly':True,'containsReferenceImageBytes':False,'provenance':'generated-by-nexu-forge'
        }
        dataset_rel=os.path.join('Dataset','dataset-record.json')
        with open(os.path.join(output_dir,dataset_rel),'w',encoding='utf-8') as f: json.dump(dataset,f,indent=2)
        dataset_outputs=[dataset_rel]+training_views
        report['datasetOutputs']=dataset_outputs
        report['datasetRecord']=dataset_rel
        report['datasetErrors']=dataset_errors
    with open(os.path.join(output_dir,'validation.json'),'w',encoding='utf-8') as f: json.dump(report,f,indent=2)
    with open(os.path.join(output_dir,'quality.json'),'w',encoding='utf-8') as f: json.dump({'assetName':recipe['assetName'],'score':quality_score,'status':quality_status,'checks':quality_checks,'construction':construction},f,indent=2)
    print('NEXU3D_RESULT '+json.dumps(report,separators=(',',':')))


if __name__=='__main__':
    try: main()
    except Exception as exc:
        traceback.print_exc(); print(f"NEXU3D_ERROR: {exc}",file=sys.stderr); raise SystemExit(3)
