let capture=null,epoch=0,timer=null,api;
const el=id=>document.getElementById(id);
const profiles={economy:{edge:800,quality:.5,delay:1000},balanced:{edge:1280,quality:.65,delay:500},detail:{edge:1600,quality:.8,delay:250}};
function controls(active){el('startScreen').disabled=active;el('stopScreen').disabled=!active;el('screenDevice').disabled=active;}
export function updateScreenDevices(devices){
 const select=el('screenDevice');if(!select)return;const selected=capture?.deviceId||select.value;
 select.replaceChildren(...devices.map(d=>{const o=document.createElement('option');o.value=d.deviceId;o.textContent=d.name;return o;}));
 if(devices.some(d=>d.deviceId===selected))select.value=selected;
 if(capture&&!devices.some(d=>d.deviceId===capture.deviceId))void stop('Selected tablet was forgotten.');
}
async function stop(message='Screen sharing is off.'){
 const ended=capture;capture=null;++epoch;clearTimeout(timer);controls(false);
 if(ended){ended.stream.getTracks().forEach(t=>t.stop());ended.video.srcObject=null;}
 el('screenStatus').textContent=message;
 if(ended?.sessionId)try{await api('/api/screen/stop',{method:'POST',body:JSON.stringify({sessionId:ended.sessionId})});}catch{}
}
export function initScreenSharing(requestApi){
 api=requestApi;el('stopScreen').onclick=()=>void stop();
 el('startScreen').onclick=async()=>{
  const deviceId=el('screenDevice').value;if(!deviceId){el('screenStatus').textContent='Pair your tablet first.';return;}
  if(!navigator.mediaDevices?.getDisplayMedia){el('screenStatus').textContent='Open Forge in desktop Edge or Chrome to share a screen.';return;}
  const ticket=++epoch;controls(true);let acquired=null;
  try{
   acquired=await navigator.mediaDevices.getDisplayMedia({video:{frameRate:{ideal:4,max:4}},audio:false});
   if(ticket!==epoch){acquired.getTracks().forEach(t=>t.stop());return;}
   const video=document.createElement('video');video.muted=true;video.playsInline=true;video.srcObject=acquired;
   const own={stream:acquired,deviceId,video,sessionId:null};capture=own;
   acquired.getVideoTracks()[0].addEventListener('ended',()=>{if(capture===own)void stop();});
   const session=await api('/api/screen/start',{method:'POST',body:JSON.stringify({deviceId})});own.sessionId=session.sessionId;
   if(ticket!==epoch){await api('/api/screen/stop',{method:'POST',body:JSON.stringify({sessionId:own.sessionId})});return;}
   await video.play();if(ticket!==epoch)return;
   const canvas=document.createElement('canvas'),context=canvas.getContext('2d');let failures=0;
   async function frame(){
    if(ticket!==epoch)return;const began=performance.now();const profile=profiles[el('screenQuality').value]||profiles.balanced;
    try{
     if(!video.videoWidth||!video.videoHeight)throw new Error('Waiting for screen capture');
     const scale=Math.min(1,profile.edge/video.videoWidth,profile.edge/video.videoHeight);
     canvas.width=Math.max(1,Math.round(video.videoWidth*scale));canvas.height=Math.max(1,Math.round(video.videoHeight*scale));
     context.drawImage(video,0,0,canvas.width,canvas.height);let quality=profile.quality,base64;
     do{base64=canvas.toDataURL('image/jpeg',quality).split(',')[1];quality-=.15;}while(base64.length>700000&&quality>=.2);
     if(base64.length>700000)throw new Error('Choose Economy for this screen');
     await api('/api/screen/frame',{method:'POST',body:JSON.stringify({sessionId:own.sessionId,width:canvas.width,height:canvas.height,base64})});
     if(ticket!==epoch)return;failures=0;
     el('screenStatus').textContent=`Sharing ${canvas.width} × ${canvas.height} · ${Math.round(base64.length*.75/1024)} KB/frame · ${Math.round(performance.now()-began)} ms upload. Open Screen on your tablet.`;
     timer=setTimeout(frame,profile.delay);
    }catch(e){if(ticket!==epoch)return;if(++failures>=3){await stop('Sharing stopped: '+e.message);return;}el('screenStatus').textContent='Connection interrupted. Reconnecting…';timer=setTimeout(frame,1500);}
   }
   await frame();
  }catch(e){if(ticket===epoch){if(acquired)acquired.getTracks().forEach(t=>t.stop());await stop(e.name==='NotAllowedError'?'Screen selection cancelled.':'Cannot share: '+e.message);}}
 };
 window.addEventListener('pagehide',()=>{const own=capture;capture=null;++epoch;clearTimeout(timer);if(own){own.stream.getTracks().forEach(t=>t.stop());if(own.sessionId)fetch('/api/screen/stop',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId:own.sessionId}),keepalive:true}).catch(()=>{});}});
}
