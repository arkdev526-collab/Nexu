import { safeAssetName, validateRecipe } from './schema.mjs';
import { buildGrammarPlan, targetTrianglesFromPrompt } from './asset-grammar.mjs';
import { compileCreationPrompt } from './prompt-intelligence.mjs';

function titleName(prompt, kind) {
  const words = prompt.replace(/[^A-Za-z0-9 ]/g, ' ').trim().split(/\s+/).filter(Boolean).slice(0, 6);
  const stem = words.length ? words.map(w => w[0].toUpperCase() + w.slice(1).toLowerCase()).join('_') : kind;
  return safeAssetName(`SM_${stem}`);
}

function generationMode(value){return value==='fast'||value==='quality'?value:'balanced';}
function modeAdjustedPlan(plan,mode){
  const p=structuredClone(plan),m=generationMode(mode);
  if(m==='fast'){
    p.materials=(p.materials||[]).map(x=>({...x,textureResolution:Math.min(Number(x.textureResolution||512),256)}));
    for(const part of p.parts||[])if(part.type==='procedural_creature'&&part.details?.voxelSize)part.details.voxelSize=Math.min(.18,part.details.voxelSize*1.28);
  }else if(m==='quality'){
    p.materials=(p.materials||[]).map(x=>({...x,textureResolution:Math.max(Number(x.textureResolution||512),1024)}));
    for(const part of p.parts||[])if(part.type==='procedural_creature'&&part.details?.voxelSize)part.details.voxelSize=Math.max(.012,part.details.voxelSize*.84);
  }
  return p;
}

export function planPrompt(prompt, options = {}) {
  if (typeof prompt !== 'string' || !prompt.trim()) throw new Error('A non-empty 3D prompt is required');
  const understanding=compileCreationPrompt(prompt),effectivePrompt=understanding.plannerPrompt||prompt,lower=effectivePrompt.toLowerCase(),mode=generationMode(options.generationMode);
  const { grammarId, assetClass, plan:basePlan } = buildGrammarPlan(effectivePrompt),plan=modeAdjustedPlan(basePlan,mode);
  return validateRecipe({
    schemaVersion:'1.2',
    assetName: options.assetName ?? titleName(effectivePrompt, assetClass),
    assetClass,
    grammarId,
    sourcePrompt: prompt,
    profile: options.profile ?? (/unreal|asa|ark/.test(lower) ? 'unreal-asa' : 'generic'),
    targetTriangles: options.targetTriangles ?? targetTrianglesFromPrompt(effectivePrompt, plan.defaultTris),
    parts: plan.parts,
    materials: plan.materials,
    uv: true,
    collision: options.collision ?? true,
    lods: options.lods ?? (/\b4\s*lods?\b/i.test(effectivePrompt) ? 3 : /\b3\s*lods?\b/i.test(effectivePrompt) ? 2 : /\b2\s*lods?\b/i.test(effectivePrompt) ? 1 : 0),
    exports: options.exports ?? ['blend','fbx','glb'],
    quality: {
      generationMode: mode,
      autoRepair: options.autoRepair ?? true,
      autoMeshRepair: options.autoMeshRepair ?? true,
      targetTolerancePct: options.targetTolerancePct ?? (mode==='fast'?.06:mode==='quality'?.02:.03),
      previews: options.previews ?? true,
      previewSize: options.previewSize ?? (mode==='fast'?512:mode==='quality'?1024:768),
      datasetCapture: options.datasetCapture ?? mode!=='fast',
      datasetViewSize: options.datasetViewSize ?? (mode==='fast'?320:mode==='quality'?640:512)
    }
  });
}
