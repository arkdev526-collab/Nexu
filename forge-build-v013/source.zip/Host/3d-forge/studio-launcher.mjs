#!/usr/bin/env node
import { access, mkdir, open, readFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const dataRoot = resolve(process.env.NEXU_FORGE_DATA_DIR?.trim() || join(here, 'data'));
const runtimeRoot = join(dataRoot, '.runtime');
const sessionPath = join(runtimeRoot, '.studio-session.json');
const logDir = join(dataRoot, 'Logs');
const serverPath = join(here, 'studio-server.mjs');

async function exists(path) { try { await access(path, constants.R_OK); return true; } catch { return false; } }

async function openUrl(url) {
  if (process.platform !== 'win32') { console.log(url); return; }
  const candidates = [
    join(process.env['ProgramFiles(x86)'] ?? '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    join(process.env.ProgramFiles ?? '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    join(process.env.LOCALAPPDATA ?? '', 'Microsoft', 'Edge', 'Application', 'msedge.exe')
  ].filter(Boolean);
  for (const path of candidates) {
    try {
      await access(path, constants.X_OK);
      const child = spawn(path, [`--app=${url}`, '--start-maximized'], { detached:true, stdio:'ignore', windowsHide:true, shell:false });
      child.unref(); return;
    } catch {}
  }
  const child = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], { detached:true, stdio:'ignore', windowsHide:true, shell:false });
  child.unref();
}

async function existingSession() {
  try {
    const session = JSON.parse(await readFile(sessionPath, 'utf8'));
    const response = await fetch(`http://127.0.0.1:${session.port}/health`, { signal: AbortSignal.timeout(1200) });
    if (response.ok) return session;
  } catch {}
  return null;
}

async function main() {
  const current = await existingSession();
  if (current) { await openUrl(current.url); return; }
  await mkdir(logDir, { recursive:true });
  await mkdir(runtimeRoot, { recursive:true });
  const logPath = join(logDir, 'studio-server.log');
  const handle = await open(logPath, 'a');
  const child = spawn(process.execPath, [serverPath], {
    detached: true,
    windowsHide: true,
    shell: false,
    stdio: ['ignore', handle.fd, handle.fd],
    cwd: resolve(here, '..')
  });
  child.unref();
  await handle.close();
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 160));
    const session = await existingSession();
    if (session) return;
  }
  throw new Error(`Studio server did not start. See ${logPath}`);
}

main().catch(error => { console.error(`NEXU STUDIO LAUNCH ERROR: ${error.message}`); process.exitCode = 1; });
