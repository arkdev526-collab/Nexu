# Nexu AI 3D Forge v0.1.3 — Blender Bootstrap Repair Candidate

**Created:** 17 August 2026  
**Status:** Engineering candidate; deterministic planner and security/QA layer implemented. Real Blender export verification pending because Blender is not present in the build runtime.

## Goal

Create game-oriented static 3D props from a text description through a bounded, inspectable local pipeline that can emit `.blend`, `.fbx` and `.glb` without allowing user or AI text to become executable Blender Python.

## Delivered

- `Nexu3D` schema v1 validator with bounded numbers, names, part counts, material counts and allow-listed primitive types.
- deterministic text planner for barrel, crate, pillar, table, wall, rock and generic static props;
- dimensional prompt handling for mm/cm/m height requests and triangle-target parsing;
- generic and Unreal/ASA export profiles;
- trusted Blender 5.2.x background worker;
- basic PBR material construction;
- geometry, bevel application and smart UV projection;
- simple `UCX_` bounding-box collision;
- optional decimated LOD FBX outputs;
- `.blend`, `.fbx`, `.glb` export path;
- `validation.json` generation evidence;
- output inspector;
- read-only Doctor;
- one-click Windows prompt/build launcher;
- no new npm runtime dependencies;
- inherited Sumero Studio Technology Authority v1.0.0.

## Security decisions

1. AI text does not become Python, shell or Blender expressions.
2. The worker script is package-owned and receives validated JSON only.
3. `--factory-startup` and `--disable-autoexec` reduce reliance on user startup state and blend-file auto-execution.
4. Blender 5.2.x is version-gated.
5. Remote downloads, add-on installation and arbitrary input paths are outside Phase 1.
6. Output is confined to the selected output directory.

## Deliberate limitations

This is **not** a neural text-to-3D model. Phase 1 is the safe procedural substrate that Nexu AI can later drive with structured output. It does not yet produce sculpted/organic characters, rigs, skeletal meshes, animation, image-to-3D reconstruction, generated texture images or verified ASA DevKit imports.

## v0.1.1 repair

The Phase 1 architecture and feature scope are unchanged. v0.1.1 repairs a terminal-dependent compiler regression test exposed on Windows Terminal when ANSI colour is inherited by a spawned generated program. No persistence semantics, Nexu Language syntax, 3D schema, Blender worker contract or export profile were changed.

## v0.1.3 repair

Target-PC evidence showed Node.js 24.19.0 PASS and Blender NOT FOUND. v0.1.3 adds a bounded Windows prerequisite bootstrap and broader common-path Blender discovery. The Nexu3D schema, planner, worker trust boundary and Phase 1 model scope are unchanged.
