# Nexu AI 3D Forge v0.10.1

## Universal Creation Intelligence, Fast Cache & Full Studio UX

v0.10 preserves the v0.9 creature foundation and expands Forge to 43 permanent local grammars, 387 recognised subject/modifier phrases, live Prompt Coaching, three generation modes and FastForge exact-build reuse.

## Runtime lifecycle

```text
Natural wording / reference
  -> Prompt Intelligence
  -> Brief / Creation Intelligence
  -> allow-listed Asset or Creature Grammar
  -> validated Nexu3D recipe
  -> FastForge fingerprint
       HIT  -> existing validated asset
       MISS -> trusted Blender worker
                 -> mesh repair / UV / material / collision / LOD
                 -> QA + GLB/FBX/BLEND
                 -> local dataset record when enabled
```

## Generation modes

- Fast: lower-cost materials/preview, coarser organic pass, no dataset capture, speed-priority uncompressed `.blend`.
- Balanced: normal production defaults and Blender-compressed `.blend`.
- Maximum Quality: denser organic pass, 1K material baseline, larger evidence surfaces and compressed `.blend`.

## Creation families

Existing rigid assets and eight creature foundations remain. v0.10 adds Door, Window frame, Sword, Shield, Axe, Hammer, Spear, Bucket, Pot, Book, Torch and Wagon wheel.

## Storage and speed

FastForge stores only a Brotli-compressed recipe index and points to existing validated user assets. It does not hard-link editable model files. An exact repeat can skip Blender entirely. Clearing the recipe cache never deletes generated assets.

## Safety

User/AI text is never executed as Python or shell. All generation is bounded structured data interpreted by package-owned worker code. No paid or temporary generation provider is required.
