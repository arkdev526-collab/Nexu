#!/usr/bin/env node
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import { resolve } from 'node:path';
import { planPrompt } from './planner.mjs';
import { validateRecipe } from './schema.mjs';
import { blenderVersion, findBlender, isSupportedBlenderVersion, runBlender } from './blender.mjs';
import { inspectOutput } from './qa.mjs';

function value(args, flag, fallback=null) { const i=args.indexOf(flag); return i>=0 && i+1<args.length ? args[i+1] : fallback; }
function has(args, flag) { return args.includes(flag); }
function help(){console.log(`Nexu AI 3D Forge v0.2.0\n\nCommands:\n  doctor\n  plan <prompt> [--out recipe.json] [--profile generic|unreal-asa]\n  build <prompt> [--out-dir path] [--profile generic|unreal-asa] [--blender path]
  build-interactive [--out-dir path] [--profile generic|unreal-asa] [--blender path]\n  build-recipe <recipe.json> [--out-dir path] [--blender path]\n  inspect <output-dir>\n`)}



function stamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

async function writeBuildLog(lines) {
  const logDir = resolve('3d-forge/logs');
  await mkdir(logDir, { recursive: true });
  const body = `${lines.join('\n')}\n`;
  const named = resolve(logDir, `build-${stamp()}.log`);
  const last = resolve(logDir, 'last-build.log');
  await writeFile(named, body, 'utf8');
  await writeFile(last, body, 'utf8');
  return { named, last };
}

async function executeBuild(prompt, args, logLines = []) {
  const recipe = planPrompt(prompt,{profile:value(args,'--profile',undefined)});
  const out=resolve(value(args,'--out-dir',`3d-forge/output/${recipe.assetName}`));
  logLines.push(`Prompt: ${prompt}`);
  logLines.push(`Asset: ${recipe.assetName}`);
  logLines.push(`Profile: ${recipe.profile}`);
  logLines.push(`Parts: ${recipe.parts.length}`);
  logLines.push(`Target triangles: ${recipe.targetTriangles}`);
  logLines.push(`LODs: ${recipe.lods}`);
  logLines.push(`Output: ${out}`);
  const result=await runBlender(recipe,out,{blenderPath:value(args,'--blender',undefined)});
  logLines.push(`Blender: ${result.blenderVersion}`);
  logLines.push(`Status: SUCCESS`);
  logLines.push(JSON.stringify(result.report,null,2));
  return { recipe, out, result };
}

async function main(){
  const args=process.argv.slice(2), cmd=args.shift();
  if(!cmd || cmd==='help' || cmd==='--help'){help();return;}
  if(cmd==='doctor'){
    const blender=await findBlender(value(args,'--blender',undefined));
    const version=await blenderVersion(blender);
    const nodeOk=/^v24\.19\./.test(process.version); const blenderOk=isSupportedBlenderVersion(version);
    console.log(`Nexu AI 3D Forge Doctor`); console.log(`Node: ${process.version} ${nodeOk?'PASS':'FAIL (requires 24.19.x LTS)'}`); console.log(`Blender: ${version ?? 'NOT FOUND'} ${blenderOk?'PASS':'FAIL (requires stable 5.2.x)'}`); console.log(`Path: ${blender}`);
    if(!nodeOk || !blenderOk){process.exitCode=2; console.log('ACTION: Install Node.js 24.19.x LTS and stable Blender 5.2.x; set NEXU_BLENDER_PATH if Blender is not auto-detected.');}
    return;
  }
  if(cmd==='plan'){
    const prompt=args.filter((_,i)=>i < (args.indexOf('--out')>=0?args.indexOf('--out'):args.length) && i < (args.indexOf('--profile')>=0?args.indexOf('--profile'):args.length)).join(' ').trim() || args[0];
    if(!prompt) throw new Error('plan requires a text prompt');
    const recipe=planPrompt(prompt,{profile:value(args,'--profile',undefined)}); const json=JSON.stringify(recipe,null,2);
    const out=value(args,'--out'); if(out){await writeFile(resolve(out),json,'utf8');console.log(`Wrote ${resolve(out)}`);} else console.log(json); return;
  }
  if(cmd==='build'){
    const knownFlagIndex=args.findIndex(x=>x.startsWith('--')); const prompt=(knownFlagIndex<0?args:args.slice(0,knownFlagIndex)).join(' ').trim(); if(!prompt) throw new Error('build requires a text prompt');
    const logLines=[`Nexu AI 3D Forge v0.2.0`, `Started: ${new Date().toISOString()}`];
    try {
      const { result, out } = await executeBuild(prompt,args,logLines);
      console.log(`Generated ${result.report.assetName} -> ${out}`); console.log(JSON.stringify(result.report,null,2));
      const log=await writeBuildLog(logLines); console.log(`Log: ${log.last}`);
    } catch (error) {
      logLines.push(`Status: FAILED`); logLines.push(error?.stack ?? String(error));
      const log=await writeBuildLog(logLines); console.error(`NEXU3D ERROR: ${error.message}`); console.error(`Diagnostic log: ${log.last}`); process.exitCode=1;
    }
    return;
  }
  if(cmd==='build-interactive'){
    const logLines=[`Nexu AI 3D Forge v0.2.0`, `Started: ${new Date().toISOString()}`];
    const blender=await findBlender(value(args,'--blender',undefined));
    const version=await blenderVersion(blender);
    const nodeOk=/^v24\.19\./.test(process.version); const blenderOk=isSupportedBlenderVersion(version);
    console.log(`Preflight Node: ${process.version} ${nodeOk?'PASS':'FAIL (requires 24.19.x LTS)'}`);
    console.log(`Preflight Blender: ${version ?? 'NOT FOUND'} ${blenderOk?'PASS':'FAIL (requires stable 5.2.x)'}`);
    logLines.push(`Node: ${process.version} ${nodeOk?'PASS':'FAIL'}`); logLines.push(`Blender: ${version ?? 'NOT FOUND'} ${blenderOk?'PASS':'FAIL'}`); logLines.push(`Blender path: ${blender}`);
    if(!nodeOk || !blenderOk){
      logLines.push('Status: PREFLIGHT FAILED'); const log=await writeBuildLog(logLines);
      console.error('ACTION: Run CHECK-NEXU-3D.cmd and repair the failed requirement before building.'); console.error(`Diagnostic log: ${log.last}`); process.exitCode=2; return;
    }
    const rl=createInterface({input,output});
    let prompt='';
    try { prompt=(await rl.question('Describe the static 3D model to create: ')).trim(); }
    finally { rl.close(); }
    if(!prompt){ logLines.push('Status: CANCELLED - empty prompt'); const log=await writeBuildLog(logLines); console.error('ERROR: No prompt supplied.'); console.error(`Diagnostic log: ${log.last}`); process.exitCode=2; return; }
    try {
      const preview=planPrompt(prompt,{profile:value(args,'--profile',undefined)});
      console.log(''); console.log(`Planned asset: ${preview.assetName}`); console.log(`Profile: ${preview.profile}`); console.log(`Recipe parts: ${preview.parts.length}`); console.log(`Target triangles: ${preview.targetTriangles}`); console.log(`LOD exports: ${preview.lods}`); console.log(`Auto quality repair: ${preview.quality.autoRepair?'ON':'OFF'}`); console.log(`Preview render set: ${preview.quality.previews?'ON':'OFF'}`); console.log('Starting Blender worker...'); console.log('');
      const { result, out }=await executeBuild(prompt,args,logLines);
      console.log(`Generated ${result.report.assetName}`); console.log(`Output: ${out}`); console.log(JSON.stringify(result.report,null,2));
      console.log(`Quality: ${result.report.qualityScore}/100 ${String(result.report.qualityStatus).toUpperCase()}`);
      if (result.report.previewOutputs?.length) console.log(`Previews: ${result.report.previewOutputs.join(', ')}`);
      const log=await writeBuildLog(logLines); console.log(`Diagnostic log: ${log.last}`);
      if (process.platform==='win32') { try { const { spawn } = await import('node:child_process'); const explorer=spawn('explorer.exe',[out],{detached:true,stdio:'ignore',windowsHide:false,shell:false}); explorer.unref(); console.log('Output folder opened in Explorer.'); } catch {} }
    } catch(error) {
      logLines.push('Status: FAILED'); logLines.push(error?.stack ?? String(error)); const log=await writeBuildLog(logLines);
      console.error(''); console.error(`NEXU3D ERROR: ${error.message}`); console.error(`Diagnostic log: ${log.last}`); process.exitCode=1;
    }
    return;
  }
  if(cmd==='build-recipe'){
    const path=args[0]; if(!path) throw new Error('build-recipe requires a .json recipe'); const recipe=validateRecipe(JSON.parse(await readFile(resolve(path),'utf8'))); const out=resolve(value(args,'--out-dir',`3d-forge/output/${recipe.assetName}`));
    const result=await runBlender(recipe,out,{blenderPath:value(args,'--blender',undefined)}); console.log(JSON.stringify(result.report,null,2)); return;
  }
  if(cmd==='inspect'){
    const dir=args[0]; if(!dir) throw new Error('inspect requires an output directory'); const result=await inspectOutput(resolve(dir)); console.log(JSON.stringify(result,null,2)); if(result.status!=='pass')process.exitCode=2; return;
  }
  throw new Error(`Unknown command '${cmd}'`);
}
main().catch(e=>{console.error(`NEXU3D ERROR: ${e.message}`);process.exitCode=1;});
