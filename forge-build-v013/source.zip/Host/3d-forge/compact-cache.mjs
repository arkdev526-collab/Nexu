import { access, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { createHash } from 'node:crypto';
import { brotliCompress, brotliDecompress, constants as zc } from 'node:zlib';
import { promisify } from 'node:util';
import { dirname, join, resolve, sep } from 'node:path';

const compress=promisify(brotliCompress),decompress=promisify(brotliDecompress);
function stable(v){if(Array.isArray(v))return v.map(stable);if(v&&typeof v==='object'){const o={};for(const k of Object.keys(v).sort())o[k]=stable(v[k]);return o;}return v;}
export function recipeFingerprint(recipe){return createHash('sha256').update(JSON.stringify(stable(recipe))).digest('hex');}
async function exists(p){try{await access(p,constants.R_OK);return true}catch{return false}}
export async function writeCompactJson(path,value){await mkdir(dirname(path),{recursive:true});const raw=Buffer.from(JSON.stringify(value),'utf8');const packed=await compress(raw,{params:{[zc.BROTLI_PARAM_MODE]:zc.BROTLI_MODE_TEXT,[zc.BROTLI_PARAM_QUALITY]:5,[zc.BROTLI_PARAM_SIZE_HINT]:raw.length,[zc.BROTLI_PARAM_LGWIN]:20}});await writeFile(path,packed);return{rawBytes:raw.length,packedBytes:packed.length};}
export async function readCompactJson(path,fallback=null){try{return JSON.parse((await decompress(await readFile(path))).toString('utf8'));}catch{return fallback;}}

export class CompactBuildCache{
  constructor(root,outputRoot,{maxEntries=96}={}){this.root=resolve(root);this.outputRoot=resolve(outputRoot);this.maxEntries=maxEntries;this.indexPath=join(this.root,'build-index.json.br');this._index=null;this._stats=null;}
  async _load(){if(this._index)return this._index;await mkdir(this.root,{recursive:true});const value=await readCompactJson(this.indexPath,null);this._index=value&&value.schema==='nexu.forge.build-cache.v1'&&Array.isArray(value.entries)?value:{schema:'nexu.forge.build-cache.v1',entries:[]};return this._index;}
  _insideOutput(rel){const p=resolve(this.outputRoot,rel),prefix=this.outputRoot.endsWith(sep)?this.outputRoot:this.outputRoot+sep;if(p!==this.outputRoot&&!p.startsWith(prefix))throw new Error('Cache entry escaped the Forge Assets root.');return p;}
  async lookup(recipe){const index=await this._load(),key=recipeFingerprint(recipe),entry=index.entries.find(x=>x.key===key);if(!entry)return null;const dir=this._insideOutput(entry.outputRelative);if(!(await exists(join(dir,'validation.json')))){index.entries=index.entries.filter(x=>x!==entry);await this._save();return null;}entry.lastUsedAt=new Date().toISOString();entry.hits=(entry.hits||0)+1;await this._save();return{...entry,dir};}
  async register(recipe,outputRelative){const index=await this._load(),key=recipeFingerprint(recipe),now=new Date().toISOString(),dir=this._insideOutput(outputRelative);if(!(await exists(join(dir,'validation.json'))))throw new Error('Cannot cache an output without validation.json.');const old=index.entries.find(x=>x.key===key);if(old){old.outputRelative=outputRelative;old.lastUsedAt=now;old.updatedAt=now;}else index.entries.push({key,outputRelative,createdAt:now,updatedAt:now,lastUsedAt:now,hits:0});index.entries.sort((a,b)=>String(b.lastUsedAt).localeCompare(String(a.lastUsedAt)));if(index.entries.length>this.maxEntries)index.entries.length=this.maxEntries;await this._save();return key;}
  async _save(){const index=await this._load();this._stats=await writeCompactJson(this.indexPath,index);}
  async stats(){const index=await this._load();let packedBytes=0;try{packedBytes=(await stat(this.indexPath)).size}catch{}return{schema:'nexu.forge.cache-stats.v1',entries:index.entries.length,totalHits:index.entries.reduce((n,x)=>n+(x.hits||0),0),indexBytes:packedBytes,maxEntries:this.maxEntries,mode:'exact-recipe reuse + Brotli index',preventsDuplicateBuilds:true};}
  async clear(){this._index={schema:'nexu.forge.build-cache.v1',entries:[]};await rm(this.indexPath,{force:true});return this.stats();}
}

export async function compactCompletedJobLog(path,value){const target=path.endsWith('.json')?path+'.br':path+'.br';const stats=await writeCompactJson(target,value);try{await rm(path,{force:true})}catch{}return{path:target,...stats};}
