import { validateRecipe } from './schema.mjs';

const PRESETS = Object.freeze({
  'aged-oak': { style:'aged_wood', baseColor:[0.30,0.105,0.032,1], metallic:0, roughness:0.72, variation:0.58, wear:0.46, normalStrength:0.34, textureResolution:512, tileable:true },
  'fresh-oak': { style:'wood', baseColor:[0.43,0.19,0.065,1], metallic:0, roughness:0.58, variation:0.42, wear:0.10, normalStrength:0.28, textureResolution:512, tileable:true },
  'worn-iron': { style:'worn_iron', baseColor:[0.12,0.13,0.14,1], metallic:1, roughness:0.46, variation:0.28, wear:0.42, normalStrength:0.22, textureResolution:512, tileable:true },
  'rusted-iron': { style:'rusted_iron', baseColor:[0.20,0.075,0.025,1], metallic:0.72, roughness:0.66, variation:0.54, wear:0.78, normalStrength:0.30, textureResolution:512, tileable:true },
  'brushed-steel': { style:'brushed_metal', baseColor:[0.56,0.57,0.58,1], metallic:1, roughness:0.28, variation:0.18, wear:0.12, normalStrength:0.14, textureResolution:512, tileable:true },
  'weathered-stone': { style:'stone', baseColor:[0.33,0.32,0.30,1], metallic:0, roughness:0.88, variation:0.48, wear:0.42, normalStrength:0.38, textureResolution:512, tileable:true },
  'mossy-stone': { style:'mossy_stone', baseColor:[0.22,0.27,0.18,1], metallic:0, roughness:0.92, variation:0.62, wear:0.56, normalStrength:0.40, textureResolution:512, tileable:true },
  'painted-metal': { style:'painted_metal', baseColor:[0.12,0.20,0.30,1], metallic:0.22, roughness:0.48, variation:0.24, wear:0.38, normalStrength:0.18, textureResolution:512, tileable:true },
  'ceramic': { style:'ceramic', baseColor:[0.62,0.62,0.60,1], metallic:0, roughness:0.24, variation:0.08, wear:0.05, normalStrength:0.08, textureResolution:512, tileable:true },
  'leather': { style:'leather', baseColor:[0.24,0.075,0.035,1], metallic:0, roughness:0.67, variation:0.36, wear:0.34, normalStrength:0.30, textureResolution:512, tileable:true },
  'dragon-scales': { style:'scales', baseColor:[0.055,0.065,0.050,1], metallic:0.02, roughness:0.58, variation:0.46, wear:0.26, normalStrength:0.52, textureResolution:512, tileable:true },
  'wing-membrane': { style:'membrane', baseColor:[0.17,0.055,0.045,1], metallic:0, roughness:0.72, variation:0.36, wear:0.35, normalStrength:0.24, textureResolution:512, tileable:true },
  'horn-and-claw': { style:'bone', baseColor:[0.21,0.17,0.105,1], metallic:0, roughness:0.64, variation:0.28, wear:0.30, normalStrength:0.20, textureResolution:512, tileable:true },
  'coarse-fur': { style:'fur', baseColor:[0.17,0.12,0.08,1], metallic:0, roughness:0.82, variation:0.58, wear:0.18, normalStrength:0.46, textureResolution:512, tileable:true },
  'dark-chitin': { style:'chitin', baseColor:[0.07,0.05,0.038,1], metallic:0.04, roughness:0.46, variation:0.38, wear:0.16, normalStrength:0.40, textureResolution:512, tileable:true }
});

function clamp(v,min=0,max=1){return Math.max(min,Math.min(max,Number(v)))}
function colourScale(c,f){return [clamp(c[0]*f),clamp(c[1]*f),clamp(c[2]*f),c[3]??1]}
function findMaterial(recipe,name){if(!recipe?.materials?.length)throw new Error('This asset has no editable material definitions.');if(name){const exact=recipe.materials.find(m=>m.name===name);if(exact)return exact;}return recipe.materials[0];}
function presetFromText(text,material){const s=text.toLowerCase();if(/scale|scaled hide|dragon skin/.test(s))return PRESETS['dragon-scales'];if(/wing membrane|leathery wing/.test(s))return PRESETS['wing-membrane'];if(/horn|claw|keratin|bone/.test(s))return PRESETS['horn-and-claw'];if(/fur|furry/.test(s))return PRESETS['coarse-fur'];if(/chitin|carapace|exoskeleton/.test(s))return PRESETS['dark-chitin'];if(/rust|corrod/.test(s))return PRESETS['rusted-iron'];if(/brush(ed)?\s*(steel|metal)|stainless/.test(s))return PRESETS['brushed-steel'];if(/moss/.test(s))return PRESETS['mossy-stone'];if(/ceramic|porcelain/.test(s))return PRESETS.ceramic;if(/leather/.test(s))return PRESETS.leather;if(/paint(ed)?\s*(metal|iron|steel)/.test(s))return PRESETS['painted-metal'];if(/fresh|new\s+wood|clean\s+wood/.test(s))return PRESETS['fresh-oak'];if(/old|aged|weathered/.test(s)&&/wood|oak|timber/.test(s))return PRESETS['aged-oak'];if(/stone|rock/.test(s))return PRESETS['weathered-stone'];if(/iron|metal|steel/.test(s))return material?.metallic>0.5?PRESETS['worn-iron']:PRESETS['brushed-steel'];if(/wood|oak|timber/.test(s))return PRESETS['aged-oak'];return null;}
function change(changes,path,before,after){if(JSON.stringify(before)!==JSON.stringify(after))changes.push({path,before,after});}

export function materialPresets(){return Object.entries(PRESETS).map(([id,spec])=>({id,label:id.split('-').map(w=>w[0].toUpperCase()+w.slice(1)).join(' '),...spec}));}

export function planMaterialGeneration(recipeInput,request,{materialName=null,preset=null,resolution=null}={}){
  const recipe=structuredClone(validateRecipe(recipeInput));
  const material=findMaterial(recipe,materialName);
  const index=recipe.materials.findIndex(m=>m.name===material.name);
  const before=structuredClone(material);
  const text=String(request??'').trim().slice(0,1000);
  if(!text&&!preset)throw new Error('Describe the material you want or choose a material preset.');
  const selected=(preset&&PRESETS[preset])||presetFromText(text,material);
  if(selected)Object.assign(material,structuredClone(selected));
  const s=text.toLowerCase();
  if(/lighter|brighter/.test(s))material.baseColor=colourScale(material.baseColor,1.22);
  if(/darker/.test(s))material.baseColor=colourScale(material.baseColor,.78);
  if(/rougher|matte|matt\b/.test(s))material.roughness=clamp(material.roughness+.16);
  if(/smoother|polished|gloss/.test(s))material.roughness=clamp(material.roughness-.18);
  if(/more\s+metallic/.test(s))material.metallic=clamp(material.metallic+.2);
  if(/less\s+metallic/.test(s))material.metallic=clamp(material.metallic-.2);
  if(/more\s+(?:wear|worn)|heavily\s+worn|damaged/.test(s))material.wear=clamp((material.wear??.2)+.22);
  if(/cleaner|less\s+worn|newer/.test(s))material.wear=clamp((material.wear??.2)-.22);
  if(/more\s+variation|varied|patchy/.test(s))material.variation=clamp((material.variation??.25)+.2);
  if(/less\s+variation|uniform/.test(s))material.variation=clamp((material.variation??.25)-.2);
  const rough=s.match(/roughness\s*(?:to|=)?\s*(0(?:\.\d+)?|1(?:\.0+)?)/);if(rough)material.roughness=clamp(Number(rough[1]));
  const metal=s.match(/metallic\s*(?:to|=)?\s*(0(?:\.\d+)?|1(?:\.0+)?)/);if(metal)material.metallic=clamp(Number(metal[1]));
  const normal=s.match(/normal(?:\s+strength)?\s*(?:to|=)?\s*(0(?:\.\d+)?|1(?:\.0+)?)/);if(normal)material.normalStrength=clamp(Number(normal[1]));
  const res=Number(resolution);if([256,512,1024].includes(res))material.textureResolution=res;
  material.pbrGenerate=true;material.tileable=material.tileable!==false;
  recipe.materials[index]=material;
  const checked=validateRecipe(recipe);
  const after=checked.materials[index];const changes=[];
  for(const key of ['style','baseColor','metallic','roughness','variation','wear','normalStrength','textureResolution','tileable','pbrGenerate'])change(changes,`materials.${after.name}.${key}`,before[key],after[key]);
  if(!changes.length)throw new Error('Forge could not find an allow-listed material change in that request. Try “aged oak”, “rusted iron”, “make it rougher”, or choose a preset.');
  return {schema:'nexu.forge.material-plan.v1',request:text||`Preset: ${preset}`,materialName:after.name,preset:preset||null,recipe:checked,changes,summary:`${after.name}: ${after.style}, roughness ${after.roughness.toFixed(2)}, metallic ${after.metallic.toFixed(2)}, ${after.textureResolution}px PBR set`};
}
