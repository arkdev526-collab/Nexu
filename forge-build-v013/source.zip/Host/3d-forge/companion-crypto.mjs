import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';

const WINDOW_MS = 5 * 60 * 1000;
const B64URL = /^[A-Za-z0-9_-]+$/;

function b64url(buffer){ return Buffer.from(buffer).toString('base64url'); }
function fromB64url(value,label='value'){
  if(typeof value!=='string'||!value||!B64URL.test(value)) throw new Error(`Invalid ${label}.`);
  return Buffer.from(value,'base64url');
}
function derivePairingKey(secretCode){
  const normalized=String(secretCode??'').toUpperCase().replace(/[^A-Z2-9]/g,'');
  if(normalized.length!==16) throw new Error('Pairing code secret must contain 16 characters.');
  return createHash('sha256').update(`nexu-forge-pair-v1:${normalized}`,'utf8').digest();
}
function validateKey(key){ const b=Buffer.from(key); if(b.length!==32) throw new Error('Companion key must be 32 bytes.'); return b; }
function aad(context,envelope){ return Buffer.from(`${context}|${envelope.v}|${envelope.ts}|${envelope.nonce}`,'utf8'); }

function seal(key,payload,context,{now=Date.now()}={}){
  key=validateKey(key);
  const envelope={v:1,ts:now,nonce:b64url(randomBytes(16)),iv:b64url(randomBytes(12))};
  const cipher=createCipheriv('aes-256-gcm',key,fromB64url(envelope.iv,'IV'));
  cipher.setAAD(aad(context,envelope));
  const plaintext=Buffer.from(JSON.stringify(payload),'utf8');
  const ciphertext=Buffer.concat([cipher.update(plaintext),cipher.final()]);
  return {...envelope,ciphertext:b64url(ciphertext),tag:b64url(cipher.getAuthTag())};
}
function open(key,envelope,context,{now=Date.now(),windowMs=WINDOW_MS,nonceCache=null}={}){
  key=validateKey(key);
  if(!envelope||envelope.v!==1||!Number.isFinite(Number(envelope.ts))) throw new Error('Invalid companion envelope.');
  const ts=Number(envelope.ts); if(Math.abs(now-ts)>windowMs) throw new Error('Companion message expired.');
  const nonce=String(envelope.nonce??''); fromB64url(nonce,'nonce');
  if(nonceCache){ if(nonceCache.has(nonce)) throw new Error('Replay rejected.'); nonceCache.add(nonce); if(nonceCache.size>500){ const first=nonceCache.values().next().value; nonceCache.delete(first); } }
  const iv=fromB64url(envelope.iv,'IV'),tag=fromB64url(envelope.tag,'tag'),ciphertext=fromB64url(envelope.ciphertext,'ciphertext');
  if(iv.length!==12||tag.length!==16) throw new Error('Invalid companion cryptographic envelope.');
  const decipher=createDecipheriv('aes-256-gcm',key,iv); decipher.setAAD(aad(context,envelope)); decipher.setAuthTag(tag);
  const plaintext=Buffer.concat([decipher.update(ciphertext),decipher.final()]).toString('utf8');
  try{return JSON.parse(plaintext);}catch{throw new Error('Companion payload is not valid JSON.');}
}
function generateDeviceSecret(){ return randomBytes(32); }

export { WINDOW_MS, b64url, fromB64url, derivePairingKey, seal, open, generateDeviceSecret };
