#!/usr/bin/env node
import { pairingQr } from './pairing-qr.mjs';
import { ScreenShare } from './screen-share.mjs';
import http from 'node:http';
import { createReadStream, unlinkSync } from 'node:fs';
import { access, cp, mkdir, readFile, readdir, rename, stat, writeFile, unlink } from 'node:fs/promises';
import { constants } from 'node:fs';
import { randomBytes, randomUUID } from 'node:crypto';
import { basename, dirname, extname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { planPrompt } from './planner.mjs';
import { validateRecipe } from './schema.mjs';
import { interpretBrief } from './brief.mjs';
import { planRefinement } from './refine.mjs';
import { materialPresets, planMaterialGeneration } from './material-intelligence.mjs';
import { providerCatalogue } from './reference-providers.mjs';
import { grammarCatalogue } from './asset-grammar.mjs';
import { creationKnowledgeSummary } from './creation-intelligence.mjs';
import { compileCreationPrompt, promptVocabularySummary } from './prompt-intelligence.mjs';
import { CompactBuildCache } from './compact-cache.mjs';
import { LearningLedger } from './learning-ledger.mjs';
import { applyReferenceGuidance } from './reference-guidance.mjs';
import { blenderVersion, findBlender, isSupportedBlenderVersion, runBlender } from './blender.mjs';
import { inspectOutput } from './qa.mjs';
import { downloadVerifiedSetup, fetchUpdateManifest, installedVersions, launchRollback, launchVerifiedInstaller, readFixtureManifest } from './update-client.mjs';
import { createCompanionService } from './companion-server.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const studioRoot = join(here, 'studio');
const dataRoot = resolve(process.env.NEXU_FORGE_DATA_DIR?.trim() || join(here, 'data'));
const outputRoot = join(dataRoot, 'Assets');
const projectRoot = join(dataRoot, 'Projects');
const referenceRoot = join(projectRoot, 'References');
const trashRoot = join(dataRoot, 'Recovery', 'Trash');
const logsRoot = join(dataRoot, 'Logs');
const runtimeRoot = join(dataRoot, '.runtime');
const learningRoot = join(dataRoot, 'Learning');
const cacheRoot = join(dataRoot, 'Cache');
const learning = new LearningLedger(learningRoot);
const buildCache = new CompactBuildCache(cacheRoot, outputRoot, { maxEntries: 96 });
const sessionPath = join(runtimeRoot, '.studio-session.json');
const appVersion = '0.13.0';
const host = '127.0.0.1';
const maxJsonBytes = 128 * 1024;
const maxReferenceBytes = 12 * 1024 * 1024;
const jobs = new Map();
const queue = [];
let activeJobId = null;
let shuttingDown = false;

function argValue(flag, fallback=null){ const i=process.argv.indexOf(flag); return i>=0&&i+1<process.argv.length?process.argv[i+1]:fallback; }
function sendJson(res,status,value,extra={}){ const body=JSON.stringify(value); res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...extra}); res.end(body); }
function sendText(res,status,body,type='text/plain; charset=utf-8',extra={}){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...extra});res.end(body);}
function securityHeaders(){return{
  'Content-Security-Policy':"default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; connect-src 'self'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Cross-Origin-Resource-Policy':'same-origin',
  'Permissions-Policy':'camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=()'
};}
function cookies(req){const out={};for(const p of String(req.headers.cookie??'').split(';')){const i=p.indexOf('=');if(i>0)out[p.slice(0,i).trim()]=p.slice(i+1).trim();}return out;}
function sameOrigin(req,port){const origin=req.headers.origin;return !origin||origin===`http://${host}:${port}`;}
function safePrompt(v){if(typeof v!=='string')throw new Error('Prompt must be text.');const p=v.trim();if(!p)throw new Error('Describe the model you want to create.');if(p.length>2000)throw new Error('Prompt is limited to 2,000 characters.');return p;}
function safeProfile(v){return v==='unreal-asa'?'unreal-asa':'generic';}
function safeGenerationMode(v){return v==='fast'||v==='quality'?v:'balanced';}
function safeText(v,max=80){return String(v??'').replace(/[\u0000-\u001f<>]/g,'').trim().slice(0,max);}
function buildStamp(){const d=new Date(),p=n=>String(n).padStart(2,'0');return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;}
function encodeId(rel){return Buffer.from(rel).toString('base64url');}
function decodeId(id){try{return Buffer.from(id,'base64url').toString('utf8');}catch{throw new Error('Invalid asset identifier.');}}

async function readJson(req,limit=maxJsonBytes){return new Promise((ok,fail)=>{let size=0,body='';req.setEncoding('utf8');req.on('data',c=>{size+=Buffer.byteLength(c);if(size>limit){fail(new Error('Request body is too large.'));req.destroy();return;}body+=c;});req.on('end',()=>{if(!body.trim())return ok({});try{ok(JSON.parse(body));}catch{fail(new Error('Invalid JSON request.'));}});req.on('error',fail);});}
async function readBinary(req,max=maxReferenceBytes){return new Promise((ok,fail)=>{let size=0;const chunks=[];req.on('data',c=>{size+=c.length;if(size>max){fail(new Error('Reference image exceeds the 12 MB limit.'));req.destroy();return;}chunks.push(c);});req.on('end',()=>ok(Buffer.concat(chunks)));req.on('error',fail);});}
function resolveWithin(root,rel,label='Path'){if(typeof rel!=='string'||!rel.trim())throw new Error(`${label} is required.`);const target=resolve(root,rel);const prefix=root.endsWith(sep)?root:root+sep;if(target!==root&&!target.startsWith(prefix))throw new Error(`${label} is outside the allowed Forge directory.`);return target;}
function resolveOutputRelative(rel){return resolveWithin(outputRoot,rel,'Output path');}
function fileUrl(abs){const rel=relative(outputRoot,abs).split(sep).join('/');return `/asset-file?path=${encodeURIComponent(rel)}`;}

const STAGE_ORDER=['Queued','Preparing','Cache reuse','Materials','Texturing','Modelling','Collision','Validation','Dataset','Exporting','READY','READY WITH WARNINGS','BLOCKED'];
function stageProgress(job){if(job.status==='failed'||job.status==='cancelled')return {index:0,total:8,percent:0,label:job.stage};if(job.status.startsWith('completed'))return {index:8,total:8,percent:100,label:job.stage};const map={Queued:0,Preparing:1,'Cache reuse':7,Materials:2,Texturing:3,Modelling:4,Collision:5,Validation:6,Dataset:7,Exporting:8};const index=map[job.stage]??0;return {index,total:8,percent:Math.round(index/8*100),label:job.stage};}
function publicJob(job){return {id:job.id,prompt:job.prompt,assetName:job.recipe?.assetName??null,profile:job.profile,generationMode:job.recipe?.quality?.generationMode??'balanced',cacheHit:Boolean(job.cacheHit),cacheSource:job.cacheSource??null,status:job.status,stage:job.stage,progress:stageProgress(job),createdAt:job.createdAt,startedAt:job.startedAt??null,finishedAt:job.finishedAt??null,outputRelative:job.outputRelative??null,parentDirectory:job.parentDirectory??null,refinement:job.refinement??null,materialGeneration:job.materialGeneration??null,report:job.report??null,inspection:job.inspection??null,error:job.error??null,logTail:job.logTail.slice(-12),queuePosition:job.status==='queued'?Math.max(1,queue.indexOf(job.id)+1):0};}
async function writeStudioJob(job){await mkdir(logsRoot,{recursive:true});await writeFile(join(logsRoot,`studio-job-${job.id}.json`),JSON.stringify(publicJob(job),null,2),'utf8');}
function record(job,line){const clean=String(line).replace(/\x1B\[[0-?]*[ -\/]*[@-~]/g,'').trim();if(!clean)return;job.logTail.push(clean.slice(0,600));if(job.logTail.length>120)job.logTail.splice(0,job.logTail.length-120);const stage=clean.match(/NEXU3D_STAGE\s+(materials|texturing|modelling|collision|validation|dataset|exporting)/i)?.[1]?.toLowerCase();if(stage)job.stage={materials:'Materials',texturing:'Texturing',modelling:'Modelling',collision:'Collision',validation:'Validation',dataset:'Dataset',exporting:'Exporting'}[stage];}

async function writeVersionMeta(job){const meta={schema:'nexu.forge.version.v1',assetName:job.recipe.assetName,versionId:job.id,createdAt:job.createdAt,finishedAt:job.finishedAt,parentDirectory:job.parentDirectory??null,sourcePrompt:job.prompt,refinement:job.refinement??null,materialGeneration:job.materialGeneration??null,referenceGuidance:job.referenceGuidance??null};await writeFile(join(job.outputDir,'.forge-version.json'),JSON.stringify(meta,null,2),'utf8');}
async function processJob(job){activeJobId=job.id;job.status='running';job.stage='Preparing';job.startedAt=new Date().toISOString();await writeStudioJob(job);const controller=new AbortController();job.controller=controller;try{const cached=await buildCache.lookup(job.recipe);if(cached){job.cacheHit=true;job.cacheSource=cached.outputRelative;job.outputRelative=cached.outputRelative;job.outputDir=resolveOutputRelative(cached.outputRelative);job.stage='Cache reuse';record(job,`FastForge: exact validated recipe reused from ${cached.outputRelative}`);job.report=await readOptional(join(job.outputDir,'validation.json'),{});job.inspection=await inspectOutput(job.outputDir);job.status=job.inspection.status==='blocked'?'completed-blocked':job.inspection.status==='ready-with-warnings'?'completed-with-warnings':'completed';job.stage=job.inspection.label;record(job,`FastForge cache hit · Blender generation skipped · ${job.inspection.label}`);}else{const result=await runBlender(job.recipe,job.outputDir,{signal:controller.signal,onOutput:(k,t)=>record(job,`${k==='stderr'?'Blender':'Worker'}: ${t}`)});job.stage='Validation';job.report=result.report;job.inspection=await inspectOutput(job.outputDir);job.status=job.inspection.status==='blocked'?'completed-blocked':job.inspection.status==='ready-with-warnings'?'completed-with-warnings':'completed';job.stage=job.inspection.label;record(job,`Quality: ${result.report.qualityScore}/100 ${job.inspection.label}`);if(job.status.startsWith('completed'))await buildCache.register(job.recipe,job.outputRelative);}}catch(error){if(controller.signal.aborted){job.status='cancelled';job.stage='Cancelled';job.error='Build cancelled by user.';}else{job.status='failed';job.stage='Failed';job.error=error?.message??String(error);record(job,job.error);}}finally{job.finishedAt=new Date().toISOString();delete job.controller;if(job.status.startsWith('completed')&&!job.cacheHit)await writeVersionMeta(job);await writeStudioJob(job);activeJobId=null;setTimeout(pumpQueue,0);}}
async function pumpQueue(){if(activeJobId||shuttingDown)return;while(queue.length){const id=queue.shift(),job=jobs.get(id);if(!job||job.status!=='queued')continue;await processJob(job);return;}}
function queueRecipe(recipe,prompt,profile,{parentDirectory=null,refinement=null,materialGeneration=null,referenceGuidance=null}={}){const id=`${buildStamp()}-${randomUUID().slice(0,8)}`;const rel=`${recipe.assetName}/${id}`;const job={id,prompt,profile,recipe,status:'queued',stage:'Queued',createdAt:new Date().toISOString(),outputRelative:rel,outputDir:resolveOutputRelative(rel),parentDirectory,refinement,materialGeneration,referenceGuidance,logTail:[]};jobs.set(id,job);queue.push(id);setTimeout(pumpQueue,0);return job;}

async function walkNamed(dir,name,depth=0,found=[]){if(depth>6)return found;let entries=[];try{entries=await readdir(dir,{withFileTypes:true});}catch{return found;}for(const e of entries){const p=join(dir,e.name);if(e.isDirectory())await walkNamed(p,name,depth+1,found);else if(e.isFile()&&e.name===name)found.push(p);}return found;}
async function readOptional(path,fallback=null){try{return JSON.parse(await readFile(path,'utf8'));}catch{return fallback;}}
async function findRecipe(dir){const jobDir=join(dir,'.nexu3d');const entries=await readdir(jobDir);const name=entries.find(x=>x.toLowerCase().endsWith('.n3d.json'));if(!name)throw new Error('Nexu3D source recipe is missing for this asset version.');return JSON.parse(await readFile(join(jobDir,name),'utf8'));}
async function recordLearningFeedback(directory,choice,note='',source='desktop'){const dir=resolveOutputRelative(directory),recipe=await findRecipe(dir),report=JSON.parse(await readFile(join(dir,'validation.json'),'utf8'));return learning.add({directory,report,recipe,verdict:choice,note,source});}
function hasExplicitTriangleTarget(prompt){return /\b\d[\d,]*\s*(?:triangles|tris|polygons|polys)\b/i.test(String(prompt));}
function creatureCue(prompt,key){const p=String(prompt).toLowerCase();return ({bodyBulk:/slender|lean|thin|heavy|bulky|massive|armou?red/,neckRatio:/long neck|short neck/,tailRatio:/long tail|short tail|tailless|no tail/,wingSpanRatio:/small wings|large wings|huge wings|massive wings|enormous wings/,hornScale:/hornless|no horns?|small horns?|large horns?|huge horns?/,dorsalSpikes:/spikeless|no spikes|many spikes|spiny/}[key]??/$^/).test(p);}
async function applyLearnedDefaults(recipe,prompt){
  const suggestion=await learning.suggestion(recipe.grammarId);const changes=[];let next=structuredClone(recipe);
  if(suggestion.applyAutomatically&&!hasExplicitTriangleTarget(prompt)){
    const base=next.targetTriangles,recommended=Math.max(12,Math.min(2_000_000,Number(suggestion.recommendedTargetTriangles))),bounded=Math.round(Math.max(base*0.65,Math.min(base*1.55,recommended)));
    if(bounded!==base){next.targetTriangles=bounded;changes.push({path:'targetTriangles',before:base,after:bounded,reason:'local accepted-result median'});}
  }
  const part=next.parts?.find?.(x=>x.type==='procedural_creature'),m=suggestion.recommendedMorphology;
  if(part&&m&&suggestion.goodCount>=2){
    const d=part.details,L=d.bodyLength;
    const candidates={bodyBulk:Math.max(.7,Math.min(1.35,Number(m.bodyBulk))),neckRatio:Math.max(.05,Math.min(.5,Number(m.neckRatio))),tailRatio:Math.max(0,Math.min(.9,Number(m.tailRatio))),wingSpanRatio:Math.max(0,Math.min(1.9,Number(m.wingSpanRatio))),hornScale:Math.max(0,Math.min(.9,Number(m.hornScale))),dorsalSpikes:Math.max(0,Math.min(20,Math.round(Number(m.dorsalSpikes))))};
    for(const [key,val] of Object.entries(candidates)){
      if(!Number.isFinite(val)||creatureCue(prompt,key))continue;
      const prop=key==='neckRatio'?'neckLength':key==='tailRatio'?'tailLength':key==='wingSpanRatio'?'wingSpan':key;const after=['neckRatio','tailRatio','wingSpanRatio'].includes(key)?val*L:val,before=d[prop];
      if(Math.abs(Number(before)-Number(after))>1e-6){d[prop]=after;changes.push({path:`creature.${prop}`,before,after,reason:'bounded local accepted-creature median'});}
    }
  }
  return{recipe:validateRecipe(next),suggestion,changes};
}
async function planWithLearning(prompt,profile,referenceEvidence,generationMode='balanced'){const mode=safeGenerationMode(generationMode),base=planPrompt(prompt,{profile,generationMode:mode}),learned=await applyLearnedDefaults(base,prompt),guided=applyReferenceGuidance(learned.recipe,referenceEvidence);return{recipe:guided.recipe,understanding:compileCreationPrompt(prompt),generationMode:mode,referenceGuidance:guided.evidence,referenceChanges:guided.changes,learningSuggestion:learned.suggestion,learningChanges:learned.changes};}
async function assetMeta(dir){return await readOptional(join(dir,'.forge-meta.json'),{displayName:null,tags:[],favourite:false});}
async function saveAssetMeta(dir,input){const old=await assetMeta(dir);const meta={displayName:safeText(input.displayName??old.displayName,80)||null,tags:Array.isArray(input.tags)?[...new Set(input.tags.map(x=>safeText(x,30)).filter(Boolean))].slice(0,12):old.tags,favourite:typeof input.favourite==='boolean'?input.favourite:Boolean(old.favourite)};await writeFile(join(dir,'.forge-meta.json'),JSON.stringify(meta,null,2),'utf8');return meta;}

async function listAssets(){
  await mkdir(outputRoot,{recursive:true});
  const validations=await walkNamed(outputRoot,'validation.json');
  const assets=[];
  for(const validationPath of validations){
    try{
      const report=JSON.parse(await readFile(validationPath,'utf8'));
      const dir=dirname(validationPath),s=await stat(validationPath),version=await readOptional(join(dir,'.forge-version.json'),{}),meta=await assetMeta(dir),inspection=await inspectOutput(dir),recipe=await findRecipe(dir);
      const previewCandidates=['Preview/perspective.png','preview/perspective.png',...(report.previewOutputs??[])];let preview=null;
      for(const candidate of previewCandidates){const p=join(dir,candidate);try{await access(p,constants.R_OK);preview=fileUrl(p);break;}catch{}}
      const relDir=relative(outputRoot,dir).split(sep).join('/'),glb=(report.outputs??[]).find(x=>x.toLowerCase().endsWith('.glb')&&!x.includes('_COLLISION'))??null,collisionGlb=report.collisionGlb??(report.outputs??[]).find(x=>x.includes('_COLLISION')&&x.endsWith('.glb'))??null;
      assets.push({
        id:encodeId(relDir),directory:relDir,assetName:report.assetName??relDir.split('/').at(-2)??relDir,displayName:meta.displayName,profile:report.profile??'generic',assetClass:report.assetClass??recipe.assetClass??'GenericProp',grammarId:report.grammarId??recipe.grammarId??'generic-prop',datasetRecord:report.datasetRecord??null,datasetOutputs:report.datasetOutputs??[],meshRepair:report.meshRepair??null,
        triangles:report.triangles??0,vertices:report.geometryDiagnostics?.vertices??null,targetTriangles:report.targetTriangles??0,qualityScore:report.qualityScore??null,qualityStatus:report.qualityStatus??null,qaLabel:inspection.label,
        validationChecks:inspection.checks??[],diagnostics:report.geometryDiagnostics??{},qualityChecks:report.qualityChecks??[],generatedObjectCount:report.generatedObjectCount??0,materialCount:report.materialCount??null,uvRequested:report.uvRequested===true,
        collisionCreated:report.collisionCreated===true,collisionKind:report.collisionKind??null,lodCount:Array.isArray(report.lodOutputs)?report.lodOutputs.length:0,
        modifiedAt:s.mtime.toISOString(),createdAt:version.createdAt??s.birthtime.toISOString(),parentDirectory:version.parentDirectory??null,refinement:version.refinement??null,sourcePrompt:version.sourcePrompt??null,
        tags:meta.tags??[],favourite:Boolean(meta.favourite),materials:recipe.materials??[],materialOutputs:(report.materialOutputs??[]).map(x=>({name:x,url:fileUrl(join(dir,x))})),preview,glbUrl:glb?fileUrl(join(dir,glb)):null,collisionGlbUrl:collisionGlb?fileUrl(join(dir,collisionGlb)):null,
        lods:(report.lodDetails??[]).map((x,i)=>({level:i+1,triangles:x.triangles,file:x.file,glbUrl:x.glbFile?fileUrl(join(dir,x.glbFile)):null})),
        previewUrls:(report.previewOutputs??[]).filter(x=>x.toLowerCase().endsWith('.png')).map(x=>({name:x,url:fileUrl(join(dir,x))})),
        outputs:[...(report.outputs??[]),...(report.lodOutputs??[])].map(x=>({name:x,url:fileUrl(join(dir,x))}))
      });
    }catch{}
  }
  assets.sort((a,b)=>b.modifiedAt.localeCompare(a.modifiedAt));return assets;
}

function detectImage(buffer,type){if(type==='image/png'&&buffer.length>8&&buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return '.png';if((type==='image/jpeg'||type==='image/jpg')&&buffer[0]===0xff&&buffer[1]===0xd8)return '.jpg';if(type==='image/webp'&&buffer.length>12&&buffer.subarray(0,4).toString()==='RIFF'&&buffer.subarray(8,12).toString()==='WEBP')return '.webp';throw new Error('Reference must be a valid PNG, JPEG or WebP image.');}
async function saveReferenceBuffer(data,type,fileName='reference',viewName='reference'){const ext=detectImage(data,String(type??'').split(';')[0].toLowerCase());await mkdir(referenceRoot,{recursive:true});const view=safeText(viewName,20).toLowerCase().replace(/[^a-z0-9_-]/g,'')||'reference';let decodedName=String(fileName??'reference');try{decodedName=decodeURIComponent(decodedName);}catch{}const original=safeText(decodedName,80).replace(/\.[^.]+$/,'');const file=`${buildStamp()}-${randomUUID().slice(0,8)}-${(original||'reference').replace(/[^A-Za-z0-9_-]/g,'_')}${ext}`;const path=join(referenceRoot,file);await writeFile(path,data);return {id:encodeId(file),name:file,view,size:data.length,url:`/reference-file?id=${encodeURIComponent(encodeId(file))}`};}
async function saveReference(req){const type=String(req.headers['content-type']??'').split(';')[0].toLowerCase();const data=await readBinary(req);return saveReferenceBuffer(data,type,req.headers['x-file-name']??'reference',req.headers['x-reference-view']??'reference');}

async function openExternal(target,type='folder'){if(process.platform!=='win32')throw new Error('This action is available on the Windows target build.');if(type==='folder'){const c=spawn('explorer.exe',[target],{detached:true,stdio:'ignore',windowsHide:false,shell:false});c.unref();return;}const blender=await findBlender();const c=spawn(blender,[target],{detached:true,stdio:'ignore',windowsHide:true,shell:false});c.unref();}
async function launchBrowser(url){if(process.argv.includes('--no-open'))return;if(process.platform!=='win32'){console.log(`Open ${url}`);return;}const candidates=[join(process.env['ProgramFiles(x86)']??'','Microsoft','Edge','Application','msedge.exe'),join(process.env.ProgramFiles??'','Microsoft','Edge','Application','msedge.exe'),join(process.env.LOCALAPPDATA??'','Microsoft','Edge','Application','msedge.exe')].filter(Boolean);for(const candidate of candidates){try{await access(candidate,constants.X_OK);const c=spawn(candidate,[`--app=${url}`,'--start-maximized'],{detached:true,stdio:'ignore',windowsHide:true,shell:false});c.unref();return;}catch{}}const c=spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{detached:true,stdio:'ignore',windowsHide:true,shell:false});c.unref();}

async function serveStudioFile(res,path,headers){const allowed=new Map([['/studio/screen.js',['screen.js','text/javascript; charset=utf-8']],['/studio/app.js',['app.js','text/javascript; charset=utf-8']],['/studio/viewport.js',['viewport.js','text/javascript; charset=utf-8']],['/studio/styles.css',['styles.css','text/css; charset=utf-8']],['/studio/app-icon.png',['app-icon.png','image/png']]]);const item=allowed.get(path);if(!item)return false;const file=join(studioRoot,item[0]);let s;try{s=await stat(file);}catch{return false;}res.writeHead(200,{'Content-Type':item[1],'Content-Length':s.size,'Cache-Control':'no-store',...headers});createReadStream(file).pipe(res);return true;}

async function createServer(){for(const p of [outputRoot,projectRoot,referenceRoot,trashRoot,logsRoot,runtimeRoot,learningRoot,cacheRoot])await mkdir(p,{recursive:true});const token=argValue('--token',randomBytes(32).toString('hex'));const requestedPort=Number(argValue('--port','0'))||0;const ui=await readFile(join(studioRoot,'index.html'),'utf8');let actualPort=0;
 const screenShare=new ScreenShare();
 const companion=await createCompanionService({version:appVersion,runtimeRoot,handlers:{
   'screen.frame':async(p,context)=>screenShare.read(context.deviceId,p.afterSequence,p.sessionId),
   'status':async()=>({app:'Nexu AI 3D Forge',version:appVersion,queue:{running:activeJobId?1:0,waiting:queue.length},localWorker:true}),
   'brief':async p=>{const prompt=safePrompt(p.prompt);return{brief:interpretBrief(prompt,safeProfile(p.profile)),understanding:compileCreationPrompt(prompt)};},
   'plan':async p=>{const prompt=safePrompt(p.prompt),profile=safeProfile(p.profile),guided=await planWithLearning(prompt,profile,p.referenceEvidence,p.generationMode);return{brief:interpretBrief(prompt,profile),...guided};},
   'build':async p=>{const prompt=safePrompt(p.prompt),profile=safeProfile(p.profile),guided=await planWithLearning(prompt,profile,p.referenceEvidence,p.generationMode),job=queueRecipe(guided.recipe,prompt,profile,{referenceGuidance:guided.referenceGuidance});await writeStudioJob(job);return{job:publicJob(job),learningChanges:guided.learningChanges};},
   'refine.plan':async p=>{const dir=resolveOutputRelative(p.directory),recipe=await findRecipe(dir);return{plan:planRefinement(recipe,safeText(p.request,1000))};},
   'refine.apply':async p=>{const parent=safeText(p.directory,300),dir=resolveOutputRelative(parent),recipe=await findRecipe(dir),plan=planRefinement(recipe,safeText(p.request,1000)),job=queueRecipe(plan.recipe,recipe.sourcePrompt||'Refined asset',recipe.profile,{parentDirectory:parent,refinement:{request:plan.request,changes:plan.changes}});await writeStudioJob(job);return{plan,job:publicJob(job)};},
   'material.presets':async()=>({presets:materialPresets()}),
   'material.plan':async p=>{const dir=resolveOutputRelative(p.directory),recipe=await findRecipe(dir);return{plan:planMaterialGeneration(recipe,safeText(p.request,1000),{materialName:safeText(p.materialName,80)||null,preset:safeText(p.preset,60)||null,resolution:Number(p.resolution)||null})};},
   'material.apply':async p=>{const parent=safeText(p.directory,300),dir=resolveOutputRelative(parent),recipe=await findRecipe(dir),plan=planMaterialGeneration(recipe,safeText(p.request,1000),{materialName:safeText(p.materialName,80)||null,preset:safeText(p.preset,60)||null,resolution:Number(p.resolution)||null}),job=queueRecipe(plan.recipe,recipe.sourcePrompt||'Material variant',recipe.profile,{parentDirectory:parent,materialGeneration:{request:plan.request,materialName:plan.materialName,changes:plan.changes}});await writeStudioJob(job);return{plan,job:publicJob(job)};},
   'grammar.catalogue':async()=>({grammars:grammarCatalogue(),vocabulary:promptVocabularySummary()}),
   'learning.stats':async()=>({stats:await learning.stats()}),
   'learning.feedback':async p=>({feedback:await recordLearningFeedback(safeText(p.directory,300),String(p.verdict??''),safeText(p.note,500),'android')}),
   'jobs':async()=>({jobs:[...jobs.values()].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,50).map(publicJob),activeJobId,queued:queue.length}),
   'job.get':async p=>{const job=jobs.get(String(p.id??''));if(!job)throw new Error('Build job not found.');return{job:publicJob(job)};},
   'job.cancel':async p=>{const job=jobs.get(String(p.id??''));if(!job)throw new Error('Build job not found.');if(job.status==='queued'){job.status='cancelled';job.stage='Cancelled';job.finishedAt=new Date().toISOString();await writeStudioJob(job);}else if(job.status==='running'&&job.controller)job.controller.abort();return{job:publicJob(job)};},
   'assets':async()=>({assets:(await listAssets()).map(a=>({id:a.id,directory:a.directory,assetName:a.assetName,displayName:a.displayName,profile:a.profile,assetClass:a.assetClass,grammarId:a.grammarId,datasetRecord:a.datasetRecord,triangles:a.triangles,vertices:a.vertices,targetTriangles:a.targetTriangles,qualityScore:a.qualityScore,qaLabel:a.qaLabel,collisionCreated:a.collisionCreated,lodCount:a.lodCount,modifiedAt:a.modifiedAt,createdAt:a.createdAt,parentDirectory:a.parentDirectory,tags:a.tags,favourite:a.favourite,materials:a.materials,lods:a.lods.map(x=>({level:x.level,triangles:x.triangles,file:x.file}))}))}),
   'asset.glb':async p=>{const dir=resolveOutputRelative(p.directory),entries=await readdir(dir),level=Math.max(0,Number(p.lod)||0);let file;if(p.collision===true)file=entries.find(x=>/_COLLISION\.glb$/i.test(x));else if(level>0)file=entries.find(x=>new RegExp(`_LOD${level}\\.glb$`,'i').test(x));else file=entries.find(x=>x.toLowerCase().endsWith('.glb')&&!/_lod\d+\.glb$/i.test(x)&&!/collision/i.test(x));if(!file)throw new Error('Requested GLB is not available for this asset version.');const data=await readFile(join(dir,file));if(data.length>32*1024*1024)throw new Error('GLB exceeds the 32 MB Android transfer limit.');return{file,size:data.length,mime:'model/gltf-binary',base64:data.toString('base64')};},
   'reference.upload':async p=>{const data=Buffer.from(String(p.base64??''),'base64');if(!data.length||data.length>12*1024*1024)throw new Error('Reference image must be between 1 byte and 12 MB.');return{reference:await saveReferenceBuffer(data,p.mime,p.fileName,p.view)};}
 }});
 const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url??'/',`http://${host}:${actualPort||requestedPort||80}`),headers=securityHeaders();const authenticated=cookies(req).nexu_session===token;
   if(url.pathname==='/health')return sendJson(res,200,{ok:true,app:'Nexu AI 3D Forge',version:appVersion},headers);
   if(url.pathname==='/'&&req.method==='GET'){if(!authenticated&&url.searchParams.get('token')===token){res.writeHead(302,{Location:'/','Set-Cookie':`nexu_session=${token}; HttpOnly; SameSite=Strict; Path=/`,...headers});return res.end();}if(!authenticated)return sendText(res,403,'Nexu Forge session is not authorised.','text/plain; charset=utf-8',headers);return sendText(res,200,ui.replaceAll('__NEXU_STUDIO_VERSION__',appVersion),'text/html; charset=utf-8',headers);}
   if(!authenticated)return sendJson(res,401,{error:'Unauthorised local Forge session.'},headers);if(!sameOrigin(req,actualPort))return sendJson(res,403,{error:'Origin rejected.'},headers);
   if(await serveStudioFile(res,url.pathname,headers))return;
   if(url.pathname==='/api/status'&&req.method==='GET'){const blender=await findBlender(),version=await blenderVersion(blender);return sendJson(res,200,{app:'Nexu AI 3D Forge',version:appVersion,node:{version:process.version,ok:/^v24\.19\./.test(process.version)},blender:{version,path:blender,ok:isSupportedBlenderVersion(version)},localOnly:true,server:{host,port:actualPort,pid:process.pid},dataRoot,roots:{assets:outputRoot,projects:projectRoot,recovery:trashRoot,logs:logsRoot,cache:cacheRoot},queue:{running:activeJobId?1:0,waiting:queue.length},cache:await buildCache.stats(),providers:providerCatalogue(),companion:companion.status(),creationKnowledge:creationKnowledgeSummary(),update:{channel:'Stable',liveFeed:false,manifest:'fixture only',preservesUserData:true}},headers);}
   if(url.pathname==='/api/prompt-intelligence'&&req.method==='POST'){const b=await readJson(req),prompt=safePrompt(b.prompt);return sendJson(res,200,{understanding:compileCreationPrompt(prompt),vocabulary:promptVocabularySummary()},headers);}
   if(url.pathname==='/api/brief'&&req.method==='POST'){const b=await readJson(req),prompt=safePrompt(b.prompt),profile=safeProfile(b.profile);return sendJson(res,200,{brief:interpretBrief(prompt,profile),understanding:compileCreationPrompt(prompt)},headers);}
   if(url.pathname==='/api/plan'&&req.method==='POST'){const b=await readJson(req),prompt=safePrompt(b.prompt),profile=safeProfile(b.profile),guided=await planWithLearning(prompt,profile,b.referenceEvidence,b.generationMode);return sendJson(res,200,{brief:interpretBrief(prompt,profile),...guided},headers);}
   if(url.pathname==='/api/build'&&req.method==='POST'){const b=await readJson(req),prompt=safePrompt(b.prompt),profile=safeProfile(b.profile),guided=await planWithLearning(prompt,profile,b.referenceEvidence,b.generationMode),recipe=guided.recipe;const job=queueRecipe(recipe,prompt,profile,{referenceGuidance:guided.referenceGuidance});await writeStudioJob(job);return sendJson(res,202,{job:publicJob(job),learningChanges:guided.learningChanges},headers);}
   if(url.pathname==='/api/refine/plan'&&req.method==='POST'){const b=await readJson(req),dir=resolveOutputRelative(b.directory),recipe=await findRecipe(dir),plan=planRefinement(recipe,safeText(b.request,1000));return sendJson(res,200,{plan},headers);}
   if(url.pathname==='/api/refine/apply'&&req.method==='POST'){const b=await readJson(req),parent=safeText(b.directory,300),dir=resolveOutputRelative(parent),recipe=await findRecipe(dir),plan=planRefinement(recipe,safeText(b.request,1000));const job=queueRecipe(plan.recipe,recipe.sourcePrompt||'Refined asset',recipe.profile,{parentDirectory:parent,refinement:{request:plan.request,changes:plan.changes}});await writeStudioJob(job);return sendJson(res,202,{plan,job:publicJob(job)},headers);}
   if(url.pathname==='/api/material/presets'&&req.method==='GET')return sendJson(res,200,{presets:materialPresets()},headers);
   if(url.pathname==='/api/material/plan'&&req.method==='POST'){const b=await readJson(req),dir=resolveOutputRelative(b.directory),recipe=await findRecipe(dir),plan=planMaterialGeneration(recipe,safeText(b.request,1000),{materialName:safeText(b.materialName,80)||null,preset:safeText(b.preset,60)||null,resolution:Number(b.resolution)||null});return sendJson(res,200,{plan},headers);}
   if(url.pathname==='/api/material/apply'&&req.method==='POST'){const b=await readJson(req),parent=safeText(b.directory,300),dir=resolveOutputRelative(parent),recipe=await findRecipe(dir),plan=planMaterialGeneration(recipe,safeText(b.request,1000),{materialName:safeText(b.materialName,80)||null,preset:safeText(b.preset,60)||null,resolution:Number(b.resolution)||null});const job=queueRecipe(plan.recipe,recipe.sourcePrompt||'Material variant',recipe.profile,{parentDirectory:parent,materialGeneration:{request:plan.request,materialName:plan.materialName,changes:plan.changes}});await writeStudioJob(job);return sendJson(res,202,{plan,job:publicJob(job)},headers);}
   if(url.pathname==='/api/jobs'&&req.method==='GET')return sendJson(res,200,{jobs:[...jobs.values()].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,50).map(publicJob),activeJobId,queued:queue.length},headers);
   const jm=url.pathname.match(/^\/api\/jobs\/([A-Za-z0-9-]+)$/);if(jm&&req.method==='GET'){const job=jobs.get(jm[1]);return job?sendJson(res,200,{job:publicJob(job)},headers):sendJson(res,404,{error:'Build job not found.'},headers);}
   const cm=url.pathname.match(/^\/api\/jobs\/([A-Za-z0-9-]+)\/cancel$/);if(cm&&req.method==='POST'){const job=jobs.get(cm[1]);if(!job)return sendJson(res,404,{error:'Build job not found.'},headers);if(job.status==='queued'){job.status='cancelled';job.stage='Cancelled';job.finishedAt=new Date().toISOString();await writeStudioJob(job);}else if(job.status==='running'&&job.controller)job.controller.abort();return sendJson(res,200,{job:publicJob(job)},headers);}
   if(url.pathname==='/api/assets'&&req.method==='GET')return sendJson(res,200,{assets:await listAssets()},headers);
   const am=url.pathname.match(/^\/api\/assets\/([A-Za-z0-9_-]+)\/meta$/);if(am&&req.method==='POST'){const dir=resolveOutputRelative(decodeId(am[1])),meta=await saveAssetMeta(dir,await readJson(req));return sendJson(res,200,{meta},headers);}
   const dm=url.pathname.match(/^\/api\/assets\/([A-Za-z0-9_-]+)\/duplicate$/);if(dm&&req.method==='POST'){const srcRel=decodeId(dm[1]),src=resolveOutputRelative(srcRel),recipe=await findRecipe(src);const id=`${buildStamp()}-${randomUUID().slice(0,8)}-copy`,destRel=`${recipe.assetName}/${id}`,dest=resolveOutputRelative(destRel);await cp(src,dest,{recursive:true,errorOnExist:true});await writeFile(join(dest,'.forge-version.json'),JSON.stringify({schema:'nexu.forge.version.v1',assetName:recipe.assetName,versionId:id,createdAt:new Date().toISOString(),parentDirectory:srcRel,sourcePrompt:recipe.sourcePrompt,refinement:{request:'Duplicate version',changes:[]}},null,2));return sendJson(res,200,{directory:destRel},headers);}
   const tm=url.pathname.match(/^\/api\/assets\/([A-Za-z0-9_-]+)\/trash$/);if(tm&&req.method==='POST'){const rel=decodeId(tm[1]),src=resolveOutputRelative(rel),name=`${buildStamp()}-${basename(src)}`,dest=resolve(trashRoot,name);await rename(src,dest);return sendJson(res,200,{trashed:true,id:encodeId(name)},headers);}
   if(url.pathname==='/api/trash'&&req.method==='GET'){const entries=await readdir(trashRoot,{withFileTypes:true});return sendJson(res,200,{items:entries.filter(x=>x.isDirectory()).map(x=>({id:encodeId(x.name),name:x.name}))},headers);}
   const restore=url.pathname.match(/^\/api\/trash\/([A-Za-z0-9_-]+)\/restore$/);if(restore&&req.method==='POST'){const name=decodeId(restore[1]),src=resolveWithin(trashRoot,name,'Trash item'),recipe=await findRecipe(src),destRel=`${recipe.assetName}/${buildStamp()}-${randomUUID().slice(0,8)}-restored`,dest=resolveOutputRelative(destRel);await rename(src,dest);return sendJson(res,200,{restored:true,directory:destRel},headers);}
   if(url.pathname==='/api/reference'&&req.method==='POST')return sendJson(res,201,{reference:await saveReference(req)},headers);
   if(url.pathname==='/reference-file'&&req.method==='GET'){const file=decodeId(url.searchParams.get('id')??''),target=resolveWithin(referenceRoot,file,'Reference'),extension=extname(target).toLowerCase();if(!['.png','.jpg','.webp'].includes(extension))return sendJson(res,403,{error:'Reference type not exposed.'},headers);const s=await stat(target);res.writeHead(200,{'Content-Type':extension==='.png'?'image/png':extension==='.webp'?'image/webp':'image/jpeg','Content-Length':s.size,'Cache-Control':'private, no-store',...headers});createReadStream(target).pipe(res);return;}
   if(url.pathname==='/api/grammar'&&req.method==='GET')return sendJson(res,200,{grammars:grammarCatalogue()},headers);
   if(url.pathname==='/api/creation-knowledge'&&req.method==='GET')return sendJson(res,200,{knowledge:creationKnowledgeSummary(),vocabulary:promptVocabularySummary()},headers);
   if(url.pathname==='/api/cache/status'&&req.method==='GET')return sendJson(res,200,{cache:await buildCache.stats()},headers);
   if(url.pathname==='/api/cache/clear'&&req.method==='POST')return sendJson(res,200,{cache:await buildCache.clear()},headers);
   if(url.pathname==='/api/learning/stats'&&req.method==='GET')return sendJson(res,200,{stats:await learning.stats()},headers);
   if(url.pathname==='/api/learning/suggestion'&&req.method==='GET')return sendJson(res,200,{suggestion:await learning.suggestion(safeText(url.searchParams.get('grammarId'),80))},headers);
   if(url.pathname==='/api/learning/feedback'&&req.method==='POST'){const b=await readJson(req);return sendJson(res,201,{feedback:await recordLearningFeedback(safeText(b.directory,300),String(b.verdict??''),safeText(b.note,500),'desktop')},headers);}
   if(url.pathname==='/api/providers'&&req.method==='GET')return sendJson(res,200,{providers:providerCatalogue()},headers);
   if(url.pathname==='/api/screen/start'&&req.method==='POST'){const b=await readJson(req);if(!companion.status().pairedDevices.some(d=>d.deviceId===b.deviceId))throw new Error('Choose a paired device');return sendJson(res,200,screenShare.start(b.deviceId),headers);}
   if(url.pathname==='/api/screen/frame'&&req.method==='POST')return sendJson(res,200,screenShare.publish(await readJson(req,720000)),headers);
   if(url.pathname==='/api/screen/stop'&&req.method==='POST')return sendJson(res,200,screenShare.stop((await readJson(req)).sessionId),headers);
   if(url.pathname==='/api/companion/status'&&req.method==='GET')return sendJson(res,200,companion.status(),headers);
   if(url.pathname==='/api/companion/pairing'&&req.method==='POST')return sendJson(res,201,{pairing:(()=>{const p=companion.createPairingOffer();return {...p,qr:pairingQr(p.uri)};})()},headers);
   if(url.pathname==='/api/companion/revoke'&&req.method==='POST'){const b=await readJson(req);return sendJson(res,200,{revoked:(screenShare.stop(),await companion.revoke(safeText(b.deviceId,80)))},headers);}
   if(url.pathname==='/api/update/status'&&req.method==='GET'){const manifestUrl=process.env.NEXU_FORGE_UPDATE_MANIFEST_URL?.trim();const fixturePath=join(here,'update-manifest.fixture.json');const manifest=manifestUrl?await fetchUpdateManifest(manifestUrl,appVersion):await readFixtureManifest(fixturePath,appVersion);return sendJson(res,200,{...manifest,liveFeed:Boolean(manifestUrl),installedVersions:await installedVersions(),rollbackAvailable:(await installedVersions()).some(v=>v!==appVersion)},headers);}
   if(url.pathname==='/api/update/apply'&&req.method==='POST'){const manifestUrl=process.env.NEXU_FORGE_UPDATE_MANIFEST_URL?.trim();if(!manifestUrl)return sendJson(res,409,{error:'Production update feed is not configured in this candidate.'},headers);const manifest=await fetchUpdateManifest(manifestUrl,appVersion);if(!manifest.newer)return sendJson(res,409,{error:'No newer update is available.'},headers);const updateDir=join(dataRoot,'.updates');const downloaded=await downloadVerifiedSetup(manifest,updateDir);await launchVerifiedInstaller(downloaded.path);return sendJson(res,202,{ok:true,version:manifest.availableVersion,verifiedSha256:downloaded.sha256},headers);}
   if(url.pathname==='/api/update/rollback'&&req.method==='POST'){await launchRollback();return sendJson(res,202,{ok:true,message:'Rollback setup launched. Forge will remain open until you confirm the rollback.'},headers);}
   if(url.pathname==='/asset-file'&&req.method==='GET'){const target=resolveOutputRelative(url.searchParams.get('path')??''),extension=extname(target).toLowerCase(),allowed=new Set(['.png','.json','.fbx','.glb','.blend','.log','.txt']);if(!allowed.has(extension))return sendJson(res,403,{error:'File type not exposed by Forge.'},headers);let s;try{s=await stat(target);}catch{return sendJson(res,404,{error:'Asset file not found.'},headers);}if(!s.isFile())return sendJson(res,404,{error:'Asset file not found.'},headers);const types={'.png':'image/png','.json':'application/json','.fbx':'application/octet-stream','.glb':'model/gltf-binary','.blend':'application/octet-stream','.log':'text/plain; charset=utf-8','.txt':'text/plain; charset=utf-8'};res.writeHead(200,{'Content-Type':types[extension]??'application/octet-stream','Content-Length':s.size,'Cache-Control':'no-store',...headers});createReadStream(target).pipe(res);return;}
   if(url.pathname==='/api/open-folder'&&req.method==='POST'){const b=await readJson(req);await openExternal(resolveOutputRelative(b.directory),'folder');return sendJson(res,200,{ok:true},headers);}
   if(url.pathname==='/api/open-blender'&&req.method==='POST'){const b=await readJson(req),dir=resolveOutputRelative(b.directory),entries=await readdir(dir),blend=entries.find(x=>x.toLowerCase().endsWith('.blend'));if(!blend)return sendJson(res,404,{error:'No .blend master found.'},headers);await openExternal(join(dir,blend),'blender');return sendJson(res,200,{ok:true},headers);}
   if(url.pathname==='/api/shutdown'&&req.method==='POST'){shuttingDown=true;sendJson(res,200,{ok:true},headers);setTimeout(async()=>{await companion.close();server.close(()=>process.exit(0));},100);return;}
   return sendJson(res,404,{error:'Not found.'},headers);
 }catch(error){return sendJson(res,400,{error:error?.message??String(error)},securityHeaders());}});
 await new Promise((ok,fail)=>{server.once('error',fail);server.listen(requestedPort,host,ok);});actualPort=server.address().port;const url=`http://${host}:${actualPort}/?token=${token}`;await writeFile(sessionPath,JSON.stringify({pid:process.pid,port:actualPort,token,url,startedAt:new Date().toISOString()},null,2));console.log(`NEXU_STUDIO_READY ${url}`);await launchBrowser(url);const cleanup=async()=>{try{await unlink(sessionPath);}catch{}};process.on('exit',()=>{try{unlinkSync(sessionPath);}catch{}});process.on('SIGINT',async()=>{shuttingDown=true;await cleanup();await companion.close();server.close(()=>process.exit(0));});process.on('SIGTERM',async()=>{shuttingDown=true;await cleanup();await companion.close();server.close(()=>process.exit(0));});return{server,url,token,port:actualPort,companion};
}
export {createServer,safePrompt,safeProfile,resolveOutputRelative};
if(process.argv[1]&&resolve(process.argv[1])===resolve(fileURLToPath(import.meta.url)))createServer().catch(error=>{console.error(`NEXU STUDIO ERROR: ${error.message}`);process.exitCode=1;});
