import { validateRecipe } from './schema.mjs';

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function pct(text, fallback = 0.12) {
  const m = text.match(/(\d+(?:\.\d+)?)\s*%/); return m ? Math.min(0.8, Number(m[1]) / 100) : fallback;
}
function numberBefore(text, word) { const m = text.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*${word}`, 'i')); return m ? Number(m[1]) : null; }
function push(changes, path, before, after, reason) { if (JSON.stringify(before) !== JSON.stringify(after)) changes.push({ path, before, after, reason }); }

export function planRefinement(recipeInput, requestInput) {
  const recipe = clone(validateRecipe(recipeInput));
  const request = String(requestInput ?? '').trim();
  if (!request || request.length > 1000) throw new Error('Refinement request must be 1–1,000 characters.');
  const lower = request.toLowerCase();
  const next = clone(recipe);
  const changes = [];
  const barrelIndex = next.parts.findIndex(p => p.type === 'procedural_barrel');
  const drumIndex = next.parts.findIndex(p => p.type === 'procedural_drum');
  const creatureIndex = next.parts.findIndex(p => p.type === 'procedural_creature');

  if (/\bwider|broader|fatter\b/.test(lower)) {
    const scale = 1 + pct(lower);
    for (let i = 0; i < next.parts.length; i++) {
      const p = next.parts[i]; const before = [...p.dimensions]; p.dimensions[0] *= scale; p.dimensions[1] *= scale;
      if (p.type === 'procedural_barrel') { p.details.endRadius *= scale; p.details.bellyRadius *= scale; }
      if (p.type === 'procedural_drum') p.details.radius *= scale;
      if (p.type === 'procedural_creature') { p.details.bodyWidth *= scale; p.dimensions[1]=p.details.bodyWidth; }
      if (p.type === 'procedural_creature') { p.details.bodyWidth *= scale; p.dimensions[1]=p.details.bodyWidth; }
      push(changes, `parts[${i}].width/depth`, before, [...p.dimensions], 'Increase width while preserving height.');
    }
  }
  if (/\bnarrower|slimmer|thinner\b/.test(lower)) {
    const scale = Math.max(0.3, 1 - pct(lower));
    for (let i = 0; i < next.parts.length; i++) {
      const p = next.parts[i]; const before = [...p.dimensions]; p.dimensions[0] *= scale; p.dimensions[1] *= scale;
      if (p.type === 'procedural_barrel') { p.details.endRadius *= scale; p.details.bellyRadius *= scale; }
      if (p.type === 'procedural_drum') p.details.radius *= scale;
      if (p.type === 'procedural_creature') { p.details.bodyWidth *= scale; p.dimensions[1]=p.details.bodyWidth; }
      push(changes, `parts[${i}].width/depth`, before, [...p.dimensions], 'Reduce width while preserving height.');
    }
  }
  const cm = lower.match(/(?:reduce|lower|shorten).*?height.*?(\d+(?:\.\d+)?)\s*cm/);
  if (cm) {
    const delta = Number(cm[1]) / 100;
    for (let i=0;i<next.parts.length;i++) { const p=next.parts[i]; const before=p.dimensions[2]; p.dimensions[2]=Math.max(0.02,p.dimensions[2]-delta); if(p.type==='procedural_creature')p.details.bodyHeight=p.dimensions[2]; push(changes,`parts[${i}].height`,before,p.dimensions[2],`Reduce height by ${cm[1]} cm.`); }
  }
  const hoopCount = lower.match(/(?:use|make|change|to|with)\s+(?:the\s+)?(?:bands?|hoops?)\s*(?:to)?\s*(\d+)/) ?? lower.match(/(?:three|four|five|six|seven|eight)\s+(?:bands?|hoops?)/);
  if (barrelIndex >= 0 && hoopCount) {
    const wordMap={three:3,four:4,five:5,six:6,seven:7,eight:8}; const raw=hoopCount[1] ?? hoopCount[0].split(/\s+/)[0]; const n=Number(raw)||wordMap[raw];
    if (n >= 2 && n <= 8) { const before=next.parts[barrelIndex].details.hoopCount; next.parts[barrelIndex].details.hoopCount=n; push(changes,`parts[${barrelIndex}].details.hoopCount`,before,n,'Change hoop count.'); }
  }
  const tris = numberBefore(lower, '(?:triangles|tris|polygons|polys)');
  if (tris) { const before=next.targetTriangles; next.targetTriangles=Math.max(12,Math.min(2_000_000,Math.round(tris))); push(changes,'targetTriangles',before,next.targetTriangles,'Update game geometry budget.'); }
  if (/\bolder|more aged|weathered|rustic\b/.test(lower)) {
    next.materials = next.materials.map((m,i) => { const before=m.style; if (m.style==='wood') m.style='aged_wood'; if (m.style==='iron') m.style='worn_iron'; push(changes,`materials[${i}].style`,before,m.style,'Age surface treatment.'); return m; });
  }
  if (/\blighter wood|wood lighter\b/.test(lower)) {
    next.materials = next.materials.map((m,i)=>{ if (!/wood/.test(m.style)) return m; const before=[...m.baseColor]; m.baseColor=m.baseColor.map((v,j)=>j===3?v:Math.min(1,v*1.25+0.03)); push(changes,`materials[${i}].baseColor`,before,m.baseColor,'Lighten wood base colour.'); return m;});
  }
  const rough = lower.match(/roughness\s*(?:to|=)?\s*(0(?:\.\d+)?|1(?:\.0+)?)/);
  if (rough) { const value=Number(rough[1]); next.materials=next.materials.map((m,i)=>{const before=m.roughness;m.roughness=value;push(changes,`materials[${i}].roughness`,before,value,'Explicit roughness request.');return m;}); }
  if (barrelIndex >= 0 && /less cylindrical|more barrel|more bulge|stronger belly/.test(lower)) {
    const d=next.parts[barrelIndex].details; const before=d.bellyRadius; d.bellyRadius=Math.min(20,Math.max(d.endRadius*1.06,d.bellyRadius*1.08)); next.parts[barrelIndex].dimensions[0]=d.bellyRadius*2; next.parts[barrelIndex].dimensions[1]=d.bellyRadius*2; push(changes,`parts[${barrelIndex}].details.bellyRadius`,before,d.bellyRadius,'Increase barrel belly curvature.');
  }
  if (barrelIndex >= 0 && /add (?:another|one) plank|more plank/.test(lower)) { const d=next.parts[barrelIndex].details; const before=d.endPlanks; d.endPlanks=Math.min(12,d.endPlanks+1); push(changes,`parts[${barrelIndex}].details.endPlanks`,before,d.endPlanks,'Add an end plank.'); }
  if (/collision.*(?:closer|tighter|fit)/.test(lower)) changes.push({path:'collision',before:'generated',after:'regenerate tighter from revised bounds',reason:'Regenerate collision after geometry change.'});
  if (drumIndex >= 0 && /more ribs?/.test(lower)) { const d=next.parts[drumIndex].details; const before=d.ribCount; d.ribCount=Math.min(6,d.ribCount+1); push(changes,`parts[${drumIndex}].details.ribCount`,before,d.ribCount,'Add drum rib.'); }
  if (creatureIndex >= 0) {
    const d=next.parts[creatureIndex].details;
    const morph=(key,after,reason)=>{const before=d[key];d[key]=after;push(changes,`parts[${creatureIndex}].details.${key}`,before,after,reason);};
    if (/(?:larger|bigger|wider) wings?|increase wing|wings?.{0,24}(?:larger|bigger|wider)/.test(lower) && d.wingCount>0) morph('wingSpan',Math.min(120,d.wingSpan*(1+pct(lower,.15))),'Increase creature wing span.');
    if (/smaller wings?|reduce wing|shorter wings?/.test(lower) && d.wingCount>0) morph('wingSpan',Math.max(.05,d.wingSpan*(1-pct(lower,.15))),'Reduce creature wing span.');
    if (/(?:longer neck|extend neck|neck.{0,20}longer)/.test(lower)) morph('neckLength',Math.min(60,d.neckLength*(1+pct(lower,.18))+.02),'Lengthen creature neck.');
    if (/(?:shorter neck|reduce neck|neck.{0,20}shorter)/.test(lower)) morph('neckLength',Math.max(0,d.neckLength*(1-pct(lower,.18))),'Shorten creature neck.');
    if (/(?:longer tail|extend tail|tail.{0,20}longer)/.test(lower)) morph('tailLength',Math.min(100,d.tailLength*(1+pct(lower,.18))+.03),'Lengthen creature tail.');
    if (/(?:shorter tail|reduce tail|tail.{0,20}shorter)/.test(lower)) morph('tailLength',Math.max(0,d.tailLength*(1-pct(lower,.18))),'Shorten creature tail.');
    if (/(?:larger horns?|bigger horns?|huge horns?|horns?.{0,20}(?:larger|bigger|huge))/.test(lower)) morph('hornScale',Math.min(2,Math.max(.12,d.hornScale)*(1+pct(lower,.22))),'Increase horn scale.');
    if (/(?:smaller horns?|reduce horns?|horns?.{0,20}smaller)/.test(lower)) morph('hornScale',Math.max(0,d.hornScale*(1-pct(lower,.22))),'Reduce horn scale.');
    if (/hornless|no horns?|remove horns?/.test(lower)) morph('hornScale',0,'Remove horns.');
    if (/(?:bulkier|heavier body|more muscular|massive body|body.{0,20}bulkier)/.test(lower)) morph('bodyBulk',Math.min(1.8,d.bodyBulk*(1+pct(lower,.12))),'Increase body bulk.');
    if (/(?:slender|leaner|less bulky|lighter body|body.{0,20}(?:slender|leaner|less bulky))/.test(lower)) morph('bodyBulk',Math.max(.45,d.bodyBulk*(1-pct(lower,.12))),'Reduce body bulk.');
    if (/more spikes?|spikier|spiny/.test(lower)) morph('dorsalSpikes',Math.min(24,d.dorsalSpikes+3),'Add dorsal spikes.');
    if (/fewer spikes?|less spiky/.test(lower)) morph('dorsalSpikes',Math.max(0,d.dorsalSpikes-3),'Reduce dorsal spikes.');
    if (/no spikes?|remove spikes?|spikeless/.test(lower)) morph('dorsalSpikes',0,'Remove dorsal spikes.');
    if (/torn wings?|ripped wings?|damaged wings?/.test(lower) && d.wingCount>0) morph('tornWings',true,'Use torn wing silhouette.');
    if (/intact wings?|repair wings?|clean wings?/.test(lower) && d.wingCount>0) morph('tornWings',false,'Restore intact wing silhouette.');
  }

  if (!changes.length) throw new Error('That refinement is not yet an allow-listed Forge operation. Try width/height, triangle target, materials, creature wing/neck/tail/horn/body/spike changes, barrel construction changes or collision fit.');
  const validated = validateRecipe(next);
  return Object.freeze({ request, changes, recipe: validated, requiresRegeneration: true, safe: true });
}
