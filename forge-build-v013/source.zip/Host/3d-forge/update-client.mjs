import { createHash } from 'node:crypto';
import { access, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { basename, join, resolve } from 'node:path';
import { spawn } from 'node:child_process';

const MAX_SETUP_BYTES = 512 * 1024 * 1024;
const PRODUCT = 'Nexu AI 3D Forge';
const SCHEMA = 'nexu.forge.update.v1';

function semver(v){const m=String(v??'').match(/^(\d+)\.(\d+)\.(\d+)$/);if(!m)throw new Error(`Invalid semantic version: ${v}`);return m.slice(1).map(Number);}
export function compareVersions(a,b){const x=semver(a),y=semver(b);for(let i=0;i<3;i++){if(x[i]<y[i])return-1;if(x[i]>y[i])return 1;}return 0;}
export function validateUpdateManifest(raw,currentVersion){
  if(!raw||raw.schema!==SCHEMA)throw new Error('Update manifest schema is not supported.');
  const availableVersion=String(raw.availableVersion??'');
  semver(availableVersion); semver(currentVersion);
  const newer=compareVersions(currentVersion,availableVersion)<0;
  const out={schema:SCHEMA,currentVersion,availableVersion,channel:String(raw.channel??'Stable'),releaseNotes:String(raw.releaseNotes??''),sizeBytes:Number(raw.sizeBytes??0),downloadUrl:raw.downloadUrl??null,sha256:raw.sha256??null,newer,live:Boolean(raw.live)};
  if(newer){
    if(typeof out.downloadUrl!=='string'||!out.downloadUrl.startsWith('https://'))throw new Error('Newer update requires an HTTPS download URL.');
    if(typeof out.sha256!=='string'||!/^[a-f0-9]{64}$/i.test(out.sha256))throw new Error('Newer update requires a SHA-256 digest.');
    if(!Number.isSafeInteger(out.sizeBytes)||out.sizeBytes<=0||out.sizeBytes>MAX_SETUP_BYTES)throw new Error('Update size is invalid or exceeds the 512 MB safety limit.');
  }
  return Object.freeze(out);
}
export async function fetchUpdateManifest(url,currentVersion,{signal}={}){
  if(typeof url!=='string'||!url.startsWith('https://'))throw new Error('Update manifest URL must use HTTPS.');
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12_000);if(signal)signal.addEventListener('abort',()=>controller.abort(),{once:true});
  try{const res=await fetch(url,{redirect:'error',signal:controller.signal,headers:{Accept:'application/json'}});if(!res.ok)throw new Error(`Update manifest HTTP ${res.status}.`);const raw=await res.json();return validateUpdateManifest(raw,currentVersion);}finally{clearTimeout(timer);}
}
export async function readFixtureManifest(path,currentVersion){return validateUpdateManifest(JSON.parse(await readFile(path,'utf8')),currentVersion);}
export async function downloadVerifiedSetup(manifest,directory,{signal}={}){
  if(!manifest?.newer)throw new Error('No newer update is available.');
  await mkdir(directory,{recursive:true});
  const url=new URL(manifest.downloadUrl);const name=basename(url.pathname)||`Nexu-AI-3D-Forge-Setup-${manifest.availableVersion}-x64.exe`;
  if(!/\.exe$/i.test(name))throw new Error('Update payload must be a Windows executable.');
  const res=await fetch(url,{redirect:'error',signal,headers:{Accept:'application/octet-stream'}});if(!res.ok)throw new Error(`Update download HTTP ${res.status}.`);
  const declared=Number(res.headers.get('content-length')||0);if(declared&&declared!==manifest.sizeBytes)throw new Error('Update size does not match the signed manifest metadata.');
  const bytes=Buffer.from(await res.arrayBuffer());if(bytes.length!==manifest.sizeBytes||bytes.length>MAX_SETUP_BYTES)throw new Error('Downloaded update size is invalid.');
  const digest=createHash('sha256').update(bytes).digest('hex');if(digest.toLowerCase()!==manifest.sha256.toLowerCase())throw new Error('Downloaded update failed SHA-256 verification.');
  const target=resolve(directory,name);await writeFile(target,bytes,{mode:0o755});return{path:target,sha256:digest,sizeBytes:bytes.length};
}
export function installedRoot(){return join(process.env.LOCALAPPDATA??'', 'Programs','Sumero Studio',PRODUCT);}
export function installedSetupPath(){return join(installedRoot(),'Nexu-AI-3D-Forge-Setup.exe');}
function spawnDetached(exe,args=[]){const child=spawn(exe,args,{detached:true,stdio:'ignore',windowsHide:true,shell:false});child.unref();return child.pid;}
export async function launchVerifiedInstaller(path){if(process.platform!=='win32')throw new Error('Update installation is available only on Windows.');await access(path,constants.X_OK);return spawnDetached(path,[]);}
export async function launchRollback(){if(process.platform!=='win32')throw new Error('Rollback is available only on Windows.');const setup=installedSetupPath();await access(setup,constants.X_OK);return spawnDetached(setup,['--rollback']);}
export async function installedVersions(){const root=join(installedRoot(),'versions');try{return (await readdir(root,{withFileTypes:true})).filter(x=>x.isDirectory()&&/^\d+\.\d+\.\d+$/.test(x.name)).map(x=>x.name).sort(compareVersions);}catch{return[];}}
