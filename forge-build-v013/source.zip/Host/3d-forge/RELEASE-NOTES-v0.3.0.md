# Nexu AI 3D Forge v0.3.0 — Studio Workspace Foundation Candidate

v0.3.0 turns the proven CLI-driven 3D Forge into a creator-facing local Studio without replacing the protected Nexu Language 0.6.0 foundation.

## Headline changes

- premium Create workspace with model brief, Plan and Build;
- generated perspective/front/side/wireframe/collision previews;
- quality and triangle-budget evidence;
- searchable local Asset Library;
- serial Build Queue with cancellation;
- Diagnostics and Settings surfaces;
- one-click detached Studio launcher;
- local session authentication and browser security headers;
- versioned output directories so Studio builds do not silently overwrite one another;
- Open in Blender and Open folder workflow;
- no Electron and no new npm runtime dependency.

## Preserved

- Nexu3D validated recipe boundary;
- Blender 5.2.x pin;
- Unreal/ASA profile;
- `.blend` / `.fbx` / `.glb` exports;
- custom collision and LOD exports;
- procedural quality foundation from v0.2.0;
- existing CLI launchers for diagnostic/recovery use.

## Verification boundary

No claim is made that the Windows Edge shell or a live Studio-triggered Blender job executed in the Linux build environment. Existing CLI Blender generation was already proven on the target Windows PC in v0.1.3; v0.3.0 requires one target-PC Studio smoke test before promotion.
