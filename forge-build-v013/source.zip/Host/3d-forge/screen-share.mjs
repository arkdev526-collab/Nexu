import {randomUUID} from 'node:crypto';
export const MAX_FRAME_BYTES=525000, STALE_MS=5000;
export function jpegSize(bytes){
 if(bytes.length<4||bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)throw new Error('Expected JPEG');
 let i=2;
 while(i+3<bytes.length){
  if(bytes[i++]!==255)throw new Error('Invalid JPEG marker');while(bytes[i]===255)i++;
  const marker=bytes[i++];if(marker===0xda||marker===0xd9)break;
  if(marker===0x01||marker>=0xd0&&marker<=0xd7)continue;
  const length=bytes.readUInt16BE(i);if(length<2||i+length>bytes.length)throw new Error('Truncated JPEG');
  if([0xc0,0xc1,0xc2].includes(marker)){if(length<8)throw new Error('Invalid JPEG header');return {width:bytes.readUInt16BE(i+5),height:bytes.readUInt16BE(i+3)};}
  i+=length;
 }
 throw new Error('JPEG dimensions missing');
}
export class ScreenShare {
 constructor({now=Date.now}={}) {this.now=now;this.stop();}
 stop(sessionId) {
  if(sessionId&&this.session?.id!==sessionId)return {active:Boolean(this.session),stopped:false};
  this.session=null;this.frame=null;return {active:false,stopped:true};
 }
 start(deviceId) {if(typeof deviceId!=='string'||!deviceId)throw new Error('Choose a tablet');this.stop();this.session={id:randomUUID(),deviceId,sequence:0};return {sessionId:this.session.id};}
 publish(p) {
  if(!this.session || p.sessionId!==this.session.id)throw new Error('Screen session ended');
  if(!Number.isInteger(p.width)||!Number.isInteger(p.height)||p.width<1||p.height<1||p.width>1600||p.height>1600)throw new Error('Invalid screen dimensions');
  if(typeof p.base64!=='string'||p.base64.length>700000||!/^[/+A-Za-z0-9]+={0,2}$/.test(p.base64))throw new Error('Invalid screen frame');
  const b=Buffer.from(p.base64,'base64');if(b.length>MAX_FRAME_BYTES||b.toString('base64')!==p.base64)throw new Error('Invalid screen encoding');
  const size=jpegSize(b);if(size.width!==p.width||size.height!==p.height)throw new Error('JPEG dimensions do not match');
  this.frame={base64:p.base64,width:p.width,height:p.height,at:this.now(),sequence:++this.session.sequence,sessionId:this.session.id,bytes:b.length};return {ok:true,sequence:this.frame.sequence};
 }
 read(deviceId,afterSequence,sessionId) {
  if(!this.session||this.session.deviceId!==deviceId||!this.frame)return {active:false};
  if(this.now()-this.frame.at>STALE_MS){this.frame=null;return {active:false};}
  const {base64,...meta}=this.frame;
  if(sessionId===this.session.id&&Number.isSafeInteger(afterSequence)&&afterSequence>=this.frame.sequence)return {active:true,unchanged:true,...meta};
  return {active:true,unchanged:false,base64,...meta};
 }
}
