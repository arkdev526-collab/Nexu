# Nexu AI 3D Forge 0.8.0 QA

- Forge deterministic tests: **52/52 PASS**.
- Protected Nexu Language tests: **70/70 PASS**.
- 23 ready local grammar families: PASS.
- Safe Mesh Repair v1 source/contract: PASS.
- Seven-view local dataset record: PASS.
- Good / Needs Work ledger and bounded accepted-result adaptation: PASS.
- 14px minimum Studio typography gate: PASS.
- No paid or temporary neural provider ships in v0.8: PASS.
- Real Blender 5.2 generation and exact Windows Setup lifecycle: pending target-PC qualification.
