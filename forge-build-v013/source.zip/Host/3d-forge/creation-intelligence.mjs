import { buildCreaturePlan, creatureCatalogue, creatureStyleProfiles } from './creature-grammar.mjs';
import { compileCreationPrompt, promptVocabularySummary } from './prompt-intelligence.mjs';

const CATEGORY_HINTS=Object.freeze([
  ['Fantasy creature',/\bdragon|wyvern|griff(?:in|on)|basilisk|drake\b/i],
  ['Quadruped mammal',/\bwolf|dog|fox|bear|lion|tiger|horse\b/i],
  ['Arachnid',/\bspider|arachnid|scorpion\b/i],
  ['Serpent',/\bsnake|serpent|viper|cobra\b/i],
  ['Bird',/\bbird|eagle|raven|crow|owl|hawk|falcon\b/i],
  ['Aquatic creature',/\bfish|salmon|trout|carp|piranha|tuna\b/i]
]);

export function resolveCreationIntent(prompt){
  const compiled=compileCreationPrompt(prompt),text=compiled.plannerPrompt;
  const creature=buildCreaturePlan(text);
  if(creature)return Object.freeze({domain:'creature',category:creature.category,grammarId:creature.grammarId,assetClass:creature.assetClass,confidence:'high',understanding:compiled});
  const category=CATEGORY_HINTS.find(([,re])=>re.test(text))?.[0]??'Object / prop';
  return Object.freeze({domain:'object',category,grammarId:compiled.grammarId,assetClass:compiled.subject,confidence:compiled.confidence==='high'?'high':category==='Object / prop'?'normal':'review',understanding:compiled});
}

export function creationKnowledgeSummary(){
  const creatures=creatureCatalogue(),vocabulary=promptVocabularySummary();
  return Object.freeze({schema:'nexu.forge.creation-knowledge.v2',totalGrammars:vocabulary.subjects,creatureGrammars:creatures.length,creatureCategories:[...new Set(creatures.map(x=>x.category))],styleProfiles:creatureStyleProfiles(),promptVocabulary:vocabulary,localOnly:true,paidProviders:0,arbitraryCode:false});
}
