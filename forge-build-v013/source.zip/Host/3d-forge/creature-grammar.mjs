import { safeAssetName } from './schema.mjs';

const MAT = Object.freeze({
  scales: { name:'M_Scales', style:'scales', baseColor:[0.075,0.09,0.065,1], metallic:0.02, roughness:0.58, variation:0.42, wear:0.22, normalStrength:0.46, textureResolution:512, tileable:true, pbrGenerate:true },
  darkScales: { name:'M_DarkScales', style:'scales', baseColor:[0.028,0.034,0.042,1], metallic:0.05, roughness:0.52, variation:0.55, wear:0.30, normalStrength:0.52, textureResolution:512, tileable:true, pbrGenerate:true },
  membrane: { name:'M_WingMembrane', style:'membrane', baseColor:[0.16,0.055,0.045,1], metallic:0, roughness:0.72, variation:0.34, wear:0.35, normalStrength:0.24, textureResolution:512, tileable:true, pbrGenerate:true },
  horn: { name:'M_HornClaw', style:'bone', baseColor:[0.20,0.16,0.10,1], metallic:0, roughness:0.64, variation:0.28, wear:0.30, normalStrength:0.20, textureResolution:512, tileable:true, pbrGenerate:true },
  fur: { name:'M_Fur', style:'fur', baseColor:[0.16,0.11,0.075,1], metallic:0, roughness:0.82, variation:0.58, wear:0.20, normalStrength:0.46, textureResolution:512, tileable:true, pbrGenerate:true },
  feather: { name:'M_Feather', style:'feather', baseColor:[0.22,0.20,0.16,1], metallic:0, roughness:0.66, variation:0.42, wear:0.14, normalStrength:0.28, textureResolution:512, tileable:true, pbrGenerate:true },
  chitin: { name:'M_Chitin', style:'chitin', baseColor:[0.075,0.055,0.04,1], metallic:0.04, roughness:0.46, variation:0.38, wear:0.16, normalStrength:0.40, textureResolution:512, tileable:true, pbrGenerate:true },
  skin: { name:'M_Skin', style:'skin', baseColor:[0.24,0.20,0.17,1], metallic:0, roughness:0.62, variation:0.28, wear:0.12, normalStrength:0.24, textureResolution:512, tileable:true, pbrGenerate:true },
  wetSkin: { name:'M_WetSkin', style:'skin', baseColor:[0.10,0.18,0.20,1], metallic:0, roughness:0.34, variation:0.36, wear:0.10, normalStrength:0.22, textureResolution:512, tileable:true, pbrGenerate:true }
});

const STYLE_PROFILES = Object.freeze([
  'medieval-fantasy','dark-fantasy','ancient-beast','realistic','stylised-game','skeletal','corrupted'
]);

function scaleWord(prompt){const p=String(prompt).toLowerCase();return /tiny|miniature|small/.test(p)?.72:/huge|massive|large|giant|enormous/.test(p)?1.3:1;}
function explicitHeight(prompt,fallback){const m=String(prompt).match(/(?:height|tall|high)?\s*(\d+(?:\.\d+)?)\s*(mm|cm|m|metres?|meters?)/i);if(!m)return fallback;const n=Number(m[1]),u=m[2].toLowerCase();return u==='mm'?n/1000:u==='cm'?n/100:n;}
function explicitTarget(prompt,fallback){const m=String(prompt).match(/(?:about|around|target)?\s*(\d{3,7})\s*(?:triangles|tris|polygons|polys)/i);return m?Math.max(500,Math.min(250000,Number(m[1]))):fallback;}
function styleProfile(prompt){const p=String(prompt).toLowerCase();if(/dark fantasy|demonic|infernal/.test(p))return'dark-fantasy';if(/ancient|elder|primeval/.test(p))return'ancient-beast';if(/stylised|stylized|cartoon/.test(p))return'stylised-game';if(/skeletal|skeleton|undead/.test(p))return'skeletal';if(/corrupt|mutated|blight/.test(p))return'corrupted';if(/mediev(?:al|il)|fantasy/.test(p))return'medieval-fantasy';return'realistic';}
function colorised(base,prompt){const p=String(prompt).toLowerCase();const out={...base,baseColor:[...base.baseColor]};if(/black|obsidian/.test(p))out.baseColor=[0.018,0.022,0.028,1];else if(/red|crimson/.test(p))out.baseColor=[0.22,0.035,0.025,1];else if(/green|emerald/.test(p))out.baseColor=[0.05,0.15,0.065,1];else if(/blue|azure/.test(p))out.baseColor=[0.04,0.075,0.19,1];else if(/white|ivory/.test(p))out.baseColor=[0.56,0.58,0.54,1];else if(/gold|golden/.test(p))out.baseColor=[0.42,0.25,0.055,1];return out;}
function details(kind,prompt,{length,height,width,limbs,wings,tail=1,neck=.25,horns=.35,spikes=0,archetype='organic'}={}){
  const scale=scaleWord(prompt), h=explicitHeight(prompt,height*scale), ratio=h/(height*scale||1), bodyLength=length*scale*ratio, bodyWidth=width*scale*ratio;
  const p=String(prompt).toLowerCase();
  return {
    creatureKind:kind,archetype,styleProfile:styleProfile(prompt),bodyLength,bodyWidth,bodyHeight:h,
    bodyBulk:/slender|lean|thin/.test(p)?.78:/heavy|bulky|armou?red|massive/.test(p)?1.22:1,
    neckLength:bodyLength*(/long neck/.test(p)?.42:/short neck/.test(p)?.14:neck),
    tailLength:tail?bodyLength*(/long tail/.test(p)?.82:/short tail/.test(p)?.34:.58):0,
    wingSpan:wings?bodyLength*(/enormous|huge|massive wings/.test(p)?1.75:/small wings/.test(p)?.9:1.35):0,
    hornScale:/no horns?|hornless/.test(p)?0:/large horns?|huge horns?/.test(p)?.72:/small horns?/.test(p)?.22:horns,
    limbCount:limbs,wingCount:wings,dorsalSpikes:/spikeless|no spikes/.test(p)?0:/many spikes|spiny/.test(p)?Math.max(spikes,12):spikes,
    tornWings:/torn|ripped|damaged wings?/.test(p),symmetry:/asymmetric|asymmetrical/.test(p)?0.85:1,
    bodyMaterial:kind==='wolf'?MAT.fur.name:kind==='griffin'?MAT.feather.name:kind==='spider'?MAT.chitin.name:kind==='bird'?MAT.feather.name:kind==='fish'?MAT.wetSkin.name:kind==='snake'?MAT.scales.name:MAT.scales.name,
    membraneMaterial:(kind==='griffin'||kind==='bird')?MAT.feather.name:MAT.membrane.name,
    hornMaterial:MAT.horn.name,
    voxelSize:Math.max(.018,Math.min(.14,h/28))
  };
}
function creaturePart(name,d){return{name,type:'procedural_creature',dimensions:[d.bodyLength,d.bodyWidth,d.bodyHeight],location:[0,0,0],rotationDeg:[0,0,0],material:null,details:d};}

function dragon(prompt){const d=details('dragon',prompt,{length:4.6,height:2.4,width:1.45,limbs:4,wings:2,tail:1,neck:.28,horns:.40,spikes:9,archetype:'winged-quadruped'});const body=colorised(/black|dark/.test(String(prompt).toLowerCase())?MAT.darkScales:MAT.scales,prompt);body.name=d.bodyMaterial;return{parts:[creaturePart('DragonAssembly',d)],materials:[body,MAT.membrane,MAT.horn],defaultTris:explicitTarget(prompt,18000),creationClass:'FantasyCreature'};}
function wyvern(prompt){const d=details('wyvern',prompt,{length:4.2,height:2.2,width:1.25,limbs:2,wings:2,tail:1,neck:.24,horns:.26,spikes:7,archetype:'winged-biped'});const body=colorised(MAT.darkScales,prompt);body.name=d.bodyMaterial;return{parts:[creaturePart('WyvernAssembly',d)],materials:[body,MAT.membrane,MAT.horn],defaultTris:explicitTarget(prompt,15000),creationClass:'FantasyCreature'};}
function griffin(prompt){const d=details('griffin',prompt,{length:2.6,height:1.65,width:.9,limbs:4,wings:2,tail:1,neck:.18,horns:0,spikes:0,archetype:'hybrid-winged-quadruped'});return{parts:[creaturePart('GriffinAssembly',d)],materials:[MAT.feather,MAT.fur,MAT.horn],defaultTris:explicitTarget(prompt,16000),creationClass:'FantasyCreature'};}
function wolf(prompt){const d=details('wolf',prompt,{length:1.65,height:.95,width:.48,limbs:4,wings:0,tail:1,neck:.12,horns:0,spikes:0,archetype:'quadruped-mammal'});return{parts:[creaturePart('WolfAssembly',d)],materials:[colorised(MAT.fur,prompt),MAT.horn],defaultTris:explicitTarget(prompt,8000),creationClass:'QuadrupedMammal'};}
function spider(prompt){const d=details('spider',prompt,{length:1.4,height:.55,width:1.1,limbs:8,wings:0,tail:0,neck:0,horns:0,spikes:0,archetype:'arachnid'});return{parts:[creaturePart('SpiderAssembly',d)],materials:[colorised(MAT.chitin,prompt)],defaultTris:explicitTarget(prompt,10000),creationClass:'Arachnid'};}
function snake(prompt){const d=details('snake',prompt,{length:3.1,height:.42,width:.38,limbs:0,wings:0,tail:1,neck:.08,horns:0,spikes:0,archetype:'serpent'});return{parts:[creaturePart('SnakeAssembly',d)],materials:[colorised(MAT.scales,prompt)],defaultTris:explicitTarget(prompt,7000),creationClass:'Serpent'};}
function bird(prompt){const d=details('bird',prompt,{length:.85,height:.62,width:.42,limbs:2,wings:2,tail:1,neck:.10,horns:0,spikes:0,archetype:'avian'});return{parts:[creaturePart('BirdAssembly',d)],materials:[colorised(MAT.feather,prompt),MAT.horn],defaultTris:explicitTarget(prompt,8000),creationClass:'Bird'};}
function fish(prompt){const d=details('fish',prompt,{length:1.15,height:.48,width:.34,limbs:0,wings:0,tail:1,neck:0,horns:0,spikes:0,archetype:'aquatic'});return{parts:[creaturePart('FishAssembly',d)],materials:[colorised(MAT.wetSkin,prompt)],defaultTris:explicitTarget(prompt,6000),creationClass:'AquaticCreature'};}

const CREATURES=Object.freeze([
  ['dragon','Dragon','Fantasy creature',/\bdragon\b/,dragon],
  ['wyvern','Wyvern','Fantasy creature',/\bwyvern\b/,wyvern],
  ['griffin','Griffin','Fantasy creature',/\bgriff(?:in|on)\b/,griffin],
  ['wolf','Wolf','Quadruped mammal',/\b(?:wolf|dire wolf)\b/,wolf],
  ['giant-spider','Giant spider','Arachnid',/\b(?:giant\s+)?spider\b|\barachnid\b/,spider],
  ['snake','Snake','Serpent',/\b(?:snake|serpent|viper|cobra)\b/,snake],
  ['bird','Bird','Bird',/\b(?:bird|eagle|raven|crow|owl|hawk)\b/,bird],
  ['fish','Fish','Aquatic creature',/\b(?:fish|salmon|trout|carp|piranha)\b/,fish]
].map(([id,name,category,pattern,build])=>Object.freeze({id,name,category,pattern,build})));

export function creatureCatalogue(){return CREATURES.map(({id,name,category})=>({id,name,category,status:'ready',execution:'local',editable:true,organic:true}));}
export function creatureStyleProfiles(){return [...STYLE_PROFILES];}
export function buildCreaturePlan(prompt){const lower=String(prompt??'').toLowerCase();const grammar=CREATURES.find(g=>g.pattern.test(lower));if(!grammar)return null;const plan=grammar.build(prompt);return{grammarId:grammar.id,assetClass:safeAssetName(grammar.name.replace(/\s+/g,'')),category:grammar.category,plan};}
export function isCreatureGrammarId(id){return CREATURES.some(g=>g.id===id);}
