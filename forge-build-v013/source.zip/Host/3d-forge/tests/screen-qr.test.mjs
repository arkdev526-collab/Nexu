import {readFileSync} from 'node:fs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ScreenShare} from '../screen-share.mjs';
import {pairingQr} from '../pairing-qr.mjs';
const frame={width:800,height:600,base64:readFileSync(new URL('./fixtures/screen.jpg',import.meta.url)).toString('base64')};
test('screen is private to selected device, expires and stops',()=>{
 let now=1000;const s=new ScreenShare({now:()=>now});assert.deepEqual(s.read('a'),{active:false});
 const {sessionId}=s.start('a');s.publish({...frame,sessionId});assert.equal(s.read('a').active,true);assert.equal(s.read('b').active,false);
 now+=5001;assert.equal(s.read('a').active,false);s.publish({...frame,sessionId});assert.equal(s.read('a').active,true);
 const next=s.start('a');s.publish({...frame,...next});s.stop();assert.equal(s.read('a').active,false);
});
test('replaced sessions cannot publish and invalid frames are rejected',()=>{
 const s=new ScreenShare(),old=s.start('a'),next=s.start('b');assert.throws(()=>s.publish({...frame,...old}));
 for(const extra of [{width:99999},{height:0},{base64:'<svg>'},{base64:'A'.repeat(700001)},{base64:'AAAA'}])assert.throws(()=>s.publish({...frame,...next,...extra}));
 assert.equal(s.read('b').active,false);
});
test('QR generates locally with quiet zone and rejects arbitrary content',()=>{
 const uri='nexuforge://pair?v=1&host=192.168.0.177&port=53971&offer=DAEAA545&secret=ABCDEFGHIJKLMNOP';
 const result=pairingQr(uri);assert.match(result,/^data:image\/svg\+xml;base64,/);
 const svg=Buffer.from(result.split(',')[1],'base64').toString();assert.match(svg,/shape-rendering="crispEdges"/);assert.match(svg,/fill="white"/);assert.throws(()=>pairingQr('https://example.com'));
});
test('old tab stop cannot stop a new sharing session, and unchanged frames omit pixels',()=>{
 const s=new ScreenShare(),old=s.start('a'),next=s.start('b');s.publish({...frame,...next});
 assert.equal(s.stop(old.sessionId).stopped,false);const received=s.read('b');assert.equal(received.active,true);
 const same=s.read('b',received.sequence,next.sessionId);assert.equal(same.unchanged,true);assert.equal(same.base64,undefined);
 assert.equal(s.read('b',received.sequence,old.sessionId).unchanged,false);
 assert.throws(()=>s.publish({...frame,...next,width:10}),/dimensions/);
});
