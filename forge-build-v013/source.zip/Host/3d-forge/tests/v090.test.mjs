import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { grammarCatalogue } from '../asset-grammar.mjs';
import { planPrompt } from '../planner.mjs';
import { interpretBrief } from '../brief.mjs';
import { creationKnowledgeSummary } from '../creation-intelligence.mjs';
import { creatureCatalogue } from '../creature-grammar.mjs';
import { planRefinement } from '../refine.mjs';
import { materialPresets } from '../material-intelligence.mjs';
import { LearningLedger } from '../learning-ledger.mjs';
import { validateRecipe } from '../schema.mjs';

const here=dirname(fileURLToPath(import.meta.url));
const forge=resolve(here,'..');
const root=resolve(forge,'..');

const creatureCases=[
  ['large medieval fantasy dragon with dark scales four legs torn wings and horned head','dragon',4,2],
  ['dark fantasy wyvern with torn wings','wyvern',2,2],
  ['ancient griffin','griffin',4,2],
  ['scarred wolf','wolf',4,0],
  ['giant poisonous spider','giant-spider',8,0],
  ['long green snake','snake',0,0],
  ['weathered raven bird','bird',2,2],
  ['large blue fish','fish',0,0]
];

test('v0.9 Creation Knowledge exposes eight permanent local creature foundations',()=>{
  const creatures=creatureCatalogue();
  assert.equal(creatures.length,8);
  for(const id of ['dragon','wyvern','griffin','wolf','giant-spider','snake','bird','fish'])assert.ok(creatures.some(x=>x.id===id),id);
  assert.ok(creatures.every(x=>x.status==='ready'&&x.execution==='local'&&x.editable&&x.organic));
  const all=grammarCatalogue();assert.ok(all.length>=31,`expected >=31 total grammars, got ${all.length}`);
  const summary=creationKnowledgeSummary();assert.equal(summary.creatureGrammars,8);assert.equal(summary.localOnly,true);assert.equal(summary.paidProviders,0);assert.equal(summary.arbitraryCode,false);
});

test('v0.9 creature prompts route to bounded organic grammar recipes with correct anatomy',()=>{
  for(const [prompt,id,limbs,wings] of creatureCases){
    const r=planPrompt(prompt,{profile:'generic'});assert.equal(r.grammarId,id);assert.equal(r.parts.length,1);assert.equal(r.parts[0].type,'procedural_creature');assert.equal(r.parts[0].details.limbCount,limbs);assert.equal(r.parts[0].details.wingCount,wings);assert.ok(r.targetTriangles>=500);assert.ok(r.materials.length>=1);
  }
  const dragon=planPrompt('create a large medievil dragon with black scales torn wings and huge horns around 22000 triangles for ASA with 3 LODs');
  assert.equal(dragon.profile,'unreal-asa');assert.equal(dragon.targetTriangles,22000);assert.equal(dragon.lods,2);assert.equal(dragon.parts[0].details.styleProfile,'medieval-fantasy');assert.equal(dragon.parts[0].details.tornWings,true);assert.ok(dragon.parts[0].details.hornScale>.4);
  assert.ok(dragon.materials.some(m=>m.style==='scales'));assert.ok(dragon.materials.some(m=>m.style==='membrane'));assert.ok(dragon.materials.some(m=>m.style==='bone'));
});

test('v0.9 brief interpreter understands creature semantics and common medieval misspelling',()=>{
  const b=interpretBrief('Create a medievil dragon with black scales and torn wings','unreal-asa');
  assert.equal(b.subject,'Dragon');assert.equal(b.style,'medieval');assert.match(b.construction,/Organic Fantasy creature grammar/);assert.match(b.target,/creature/i);assert.equal(b.privacy,'local');
});

test('v0.9 validator rejects anatomically inconsistent creature recipes before Blender',()=>{
  const r=planPrompt('medieval dragon');const bad=structuredClone(r);bad.parts[0].details.limbCount=2;
  assert.throws(()=>validateRecipe(bad),/does not match dragon foundation anatomy/);
  const badKind=structuredClone(r);badKind.parts[0].details.creatureKind='remote_python_dragon';
  assert.throws(()=>validateRecipe(badKind),/creatureKind.*not allowed/);
});

test('v0.9 non-destructive creature refinement supports morphology without arbitrary code',()=>{
  const r=planPrompt('medieval dragon with torn wings');
  const p=planRefinement(r,'make the wings 20% larger, tail longer, horns smaller and body bulkier with more spikes');
  assert.ok(p.changes.some(x=>x.path.endsWith('.wingSpan')));assert.ok(p.changes.some(x=>x.path.endsWith('.tailLength')));assert.ok(p.changes.some(x=>x.path.endsWith('.hornScale')));assert.ok(p.changes.some(x=>x.path.endsWith('.bodyBulk')));assert.ok(p.changes.some(x=>x.path.endsWith('.dorsalSpikes')));assert.equal(p.safe,true);
});

test('v0.9 local learning stores creature morphology and derives bounded accepted medians',async t=>{
  const dir=await mkdtemp(join(tmpdir(),'nexu-creature-learning-'));t.after(()=>rm(dir,{recursive:true,force:true}));const ledger=new LearningLedger(dir);
  const r1=planPrompt('medieval dragon with huge wings around 18000 triangles');const r2=planPrompt('ancient dragon with large horns around 22000 triangles');
  const report={assetName:r1.assetName,qualityScore:92,triangles:18000,targetTriangles:18000};await ledger.add({directory:'dragon/v1',report,recipe:r1,verdict:'good'});await ledger.add({directory:'dragon/v2',report:{...report,targetTriangles:22000},recipe:r2,verdict:'good'});
  const rows=await ledger.rows();assert.equal(rows.length,2);assert.equal(rows[0].creatureMorphology.kind,'dragon');assert.ok(Number.isFinite(rows[0].creatureMorphology.wingSpanRatio));
  const s=await ledger.suggestion('dragon');assert.equal(s.goodCount,2);assert.equal(s.recommendedTargetTriangles,20000);assert.ok(s.recommendedMorphology);assert.ok(s.recommendedMorphology.wingSpanRatio>0);
});

test('v0.9 creature material intelligence exposes owned PBR presets',()=>{
  const ids=new Set(materialPresets().map(x=>x.id));for(const id of ['dragon-scales','wing-membrane','horn-and-claw','coarse-fur','dark-chitin'])assert.ok(ids.has(id),id);
});

test('v0.9 Blender worker contains real organic guide-volume, voxel-remesh, wing and anatomy evidence stages',async()=>{
  const worker=await readFile(join(forge,'blender-worker.py'),'utf8');
  assert.match(worker,/def create_procedural_creature\(/);assert.match(worker,/def join_voxel_body\(/);assert.match(worker,/type='REMESH'/);assert.match(worker,/mode='VOXEL'/);assert.match(worker,/def add_membrane\(/);assert.match(worker,/organicRemesh':True/);assert.match(worker,/creatureKind/);
  assert.doesNotMatch(worker,/\bexec\s*\(/);assert.doesNotMatch(worker,/\beval\s*\(/);
});

test('v0.9 Studio and Windows payload expose Creation Intelligence without paid provider dependency',async()=>{
  const [server,html,app,build]=await Promise.all([readFile(join(forge,'studio-server.mjs'),'utf8'),readFile(join(forge,'studio','index.html'),'utf8'),readFile(join(forge,'studio','app.js'),'utf8'),readFile(join(root,'packaging','build-windows-candidate.go'),'utf8')]);
  assert.match(server,/const appVersion = '0\.13\.0'/);assert.match(server,/creationKnowledgeSummary/);assert.match(server,/\/api\/creation-knowledge/);
  assert.match(html,/Medieval dragon/);assert.match(html,/Dragon scales/);assert.match(html,/Creation Intelligence & Learning/);assert.match(app,/organic creature foundations/);
  assert.match(build,/expectedVersion = "0\.13\.0"/);assert.match(build,/creature-grammar\.mjs/);assert.match(build,/creation-intelligence\.mjs/);
});
