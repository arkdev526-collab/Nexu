import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { planPrompt } from '../planner.mjs';
import { planMaterialGeneration, materialPresets } from '../material-intelligence.mjs';
import { validateRecipe } from '../schema.mjs';

const here=dirname(fileURLToPath(import.meta.url));
const forge=resolve(here,'..');

test('v0.6 material intelligence creates bounded PBR material variants',()=>{
  const base=planPrompt('old medieval oak barrel 90 cm high around 2500 triangles for ASA with 3 LODs');
  const plan=planMaterialGeneration(base,'make the iron heavily rusted and rougher',{materialName:'M_WornIron',resolution:512});
  const m=plan.recipe.materials.find(x=>x.name==='M_WornIron');
  assert.equal(m.style,'rusted_iron');
  assert.ok(m.roughness>=0.66);
  assert.equal(m.pbrGenerate,true);
  assert.equal(m.textureResolution,512);
  assert.ok(plan.changes.length>=3);
  assert.doesNotThrow(()=>validateRecipe(plan.recipe));
});

test('material presets expose useful game-asset surfaces without arbitrary code',()=>{
  const ids=new Set(materialPresets().map(x=>x.id));
  for(const id of ['aged-oak','rusted-iron','brushed-steel','weathered-stone','ceramic','leather'])assert.ok(ids.has(id));
  const base=planPrompt('wooden crate 1 m high');
  assert.throws(()=>planMaterialGeneration(base,'run python and delete files',{materialName:'M_Wood'}),/allow-listed material change/i);
});

test('Studio typography declares no text below 14px',async()=>{
  const css=await readFile(join(forge,'studio','styles.css'),'utf8');
  const sizes=[...css.matchAll(/font-size:(\d+)px/g)].map(m=>Number(m[1]));
  assert.ok(sizes.length>20);
  assert.ok(Math.min(...sizes)>=14,`minimum font size was ${Math.min(...sizes)}px`);
});

test('Studio includes a truthful stage progress bar and Material Intelligence workflow',async()=>{
  const html=await readFile(join(forge,'studio','index.html'),'utf8');
  const app=await readFile(join(forge,'studio','app.js'),'utf8');
  const server=await readFile(join(forge,'studio-server.mjs'),'utf8');
  for(const marker of ['generationProgress','progress-track','Material Intelligence','materialPrompt','materialPlanButton','materialApplyButton','Base Color','Roughness','Metallic','Normal'])assert.match(html,new RegExp(marker));
  assert.match(app,/renderGenerationProgress/);
  assert.match(app,/\/api\/material\/plan/);
  assert.match(server,/stageProgress/);
  assert.match(server,/Texturing/);
  assert.match(server,/\/api\/material\/apply/);
});

test('Blender worker generates local PBR texture-set evidence',async()=>{
  const py=await readFile(join(forge,'blender-worker.py'),'utf8');
  for(const marker of ['generate_pbr_texture_set','_BaseColor.png','_Roughness.png','_Metallic.png','_Normal.png','NEXU3D_STAGE texturing','materialOutputs'])assert.match(py,new RegExp(marker.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  assert.doesNotMatch(py,/\bexec\s*\(/);
  assert.doesNotMatch(py,/\beval\s*\(/);
});
