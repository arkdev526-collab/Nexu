import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { grammarCatalogue } from '../asset-grammar.mjs';
import { planPrompt } from '../planner.mjs';
import { LearningLedger } from '../learning-ledger.mjs';
import { REFERENCE_PROVIDERS } from '../reference-providers.mjs';

const here=dirname(fileURLToPath(import.meta.url));
const forge=resolve(here,'..');
const root=resolve(forge,'..');

test('v0.8 local Asset Grammar Library exposes at least 20 ready editable model families',()=>{
  const catalogue=grammarCatalogue();
  assert.ok(catalogue.length>=20,`expected >=20 grammars, got ${catalogue.length}`);
  for(const id of ['barrel','chest','chair','cupboard','stairs','log','stump','crystal-cluster','lantern','weapon-rack','bridge-section'])assert.ok(catalogue.some(x=>x.id===id),id);
  assert.ok(catalogue.every(x=>x.status==='ready'&&x.execution==='local'&&x.editable===true));
});

test('v0.8 planner preserves schema 1.2 while adding grammar identity, mesh repair and local dataset capture',()=>{
  const cases=[
    ['weathered treasure chest 70 cm high','chest'],
    ['old iron lantern 45 cm high','lantern'],
    ['wooden bridge 3 m long','bridge-section'],
    ['weapon rack 1.7 m high','weapon-rack'],
    ['tree stump 70 cm high','stump']
  ];
  for(const [prompt,id] of cases){const recipe=planPrompt(prompt);assert.equal(recipe.schemaVersion,'1.2');assert.equal(recipe.grammarId,id);assert.ok(recipe.assetClass);assert.ok(recipe.parts.length>=1);assert.equal(recipe.quality.autoMeshRepair,true);assert.equal(recipe.quality.datasetCapture,true);assert.equal(recipe.quality.datasetViewSize,512);}
});

test('v0.8 learning ledger stores explicit local preference evidence without image bytes',async t=>{
  const dir=await mkdtemp(join(tmpdir(),'nexu-learning-'));t.after(()=>rm(dir,{recursive:true,force:true}));
  const ledger=new LearningLedger(dir);const recipe=planPrompt('old wooden chair 1 m high');const report={assetName:recipe.assetName,qualityScore:91,triangles:1700,targetTriangles:1800};
  const row=await ledger.add({directory:'SM_Chair/v1',report,recipe,verdict:'good',source:'desktop'});
  assert.equal(row.verdict,'good');assert.equal(row.grammarId,'chair');assert.equal(row.recipeSha256.length,64);assert.equal('image' in row,false);
  await ledger.add({directory:'SM_Chair/v2',report,recipe,verdict:'needs-work',note:'Back is too heavy',source:'android'});
  const stats=await ledger.stats();assert.equal(stats.total,2);assert.equal(stats.good,1);assert.equal(stats.needsWork,1);assert.equal(stats.localOnly,true);assert.equal(stats.containsImageBytes,false);
  const early=await ledger.suggestion('chair');assert.equal(early.applyAutomatically,false);
  await ledger.add({directory:'SM_Chair/v3',report:{...report,targetTriangles:2200,qualityScore:94},recipe,verdict:'good',source:'desktop'});
  const learned=await ledger.suggestion('chair');assert.equal(learned.applyAutomatically,true);assert.equal(learned.goodCount,2);assert.equal(learned.recommendedTargetTriangles,2000);assert.ok(learned.confidence>0);
});

test('v0.8 dataset capture and safe mesh repair are real Blender worker stages',async()=>{
  const worker=await readFile(join(forge,'blender-worker.py'),'utf8');
  assert.match(worker,/def repair_meshes\(objects\):/);assert.match(worker,/bmesh\.ops\.remove_doubles/);assert.match(worker,/bmesh\.ops\.recalc_face_normals/);
  assert.match(worker,/NEXU3D_STAGE dataset/);assert.match(worker,/nexu\.forge\.dataset\.v1/);assert.match(worker,/dataset-record\.json/);
  for(const view of ['front.png','back.png','left.png','right.png','top.png','bottom.png','perspective.png'])assert.match(worker,new RegExp(view.replace('.','\\.')));
  assert.match(worker,/containsReferenceImageBytes':False/);
});

test('v0.8 Studio exposes local learning feedback, grammar catalogue and truthful eight-stage generation progress',async()=>{
  const server=await readFile(join(forge,'studio-server.mjs'),'utf8');
  const html=await readFile(join(forge,'studio','index.html'),'utf8');
  const app=await readFile(join(forge,'studio','app.js'),'utf8');
  const currentVersion=(await readFile(join(root,'VERSION.txt'),'utf8')).trim();
  assert.match(server,new RegExp(`const appVersion = '${currentVersion.replaceAll('.', '\\.')}'`));assert.match(server,/\/api\/grammar/);assert.match(server,/\/api\/learning\/feedback/);assert.match(server,/\/api\/learning\/suggestion/);assert.match(server,/applyLearnedDefaults/);assert.match(server,/NEXU3D_STAGE\\s\+\(materials\|texturing\|modelling\|collision\|validation\|dataset\|exporting\)/);
  assert.match(html,/(?:Learning & Dataset Lab|Creation Intelligence & Learning)/);assert.match(html,/Good result/);assert.match(html,/Needs work/);assert.match(html,/Stage 1 of 8/);
  assert.match(app,/submitFeedback\('good'\)/);assert.match(app,/submitFeedback\('needs-work'\)/);assert.match(app,/\/api\/learning\/stats/);assert.match(app,/Local accepted-result learning was applied safely/);
});

test('v0.8 final-only provider policy keeps only the owned procedural provider available by default',()=>{
  const available=REFERENCE_PROVIDERS.filter(x=>x.status==='available');assert.deepEqual(available.map(x=>x.id),['procedural-reference']);
  const tripo=REFERENCE_PROVIDERS.find(x=>x.id==='triposr');assert.equal(tripo.status,'evaluated-not-integrated');assert.equal(tripo.licence,'MIT');
});

test('v0.8 new runtime modules do not introduce arbitrary shell or eval execution',async()=>{
  for(const file of ['asset-grammar.mjs','learning-ledger.mjs']){const src=await readFile(join(forge,file),'utf8');assert.doesNotMatch(src,/\beval\s*\(/);assert.doesNotMatch(src,/\bexec\s*\(/);assert.doesNotMatch(src,/shell\s*:\s*true/);}
});

test('v0.8 Windows candidate payload includes permanent grammar and learning runtime modules',async()=>{
  const build=await readFile(join(root,'packaging','build-windows-candidate.go'),'utf8');
  const setup=await readFile(join(root,'packaging','setup-native','main.go'),'utf8');
  const currentVersion=(await readFile(join(root,'VERSION.txt'),'utf8')).trim();
  assert.match(build,new RegExp(`expectedVersion = \"${currentVersion.replaceAll('.', '\\.') }\"`));assert.match(build,/asset-grammar\.mjs/);assert.match(build,/learning-ledger\.mjs/);assert.match(setup,new RegExp(`const version = \"${currentVersion.replaceAll('.', '\\.') }\"`));
});
