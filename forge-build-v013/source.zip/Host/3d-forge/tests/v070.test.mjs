import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CompanionService, privateAddress } from '../companion-server.mjs';
import { derivePairingKey, fromB64url, open, seal } from '../companion-crypto.mjs';

const here=dirname(fileURLToPath(import.meta.url));
const forge=resolve(here,'..');
const root=resolve(forge,'..');

function secretFromDisplay(code){return code.replace(/-/g,'').slice(8);}

test('v0.7 companion crypto is AES-GCM authenticated, time-bounded and rejects tampering/replay',()=>{
  const key=derivePairingKey('ABCDEFGHJKLMNPQR');
  const env=seal(key,{hello:'forge'},'rpc:device-a',{now:100000});
  assert.equal(open(key,env,'rpc:device-a',{now:100001}).hello,'forge');
  const altered=(env.ciphertext.startsWith('A')?'B':'A')+env.ciphertext.slice(1); assert.throws(()=>open(key,{...env,ciphertext:altered},'rpc:device-a',{now:100001}),/authenticate|invalid|Unsupported|operation/i);
  assert.throws(()=>open(key,env,'rpc:device-a',{now:100000+6*60*1000}),/expired/i);
  const cache=new Set(); assert.equal(open(key,env,'rpc:device-a',{now:100001,nonceCache:cache}).hello,'forge'); assert.throws(()=>open(key,env,'rpc:device-a',{now:100001,nonceCache:cache}),/Replay rejected/);
});

test('v0.7 companion service performs one-use out-of-band pairing and encrypted allow-listed RPC',async t=>{
  const data=await mkdtemp(join(tmpdir(),'nexu-companion-'));
  const service=new CompanionService({version:'0.7.0',runtimeRoot:data,port:0,addressProvider:()=>['192.168.1.44'],handlers:{echo:async p=>({value:p.value})}});
  await service.start(); t.after(async()=>{await service.close();await rm(data,{recursive:true,force:true});});
  const offer=service.createPairingOffer(),pairKey=derivePairingKey(secretFromDisplay(offer.pairingCode)),deviceId='android-testdevice';
  const pair=seal(pairKey,{deviceId,name:'Forge Test Tablet'},`pair:${offer.offerCode}`);
  const pr=await fetch(`http://127.0.0.1:${service.port}/companion/v1/pair`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({offer:offer.offerCode,envelope:pair})});
  assert.equal(pr.status,200); const pj=await pr.json(); const paired=open(pairKey,pj.envelope,`pair:${offer.offerCode}:${pair.nonce}`); assert.equal(paired.deviceId,deviceId);
  const deviceKey=fromB64url(paired.deviceSecret,'device secret');
  const rpc=seal(deviceKey,{method:'echo',params:{value:42}},`rpc:${deviceId}`);
  const rr=await fetch(`http://127.0.0.1:${service.port}/companion/v1/rpc`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({deviceId,envelope:rpc})});
  assert.equal(rr.status,200); const rj=await rr.json(); const result=open(deviceKey,rj.envelope,`rpc:${deviceId}:${rpc.nonce}`); assert.equal(result.result.value,42);
  const replay=await fetch(`http://127.0.0.1:${service.port}/companion/v1/rpc`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({deviceId,envelope:rpc})}); assert.equal(replay.status,400);
});

test('companion server accepts only private/local addresses and never exposes shell or Python RPC',async()=>{
  assert.equal(privateAddress('192.168.1.2'),true); assert.equal(privateAddress('10.0.0.5'),true); assert.equal(privateAddress('172.31.4.5'),true); assert.equal(privateAddress('8.8.8.8'),false);
  const server=await readFile(join(forge,'companion-server.mjs'),'utf8');
  assert.match(server,/Companion operation is not allow-listed/); assert.doesNotMatch(server,/\bshell\s*:\s*true/); assert.doesNotMatch(server,/\bexec\s*\(/); assert.doesNotMatch(server,/python/i);
});

test('Windows Studio exposes explicit Android pairing controls without weakening loopback Studio auth',async()=>{
  const html=await readFile(join(forge,'studio','index.html'),'utf8'),app=await readFile(join(forge,'studio','app.js'),'utf8'),server=await readFile(join(forge,'studio-server.mjs'),'utf8');
  for(const marker of ['Android Companion','createPairing','pairingOffer','pairedDevices'])assert.match(html,new RegExp(marker));
  assert.match(app,/\/api\/companion\/pairing/); assert.match(app,/data-revoke-device/); assert.match(server,/const host = '127\.0\.0\.1'/); assert.match(server,/createCompanionService/);
});

test('Android Creator Companion is pinned to stable .NET 10, MAUI 10.0.90, API 36 and 14sp minimum UI',async()=>{
  const csproj=await readFile(join(root,'mobile','NexuAI3DForge.Android','NexuAI3DForge.Android.csproj'),'utf8');
  const global=JSON.parse(await readFile(join(root,'global.json'),'utf8'));
  const styles=await readFile(join(root,'mobile','NexuAI3DForge.Android','Resources','Styles','Styles.xaml'),'utf8');
  assert.equal(global.sdk.version,'10.0.400'); assert.equal(global.sdk.allowPrerelease,false);
  assert.match(csproj,/<TargetFramework>net10\.0-android<\/TargetFramework>/); assert.match(csproj,/<MauiVersion>10\.0\.90<\/MauiVersion>/); assert.match(csproj,/<SupportedOSPlatformVersion>30\.0<\/SupportedOSPlatformVersion>/); assert.match(csproj,/<ApplicationId>uk\.co\.sumerostudio\.nexuai3dforge<\/ApplicationId>/);
  const sizes=[...styles.matchAll(/FontSize" Value="(\d+(?:\.\d+)?)/g)].map(m=>Number(m[1])); assert.ok(sizes.length>=3); assert.ok(Math.min(...sizes)>=14,`Android minimum font size was ${Math.min(...sizes)}sp`);
});

test('Android app contains touch-first creation, truthful progress, reference, refine, material, library, queue and secure pairing surfaces',async()=>{
  const create=await readFile(join(root,'mobile','NexuAI3DForge.Android','Pages','CreatePage.xaml'),'utf8');
  const code=await readFile(join(root,'mobile','NexuAI3DForge.Android','Pages','CreatePage.xaml.cs'),'utf8');
  const settings=await readFile(join(root,'mobile','NexuAI3DForge.Android','Pages','SettingsPage.xaml'),'utf8');
  const viewer=await readFile(join(root,'mobile','NexuAI3DForge.Android','Resources','Raw','viewer.html'),'utf8');
  for(const marker of ['Generate','GenerationProgress','Add reference image','REFINE','MATERIAL INTELLIGENCE','Live 3D viewport','LodPicker'])assert.match(create,new RegExp(marker));
  assert.match(code,/job\.get/); assert.match(code,/Stage \{Math\.Max\(1,index\)\} of/); assert.match(code,/reference\.upload/); assert.match(code,/material\.apply/); assert.match(settings,/AES-256-GCM/); assert.match(viewer,/touchstart/); assert.match(viewer,/loadForgeGlb/); assert.match(viewer,/forgeTransferChunk/); assert.match(viewer,/webgl2/);
});


test('Android transport hardening disables backup of pairing secrets and binds encrypted responses to request nonces',async()=>{
  const manifest=await readFile(join(root,'mobile','NexuAI3DForge.Android','Platforms','Android','AndroidManifest.xml'),'utf8');
  const client=await readFile(join(root,'mobile','NexuAI3DForge.Android','Services','ForgeCompanionClient.cs'),'utf8');
  const server=await readFile(join(forge,'companion-server.mjs'),'utf8');
  assert.match(manifest,/android:allowBackup="false"/);
  assert.match(client,/rpc:\{_deviceId\}:\{envelope\.Nonce\}/);
  assert.match(server,/rpc:\$\{deviceId\}:\$\{body\.envelope\.nonce\}/);
});

test('Android one-click handoff uses read-only Doctor and official SignAndroidPackage build target',async()=>{
  const doctor=await readFile(join(root,'DOCTOR-ANDROID.ps1'),'utf8');
  const build=await readFile(join(root,'BUILD-ANDROID-AND-INSTALL.ps1'),'utf8');
  assert.match(doctor,/10\.0\.4xx feature band/);
  assert.match(doctor,/platforms\\android-36/);
  assert.doesNotMatch(doctor,/workload\s+install/i);
  assert.doesNotMatch(doctor,/Invoke-WebRequest/i);
  assert.match(build,/-t:SignAndroidPackage/);
  assert.match(build,/AndroidKeyStore=false/);
  assert.match(build,/@\('install','-r'/);
  assert.match(build,/Nexu-AI-3D-Forge-Android-v0\.10\.1\.apk/);
});
