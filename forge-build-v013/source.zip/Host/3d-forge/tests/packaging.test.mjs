import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)); const root=resolve(here,'..','..');

test('native one-file installer preserves Documents data and uses verified versioned application directories', async()=>{
  const src=await readFile(join(root,'packaging','setup-native','main.go'),'utf8');
  assert.match(src,/Documents/); assert.match(src,/Nexu AI 3D Forge/); assert.match(src,/versions/); assert.match(src,/current-version\.txt/); assert.match(src,/PACKAGE-MANIFEST\.sha256/); assert.match(src,/sha256\.Sum256/); assert.match(src,/preserved|preserve/i);
});

test('native dependency bootstrap stays exact and does not weaken WinGet security', async()=>{
  const src=await readFile(join(root,'packaging','setup-native','main.go'),'utf8');
  assert.match(src,/OpenJS\.NodeJS\.LTS/); assert.match(src,/24\.19\.0/); assert.match(src,/BlenderFoundation\.Blender/); assert.match(src,/5\.2\.0/); assert.doesNotMatch(src,/ignore-security-hash/i); assert.doesNotMatch(src,/ExecutionPolicy\s+(?:Bypass|Unrestricted)/i);
});

test('installer supports Installed Apps, shortcuts, uninstall and rollback while preserving user assets', async()=>{
  const src=await readFile(join(root,'packaging','setup-native','main.go'),'utf8');
  assert.match(src,/CurrentVersion\\Uninstall\\NexuAI3DForge/); assert.match(src,/--uninstall/); assert.match(src,/--rollback/); assert.match(src,/Start Menu/); assert.match(src,/Desktop/); assert.match(src,/generated assets in Documents will be preserved/i);
});

test('native application launcher hides helper processes and opens local app-mode Edge without a shell', async()=>{
  const src=await readFile(join(root,'packaging','native-launcher','main.go'),'utf8');
  assert.match(src,/exec\.Command/); assert.match(src,/--app=/); assert.match(src,/127\.0\.0\.1/); assert.match(src,/HideWindow:\s*true/); assert.doesNotMatch(src,/cmd\.exe|powershell/i);
});

test('Windows release builder pins current supported Go 1.26.6 and verifies the official archive hash before compiling', async()=>{
  const build=await readFile(join(root,'packaging','build-windows-candidate.go'),'utf8');
  const cmd=await readFile(join(root,'BUILD-WINDOWS-CANDIDATE.cmd'),'utf8');
  const launcherMod=await readFile(join(root,'packaging','native-launcher','go.mod'),'utf8');
  const setupMod=await readFile(join(root,'packaging','setup-native','go.mod'),'utf8');
  assert.match(build,/expectedGoVersion = "go1\.26\.6"/); assert.match(cmd,/5b6c5b556525810463b5c897b50dc7a82d6a3dc0bfaf55d990a7e9f31d6b2318/); assert.match(cmd,/certutil\.exe -hashfile/); assert.match(cmd,/GOTOOLCHAIN=local/); assert.doesNotMatch(cmd,/ExecutionPolicy|\-File .*\.ps1/i);
  assert.match(launcherMod,/go 1\.26\.0/); assert.match(launcherMod,/toolchain go1\.26\.6/); assert.match(setupMod,/toolchain go1\.26\.6/);
});
