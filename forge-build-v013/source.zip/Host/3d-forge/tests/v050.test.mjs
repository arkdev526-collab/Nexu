import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { interpretBrief } from '../brief.mjs';
import { planPrompt } from '../planner.mjs';
import { planRefinement } from '../refine.mjs';
import { providerCatalogue } from '../reference-providers.mjs';
import { applyReferenceGuidance, validateReferenceEvidence } from '../reference-guidance.mjs';
import { extractGlbGeometry, parseGlb } from '../studio/viewport.js';
import { validateUpdateManifest, compareVersions, readFixtureManifest } from '../update-client.mjs';

const root=resolve(import.meta.dirname,'../..');
function pad4(buf,pad=0x20){const n=(4-(buf.length%4))%4;return n?Buffer.concat([buf,Buffer.alloc(n,pad)]):buf;}
function tinyGlb(){
  const pos=Buffer.alloc(36);[0,0,0,1,0,0,0,1,0].forEach((v,i)=>pos.writeFloatLE(v,i*4));
  const idx=Buffer.alloc(6);[0,1,2].forEach((v,i)=>idx.writeUInt16LE(v,i*2));
  const bin=pad4(Buffer.concat([pos,idx]),0);
  const json={asset:{version:'2.0'},scene:0,scenes:[{nodes:[0]}],nodes:[{mesh:0}],meshes:[{primitives:[{attributes:{POSITION:0},indices:1}]}],buffers:[{byteLength:bin.length}],bufferViews:[{buffer:0,byteOffset:0,byteLength:36},{buffer:0,byteOffset:36,byteLength:6}],accessors:[{bufferView:0,componentType:5126,count:3,type:'VEC3',min:[0,0,0],max:[1,1,0]},{bufferView:1,componentType:5123,count:3,type:'SCALAR'}]};
  const jb=pad4(Buffer.from(JSON.stringify(json),'utf8'),0x20),total=12+8+jb.length+8+bin.length,b=Buffer.alloc(total);let o=0;
  b.writeUInt32LE(0x46546c67,o);o+=4;b.writeUInt32LE(2,o);o+=4;b.writeUInt32LE(total,o);o+=4;b.writeUInt32LE(jb.length,o);o+=4;b.writeUInt32LE(0x4e4f534a,o);o+=4;jb.copy(b,o);o+=jb.length;b.writeUInt32LE(bin.length,o);o+=4;b.writeUInt32LE(0x004e4942,o);o+=4;bin.copy(b,o);return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);
}

test('Brief Interpreter identifies subject, period conflict and review state without hiding the conflict',()=>{
  const b=interpretBrief('a huge old medieval wooden barrel but also futuristic for ASA','unreal-asa');
  assert.equal(b.subject,'Wooden barrel'); assert.equal(b.target,'Unreal / ASA static prop'); assert.equal(b.confidence,'review'); assert.match(b.conflicts[0],/medieval and futuristic/i);
});

test('non-destructive refinement returns validated structured diffs and leaves source recipe untouched',()=>{
  const base=planPrompt('old medieval oak barrel 90 cm high around 2500 triangles for ASA with 3 LODs'),before=JSON.stringify(base);
  const p=planRefinement(base,'make it wider and use three hoops and reduce it to 1800 triangles');
  assert.equal(JSON.stringify(base),before); assert.equal(p.safe,true); assert.equal(p.recipe.targetTriangles,1800); assert.equal(p.recipe.parts[0].details.hoopCount,3); assert.ok(p.recipe.parts[0].details.bellyRadius>base.parts[0].details.bellyRadius); assert.ok(p.changes.length>=3); assert.throws(()=>planRefinement(base,'run python to delete files'),/allow-listed/i);
});

test('reference provider catalogue blocks unsuitable defaults rather than pretending all models are supported',()=>{
  const by=Object.fromEntries(providerCatalogue().map(x=>[x.id,x]));
  assert.equal(by['procedural-reference'].status,'available'); assert.equal(by.triposr.status,'evaluated-not-integrated'); assert.equal(by['hunyuan3d-2.1'].status,'blocked'); assert.match(by['hunyuan3d-2.1'].note,/UK\/EU/i); assert.equal(by.trellis2.status,'blocked-default');
});

test('local reference evidence is bounded and guides non-metal material colour without becoming executable input',()=>{
  const r=planPrompt('old oak barrel around 2500 triangles'); const before=r.materials.map(x=>[...x.baseColor]);
  const out=applyReferenceGuidance(r,[{meanRgb:[0.8,0.2,0.1],width:1000,height:800,view:'front'}]);
  assert.equal(out.evidence.count,1); assert.ok(out.changes.length>=1); const changed=out.recipe.materials.some((m,i)=>m.metallic<=0.72&&JSON.stringify(m.baseColor)!==JSON.stringify(before[i])); assert.equal(changed,true); assert.throws(()=>validateReferenceEvidence({meanRgb:['x',0,0],width:10,height:10}),/colour evidence/i);
});

test('live viewport parser loads a valid triangle GLB and rejects malformed input',()=>{
  const buf=tinyGlb(); const parsed=parseGlb(buf); assert.equal(parsed.json.asset.version,'2.0'); const g=extractGlbGeometry(buf); assert.equal(g.primitives.length,1); assert.equal(g.primitives[0].indices.length,3); assert.deepEqual(g.bounds.min,[0,0,0]); assert.deepEqual(g.bounds.max,[1,1,0]); assert.throws(()=>parseGlb(new ArrayBuffer(8)),/valid GLB/i);
});

test('update contract blocks insecure or unverifiable newer payloads and accepts same-version fixture',async()=>{
  assert.equal(compareVersions('0.5.0','0.5.0'),0); assert.equal(compareVersions('0.4.0','0.5.0'),-1);
  assert.throws(()=>validateUpdateManifest({schema:'nexu.forge.update.v1',availableVersion:'0.6.0',downloadUrl:'http://example.invalid/setup.exe',sha256:'a'.repeat(64),sizeBytes:100},'0.5.0'),/HTTPS/);
  assert.throws(()=>validateUpdateManifest({schema:'nexu.forge.update.v1',availableVersion:'0.6.0',downloadUrl:'https://example.invalid/setup.exe',sha256:'bad',sizeBytes:100},'0.5.0'),/SHA-256/);
  const fixture=await readFixtureManifest(join(root,'packaging','update-manifest.fixture.json'),'0.10.1'); assert.equal(fixture.newer,false); assert.equal(fixture.availableVersion,'0.10.1');
});

test('trusted worker records measurable geometry diagnostics, collision GLB and stage signals',async()=>{
  const py=await readFile(join(root,'3d-forge','blender-worker.py'),'utf8');
  assert.match(py,/nonManifoldEdges/); assert.match(py,/looseEdges/); assert.match(py,/isolatedVertices/); assert.match(py,/collisionGlb/); assert.match(py,/NEXU3D_STAGE/); assert.doesNotMatch(py,/\bexec\s*\(/); assert.doesNotMatch(py,/\beval\s*\(/);
});

test('Studio jobs expose named stages rather than fake numeric percentages',async()=>{
  const server=await readFile(join(root,'3d-forge','studio-server.mjs'),'utf8');
  assert.match(server,/stage:/); assert.match(server,/NEXU3D_STAGE/); assert.doesNotMatch(server,/progress\s*:\s*\d/);
});
