import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'../..');

test('v0.2.0 setup launcher stays open and delegates to Node', async()=>{
  const text=await readFile(resolve(root,'SETUP-NEXU-3D.cmd'),'utf8');
  assert.match(text,/setup-windows\.mjs/i);
  assert.match(text,/pause/i);
});

test('Blender bootstrap remains version-pinned and does not bypass WinGet hashes', async()=>{
  const text=await readFile(resolve(root,'3d-forge/setup-windows.mjs'),'utf8');
  assert.match(text,/BlenderFoundation\.Blender/);
  assert.match(text,/BLENDER_VERSION\s*=\s*'5\.2\.0'/);
  assert.match(text,/--version/);
  assert.doesNotMatch(text,/ignore-security-hash/i);
  assert.doesNotMatch(text,/5\.3\.0/);
});
