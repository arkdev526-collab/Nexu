import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here=dirname(fileURLToPath(import.meta.url));
const forge=resolve(here,'..');
const root=resolve(forge,'..');

test('v0.10.1 Android build auto-repairs JDK 21 and Android API 36 with the official .NET target',async()=>{
  const build=await readFile(join(root,'BUILD-ANDROID-AND-INSTALL.ps1'),'utf8');
  assert.match(build,/-t:InstallAndroidDependencies/);
  assert.match(build,/-f','net10\.0-android/);
  assert.match(build,/AndroidSdkDirectory=/);
  assert.match(build,/JavaSdkDirectory=/);
  assert.match(build,/AcceptAndroidSDKLicenses=True/);
  assert.match(build,/Sumero Studio\\BuildTools\\Android/);
  assert.match(build,/platform-tools\\adb\.exe/);
});

test('v0.10.1 Android Doctor stays read-only and treats normal ADB daemon stderr as information',async()=>{
  const doctor=await readFile(join(root,'DOCTOR-ANDROID.ps1'),'utf8');
  assert.doesNotMatch(doctor,/-t:InstallAndroidDependencies/);
  assert.doesNotMatch(doctor,/workload\s+install/i);
  assert.doesNotMatch(doctor,/Invoke-WebRequest/i);
  assert.match(doctor,/Invoke-NativeCapture \$adbPath @\('devices'\)/);
  assert.match(doctor,/ADB startup/);
  assert.doesNotMatch(doctor,/& \$adbPath devices 2>\$null/);
});

test('v0.10.1 Android app and build output use one coherent patch version',async()=>{
  const project=await readFile(join(root,'mobile','NexuAI3DForge.Android','NexuAI3DForge.Android.csproj'),'utf8');
  const build=await readFile(join(root,'BUILD-ANDROID-AND-INSTALL.ps1'),'utf8');
  assert.match(project,/<ApplicationDisplayVersion>0\.10\.1<\/ApplicationDisplayVersion>/);
  assert.match(project,/<ApplicationVersion>101<\/ApplicationVersion>/);
  assert.match(build,/Nexu-AI-3D-Forge-Android-v0\.10\.1\.apk/);
});
