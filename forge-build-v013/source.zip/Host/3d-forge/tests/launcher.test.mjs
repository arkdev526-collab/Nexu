import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'../..');

test('v0.2.0 launcher holds the Windows terminal open', async()=>{
  const text=await readFile(resolve(root,'BUILD-NEXU-3D.cmd'),'utf8');
  assert.match(text,/build-interactive/);
  assert.match(text,/pause/i);
  assert.match(text,/last-build\.log/i);
  assert.doesNotMatch(text,/set\s+\/p\s+NEXU_PROMPT/i);
});

test('interactive prompt is captured in Node and successful builds open the output folder safely', async()=>{
  const text=await readFile(resolve(root,'3d-forge/cli.mjs'),'utf8');
  assert.match(text,/createInterface/);
  assert.match(text,/rl\.question\('Describe the static 3D model to create: '\)/);
  assert.match(text,/writeBuildLog/);
  assert.match(text,/Quality:/);
  assert.match(text,/explorer\.exe/);
  assert.match(text,/shell:false/);
});
