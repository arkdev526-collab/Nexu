import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { compileCreationPrompt, promptVocabularySummary } from '../prompt-intelligence.mjs';
import { CompactBuildCache, recipeFingerprint } from '../compact-cache.mjs';
import { planPrompt } from '../planner.mjs';

const here=dirname(fileURLToPath(import.meta.url));
const forge=resolve(here,'..');
const root=resolve(forge,'..');

const phraseCases=[
  ['Please make me an old wine cask for a medieval tavern','barrel'],
  ['could you generate a treasure box with worn iron','chest'],
  ['create a medievil black dragon with torn wings','dragon'],
  ['build a ruined temple column covered in moss','pillar'],
  ['forge a purple magic crystal cluster','crystal-cluster'],
  ['model me a hanging lantern with rusty iron','lantern'],
  ['design a rope bridge section for a fantasy village','bridge-section'],
  ['create a worn medieval longsword with leather grip','sword'],
  ['make me a viking shield with iron rim','shield'],
  ['generate an ancient grimoire book','book'],
  ['build a wooden cart wheel','wagon-wheel']
];

test('v0.10 Universal Creation Intelligence accepts broad natural creation language locally',()=>{
  for(const [prompt,id] of phraseCases){const u=compileCreationPrompt(prompt);assert.equal(u.grammarId,id,prompt);assert.equal(u.localOnly,true);assert.equal(u.arbitraryCode,false);assert.ok(u.plannerPrompt.length>0);}
  const typo=compileCreationPrompt('Can you please create a medievil dragan with black scales');assert.equal(typo.grammarId,'dragon');assert.ok(typo.typoCorrections.some(x=>x.includes('medievil→medieval')));assert.ok(typo.typoCorrections.some(x=>x.includes('dragan→dragon')));
});

test('v0.10 creation vocabulary materially expands what can be said without adding remote providers',()=>{
  const v=promptVocabularySummary();assert.equal(v.subjects,43);assert.ok(v.subjectPhrases>=250,`subject phrases ${v.subjectPhrases}`);assert.ok(v.modifierPhrases>=100,`modifier phrases ${v.modifierPhrases}`);assert.ok(v.totalRecognisedPhrases>=380);assert.ok(v.actions>=15);assert.ok(v.typoRepairs>=20);assert.equal(v.localOnly,true);
});

test('v0.10 twelve new permanent prop grammars generate bounded editable recipes',()=>{
  const cases=[['medieval sword with leather grip','sword'],['viking shield','shield'],['battle axe','axe'],['blacksmith hammer','hammer'],['wooden spear','spear'],['wooden bucket','bucket'],['clay pot','pot'],['ancient grimoire','book'],['medieval torch','torch'],['old cart wheel','wagon-wheel'],['wooden door','door'],['castle window frame','window-frame']];
  for(const [prompt,id] of cases){const r=planPrompt(prompt);assert.equal(r.grammarId,id,prompt);assert.ok(r.parts.length>=1);assert.ok(r.materials.length>=1);assert.equal(r.quality.generationMode,'balanced');}
});

test('v0.10 Fast, Balanced and Maximum Quality are bounded deterministic recipe modes',()=>{
  const prompt='large medieval dragon with dark scales around 18000 triangles with 3 LODs';
  const fast=planPrompt(prompt,{generationMode:'fast'}),balanced=planPrompt(prompt,{generationMode:'balanced'}),quality=planPrompt(prompt,{generationMode:'quality'});
  assert.equal(fast.quality.generationMode,'fast');assert.equal(fast.quality.datasetCapture,false);assert.equal(fast.quality.previewSize,512);assert.ok(fast.materials.every(x=>x.textureResolution<=256));
  assert.equal(balanced.quality.generationMode,'balanced');assert.equal(balanced.quality.datasetCapture,true);assert.equal(balanced.quality.previewSize,768);
  assert.equal(quality.quality.generationMode,'quality');assert.equal(quality.quality.datasetCapture,true);assert.equal(quality.quality.previewSize,1024);assert.ok(quality.materials.every(x=>x.textureResolution>=1024));
  assert.equal(fast.targetTriangles,18000);assert.equal(quality.targetTriangles,18000);assert.equal(fast.lods,2);
  assert.ok(fast.parts[0].details.voxelSize>quality.parts[0].details.voxelSize);
});

test('v0.10 FastForge fingerprints exact recipes and safely reuses validated outputs',async t=>{
  const dir=await mkdtemp(join(tmpdir(),'nexu-fastforge-'));t.after(()=>rm(dir,{recursive:true,force:true}));const assets=join(dir,'Assets'),cacheRoot=join(dir,'Cache');await mkdir(assets,{recursive:true});
  const recipe=planPrompt('old medieval oak barrel around 2500 triangles',{generationMode:'balanced'}),other=planPrompt('old medieval oak barrel around 2500 triangles',{generationMode:'fast'});
  assert.equal(recipeFingerprint(recipe),recipeFingerprint(structuredClone(recipe)));assert.notEqual(recipeFingerprint(recipe),recipeFingerprint(other));
  const rel='SM_Test/20260824-120000';const out=join(assets,rel);await mkdir(out,{recursive:true});await writeFile(join(out,'validation.json'),'{}');
  const cache=new CompactBuildCache(cacheRoot,assets,{maxEntries:8});await cache.register(recipe,rel);const hit=await cache.lookup(recipe);assert.equal(hit.outputRelative,rel);assert.equal(hit.hits,1);
  const stats=await cache.stats();assert.equal(stats.entries,1);assert.equal(stats.totalHits,1);assert.equal(stats.preventsDuplicateBuilds,true);assert.ok(stats.indexBytes>0);const packed=await readFile(join(cacheRoot,'build-index.json.br'));assert.notEqual(packed.subarray(0,1).toString(),'{');
  await rm(join(out,'validation.json'));assert.equal(await cache.lookup(recipe),null);assert.equal((await cache.stats()).entries,0);
});

test('v0.10 Studio exposes Home, prompt coaching, generation modes and storage saver without sub-14px text',async()=>{
  const [html,app,css,server,build]=await Promise.all([
    readFile(join(forge,'studio','index.html'),'utf8'),readFile(join(forge,'studio','app.js'),'utf8'),readFile(join(forge,'studio','styles.css'),'utf8'),readFile(join(forge,'studio-server.mjs'),'utf8'),readFile(join(root,'packaging','build-windows-candidate.go'),'utf8')
  ]);
  assert.match(html,/id="homeOverlay"/);assert.match(html,/id="promptCoach"/);assert.match(html,/id="generationMode"/);assert.match(html,/FastForge & Storage Saver/);
  assert.match(app,/\/api\/prompt-intelligence/);assert.match(app,/generationMode:\$\('generationMode'\)\.value/);assert.match(app,/function renderHome/);assert.match(app,/\/api\/cache\/clear/);
  for(const m of css.matchAll(/font-size:\s*(\d+)px/g))assert.ok(Number(m[1])>=14,`sub-14px UI text: ${m[0]}`);
  assert.match(server,/const appVersion = '0\.13\.0'/);assert.match(server,/CompactBuildCache/);assert.match(server,/\/api\/cache\/status/);assert.match(server,/Cache reuse/);
  assert.match(build,/expectedVersion = "0\.13\.0"/);assert.match(build,/prompt-intelligence\.mjs/);assert.match(build,/compact-cache\.mjs/);
  const worker=await readFile(join(forge,'blender-worker.py'),'utf8');assert.match(worker,/save_as_mainfile\(filepath=blend_path,compress=blend_compressed\)/);assert.match(worker,/generationMode.*!=.*fast/);
});

test('v0.10 prompt text remains data, not executable code',()=>{
  const u=compileCreationPrompt('create a dragon; rm -rf C:\\Users && eval(alert(1))');assert.equal(u.grammarId,'dragon');assert.equal(u.arbitraryCode,false);assert.equal(u.localOnly,true);assert.doesNotThrow(()=>planPrompt(u.original));
});
