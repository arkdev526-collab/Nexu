import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { planPrompt } from '../planner.mjs';
import { ForgeValidationError, validateRecipe } from '../schema.mjs';

const root=resolve(import.meta.dirname,'../..');

test('v0.2 barrel prompt produces bounded procedural Unreal/ASA recipe',()=>{
  const r=planPrompt('Create an old medieval oak barrel 90 cm high around 2500 triangles for ASA with 3 LODs');
  assert.equal(r.schemaVersion,'1.2');
  assert.equal(r.profile,'unreal-asa');
  assert.equal(r.targetTriangles,2500);
  assert.equal(r.lods,2);
  assert.equal(r.parts.length,1);
  assert.equal(r.parts[0].type,'procedural_barrel');
  assert.ok(r.parts[0].details.bellyRadius>r.parts[0].details.endRadius);
  assert.equal(r.materials.find(m=>m.name===r.parts[0].details.woodMaterial)?.style,'aged_wood');
  assert.equal(r.quality.autoRepair,true);
  assert.equal(r.quality.previews,true);
});

test('modern steel drum is not interpreted as a wooden cask',()=>{
  const r=planPrompt('modern steel chemical drum 90 cm high around 1800 triangles');
  assert.equal(r.parts[0].type,'procedural_drum');
  assert.equal(r.materials[0].style,'iron');
});

test('crate prompt creates material-referenced parts',()=>{
  const r=planPrompt('game ready wooden crate 1 m high');
  const mats=new Set(r.materials.map(m=>m.name));
  assert.ok(r.parts.every(p=>!p.material || mats.has(p.material)));
});

test('validator rejects arbitrary primitive types',()=>{
  assert.throws(()=>validateRecipe({schemaVersion:'1.1',assetName:'Bad',parts:[{name:'X',type:'python_exec',dimensions:[1,1,1]}]}),ForgeValidationError);
});

test('validator rejects path-like asset names safely rather than trusting them',()=>{
  const r=planPrompt('../ evil crate'); assert.ok(!r.assetName.includes('..')); assert.ok(!r.assetName.includes('/'));
});

test('procedural barrel validator rejects inverted barrel silhouette',()=>{
  const r=planPrompt('medieval barrel');
  const raw=JSON.parse(JSON.stringify(r)); raw.parts[0].details.bellyRadius=raw.parts[0].details.endRadius*0.8;
  assert.throws(()=>validateRecipe(raw),/bellyRadius must be greater than endRadius/i);
});

test('trusted Blender worker contains quality calibration, preview set and convex barrel collision', async()=>{
  const text=await readFile(resolve(root,'3d-forge/blender-worker.py'),'utf8');
  assert.match(text,/calibrate_barrel_details/);
  assert.match(text,/perspective\.png/);
  assert.match(text,/wireframe\.png/);
  assert.match(text,/collision\.png/);
  assert.match(text,/convex-barrel/);
  assert.match(text,/duplicate_joined/);
  assert.doesNotMatch(text,/exec\s*\(/);
  assert.doesNotMatch(text,/eval\s*\(/);
});
