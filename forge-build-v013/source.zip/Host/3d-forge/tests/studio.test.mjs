import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, mkdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { safePrompt, safeProfile, resolveOutputRelative } from '../studio-server.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const forge = resolve(here, '..');

function waitReady(child) {
  return new Promise((resolvePromise, reject) => {
    let out='';
    const timer=setTimeout(()=>reject(new Error(`Studio test server timed out. Output: ${out}`)),8000);
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      out += chunk;
      const match=out.match(/NEXU_STUDIO_READY\s+(http:\/\/127\.0\.0\.1:\d+\/\?token=[a-f0-9]+)/i);
      if(match){clearTimeout(timer);resolvePromise(match[1]);}
    });
    child.once('error',error=>{clearTimeout(timer);reject(error)});
    child.once('exit',code=>{if(code!==null&&code!==0){clearTimeout(timer);reject(new Error(`Studio server exited ${code}. ${out}`));}});
  });
}

async function startTestServer(t,device=null){
  const data=await mkdtemp(join(tmpdir(),'nexu-forge-studio-'));
  if(device){await mkdir(join(data,'.runtime'),{recursive:true});await writeFile(join(data,'.runtime','paired-android-devices.json'),JSON.stringify({devices:[device]}));}
  const token='a'.repeat(64);
  const child=spawn(process.execPath,[join(forge,'studio-server.mjs'),'--no-open','--port','0','--token',token],{cwd:resolve(forge,'..'),env:{...process.env,NEXU_FORGE_DATA_DIR:data},stdio:['ignore','pipe','pipe'],shell:false});
  t.after(async()=>{try{child.kill('SIGTERM')}catch{};await rm(data,{recursive:true,force:true})});
  const ready=await waitReady(child),base=ready.replace(/\/\?token=.*/, '');
  const auth=await fetch(ready,{redirect:'manual'}),cookie=auth.headers.get('set-cookie');
  return{child,data,ready,base,cookie};
}

test('Studio validates prompts and keeps output paths under the Forge root', () => {
  assert.equal(safePrompt('  barrel  '),'barrel');
  assert.throws(()=>safePrompt('   '),/Describe the model/);
  assert.throws(()=>safePrompt('x'.repeat(2001)),/2,000/);
  assert.equal(safeProfile('unreal-asa'),'unreal-asa');
  assert.equal(safeProfile('anything-else'),'generic');
  assert.throws(()=>resolveOutputRelative('../../outside'),/outside the allowed Forge directory/);
});

test('Studio UI includes v0.5 creator workspaces and accessibility affordances', async () => {
  const html=await readFile(join(forge,'studio','index.html'),'utf8');
  const css=await readFile(join(forge,'studio','styles.css'),'utf8');
  const app=await readFile(join(forge,'studio','app.js'),'utf8');
  for(const marker of ['Live 3D viewport','Asset Library','Update Centre','aria-label="Studio navigation"','Reference board','Material Intelligence','Export centre','Forge Recovery','Ctrl Enter']) assert.match(html,new RegExp(marker.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  assert.match(css,/@media\s*\(prefers-reduced-motion:\s*reduce\)/);
  assert.match(app,/Ctrl\+K|ctrlKey.*['"]k/i);
  assert.match(app,/Edit details/);
  assert.match(app,/\/api\/trash/);
});

test('Studio server is loopback-only, session-protected, plans references locally and exposes update contract', async (t) => {
  const {ready,base,cookie}=await startTestServer(t);
  const health=await fetch(base+'/health'); assert.equal(health.status,200);
  const auth=await fetch(ready,{redirect:'manual'}); assert.equal(auth.status,302);
  assert.match(cookie,/nexu_session=/);
  const status=await fetch(base+'/api/status',{headers:{cookie}}); assert.equal(status.status,200,status.status===200?undefined:await status.text());
  const body=await status.json(); assert.equal(body.localOnly,true); assert.equal(body.server.host,'127.0.0.1'); assert.equal(body.version,'0.13.0'); assert.equal(body.companion.protocol,'nexu.forge.companion.v1');
  const plan=await fetch(base+'/api/plan',{method:'POST',headers:{cookie,'content-type':'application/json',origin:base},body:JSON.stringify({prompt:'old medieval oak barrel 90 cm high around 2500 triangles for ASA with 3 LODs',profile:'unreal-asa',referenceEvidence:[{meanRgb:[0.42,0.28,0.16],width:800,height:600,view:'front'}]})});
  assert.equal(plan.status,200); const planned=await plan.json();
  assert.equal(planned.recipe.profile,'unreal-asa'); assert.equal(planned.recipe.targetTriangles,2500); assert.equal(planned.recipe.lods,2); assert.match(planned.recipe.assetName,/^SM_/); assert.equal(planned.referenceGuidance.count,1);
  const update=await fetch(base+'/api/update/status',{headers:{cookie}}); assert.equal(update.status,200); const u=await update.json(); assert.equal(u.schema,'nexu.forge.update.v1'); assert.equal(u.liveFeed,false);
});

test('Reference endpoint accepts only local allow-listed image types and rejects invalid bytes', async(t)=>{
  const {base,cookie}=await startTestServer(t);
  const png=Buffer.from([137,80,78,71,13,10,26,10,0,0,0,0]);
  const ok=await fetch(base+'/api/reference',{method:'POST',headers:{cookie,origin:base,'content-type':'image/png','x-file-name':encodeURIComponent('front.png'),'x-reference-view':'front'},body:png});
  assert.equal(ok.status,201); const r=await ok.json(); assert.equal(r.reference.view,'front'); assert.match(r.reference.url,/^\/reference-file/);
  const bad=await fetch(base+'/api/reference',{method:'POST',headers:{cookie,origin:base,'content-type':'image/png','x-file-name':'bad.png'},body:Buffer.from('not-an-image')}); assert.equal(bad.status,400);
});

test('Studio launcher uses detached non-shell process execution and supports single-session reuse', async () => {
  const source=await readFile(join(forge,'studio-launcher.mjs'),'utf8');
  assert.match(source,/detached:\s*true/); assert.match(source,/shell:\s*false/); assert.match(source,/\.studio-session\.json/); assert.match(source,/\/health/);
});

test('Blender bridge supports cancellation and bounded output reporting without changing existing callers', async () => {
  const source=await readFile(join(forge,'blender.mjs'),'utf8');
  assert.match(source,/signal, onOutput/); assert.match(source,/signal\.addEventListener\('abort'/); assert.match(source,/onOutput\?\./); assert.match(source,/shell:false/);
});

test('Studio keeps installed code separate from persistent user data and exposes safe update routes', async () => {
  const server=await readFile(join(forge,'studio-server.mjs'),'utf8'); const launcher=await readFile(join(forge,'studio-launcher.mjs'),'utf8');
  assert.match(server,/NEXU_FORGE_DATA_DIR/); assert.match(server,/join\(dataRoot, 'Assets'\)/); assert.match(server,/\/api\/update\/status/); assert.match(server,/\/api\/update\/apply/); assert.match(server,/\/api\/update\/rollback/); assert.match(launcher,/NEXU_FORGE_DATA_DIR/);
});

test('PC screen HTTP upload and encrypted tablet receive stop correctly',async t=>{
 const {seal,open}=await import('../companion-crypto.mjs');
 const key=Buffer.alloc(32,8),deviceId='android-screen-test';
 const {base,cookie}=await startTestServer(t,{deviceId,name:'Test tablet',secret:key.toString('base64url')});
 const headers={cookie,origin:base,'content-type':'application/json'};
 const post=(path,body)=>fetch(base+path,{method:'POST',headers,body:JSON.stringify(body)});
 const status=await (await fetch(base+'/api/status',{headers:{cookie}})).json();const bridge=`http://127.0.0.1:${status.companion.port}`;
 const rpc=async()=>{const env=seal(key,{method:'screen.frame',params:{}},`rpc:${deviceId}`);const r=await fetch(bridge+'/companion/v1/rpc',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({deviceId,envelope:env})});if(r.status!==200)return {status:r.status};const b=await r.json();return open(key,b.envelope,`rpc:${deviceId}:${env.nonce}`).result;};
 assert.equal((await rpc()).active,false);
 assert.equal((await fetch(base+'/api/screen/start',{method:'POST',headers:{'content-type':'application/json'},body:'{}'})).status,401);
 assert.equal((await post('/api/screen/start',{deviceId:'unpaired'})).status,400);
 const start=await post('/api/screen/start',{deviceId});assert.equal(start.status,200);const {sessionId}=await start.json();
 const bytes=await readFile(join(forge,'tests','fixtures','screen-large.jpg'));
 const frame={sessionId,width:640,height:480,base64:bytes.toString('base64')};
 assert.equal((await post('/api/screen/frame',frame)).status,200);
 assert.equal((await rpc()).base64,frame.base64);
 assert.equal((await post('/api/screen/stop',{})).status,200);assert.equal((await rpc()).active,false);
 assert.equal((await post('/api/screen/frame',frame)).status,400);
 await post('/api/companion/revoke',{deviceId});assert.equal((await rpc()).status,401);
});
