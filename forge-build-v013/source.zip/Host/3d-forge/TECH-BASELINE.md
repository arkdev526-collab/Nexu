# Nexu AI 3D Forge v0.9.0 — Technology Baseline

- Node.js production line: 24.19.x
- Blender worker: Blender 5.2.0 LTS
- Windows native candidate builder: Go 1.26.6
- Nexu3D recipe schema: 1.2 (compatible additive creature type)
- Desktop generation: local Node + trusted package-owned Blender Python worker
- Android companion: existing .NET 10 / MAUI companion remains protocol-compatible
- External paid/cloud generation providers: none

v0.9 adds no new external runtime dependency. Organic construction uses Blender 5.2 voxel remesh inside the existing worker boundary.
