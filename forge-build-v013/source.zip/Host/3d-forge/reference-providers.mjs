export const REFERENCE_PROVIDERS = Object.freeze([
  Object.freeze({ id:'procedural-reference', name:'Nexu Procedural Reference', status:'available', execution:'local', licence:'Sumero Studio', install:false, note:'Uses local references to guide the structured brief; does not claim neural image-to-3D.' }),
  Object.freeze({ id:'triposr', name:'TripoSR', status:'evaluated-not-integrated', execution:'local', licence:'MIT', install:false, note:'Viable research candidate, but optional Python/CUDA model packaging is deferred until a pinned Windows model-runtime bundle passes target hardware QA.' }),
  Object.freeze({ id:'hunyuan3d-2.1', name:'Hunyuan3D 2.1', status:'blocked', execution:'local', licence:'community licence', install:false, note:'Not integrated because the published model licence territory excludes the UK/EU; incompatible with this UK product.' }),
  Object.freeze({ id:'trellis2', name:'TRELLIS.2', status:'blocked-default', execution:'local', licence:'MIT', install:false, note:'Not a practical Windows default: official project targets Linux/NVIDIA-class high-VRAM hardware.' })
]);
export function providerCatalogue(){ return REFERENCE_PROVIDERS; }
