import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateRecipe } from './schema.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const workerPath = join(here, 'blender-worker.py');

async function exists(path) { try { await access(path, constants.X_OK); return true; } catch { return false; } }

export async function findBlender(explicit = process.env.NEXU_BLENDER_PATH) {
  const candidates = [];
  if (explicit) candidates.push(explicit);
  if (process.platform === 'win32') {
    const pf = process.env.ProgramFiles ?? 'C:\\Program Files';
    candidates.push(join(pf, 'Blender Foundation', 'Blender 5.2', 'blender.exe'));
    candidates.push(join(pf, 'Blender Foundation', 'Blender 5.2.0', 'blender.exe'));
    const local = process.env.LOCALAPPDATA;
    if (local) {
      candidates.push(join(local, 'Programs', 'Blender Foundation', 'Blender 5.2', 'blender.exe'));
      candidates.push(join(local, 'Programs', 'Blender Foundation', 'Blender 5.2.0', 'blender.exe'));
    }
  }
  for (const candidate of candidates) if (await exists(candidate)) return candidate;
  return 'blender';
}

export async function blenderVersion(blenderPath) {
  return new Promise((resolvePromise) => {
    const child = spawn(blenderPath, ['--version'], { windowsHide: true, shell: false });
    let out=''; child.stdout.on('data',d=>out+=d); child.stderr.on('data',d=>out+=d);
    child.on('error',()=>resolvePromise(null));
    child.on('close',code=>resolvePromise(code===0 ? out.split(/\r?\n/)[0]?.trim() ?? null : null));
  });
}

export function isSupportedBlenderVersion(version) {
  return typeof version === 'string' && /^Blender\s+5\.2(?:\.|\b)/.test(version);
}

export async function assertSupportedBlender(blenderPath) {
  const version = await blenderVersion(blenderPath);
  if (!version) throw new Error(`Blender was not found at '${blenderPath}'. Install stable Blender 5.2.x or set NEXU_BLENDER_PATH.`);
  if (!isSupportedBlenderVersion(version)) throw new Error(`Unsupported Blender runtime '${version}'. Nexu AI 3D Forge v0.2.0 is pinned to stable Blender 5.2.x.`);
  return version;
}

export async function runBlender(recipeInput, outputDir, { blenderPath, signal, onOutput } = {}) {
  const recipe = validateRecipe(recipeInput);
  const targetDir = resolve(outputDir);
  await mkdir(targetDir,{recursive:true});
  const jobDir=join(targetDir,'.nexu3d'); await mkdir(jobDir,{recursive:true});
  const recipePath=join(jobDir,`${recipe.assetName}.n3d.json`);
  await writeFile(recipePath,JSON.stringify(recipe,null,2),'utf8');
  const blender = await findBlender(blenderPath);
  const version = await assertSupportedBlender(blender);
  const args=['--background','--factory-startup','--disable-autoexec','--python-exit-code','3','--python',workerPath,'--','--recipe',recipePath,'--output',targetDir];
  const result = await new Promise((resolvePromise,reject)=>{
    const child=spawn(blender,args,{windowsHide:true,shell:false,env:{...process.env,PYTHONNOUSERSITE:'1'}});
    let stdout='',stderr='', aborted=false;
    const emit = (kind, d) => { const text=String(d); if(kind==='stdout') stdout+=text; else stderr+=text; try { onOutput?.(kind,text); } catch {} };
    child.stdout.on('data',d=>emit('stdout',d)); child.stderr.on('data',d=>emit('stderr',d));
    const abort = () => { aborted=true; try { child.kill('SIGTERM'); } catch {} };
    if (signal) { if (signal.aborted) abort(); else signal.addEventListener('abort',abort,{once:true}); }
    child.on('error',error=>reject(new Error(`Unable to launch Blender '${blender}': ${error.message}`)));
    child.on('close',code=>{ if(signal) signal.removeEventListener('abort',abort); resolvePromise({code,stdout,stderr,aborted,command:[blender,...args]}); });
  });
  if (result.aborted) throw new Error('Blender worker was cancelled.');
  if (result.code!==0) throw new Error(`Blender worker failed with exit code ${result.code}.\n${result.stderr || result.stdout}`);
  const report=JSON.parse(await readFile(join(targetDir,'validation.json'),'utf8'));
  return { recipePath, report, stdout:result.stdout, blender, blenderVersion:version };
}
