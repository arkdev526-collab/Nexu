import QRCode from './vendor/qr/index.js';
// Local rendering only: pairing credentials are never sent to a QR web service.
export function pairingQr(uri) {
 if(typeof uri !== 'string' || uri.length > 512 || !uri.startsWith('nexuforge://pair?')) throw new Error('Invalid pairing URI');
 const qr=new QRCode(-1, 0); qr.addData(uri); qr.make();
 const n=qr.getModuleCount(), size=n+8; let path='';
 for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(qr.isDark(y,x))path+=`M${x+4},${y+4}h1v1h-1z`;
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="320" height="320" shape-rendering="crispEdges"><path fill="white" d="M0 0h${size}v${size}H0z"/><path fill="black" d="${path}"/></svg>`;
 return 'data:image/svg+xml;base64,'+Buffer.from(svg).toString('base64');
}
