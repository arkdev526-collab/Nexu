#!/usr/bin/env node
import { spawn } from 'node:child_process';
import { blenderVersion, findBlender, isSupportedBlenderVersion } from './blender.mjs';

const PACKAGE_ID = 'BlenderFoundation.Blender';
const BLENDER_VERSION = '5.2.0';

function run(command, args, { inherit = false } = {}) {
  return new Promise((resolve) => {
    const child = spawn(command, args, {
      windowsHide: false,
      shell: false,
      stdio: inherit ? 'inherit' : ['ignore', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    if (!inherit) {
      child.stdout?.on('data', (d) => { stdout += d; });
      child.stderr?.on('data', (d) => { stderr += d; });
    }
    child.on('error', (error) => resolve({ code: null, stdout, stderr, error }));
    child.on('close', (code) => resolve({ code, stdout, stderr, error: null }));
  });
}

async function main() {
  console.log('============================================================');
  console.log(' NEXU AI 3D FORGE - BLENDER SETUP');
  console.log('============================================================');
  console.log('');

  if (process.platform !== 'win32') {
    throw new Error('This setup helper is for Windows only.');
  }

  const nodeOk = /^v24\.19\./.test(process.version);
  console.log(`Node: ${process.version} ${nodeOk ? 'PASS' : 'FAIL (requires 24.19.x LTS)'}`);
  if (!nodeOk) {
    throw new Error('Node.js 24.19.x LTS must pass before Blender setup. Run SETUP-AND-VERIFY.cmd first.');
  }

  const existing = await findBlender();
  const existingVersion = await blenderVersion(existing);
  if (isSupportedBlenderVersion(existingVersion)) {
    console.log(`Blender: ${existingVersion} PASS`);
    console.log(`Path: ${existing}`);
    console.log('Nothing to install. Nexu AI 3D Forge is ready for CHECK-NEXU-3D.cmd.');
    return;
  }

  console.log('Blender: NOT FOUND');
  console.log(`Required: stable Blender ${BLENDER_VERSION} x64`);
  console.log('Checking Windows Package Manager (WinGet)...');

  const wingetVersion = await run('winget', ['--version']);
  if (wingetVersion.error || wingetVersion.code !== 0) {
    throw new Error('WinGet is not available. Install Microsoft App Installer, then run SETUP-NEXU-3D.cmd again.');
  }
  console.log(`WinGet: ${wingetVersion.stdout.trim() || 'available'} PASS`);

  console.log(`Checking ${PACKAGE_ID} ${BLENDER_VERSION} in the official WinGet source...`);
  const show = await run('winget', [
    'show', '--id', PACKAGE_ID, '--exact', '--source', 'winget', '--versions', '--accept-source-agreements'
  ]);
  if (show.error || show.code !== 0) {
    throw new Error(`WinGet could not query ${PACKAGE_ID}. ${show.stderr || show.stdout}`.trim());
  }
  if (!new RegExp(`(^|\\s)${BLENDER_VERSION.replaceAll('.', '\\.')}(\\s|$)`, 'm').test(show.stdout)) {
    throw new Error(`Pinned Blender ${BLENDER_VERSION} is not currently offered by WinGet. No unverified version will be installed.`);
  }

  console.log('');
  console.log(`Installing Blender ${BLENDER_VERSION} x64 from WinGet...`);
  console.log('Windows may show an elevation/UAC prompt from the official installer.');
  console.log('');

  const install = await run('winget', [
    'install', '--id', PACKAGE_ID, '--exact', '--source', 'winget', '--version', BLENDER_VERSION,
    '--architecture', 'x64', '--accept-package-agreements', '--accept-source-agreements'
  ], { inherit: true });

  if (install.error || install.code !== 0) {
    throw new Error(`Blender installation did not complete successfully (WinGet exit ${install.code ?? 'launch error'}).`);
  }

  const blender = await findBlender();
  const version = await blenderVersion(blender);
  if (!isSupportedBlenderVersion(version)) {
    throw new Error(`Installation completed but Nexu could not verify Blender 5.2.x. Detected: ${version ?? 'not found'}. Re-run CHECK-NEXU-3D.cmd or set NEXU_BLENDER_PATH.`);
  }

  console.log('');
  console.log(`Blender: ${version} PASS`);
  console.log(`Path: ${blender}`);
  console.log('');
  console.log('READY: Run CHECK-NEXU-3D.cmd. If it passes, run BUILD-NEXU-3D.cmd.');
}

main().catch((error) => {
  console.error('');
  console.error(`SETUP ERROR: ${error.message}`);
  process.exitCode = 2;
});
