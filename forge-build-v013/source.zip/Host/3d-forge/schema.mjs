const TYPES = new Set(['box', 'cylinder', 'sphere', 'ico_sphere', 'cone', 'procedural_barrel', 'procedural_drum', 'procedural_creature']);
const PROFILES = new Set(['generic', 'unreal-asa']);
const EXPORTS = new Set(['blend', 'fbx', 'glb']);
const MATERIAL_STYLES = new Set(['flat','wood','aged_wood','iron','worn_iron','rusted_iron','brushed_metal','painted_metal','stone','mossy_stone','ceramic','leather','scales','membrane','bone','fur','feather','chitin','skin']);

export class ForgeValidationError extends Error {
  constructor(message) { super(message); this.name = 'ForgeValidationError'; }
}

function finite(value, label, { min = -Infinity, max = Infinity } = {}) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) {
    throw new ForgeValidationError(`${label} must be a finite number in range ${min}..${max}`);
  }
  return value;
}

function integer(value, label, bounds = {}) { return Math.round(finite(value, label, bounds)); }

function text(value, label, max = 128) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) {
    throw new ForgeValidationError(`${label} must be a non-empty string up to ${max} characters`);
  }
  return value.trim();
}

export function safeAssetName(value) {
  const cleaned = String(value ?? '')
    .normalize('NFKD')
    .replace(/[^A-Za-z0-9_ -]/g, '')
    .trim()
    .replace(/[ -]+/g, '_')
    .replace(/_+/g, '_')
    .slice(0, 64);
  if (!cleaned) throw new ForgeValidationError('Asset name becomes empty after sanitisation');
  return cleaned;
}

function vec3(value, label, defaults = [0, 0, 0], { min = -10000, max = 10000 } = {}) {
  const src = value ?? defaults;
  if (!Array.isArray(src) || src.length !== 3) throw new ForgeValidationError(`${label} must contain exactly three numbers`);
  return src.map((v, i) => finite(v, `${label}[${i}]`, { min, max }));
}

function colour(value, label) {
  const src = value ?? [0.5, 0.5, 0.5, 1];
  if (!Array.isArray(src) || src.length !== 4) throw new ForgeValidationError(`${label} must be RGBA`);
  return src.map((v, i) => finite(v, `${label}[${i}]`, { min: 0, max: 1 }));
}

function validateBarrelDetails(raw, label) {
  const d = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  return Object.freeze({
    endRadius: finite(d.endRadius ?? 0.245, `${label}.endRadius`, { min: 0.03, max: 20 }),
    bellyRadius: finite(d.bellyRadius ?? 0.29, `${label}.bellyRadius`, { min: 0.031, max: 20 }),
    staveCount: integer(d.staveCount ?? 24, `${label}.staveCount`, { min: 12, max: 48 }),
    verticalSegments: integer(d.verticalSegments ?? 6, `${label}.verticalSegments`, { min: 3, max: 12 }),
    staveThickness: finite(d.staveThickness ?? 0.022, `${label}.staveThickness`, { min: 0.003, max: 0.2 }),
    staveGapRatio: finite(d.staveGapRatio ?? 0.055, `${label}.staveGapRatio`, { min: 0, max: 0.2 }),
    hoopCount: integer(d.hoopCount ?? 4, `${label}.hoopCount`, { min: 2, max: 8 }),
    hoopSegments: integer(d.hoopSegments ?? 24, `${label}.hoopSegments`, { min: 12, max: 64 }),
    hoopWidth: finite(d.hoopWidth ?? 0.032, `${label}.hoopWidth`, { min: 0.005, max: 0.25 }),
    hoopDepth: finite(d.hoopDepth ?? 0.009, `${label}.hoopDepth`, { min: 0.002, max: 0.08 }),
    endPlanks: integer(d.endPlanks ?? 6, `${label}.endPlanks`, { min: 3, max: 12 }),
    rivetsPerHoop: integer(d.rivetsPerHoop ?? 2, `${label}.rivetsPerHoop`, { min: 0, max: 4 }),
    woodMaterial: safeAssetName(d.woodMaterial ?? 'M_Oak'),
    metalMaterial: safeAssetName(d.metalMaterial ?? 'M_WornIron')
  });
}

function validateDrumDetails(raw, label) {
  const d = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  return Object.freeze({
    radius: finite(d.radius ?? 0.29, `${label}.radius`, { min: 0.03, max: 20 }),
    segments: integer(d.segments ?? 32, `${label}.segments`, { min: 12, max: 96 }),
    rimWidth: finite(d.rimWidth ?? 0.025, `${label}.rimWidth`, { min: 0.003, max: 0.2 }),
    ribCount: integer(d.ribCount ?? 2, `${label}.ribCount`, { min: 0, max: 6 }),
    material: safeAssetName(d.material ?? 'M_Steel')
  });
}


const CREATURE_KINDS = new Set(['dragon','wyvern','griffin','wolf','spider','snake','bird','fish']);
const CREATURE_STYLES = new Set(['medieval-fantasy','dark-fantasy','ancient-beast','realistic','stylised-game','skeletal','corrupted']);
function validateCreatureDetails(raw,label){
  const d=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
  const creatureKind=text(d.creatureKind??'dragon',`${label}.creatureKind`,32).toLowerCase();
  if(!CREATURE_KINDS.has(creatureKind))throw new ForgeValidationError(`${label}.creatureKind '${creatureKind}' is not allowed`);
  const styleProfile=text(d.styleProfile??'realistic',`${label}.styleProfile`,40).toLowerCase();
  if(!CREATURE_STYLES.has(styleProfile))throw new ForgeValidationError(`${label}.styleProfile '${styleProfile}' is not allowed`);
  const bodyLength=finite(d.bodyLength??2,`${label}.bodyLength`,{min:.12,max:100});
  const bodyWidth=finite(d.bodyWidth??.6,`${label}.bodyWidth`,{min:.05,max:50});
  const bodyHeight=finite(d.bodyHeight??1,`${label}.bodyHeight`,{min:.08,max:50});
  return Object.freeze({
    creatureKind,archetype:text(d.archetype??'organic',`${label}.archetype`,64),styleProfile,
    bodyLength,bodyWidth,bodyHeight,bodyBulk:finite(d.bodyBulk??1,`${label}.bodyBulk`,{min:.45,max:1.8}),
    neckLength:finite(d.neckLength??0,`${label}.neckLength`,{min:0,max:60}),tailLength:finite(d.tailLength??0,`${label}.tailLength`,{min:0,max:100}),
    wingSpan:finite(d.wingSpan??0,`${label}.wingSpan`,{min:0,max:120}),hornScale:finite(d.hornScale??0,`${label}.hornScale`,{min:0,max:2}),
    limbCount:integer(d.limbCount??0,`${label}.limbCount`,{min:0,max:8}),wingCount:integer(d.wingCount??0,`${label}.wingCount`,{min:0,max:2}),
    dorsalSpikes:integer(d.dorsalSpikes??0,`${label}.dorsalSpikes`,{min:0,max:24}),tornWings:d.tornWings===true,
    symmetry:finite(d.symmetry??1,`${label}.symmetry`,{min:.5,max:1}),voxelSize:finite(d.voxelSize??.05,`${label}.voxelSize`,{min:.005,max:.5}),
    bodyMaterial:safeAssetName(d.bodyMaterial??'M_Scales'),membraneMaterial:safeAssetName(d.membraneMaterial??'M_WingMembrane'),hornMaterial:safeAssetName(d.hornMaterial??'M_HornClaw')
  });
}

function validatePart(part, index) {
  if (!part || typeof part !== 'object' || Array.isArray(part)) throw new ForgeValidationError(`parts[${index}] must be an object`);
  const type = text(part.type, `parts[${index}].type`, 32);
  if (!TYPES.has(type)) throw new ForgeValidationError(`parts[${index}].type '${type}' is not allowed`);
  const dimensions = vec3(part.dimensions, `parts[${index}].dimensions`, [1,1,1], { min: 0.001, max: 1000 });
  const material = part.material == null ? null : safeAssetName(part.material);
  let details = null;
  if (type === 'procedural_barrel') details = validateBarrelDetails(part.details, `parts[${index}].details`);
  if (type === 'procedural_drum') details = validateDrumDetails(part.details, `parts[${index}].details`);
  if (type === 'procedural_creature') details = validateCreatureDetails(part.details, `parts[${index}].details`);
  return Object.freeze({
    name: safeAssetName(part.name ?? `Part_${index + 1}`),
    type,
    dimensions,
    location: vec3(part.location, `parts[${index}].location`),
    rotationDeg: vec3(part.rotationDeg, `parts[${index}].rotationDeg`),
    segments: integer(part.segments ?? 24, `parts[${index}].segments`, { min: 3, max: 128 }),
    bevel: finite(part.bevel ?? 0, `parts[${index}].bevel`, { min: 0, max: 2 }),
    material,
    details
  });
}

function validateMaterial(material, index) {
  if (!material || typeof material !== 'object' || Array.isArray(material)) throw new ForgeValidationError(`materials[${index}] must be an object`);
  const style = material.style ?? 'flat';
  if (!MATERIAL_STYLES.has(style)) throw new ForgeValidationError(`materials[${index}].style '${style}' is not allowed`);
  const textureResolution = integer(material.textureResolution ?? 512, `materials[${index}].textureResolution`, { min: 256, max: 1024 });
  if (![256,512,1024].includes(textureResolution)) throw new ForgeValidationError(`materials[${index}].textureResolution must be 256, 512 or 1024`);
  return Object.freeze({
    name: safeAssetName(material.name ?? `Material_${index + 1}`),
    style,
    baseColor: colour(material.baseColor, `materials[${index}].baseColor`),
    metallic: finite(material.metallic ?? 0, `materials[${index}].metallic`, { min: 0, max: 1 }),
    roughness: finite(material.roughness ?? 0.5, `materials[${index}].roughness`, { min: 0, max: 1 }),
    variation: finite(material.variation ?? 0.25, `materials[${index}].variation`, { min: 0, max: 1 }),
    wear: finite(material.wear ?? 0.15, `materials[${index}].wear`, { min: 0, max: 1 }),
    normalStrength: finite(material.normalStrength ?? 0.2, `materials[${index}].normalStrength`, { min: 0, max: 1 }),
    textureResolution,
    tileable: material.tileable !== false,
    pbrGenerate: material.pbrGenerate !== false
  });
}

function validateQuality(value) {
  const q = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  return Object.freeze({
    autoRepair: q.autoRepair !== false,
    autoMeshRepair: q.autoMeshRepair !== false,
    targetTolerancePct: finite(q.targetTolerancePct ?? 0.03, 'quality.targetTolerancePct', { min: 0.005, max: 0.5 }),
    previews: q.previews !== false,
    previewSize: integer(q.previewSize ?? 768, 'quality.previewSize', { min: 256, max: 2048 }),
    datasetCapture: q.datasetCapture !== false,
    datasetViewSize: integer(q.datasetViewSize ?? 512, 'quality.datasetViewSize', { min: 256, max: 1024 }),
    generationMode: q.generationMode === 'fast' || q.generationMode === 'quality' ? q.generationMode : 'balanced'
  });
}

export function validateRecipe(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new ForgeValidationError('Recipe root must be an object');
  if (!['1.0','1.1','1.2','1.3','1.4'].includes(input.schemaVersion)) throw new ForgeValidationError(`Unsupported schemaVersion '${input.schemaVersion}'. Expected a supported Nexu3D schema from 1.0 through 1.4`);
  const parts = Array.isArray(input.parts) ? input.parts.map(validatePart) : [];
  if (!parts.length) throw new ForgeValidationError('Recipe requires at least one geometry part');
  if (parts.length > 256) throw new ForgeValidationError('Recipe exceeds 256-part limit');
  const materials = Array.isArray(input.materials) ? input.materials.map(validateMaterial) : [];
  if (materials.length > 64) throw new ForgeValidationError('Recipe exceeds 64-material limit');
  const materialNames = new Set(materials.map(m => m.name));
  for (const part of parts) {
    if (part.material && !materialNames.has(part.material)) throw new ForgeValidationError(`Part '${part.name}' references unknown material '${part.material}'`);
    if (part.type === 'procedural_barrel') {
      if (!materialNames.has(part.details.woodMaterial) || !materialNames.has(part.details.metalMaterial)) throw new ForgeValidationError(`Procedural barrel '${part.name}' references unknown wood/metal material`);
      if (part.details.bellyRadius <= part.details.endRadius) throw new ForgeValidationError(`Procedural barrel '${part.name}' bellyRadius must be greater than endRadius`);
    }
    if (part.type === 'procedural_drum' && !materialNames.has(part.details.material)) throw new ForgeValidationError(`Procedural drum '${part.name}' references unknown material '${part.details.material}'`);
    if (part.type === 'procedural_creature') {
      if (!materialNames.has(part.details.bodyMaterial)) throw new ForgeValidationError(`Procedural creature '${part.name}' references unknown body material '${part.details.bodyMaterial}'`);
      if (part.details.wingCount > 0 && !materialNames.has(part.details.membraneMaterial)) throw new ForgeValidationError(`Procedural creature '${part.name}' references unknown wing/membrane material '${part.details.membraneMaterial}'`);
      if ((part.details.hornScale > 0 || ['dragon','wyvern','griffin','wolf','bird'].includes(part.details.creatureKind)) && !materialNames.has(part.details.hornMaterial)) throw new ForgeValidationError(`Procedural creature '${part.name}' references unknown horn/claw material '${part.details.hornMaterial}'`);
      const expectedLimbs={dragon:4,wyvern:2,griffin:4,wolf:4,spider:8,snake:0,bird:2,fish:0}[part.details.creatureKind];
      const expectedWings={dragon:2,wyvern:2,griffin:2,wolf:0,spider:0,snake:0,bird:2,fish:0}[part.details.creatureKind];
      if(part.details.limbCount!==expectedLimbs)throw new ForgeValidationError(`Procedural creature '${part.name}' limbCount ${part.details.limbCount} does not match ${part.details.creatureKind} foundation anatomy (${expectedLimbs})`);
      if(part.details.wingCount!==expectedWings)throw new ForgeValidationError(`Procedural creature '${part.name}' wingCount ${part.details.wingCount} does not match ${part.details.creatureKind} foundation anatomy (${expectedWings})`);
    }
  }

  const profile = input.profile ?? 'generic';
  if (!PROFILES.has(profile)) throw new ForgeValidationError(`Unknown profile '${profile}'`);
  const exportsRequested = Array.isArray(input.exports) && input.exports.length ? [...new Set(input.exports)] : ['blend', 'fbx', 'glb'];
  for (const format of exportsRequested) if (!EXPORTS.has(format)) throw new ForgeValidationError(`Unsupported export '${format}'`);

  return Object.freeze({
    schemaVersion: input.schemaVersion,
    assetName: safeAssetName(input.assetName),
    sourcePrompt: typeof input.sourcePrompt === 'string' ? input.sourcePrompt.slice(0, 2000) : '',
    assetClass: input.assetClass == null ? 'GenericProp' : safeAssetName(input.assetClass),
    grammarId: input.grammarId == null ? 'generic-prop' : String(input.grammarId).toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,64) || 'generic-prop',
    profile,
    units: 'metres',
    targetTriangles: integer(input.targetTriangles ?? 5000, 'targetTriangles', { min: 12, max: 2_000_000 }),
    parts,
    materials,
    uv: input.uv !== false,
    collision: input.collision !== false,
    lods: integer(input.lods ?? 0, 'lods', { min: 0, max: 3 }),
    exports: exportsRequested,
    quality: validateQuality(input.quality)
  });
}
