import { appendFile, mkdir, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

function cleanText(value,max=500){return String(value??'').replace(/[\u0000-\u001f<>]/g,' ').replace(/\s+/g,' ').trim().slice(0,max);}
function verdict(value){if(value==='good'||value==='needs-work')return value;throw new Error("Feedback verdict must be 'good' or 'needs-work'.");}
function hashRecipe(recipe){return createHash('sha256').update(JSON.stringify(recipe)).digest('hex');}
function median(values){const a=values.filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return null;const m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2;}
function creatureMorphology(recipe){const p=recipe?.parts?.find?.(x=>x?.type==='procedural_creature');const d=p?.details;if(!d)return null;const L=Number(d.bodyLength)||1;return{kind:d.creatureKind,bodyBulk:Number(d.bodyBulk),neckRatio:Number(d.neckLength)/L,tailRatio:Number(d.tailLength)/L,wingSpanRatio:Number(d.wingSpan)/L,hornScale:Number(d.hornScale),dorsalSpikes:Number(d.dorsalSpikes)};}

export class LearningLedger {
  constructor(root){this.root=root;this.path=join(root,'feedback.jsonl');}
  async add({directory,report,recipe,verdict:choice,note='',source='desktop'}){
    await mkdir(this.root,{recursive:true});
    const row=Object.freeze({
      schema:'nexu.forge.feedback.v1',
      recordedAt:new Date().toISOString(),
      source:source==='android'?'android':'desktop',
      verdict:verdict(choice),
      note:cleanText(note,500),
      assetDirectory:cleanText(directory,320),
      assetName:cleanText(report?.assetName??recipe?.assetName,80),
      assetClass:cleanText(recipe?.assetClass??'GenericProp',80),
      grammarId:cleanText(recipe?.grammarId??'generic-prop',80),
      prompt:cleanText(recipe?.sourcePrompt,1000),
      qualityScore:Number.isFinite(Number(report?.qualityScore))?Number(report.qualityScore):null,
      triangles:Number.isFinite(Number(report?.triangles))?Number(report.triangles):null,
      targetTriangles:Number.isFinite(Number(report?.targetTriangles))?Number(report.targetTriangles):null,
      recipeSha256:hashRecipe(recipe??{}),
      creatureMorphology:creatureMorphology(recipe)
    });
    await appendFile(this.path,JSON.stringify(row)+'\n','utf8');
    return row;
  }
  async rows(){
    let text='';try{text=await readFile(this.path,'utf8');}catch{return[];}
    return text.split(/\r?\n/).filter(Boolean).flatMap(line=>{try{return[JSON.parse(line)]}catch{return[];}}).slice(-5000);
  }
  async suggestion(grammarId){
    const id=cleanText(grammarId,80)||'generic-prop',rows=(await this.rows()).filter(x=>(x.grammarId||'generic-prop')===id),good=rows.filter(x=>x.verdict==='good');
    const targets=good.map(x=>Number(x.targetTriangles)).filter(x=>Number.isFinite(x)&&x>=12),qualities=good.map(x=>Number(x.qualityScore)).filter(Number.isFinite);
    const recommendedTargetTriangles=good.length>=2?Math.round(median(targets)):null;
    const morphologyRows=good.map(x=>x.creatureMorphology).filter(Boolean);
    const recommendedMorphology=morphologyRows.length>=2?{
      bodyBulk:Number(median(morphologyRows.map(x=>Number(x.bodyBulk))).toFixed(3)),
      neckRatio:Number(median(morphologyRows.map(x=>Number(x.neckRatio))).toFixed(3)),
      tailRatio:Number(median(morphologyRows.map(x=>Number(x.tailRatio))).toFixed(3)),
      wingSpanRatio:Number(median(morphologyRows.map(x=>Number(x.wingSpanRatio))).toFixed(3)),
      hornScale:Number(median(morphologyRows.map(x=>Number(x.hornScale))).toFixed(3)),
      dorsalSpikes:Math.round(median(morphologyRows.map(x=>Number(x.dorsalSpikes))))
    }:null;
    return{schema:'nexu.forge.learning.suggestion.v1',grammarId:id,sampleCount:rows.length,goodCount:good.length,needsWorkCount:rows.length-good.length,confidence:Math.min(1,good.length/5),recommendedTargetTriangles,recommendedMorphology,averageAcceptedQuality:qualities.length?Math.round(qualities.reduce((a,b)=>a+b,0)/qualities.length):null,applyAutomatically:good.length>=2&&Number.isFinite(recommendedTargetTriangles),localOnly:true};
  }
  async stats(){
    const rows=await this.rows();const good=rows.filter(x=>x.verdict==='good').length,needs=rows.filter(x=>x.verdict==='needs-work').length;
    const byGrammar={};for(const row of rows){const id=row.grammarId||'generic-prop';const v=byGrammar[id]??={good:0,needsWork:0,total:0};v.total++;if(row.verdict==='good')v.good++;else v.needsWork++;}
    const adaptiveGrammars=Object.values(byGrammar).filter(v=>v.good>=2).length;
    return{schema:'nexu.forge.learning.stats.v1',total:rows.length,good,needsWork:needs,adaptiveGrammars,byGrammar,localOnly:true,containsImageBytes:false};
  }
}
