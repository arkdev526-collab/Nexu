import { validateRecipe } from './schema.mjs';

function finite01(v){const n=Number(v);if(!Number.isFinite(n))throw new Error('Reference colour evidence is invalid.');return Math.min(1,Math.max(0,n));}
export function validateReferenceEvidence(value){
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Reference evidence must be structured data.');
  if(!Array.isArray(value.meanRgb)||value.meanRgb.length!==3)throw new Error('Reference evidence requires meanRgb.');
  const width=Math.round(Number(value.width));const height=Math.round(Number(value.height));
  if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1||width>32768||height>32768)throw new Error('Reference dimensions are invalid.');
  return Object.freeze({meanRgb:value.meanRgb.map(finite01),width,height,view:String(value.view??'unclassified').slice(0,24)});
}
export function combineReferenceEvidence(values){
  const list=(Array.isArray(values)?values:[]).slice(0,6).map(validateReferenceEvidence);
  if(!list.length)return null;
  const rgb=[0,1,2].map(i=>list.reduce((s,x)=>s+x.meanRgb[i],0)/list.length);
  return Object.freeze({meanRgb:rgb,views:list.map(x=>x.view),count:list.length,mode:'local-pixel-evidence'});
}
export function applyReferenceGuidance(recipeInput,evidenceInput){
  const recipe=JSON.parse(JSON.stringify(validateRecipe(recipeInput)));const evidence=combineReferenceEvidence(evidenceInput);if(!evidence)return {recipe:validateRecipe(recipe),evidence:null,changes:[]};
  const changes=[];
  recipe.materials=recipe.materials.map((m,i)=>{
    if(m.metallic>0.72)return m; // preserve metal identity rather than painting it from a photograph.
    const before=[...m.baseColor];const blend=/wood|stone/.test(m.style)?0.24:0.16;
    const after=[0,1,2].map(j=>Math.min(1,Math.max(0,before[j]*(1-blend)+evidence.meanRgb[j]*blend))).concat(before[3]);
    m.baseColor=after;changes.push({path:`materials[${i}].baseColor`,before,after,reason:'Locally blend reference palette evidence without claiming neural image reconstruction.'});return m;
  });
  return Object.freeze({recipe:validateRecipe(recipe),evidence,changes});
}
