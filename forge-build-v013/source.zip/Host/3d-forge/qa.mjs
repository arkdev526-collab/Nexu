import { access, readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';

async function present(path) { try { await access(path); const s=await stat(path); return s.isFile() && s.size>0; } catch { return false; } }
function check(name, ok, detail, severity='blocker') { return { name, ok:Boolean(ok), detail:String(detail ?? ''), severity }; }

export async function inspectOutput(outputDir) {
  let report;
  try { report=JSON.parse(await readFile(join(outputDir,'validation.json'),'utf8')); }
  catch { return { status:'blocked', label:'BLOCKED', checks:[check('Validation report',false,'validation.json missing or invalid')] }; }
  const d=report.geometryDiagnostics ?? {};
  const checks=[];
  checks.push(check('Generation status',report.status==='generated',report.status));
  checks.push(check('Geometry',Number.isInteger(report.triangles)&&report.triangles>0,`${report.triangles ?? 0} triangles`));
  checks.push(check('Triangle budget',Number(report.triangleBudgetDeltaPct)<=10,`${report.triangleBudgetDeltaPct}% from target`,'warning'));
  checks.push(check('Vertices',Number(d.vertices ?? 0)>0,`${d.vertices ?? 'unknown'} vertices`));
  checks.push(check('Non-manifold edges',Number(d.nonManifoldEdges ?? 0)===0,`${d.nonManifoldEdges ?? 'unknown'} detected`,'warning'));
  checks.push(check('Loose edges',Number(d.looseEdges ?? 0)===0,`${d.looseEdges ?? 'unknown'} detected`,'warning'));
  checks.push(check('Isolated vertices',Number(d.isolatedVertices ?? 0)===0,`${d.isolatedVertices ?? 'unknown'} detected`,'warning'));
  checks.push(check('UV0',report.uvRequested!==true || Number(d.uvLayers ?? 0)>=1,`${d.uvLayers ?? 0} UV layer(s)`));
  checks.push(check('Generated objects',report.generatedObjectCount>0,`${report.generatedObjectCount ?? 0} objects`));
  checks.push(check('Collision',report.collisionCreated===true,report.collisionKind ?? 'not created', report.profile==='unreal-asa'?'blocker':'warning'));
  checks.push(check('Mesh repair',!(report.meshRepair?.errors?.length),`${report.meshRepair?.objectsChecked ?? 0} mesh object(s) checked; ${report.meshRepair?.verticesRemoved ?? 0} duplicate/invalid vertices removed`, 'warning'));
  checks.push(check('Training dataset',Boolean(report.datasetRecord),report.datasetRecord ?? 'dataset record not captured','warning'));
  checks.push(check('Multi-view evidence',Array.isArray(report.datasetOutputs)&&report.datasetOutputs.filter(x=>/\.(?:png)$/i.test(x)).length>=7,`${report.datasetOutputs?.filter?.(x=>/\.png$/i.test(x)).length ?? 0} training view(s)`,'warning'));
  const creature=(report.construction??[]).find(x=>x?.kind==='creature');
  if(creature){
    const expectedLimbs={dragon:4,wyvern:2,griffin:4,wolf:4,spider:8,snake:0,bird:2,fish:0}[creature.creatureKind];
    const expectedWings={dragon:2,wyvern:2,griffin:2,wolf:0,spider:0,snake:0,bird:2,fish:0}[creature.creatureKind];
    checks.push(check('Organic creature surface',creature.organicRemesh===true,creature.organicRemesh?'Voxel-remeshed organic body':'organic remesh evidence missing'));
    checks.push(check('Creature limb anatomy',creature.limbCount===expectedLimbs,`${creature.creatureKind}: ${creature.limbCount} / expected ${expectedLimbs}`));
    checks.push(check('Creature wing anatomy',creature.wingCount===expectedWings,`${creature.creatureKind}: ${creature.wingCount} / expected ${expectedWings}`));
    if(['dragon','wyvern','griffin','wolf','snake','bird','fish'].includes(creature.creatureKind))checks.push(check('Creature tail anatomy',creature.tailPresent===true,`${creature.creatureKind}: ${creature.tailPresent?'tail present':'tail missing'}`,'warning'));
  }
  checks.push(check('Quality score',Number(report.qualityScore)>=85,`${report.qualityScore}/100 (${report.qualityStatus})`,'warning'));
  if (report.profile==='unreal-asa') checks.push(check('LOD set',Array.isArray(report.lodOutputs)&&report.lodOutputs.length>=2,`${report.lodOutputs?.length ?? 0} reduced LOD(s)`,'warning'));
  for (const file of [...(report.outputs??[]),...(report.lodOutputs??[]),...(report.previewOutputs??[])]) checks.push(check(`Output ${file}`,await present(join(outputDir,file)),file));
  for (const detail of report.lodDetails ?? []) if (detail.glbFile) checks.push(check(`Viewport LOD ${detail.glbFile}`,await present(join(outputDir,detail.glbFile)),detail.glbFile,'warning'));
  checks.push(check('Quality report',await present(join(outputDir,'quality.json')),'quality.json'));
  const blockers=checks.filter(c=>!c.ok&&c.severity==='blocker');
  const warnings=checks.filter(c=>!c.ok&&c.severity==='warning');
  const status=blockers.length?'blocked':warnings.length?'ready-with-warnings':'ready';
  const label=status==='ready'?'READY':status==='ready-with-warnings'?'READY WITH WARNINGS':'BLOCKED';
  return {status,label,assetName:report.assetName,checks,blockers,warnings,report};
}
