# Nexu AI 3D Forge v0.2.0 — Asset Quality Foundation

## Status

Implementation complete in the build workspace. Target Windows Blender 5.2.0 execution is the next verification gate.

## Goal

Turn the Phase 1 proof-of-pipeline into a materially better game-asset generator without weakening the Nexu3D trust boundary.

## Implemented

- Nexu3D schema 1.1 while retaining schema 1.0 validation compatibility.
- High-level `procedural_barrel` and `procedural_drum` allow-listed builders.
- Barrel construction intelligence: individual staves, belly profile, plank end caps, four metal hoops and low-poly rivets.
- Deterministic triangle-budget calibration before final mesh creation.
- Requested 2,500-triangle barrels can be calibrated to an estimated 2,500 triangles before export.
- Aged wood, wood, iron, worn-iron and stone procedural Blender materials.
- Barrel-specific convex `UCX_` collision instead of the Phase 1 bounding box.
- Combined single Static Mesh export geometry while retaining editable source parts in the `.blend` master.
- Explicit triangulation before FBX/GLB export.
- LODs generated from a joined mesh rather than decimating every source part independently.
- Automatic preview suite: perspective, front, side, wireframe and collision PNGs.
- Deterministic quality score, triangle-budget delta, quality checks and `quality.json`.
- Successful interactive builds open their output folder in Windows Explorer using a direct non-shell process launch.

## Security preserved

Prompt text still cannot become Python, shell code, Blender add-ons, arbitrary node scripts or arbitrary paths. Procedural asset builders and material styles are package-owned and allow-listed by schema.

## Verification boundary

This build environment does not contain Blender. Python syntax, Nexu3D tests and the protected Nexu Language regression suite were executed here. Real preview rendering, `.blend`/`.fbx`/`.glb` export and ASA DevKit import must be verified on the target Windows PC with the already installed stable Blender 5.2.0 LTS.
