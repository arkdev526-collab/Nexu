import { resolveCreationIntent } from './creation-intelligence.mjs';
import { compileCreationPrompt } from './prompt-intelligence.mjs';
const PERIOD = [
  ['medieval', /\bmediev(?:al|il)|middle ages|rustic\b/i],
  ['modern', /\bmodern|contemporary\b/i],
  ['futuristic', /\bfuturistic|sci[- ]?fi|cyber\b/i],
  ['ancient', /\bancient|roman|greek\b/i]
];
function firstMatch(prompt,pairs,fallback){for(const [value,re] of pairs)if(re.test(prompt))return value;return fallback;}
export function interpretBrief(input, profile = 'generic') {
  const prompt=String(input??'').trim();if(!prompt)throw new Error('A brief is required.');
  const understanding=compileCreationPrompt(prompt),lower=understanding.plannerPrompt.toLowerCase(),creation=resolveCreationIntent(prompt);
  const subject=understanding.subject??firstMatch(lower,[['Dragon',/\bdragon\b/],['Wyvern',/\bwyvern\b/],['Griffin',/\bgriff(?:in|on)\b/],['Wolf',/\b(?:wolf|dire wolf)\b/],['Giant spider',/\b(?:giant\s+)?spider\b|\barachnid\b/],['Snake',/\b(?:snake|serpent|viper|cobra)\b/],['Bird',/\b(?:bird|eagle|raven|crow|owl|hawk)\b/],['Fish',/\b(?:fish|salmon|trout|carp|piranha)\b/]],creation.domain==='creature'?creation.assetClass:'Static prop');
  const materials=understanding.recognised.materials.map(x=>x.replace(/\b\w/g,c=>c.toUpperCase()));
  const periods=PERIOD.filter(([,re])=>re.test(lower)).map(([name])=>name),conflicts=[];
  if(periods.includes('medieval')&&periods.includes('futuristic'))conflicts.push('Medieval and futuristic style cues conflict; medieval is treated as the dominant construction period unless edited.');
  if(periods.includes('ancient')&&periods.includes('modern'))conflicts.push('Ancient and modern period cues conflict; the first construction-specific cue is prioritised.');
  const style=understanding.recognised.styles[0]??periods[0]??(understanding.recognised.conditions.some(x=>['old','aged','weathered','worn'].includes(x))?'aged':'neutral');
  const target=creation.domain==='creature'?(profile==='unreal-asa'?'Unreal / ASA static creature asset':'Portable static creature asset'):(profile==='unreal-asa'?'Unreal / ASA static prop':'Portable static 3D asset');
  const constraints=[];const height=prompt.match(/(\d+(?:\.\d+)?)\s*(mm|cm|m|metres?|meters?)\s*(?:tall|high)?/i);if(height)constraints.push(`Scale cue: ${height[1]} ${height[2]}`);const tris=prompt.match(/(\d{2,7})\s*(?:triangles|tris|polygons|polys)/i);if(tris)constraints.push(`Triangle target: ${tris[1]}`);const lod=prompt.match(/\b([2-4])\s*lods?\b/i);if(lod)constraints.push(`${lod[1]} detail levels requested`);
  if(understanding.typoCorrections.length)constraints.push(`Spelling understood: ${understanding.typoCorrections.join(', ')}`);
  return Object.freeze({original:prompt,subject,style,construction:creation.domain==='creature'?`Organic ${creation.category} grammar`:(subject==='Barrel'?'Stave-built cask':subject==='Steel drum'?'Sheet-metal drum':subject),materials:materials.length?materials:['Auto'],target,constraints,conflicts,privacy:'local',confidence:conflicts.length?'review':creation.confidence,understanding});
}
