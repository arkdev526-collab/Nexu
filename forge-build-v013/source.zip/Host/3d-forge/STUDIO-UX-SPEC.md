# Nexu AI 3D Forge Studio — UX Specification

**Version:** 0.3.0 Studio Workspace Foundation Candidate  
**Date:** 17 August 2026  
**Design authority:** SSDL philosophy → SSDS implementation; product-specific Nexu 3D Forge identity retained.

## Product goal

Turn the working Nexu3D command pipeline into a dependable creator workspace for a solo game developer without weakening the existing security boundary.

The primary loop is deliberately short:

> Describe → Plan → Build → Inspect → Open/Export → Reuse

## Information architecture

### Create
- high-priority model brief composer;
- Unreal/ASA or Generic export profile;
- deterministic Plan action before expensive generation;
- visible recipe metrics: target triangles, parts, materials, detail levels;
- one-click Build;
- active build progress and cancellation;
- generated preview tabs: perspective, front, side, wireframe, collision;
- quality score and compact inspection summary;
- Open in Blender and Open folder actions;
- generated file list.

### Asset Library
- local generated-asset discovery from `3d-forge/output`;
- latest-first cards;
- preview, triangle count, profile, quality, LOD count;
- search;
- reopen in Blender;
- open output folder;
- load the asset back into the Create preview.

### Build Queue
- serialised Blender execution to avoid uncontrolled concurrent heavy builds;
- queued/running/completed/failed/cancelled states;
- current phase/progress;
- cancel queued or active work;
- recent build history for the current Studio session.

### Diagnostics
- Node runtime health;
- Blender runtime health and path;
- local server binding;
- output path;
- queue state;
- explicit security-boundary state.

### Settings
- default Unreal/ASA profile;
- auto-open output after successful build;
- reduced-motion preference;
- visible local-only and arbitrary-code guardrails;
- explicit Studio server shutdown.

## UX principles

1. **Creation dominates.** The prompt and result stay visually central.
2. **Expensive actions are previewed.** Plan is cheap and deterministic; Build is explicit.
3. **Evidence is visible.** Quality, triangles, collision, LODs and generated files are not hidden behind success language.
4. **Local trust is legible.** Local-only status is persistent but quiet.
5. **No console dependence.** The normal workflow no longer requires users to type into CMD.
6. **Errors survive.** Build jobs retain error state/log tails rather than disappearing.
7. **Accessible by default.** Strong contrast, keyboard focus, labelled navigation, Ctrl+Enter build shortcut and `prefers-reduced-motion` support.
8. **Responsive, but desktop-first.** The workspace reflows below 1100px and collapses the rail below 760px without making mobile the primary creation environment.

## Visual language

- graphite/ink working surface;
- restrained cyan, blue and violet Sumero signal spectrum;
- neutral content areas so generated model previews remain the focal point;
- border-led hierarchy rather than excessive glass/blur;
- large radii only on major workspace surfaces;
- compact controls with larger primary creation action;
- status colours reserved for health and quality evidence.

## Security UX

The UI is not a privileged scripting console.

- HTTP binds to `127.0.0.1` only.
- Each server launch creates a cryptographically random session token.
- Initial token exchange becomes an HttpOnly SameSite=Strict cookie.
- API requests reject foreign Origin values.
- CSP denies external script/object/frame content.
- Camera, microphone, geolocation, payment, USB, serial and Bluetooth browser permissions are disabled by response policy.
- Build prompt is bounded to 2,000 characters.
- Prompt becomes a validated Nexu3D recipe, never shell text or arbitrary Python.
- Output file routes are path-root constrained and extension allow-listed.
- External Windows launches use `spawn(..., shell:false)` with argument arrays.

## Performance rules

- zero new npm runtime dependencies;
- no UI framework payload;
- generated asset discovery is filesystem based and bounded in recursion depth;
- one active Blender build at a time;
- previews are served directly from generated local files;
- no model bytes are uploaded or copied into browser storage.

## Deferred intentionally

- reference image → 3D;
- true interactive WebGL mesh viewport;
- persistent cross-session queue database;
- installer/update service;
- native WinUI shell;
- AI visual self-critique of preview renders.

These are deferred rather than faked. The next capability phase should be selected after the Studio workspace is exercised on the target Windows PC.
