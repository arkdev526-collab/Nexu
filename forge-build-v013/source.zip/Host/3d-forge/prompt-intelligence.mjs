const ACTION_PREFIXES=[
  'can you please','could you please','please','can you','could you','would you','i want you to','i want','i need','make me','make','create me','create','generate me','generate','build me','build','model me','model','design me','design','forge me','forge'
];

const TYPO_MAP=Object.freeze({
  medievil:'medieval',medival:'medieval',medevil:'medieval',mediaval:'medieval',fantacy:'fantasy',fantascy:'fantasy',
  dragan:'dragon',drgon:'dragon',wyven:'wyvern',griffon:'griffin',grifin:'griffin',wolfe:'wolf',spidar:'spider',
  barrell:'barrel',barrells:'barrels',lantren:'lantern',piller:'pillar',colum:'column',cupbord:'cupboard',
  wepon:'weapon',weaponsrack:'weapon rack',bridg:'bridge',stairway:'stairs',stairwell:'stairs',crstal:'crystal',
  roughnes:'roughness',metalic:'metallic',triangel:'triangle',triangles:'triangles'
});

const SUBJECTS=Object.freeze([
  // creatures
  ['dragon','Dragon','dragon',['dragon','medieval dragon','fantasy dragon','ancient dragon','black dragon','red dragon','fire dragon','ice dragon','winged dragon']],
  ['wyvern','Wyvern','wyvern',['wyvern','winged wyvern','dark wyvern','fantasy wyvern']],
  ['griffin','Griffin','griffin',['griffin','gryphon','griffon','winged griffin','fantasy griffin']],
  ['wolf','Wolf','wolf',['wolf','dire wolf','grey wolf','gray wolf','fantasy wolf','ancient wolf']],
  ['giant-spider','Giant spider','spider',['spider','giant spider','arachnid','fantasy spider','poisonous spider','venomous spider']],
  ['snake','Snake','snake',['snake','serpent','sea serpent','viper','cobra','python snake','fantasy serpent','basilisk serpent']],
  ['bird','Bird','bird',['bird','eagle','raven','crow','owl','hawk','falcon','fantasy bird','giant bird']],
  ['fish','Fish','fish',['fish','salmon','trout','carp','piranha','tuna fish','fantasy fish','sea fish']],
  // props/furniture
  ['barrel','Wooden barrel','barrel',['barrel','wooden barrel','oak barrel','cask','keg','ale barrel','wine barrel','medieval barrel']],
  ['steel-drum','Steel drum','steel drum',['steel drum','metal drum','oil drum','chemical drum','industrial drum','metal barrel']],
  ['crate','Crate','crate',['crate','wooden crate','shipping crate','cargo crate','storage crate','shipping box','supply crate']],
  ['chest','Chest','chest',['chest','treasure chest','coffer','treasure box','storage chest','medieval chest','fantasy chest']],
  ['table','Table','table',['table','wooden table','dining table','work table','workbench table','desk','altar table','medieval table']],
  ['bench','Bench','bench',['bench','wooden bench','park bench','medieval bench','pew bench']],
  ['stool','Stool','stool',['stool','wooden stool','bar stool','three leg stool','four leg stool']],
  ['chair','Chair','chair',['chair','wooden chair','dining chair','medieval chair','throne chair','high back chair']],
  ['shelf','Shelf','shelf',['shelf','shelving','bookcase','bookshelf','storage shelf','wall shelf']],
  ['cupboard','Cupboard','cupboard',['cupboard','cabinet','wardrobe','armoire','storage cabinet','wooden cupboard']],
  // architecture/environment
  ['pillar','Pillar','pillar',['pillar','column','stone pillar','stone column','obelisk pillar','temple column','ruined pillar']],
  ['wall','Wall','wall',['wall','stone wall','castle wall','brick wall','wooden wall','wall panel','ruined wall']],
  ['stairs','Stairs','stairs',['stairs','staircase','steps','stone stairs','wooden stairs','castle stairs']],
  ['door-frame','Door frame','door frame',['door frame','doorway','gate frame','archway','stone doorway','wooden doorway']],
  ['rock','Rock','rock',['rock','boulder','stone prop','large rock','small rock','cliff rock','mossy rock']],
  ['log','Log','log',['log','wood log','fallen log','fallen timber','tree log','timber log']],
  ['stump','Tree stump','stump',['stump','tree stump','old stump','cut tree stump','rotting stump']],
  ['crystal-cluster','Crystal cluster','crystal cluster',['crystal','crystal cluster','gem cluster','magic crystal','fantasy crystal','mineral cluster']],
  ['lantern','Lantern','lantern',['lantern','iron lantern','medieval lantern','oil lantern','hanging lantern','fantasy lantern']],
  ['weapon-rack','Weapon rack','weapon rack',['weapon rack','sword rack','weapons rack','armoury rack','medieval weapon rack']],
  ['fence','Fence','fence',['fence','wooden fence','palisade','picket fence','medieval fence','stockade fence']],
  ['signpost','Signpost','signpost',['signpost','sign post','wooden sign','road signpost','fantasy signpost','medieval sign']],
  ['bridge-section','Bridge section','bridge',['bridge','wooden bridge','stone bridge','walkway','bridge section','medieval bridge','rope bridge']],
  // weapons, tools and everyday props
  ['door','Door','door',['door','wooden door','medieval door','castle door','heavy door','door slab']],
  ['window-frame','Window frame','window frame',['window','window frame','wooden window','medieval window','castle window']],
  ['sword','Sword','sword',['sword','medieval sword','longsword','short sword','iron sword','steel sword','fantasy sword']],
  ['shield','Shield','shield',['shield','wooden shield','round shield','medieval shield','viking shield','fantasy shield']],
  ['axe','Axe','axe',['axe','battle axe','wood axe','medieval axe','fantasy axe','war axe']],
  ['hammer','Hammer','hammer',['hammer','warhammer','war hammer','blacksmith hammer','medieval hammer','fantasy hammer']],
  ['spear','Spear','spear',['spear','wooden spear','medieval spear','war spear','lance weapon','fantasy spear']],
  ['bucket','Bucket','bucket',['bucket','wooden bucket','wooden pail','metal bucket','medieval bucket']],
  ['pot','Pot','pot',['pot','clay pot','ceramic pot','medieval pot','cooking pot','storage pot']],
  ['book','Book','book',['book','old book','medieval book','tome','ancient tome','grimoire','spell book']],
  ['torch','Torch','torch',['torch','wooden torch','flaming torch','medieval torch','wall torch']],
  ['wagon-wheel','Wagon wheel','wagon wheel',['wagon wheel','cart wheel','wooden wheel','medieval wagon wheel','old cart wheel']]
].map(([grammarId,label,canonical,aliases])=>Object.freeze({grammarId,label,canonical,aliases:Object.freeze(aliases)})));

const VOCAB=Object.freeze({
  styles:['medieval','medieval fantasy','dark fantasy','ancient','realistic','stylised','stylized','cartoon','corrupted','skeletal','rustic','industrial','modern','futuristic','sci-fi','cyberpunk','gothic','viking','roman','greek'],
  materials:['oak','wood','wooden','timber','iron','steel','metal','stone','rock','ceramic','leather','scales','fur','feather','chitin','bone','horn','glass','crystal'],
  conditions:['old','aged','weathered','worn','rusted','rusty','damaged','broken','cracked','scarred','battle-worn','torn','rotting','mossy','overgrown','clean','new','polished'],
  colours:['black','white','red','crimson','green','emerald','blue','azure','gold','golden','silver','grey','gray','brown','purple','violet','orange'],
  scale:['tiny','miniature','small','medium','large','big','huge','massive','giant','enormous'],
  shape:['slender','lean','thin','wide','wider','narrow','tall','short','long','bulky','heavy','armoured','armored','curved','straight','spiked','smooth'],
  detail:['game-ready','game ready','low poly','low-poly','high poly','high-poly','hero prop','performance','lod','lods','collision','uv','pbr','rough','rougher','metallic','tileable']
});

function normaliseWord(word){return TYPO_MAP[word]??word;}
function normaliseText(input){
  return String(input??'').normalize('NFKC').toLowerCase().replace(/[“”]/g,'"').replace(/[’]/g,"'")
    .replace(/[^a-z0-9.%+\-\s']/g,' ').split(/\s+/).filter(Boolean).map(normaliseWord).join(' ').trim();
}
function stripAction(text){let out=text;for(const p of ACTION_PREFIXES.sort((a,b)=>b.length-a.length)){if(out===p)return'';if(out.startsWith(p+' ')){out=out.slice(p.length).trim();break;}}return out;}
function phrasePresent(text,phrase){const p=phrase.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/\s+/g,'\\s+');return new RegExp(`(?:^|\\b)${p}(?:\\b|$)`,'i').test(text);}
function findSubject(text){
  const candidates=[];
  for(const s of SUBJECTS)for(const alias of s.aliases)if(phrasePresent(text,alias))candidates.push({subject:s,alias});
  candidates.sort((a,b)=>b.alias.length-a.alias.length);
  return candidates[0]??null;
}
function collect(text,values){return values.filter(v=>phrasePresent(text,v));}
function replaceAlias(text,match){if(!match)return text;const canonical=match.subject.canonical;if(phrasePresent(text,canonical))return text;return `${text} ${canonical}`.replace(/\s+/g,' ').trim();}
function detectAction(original){const n=normaliseText(original);return ACTION_PREFIXES.find(p=>n===p||n.startsWith(p+' '))??'describe';}

export function compileCreationPrompt(input){
  const original=String(input??'').trim();if(!original)throw new Error('A creation prompt is required.');
  const normalised=normaliseText(original),withoutAction=stripAction(normalised),match=findSubject(withoutAction||normalised),plannerPrompt=replaceAlias(withoutAction||normalised,match);
  const recognised={
    styles:collect(normalised,VOCAB.styles),materials:collect(normalised,VOCAB.materials),conditions:collect(normalised,VOCAB.conditions),colours:collect(normalised,VOCAB.colours),scale:collect(normalised,VOCAB.scale),shape:collect(normalised,VOCAB.shape),detail:collect(normalised,VOCAB.detail)
  };
  const typoCorrections=[];const rawWords=String(input??'').toLowerCase().match(/[a-z]+/g)??[];for(const w of rawWords)if(TYPO_MAP[w]&&TYPO_MAP[w]!==w)typoCorrections.push(`${w}→${TYPO_MAP[w]}`);
  const wordCount=normalised?normalised.split(/\s+/).length:0;
  return Object.freeze({
    schema:'nexu.forge.prompt-understanding.v1',original,normalised,plannerPrompt:plannerPrompt||normalised,action:detectAction(original),
    grammarId:match?.subject.grammarId??null,subject:match?.subject.label??null,matchedAlias:match?.alias??null,recognised:Object.freeze(recognised),
    typoCorrections:[...new Set(typoCorrections)],wordCount,confidence:match?'high':'review',localOnly:true,arbitraryCode:false
  });
}

export function promptVocabularySummary(){
  const aliasCount=SUBJECTS.reduce((n,s)=>n+s.aliases.length,0),modifierCount=Object.values(VOCAB).reduce((n,x)=>n+x.length,0);
  return Object.freeze({schema:'nexu.forge.prompt-vocabulary.v1',subjects:SUBJECTS.length,subjectPhrases:aliasCount,modifierPhrases:modifierCount,totalRecognisedPhrases:aliasCount+modifierCount,actions:ACTION_PREFIXES.length,typoRepairs:Object.keys(TYPO_MAP).length,localOnly:true});
}

export function promptSubjectCatalogue(){return SUBJECTS.map(s=>({grammarId:s.grammarId,label:s.label,examples:s.aliases.slice(0,4)}));}
