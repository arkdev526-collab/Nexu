# Nexu AI 3D Forge v0.3.0 — Studio Workspace Foundation Candidate

**Date:** 17 August 2026  
**Parent:** Nexu Language 0.6.0 — protected and unchanged  
**Predecessor:** Nexu AI 3D Forge v0.2.0 — Asset Quality Foundation Candidate

## Delivered

- premium local-first Studio workspace;
- Create, Asset Library, Build Queue, Diagnostics and Settings views;
- one-click `NEXU-3D-STUDIO.cmd` launcher;
- Edge app-mode launch when Microsoft Edge is available, normal browser fallback otherwise;
- loopback-only local HTTP server with per-session authentication;
- deterministic Plan API backed by the existing Nexu3D planner;
- serial Blender build queue;
- active/queued job cancellation;
- output versioning by asset and build ID;
- generated preview discovery;
- quality/triangle/collision/LOD evidence in UI;
- Open in Blender and Open folder actions;
- browser-local workspace preferences;
- read-only diagnostics;
- explicit Studio shutdown;
- cancellation/output callbacks added to the existing Blender bridge without changing existing CLI callers;
- no new npm runtime dependencies.

## Technology decision

The Studio foundation deliberately stays on the already-working Node.js 24.19.x runtime instead of introducing Electron or another desktop framework merely to draw the UI.

The official Windows App SDK is a valid future native-shell option, but adopting a new application runtime is not justified for this candidate while the current local host can provide the full creation workflow with fewer dependencies. This follows the Sumero Technology Authority rule to preserve a supported working baseline unless a migration provides material benefit.

## Current target runtime

- Windows 11 x64;
- Node.js 24.19.x LTS (existing project pin);
- Blender stable 5.2.x (existing Forge pin);
- browser shell: Microsoft Edge app mode when available, otherwise the user's normal Windows browser;
- server bind: 127.0.0.1 only.

## Candidate boundary

This workspace has been source-tested and its live HTTP/session/Plan flow was exercised in the build environment. Real Windows Edge app-mode launch, Blender generation from the Studio queue, cancellation of a live Blender job and Windows external-open actions remain target-PC verification steps.
