# Nexu AI 3D Forge v0.5.0 — UX Research

**Research date:** 18 August 2026  
**Method:** current official product documentation first; qualitative community/review signals used only as directional evidence.

| Finding | Evidence | Source class | Confidence | Product implication | Implemented? | Reason if rejected/deferred |
|---|---|---|---|---|---|---|
| Keep the asset central and expose tools by task | Blender uses task-oriented workspaces and dedicated viewport/asset-browser contexts | Official product docs | High | Viewport-first Create/Refine/Reference/Materials/Export workflow | Yes | — |
| Geometry preview should precede expensive refinement | AI-3D tools separate shape generation from later texture/refinement steps | Official product docs | Medium-high | Brief → plan → generate → refine | Yes | — |
| Users need direct controls after generation | Sloyd/Meshy expose polycount/topology/refinement controls rather than prompt-only flow | Official product docs | High | Structured refinement + presets + inspector | Yes | — |
| Prompt drift increases with conflicting/overlong descriptions | Meshy guidance explicitly recommends clearer subject/style/detail structure | Official support docs | High | Brief Interpreter surfaces conflicts rather than silently guessing | Yes | — |
| Game-ready means more than a plausible render | Unreal/Meshy workflows emphasise topology, UVs, PBR, collision/LOD/export constraints | Official docs | High | READY / READY WITH WARNINGS / BLOCKED QA | Yes | — |
| Speed and easy prototyping are valued | Repeated review/community praise for fast AI-3D iteration | Qualitative reviews/community | Medium | Low-click generation and stage feedback | Yes | Not treated as a statistical claim |
| Topology cleanup and fine control remain common pain points | Repeated AI-3D review/community criticism | Qualitative reviews/community | Medium | Geometry diagnostics + structured control rather than one-shot output | Yes | — |
| Asset/library management can become clunky | Blender community discussions describe cataloguing/undo friction | Qualitative community | Medium-low | Automatic Forge library + built-in Recovery; no required manual folder catalogues | Yes | Signal is qualitative, not population-wide |
| Local ownership/no mandatory credits is differentiating | Cloud AI-3D products often use account/credit models; Forge can avoid that for core procedural workflow | Product/business-model comparison | Medium | Core local workflow has no account, credits or cloud requirement | Yes | — |
| A full DCC clone would add complexity without improving the core task | SSDL complexity/recovery principles + product scope | Governance/first principles | High | Focus static props; no sculpting/animation/CAD expansion | Yes | — |

## Things adopted

- Viewport-first professional creation layout.
- Task/context workspaces rather than every tool at once.
- Fast plan → generate → inspect → refine loop.
- Explicit geometry budget, LOD, collision and export evidence.
- Searchable asset library, version history, undo/redo and recoverable trash.
- Clear stage-based generation state and cancellation.

## Things transformed

- Blender's workspace principle becomes Forge's compact Create / Refine / Reference / Materials / Export strip rather than a copied Blender layout.
- Generative-3D prompt iteration becomes structured recipe diffs that remain inspectable and reversible.
- Reference-image workflows remain local and initially guide structured procedural creation rather than pretending to reconstruct a mesh neurally.

## Things rejected

- Prompt-only black-box generation.
- Forced account/credits/cloud for core creation.
- Arbitrary AI-generated Blender Python.
- Manual catalog-folder setup for the Asset Library.
- Hunyuan3D 2.1 integration because its published territory terms are unsuitable for this UK product.
- TRELLIS.2 as a default because its official requirements are not a practical general Windows baseline.

## Things deferred

- TripoSR optional local provider until a pinned Windows Python/CUDA/model bundle passes hardware and packaging QA.
- Full WinUI/WebView2-owned native shell until the correct Windows App SDK/.NET toolchain and physical Windows gate are available.
- Production online update feed until a real Sumero-hosted endpoint exists.
- Character/rigging/animation and scene generation.

## Source register

- Blender Manual: https://docs.blender.org/manual/en/latest/interface/window_system/workspaces.html
- Blender Asset Browser: https://docs.blender.org/manual/en/latest/editors/asset_browser.html
- Meshy documentation/help: https://docs.meshy.ai/ and https://help.meshy.ai/
- Sloyd: https://www.sloyd.ai/
- Unreal FBX Static Mesh Pipeline: https://dev.epicgames.com/documentation/en-us/unreal-engine/fbx-static-mesh-pipeline-in-unreal-engine
- TripoSR: https://github.com/VAST-AI-Research/TripoSR
- Hunyuan3D 2.1: https://github.com/Tencent-Hunyuan/Hunyuan3D-2.1
- TRELLIS.2: https://github.com/microsoft/TRELLIS.2
