# QA Results — Nexu AI 3D Forge v0.8.0

## Automated regression
- Nexu AI 3D Forge suite: **52/52 PASS**.
- Protected Nexu Language suite: **70/70 PASS**.
- Total deterministic tests: **122/122 PASS**.
- Nexu AI semantic check: PASS.
- Nexu AI TypeScript generation: PASS.
- TypeScript strict no-emit: PASS with available compiler.
- Blender worker Python compile: PASS.
- All Forge `.mjs` / Studio `.js` syntax checks: PASS.

## v0.8-specific gates
- 20+ ready grammar family gate: PASS (23).
- Schema compatibility: PASS (existing Nexu3D 1.2 retained; new optional fields are additive).
- Safe Mesh Repair source gate: PASS.
- Seven-view dataset capture gate: PASS.
- Local learning ledger gate: PASS.
- Bounded accepted-result adaptation gate: PASS (minimum two Good results; explicit triangle prompts override learning).
- No image bytes in feedback ledger gate: PASS.
- No external paid/cloud provider introduced: PASS.
- No `eval`, arbitrary `exec` or `shell:true` in new runtime modules: PASS.
- Windows candidate payload includes grammar/learning modules: PASS.

## Environment boundary
The build container does not contain Blender 5.2 or Node 24.19.x; therefore real v0.8 Blender output remains a target-PC qualification gate. The container also has Go 1.23.2 rather than the pinned Go 1.26.6, so no incorrectly-toolchained Windows Setup EXE is labelled as the v0.8 deliverable here. `BUILD-WINDOWS-CANDIDATE.cmd` remains the authoritative one-click Windows build path and downloads/verifies the exact pinned Go 1.26.6 toolchain before producing Setup.
