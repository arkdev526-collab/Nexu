# Technology Verification — Nexu AI 3D Forge v0.8.0

**Verification date:** 2026-08-23

## Binding choices
- Preserve Node.js 24.19.x production runtime contract.
- Preserve Blender 5.2.x trusted worker contract.
- Preserve .NET 10 / MAUI 10.0.90 / Android API 36 companion baseline.
- Pin Go 1.26.6 as the exact Windows native launcher/setup build toolchain. Official go.dev verification on 2026-08-23 lists 1.26.6 stable and publishes Windows x64 SHA-256 `5b6c5b556525810463b5c897b50dc7a82d6a3dc0bfaf55d990a7e9f31d6b2318`.
- Add no new runtime package dependency for Asset Intelligence, mesh repair, dataset capture or the learning ledger.

## Free/local provider gate
The official TripoSR repository currently identifies the project, source code and pretrained models as MIT-licensed and describes approximately 6 GB VRAM for its default single-image path. It remains evaluated but not integrated in v0.8 because its upstream runtime includes a Python/CUDA/PyTorch stack and several dependency declarations that would need a separately pinned, Windows-qualified provider bundle before it can satisfy Sumero stable/final-only policy.

## Decision
The strongest permanent step available in this environment is therefore the owned Asset Grammar + Mesh Repair + Dataset + Preference Learning foundation. It improves production value immediately and creates clean evidence for a future local neural provider without inserting a temporary service.

## Current primary-source recheck
- Node.js official download: v24.19.0 remains the latest LTS.
- Blender official download/LTS pages: Blender 5.2.0 LTS remains current and supported until July 2028.
- Go official downloads: Go 1.26.6 is the current stable 1.26 patch used by the Windows builder.
