# Nexu AI 3D Forge v0.6.0 — Autonomous Material Intelligence Prompt

Act as the smallest complete world-class team required to research, build, test, repair and package the next Nexu AI 3D Forge update. Preserve the installed v0.5.1 baseline and the proven Nexu3D → Blender engine. Do not stop at a plan.

Mandatory outcomes:
1. Add a visible, truthful generation loading/progress bar driven by actual pipeline stages, not fake elapsed-time percentages.
2. Enforce a minimum 14 px UI text size and reflow the workspace so larger type remains usable.
3. Turn Materials into a first-class creation workflow: select material slot, describe desired surface, preview structured changes, apply non-destructively.
4. Generate local PBR material outputs suitable for Blender/Unreal workflows: Base Color, Roughness, Metallic and Normal.
5. Support useful material presets plus plain-language changes while preserving user control.
6. Keep all AI/material intent behind typed allow-listed schemas. Never execute AI text as Python, shell, node code or Blender scripting.
7. Preserve local-first operation, user-owned assets, version history, recovery, update safety, live viewport and Unreal/ASA profile.
8. Research current Blender 5.2 Principled/OpenPBR guidance, Unreal 5.8 PBR inputs and current AI 3D material workflows from primary sources before finalising implementation.
9. Run existing regressions plus new material/progress/readability tests, repair failures, rebuild manifests and package a normal one-file Windows Setup candidate.
10. Report exact verification boundaries. Never call Windows/Blender behaviour passed until it has run on the target PC.
