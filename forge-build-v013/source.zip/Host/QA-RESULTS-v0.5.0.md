# Nexu AI 3D Forge v0.5.0 — QA Results

**Date:** 18 August 2026  
**Status:** Source/contract candidate validation complete in available build environment.

## Passed

```text
Protected Nexu Language tests      70 / 70 PASS
3D Forge / v0.5 tests              31 / 31 PASS
Total deterministic tests         101 / 101 PASS
```

Additional gates passed:

- all Forge `.mjs` syntax checks;
- Studio browser JavaScript syntax checks;
- Blender worker Python compilation;
- Nexu AI semantic/source check;
- Nexu AI TypeScript generation/build;
- generated TypeScript strict check using workspace TypeScript 5.8.3;
- live GLB parser fixture + malformed-file rejection;
- structured refinement immutability/rejection checks;
- reference evidence/provider policy checks;
- loopback Studio/session/origin API integration checks;
- local reference MIME/magic validation checks;
- update-manifest HTTPS/SHA/size policy tests;
- Windows launcher/setup source policy tests;
- current Go 1.26.5 Windows builder pin/hash policy test.

## Intentional production-verifier failure

The build workspace runs Node.js 22.16.0. The protected production requirement remains Node.js 24.19.x. `compiler/verify.mjs` therefore returns the expected fail-closed result rather than a false pass.

## Windows build-tool gate

The container's installed Go is 1.23.2, not the verified production Go 1.26.5 toolchain. Final Windows GUI/Setup binaries are therefore not promoted from this container. The included Windows one-click builder downloads the official Go 1.26.5 Windows x64 ZIP, checks its published SHA-256, then compiles the native launcher and Setup on Windows.

## Not physically verified here

- final Go 1.26.5 Windows compilation;
- fresh Windows install / same-version repair / update / rollback / uninstall;
- Windows shortcut and Installed Apps behaviour;
- installed-app keyboard, Narrator, High Contrast and 100–200% scaling review;
- real Blender 5.2 generation through the new v0.5 Studio surface;
- v0.5 interactive viewport against the target-generated barrel GLB;
- ASA DevKit import/LOD/collision qualification;
- production internet update endpoint (none is claimed to exist).

The headless Linux Chromium available in the container did not produce a reliable screenshot, so no installed/rendered visual QA claim is made from that attempt.
