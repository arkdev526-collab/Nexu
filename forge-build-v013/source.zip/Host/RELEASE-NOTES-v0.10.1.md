# Nexu AI 3D Forge v0.10.1 — Android Prerequisite Auto-Repair

## Trigger
A real Windows Android build reached the Android Doctor and proved the project, .NET 10.0.400 workload, Android SDK root and ADB were present, but stopped because JDK 21 and Android API 36 were missing. ADB's normal first-start daemon message on stderr was also promoted to a terminating PowerShell `NativeCommandError`.

## Repair
- Android build now invokes the official .NET for Android `InstallAndroidDependencies` target when Doctor reports missing prerequisites.
- A private build JDK is provisioned under `%LOCALAPPDATA%\Sumero Studio\BuildTools\Android\jdk-21`.
- Android SDK packages are installed into `%LOCALAPPDATA%\Android\Sdk`.
- API 36 is rechecked after repair before restore/build begins.
- ADB and Java version probes use redirected native-process capture, so expected stderr output does not become a terminating PowerShell error.
- ADB installation still requires exactly one authorised device; otherwise the APK is built and retained without failing the build.
- Android app/build identity is aligned to 0.10.1 / version code 101.

## Preserved
All v0.10.0 Universal Creation Intelligence, FastForge, compression/storage and Studio UX behaviour is preserved. Windows generation architecture and Blender worker behaviour are unchanged by this patch.
