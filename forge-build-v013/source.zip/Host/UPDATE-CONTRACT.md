# Nexu AI 3D Forge — Update Contract v1

Schema: `nexu.forge.update.v1`

A production manifest contains:

- `availableVersion` — semantic `major.minor.patch`;
- `channel`;
- `releaseNotes`;
- `sizeBytes`;
- `downloadUrl` — HTTPS only for a newer update;
- `sha256` — exact Setup executable digest;
- `live` — production/test indication.

Forge will not invent an update service. Without `NEXU_FORGE_UPDATE_MANIFEST_URL`, the Update Centre uses a local same-version QA fixture and cannot install an internet update.

For a live update Forge:

1. retrieves the manifest over HTTPS with redirects rejected;
2. validates schema/version/size/URL/SHA metadata;
3. downloads the Setup executable;
4. verifies exact byte length and SHA-256;
5. starts Setup without a shell;
6. Setup stages and verifies the internal package manifest before switching `current-version.txt`;
7. user Documents data remains outside the versioned application directory;
8. a retained previous verified version can be selected through `--rollback`.
