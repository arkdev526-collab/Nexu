# START HERE — Nexu AI 3D Forge v0.10.1

v0.10.1 preserves the complete v0.10.0 Forge feature set and repairs the Android build path seen on a real Windows machine.

## Windows app
Run `BUILD-WINDOWS-CANDIDATE.cmd` when you need to build the v0.10.1 Windows Setup candidate.

## Android
Run `BUILD-ANDROID-AND-INSTALL.cmd`.

The Android workflow now:
1. runs the read-only Doctor;
2. if JDK 21 or Android API 36 is missing, uses the official .NET for Android dependency installer;
3. re-runs Doctor;
4. restores and builds the signed engineering APK;
5. installs it when exactly one authorised Android device is connected.

Do not manually install JDK 21 or API 36 first unless this automatic repair reports a genuine failure.
