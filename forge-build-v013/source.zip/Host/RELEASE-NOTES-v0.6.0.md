# Nexu AI 3D Forge v0.6.0 — Material Intelligence & Generation Candidate

## User-facing changes

### Generation progress
Forge now exposes the real worker stages — Queued, Preparing, Materials, Texturing, Modelling, Collision, Validation and Exporting — through a visible progress bar. The bar represents completed pipeline stages rather than pretending to know a time-based percentage.

### Readability
All explicitly declared UI text sizes are now at least 14 px. Desktop panels were widened and responsive fallbacks adjusted so the larger typography does not simply clip the existing layout.

### Material Intelligence
The Materials workspace is now an active creation surface rather than a read-only summary. A user can select a material slot and request changes such as:

- `aged oak with dark grain and more wear`
- `heavily rusted iron, rougher`
- `brushed steel, polished`
- `mossy weathered stone`

Forge converts the request into an allow-listed material plan, shows the planned changes, and only then queues a new recoverable asset version.

### Local PBR generation
The trusted Blender worker can generate local texture sets per material:

- Base Color
- Roughness
- Metallic
- Normal

Supported generation sizes are 256, 512 and 1024 px. Texture generation is deterministic and local; no cloud image service is required.

## Preserved
- v0.5.1 installed-app/update model;
- live GLB viewport;
- reference board;
- non-destructive geometry refinement;
- asset history/recovery;
- Unreal / ASA profile;
- Node 24.19.x + Blender 5.2.x target runtime;
- local-only Studio host and structured Nexu3D security boundary.
