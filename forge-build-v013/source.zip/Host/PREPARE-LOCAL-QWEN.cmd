@echo off
setlocal
cd /d "%~dp0"
echo Nexu Language 0.6.0 - Prepare Local Qwen
echo.
where ollama >nul 2>nul
if errorlevel 1 (
  echo [FAIL] Ollama is not installed or is not on PATH.
  echo Opening the official Ollama Windows download page...
  start "" "https://ollama.com/download/windows"
  echo.
  echo Install Ollama, then run PREPARE-LOCAL-QWEN.cmd again.
  pause
  exit /b 1
)

echo This will download the local qwen3:8b model if it is not already installed.
echo The model download can be large and requires Internet access during setup.
choice /M "Continue and prepare qwen3:8b"
if errorlevel 2 exit /b 0

echo.
ollama pull qwen3:8b
if errorlevel 1 goto :fail

echo.
node compiler\cli.mjs local-ai doctor examples\nexu-ai.nex
if errorlevel 1 goto :fail

echo.
echo [PASS] qwen3:8b is installed and the Nexu local AI route is ready.
echo For a stricter Ollama-wide offline mode, see docs\LOCAL-AI-BRIDGE.md.
pause
exit /b 0

:fail
echo.
echo [FAIL] Local Qwen preparation did not complete. See the error above.
pause
exit /b 1
