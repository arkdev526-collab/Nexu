# Nexu AI 3D Forge v0.8.0 — Asset Intelligence & Learning

## New
- **23 ready local asset grammar families** covering barrels, drums, crates, chests, furniture, architectural props, natural props and game props.
- **Asset identity** in each recipe/output: asset class + grammar ID.
- **Safe Mesh Repair v1**: modifier application, duplicate-vertex cleanup, degenerate-edge cleanup, face-normal recalculation and mesh validation before UV generation.
- **Local Dataset Capture**: successful generation records seven dedicated training views (perspective/front/back/left/right/top/bottom) plus a structured dataset record.
- **Preference Learning Ledger**: users can mark a result `Good result` or `Needs work`, add a short improvement note, and keep the evidence locally as JSONL with no image bytes.
- **Bounded local adaptation**: after at least two accepted results for the same grammar, Forge can reuse the median accepted triangle target when the user did not explicitly specify one. Explicit prompt targets always win.
- **Learning & Dataset Lab** system card with grammar and feedback counts.
- **Dataset generation stage** in truthful build progress.
- Existing Android companion RPC can read grammar catalogue and submit local learning feedback through allow-listed encrypted calls.

## Preserved
- Nexu Language 0.6.0 parent baseline.
- Nexu3D -> trusted Blender worker architecture.
- Windows local-first storage and update model.
- Android Creator Companion v0.7.1 compatibility.
- 14px minimum desktop UI / 14sp Android minimum.
- Material Intelligence, PBR generation, live GLB viewport, reference board, refinement/version history, LOD/collision/export workflow.
- No prompt-to-shell or prompt-to-Python route.

## Provider decision
TripoSR remains a free MIT-licensed local candidate, but is not shipped as a v0.8 provider because the current upstream Python/CUDA dependency set is not sufficiently pinned/Windows-qualified for the final-only rule. Hunyuan3D 2.1 and TRELLIS.2 remain excluded for previously documented licensing/platform/default-hardware reasons.
