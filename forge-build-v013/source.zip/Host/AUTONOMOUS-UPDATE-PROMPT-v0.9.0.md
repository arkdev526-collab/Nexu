# Nexu AI 3D Forge v0.9.0 — Autonomous Build Brief

## Mode
Execute autonomously. Preserve the protected v0.8.1 baseline and Nexu Language 0.6.0. Do not stop at research or design. Implement, test, package and report the strongest truthful candidate.

## Goal
Add reusable Creation Intelligence and an owned organic creature-generation foundation so users can request creatures such as a medieval dragon in ordinary language without introducing paid/cloud/temporary providers.

## Mandatory architecture
- Prompt → Creation Intelligence → validated Nexu3D recipe → trusted package-owned Blender worker.
- No prompt → Python/shell/native code path.
- Existing rigid grammars remain supported.
- Blender 5.2 LTS remains the local geometry engine.
- User assets remain outside the application directory.
- Existing Windows installer/update and Android companion contracts remain compatible.

## Required v0.9 capability
1. eight reusable foundation creature grammars: dragon, wyvern, griffin, wolf, giant spider, snake, bird, fish;
2. semantic creature/style interpretation including common spelling variants;
3. bounded morphology and anatomy validation;
4. deterministic organic guide-volume + voxel-remesh body generation;
5. controllable wings/membranes/horns/claws/spikes/fins/beak as applicable;
6. creature PBR material families;
7. creature-specific QA;
8. non-destructive creature morphology refinement;
9. local bounded preference learning where explicit user instructions always win;
10. triangle-budget calibration;
11. flagship medieval-dragon fixture;
12. no paid generation provider and no unqualified neural dependency.

## Quality gates
- all previous tests remain passing;
- new v0.9 tests cover every grammar, anatomy rejection, refinement, learning, materials, security and packaging;
- JavaScript syntax and Blender-worker Python compile pass;
- source manifest and archives verify;
- no Qualified Release claim without target Windows + Blender physical generation.

## Flagship target prompt
`large medieval fantasy dragon with dark scales, four legs, torn wings and horned head around 18000 triangles for ASA with 3 LODs`

## Physical acceptance
The dragon and one non-dragon creature must complete real Blender generation and produce usable BLEND/FBX/GLB/LODs/collision/material/QA/dataset output before promotion.
