# Technology Verification — v0.10.1

**Date:** 2026-08-24

## Android prerequisite repair authority
Microsoft's current .NET for Android build-target documentation defines `InstallAndroidDependencies` as the supported target that discovers and installs required Android SDK packages. It requires `AndroidSdkDirectory` and `JavaSdkDirectory` and supports accepting Android SDK licences for the explicit installation workflow.

.NET MAUI / .NET for Android 10 documents API 36 as the default API for `net10.0-android` and JDK 21 support.

## Decision
v0.10.1 uses the project itself as the dependency source of truth instead of manually guessing individual Android SDK package versions. The build runs `InstallAndroidDependencies` only after the read-only Doctor reports a missing prerequisite.

## Local paths
- Java SDK: `%LOCALAPPDATA%\Sumero Studio\BuildTools\Android\jdk-21`
- Android SDK: `%LOCALAPPDATA%\Android\Sdk`

These paths keep prerequisite repair separate from the installed Forge application and preserve user-created assets.

## ADB handling
ADB may write normal daemon-start information to stderr. v0.10.1 captures native stdout/stderr independently and uses the process exit code plus parsed device output as the actual success criteria.
