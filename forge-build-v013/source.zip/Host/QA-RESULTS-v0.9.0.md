# Nexu AI 3D Forge v0.9.0 — QA Results

## Automated result
- Forge tests: **61/61 PASS**
- Protected Nexu Language tests: **70/70 PASS**
- Combined: **131/131 PASS**

## Additional checks
- all compiler / Forge / test `.mjs` files: `node --check` PASS
- `3d-forge/blender-worker.py`: Python compile PASS
- `examples/nexu-ai.nex`: semantic check PASS
- Nexu AI TypeScript generation: 2 units built PASS
- eight creature grammars present and routed correctly PASS
- anatomy validator rejects inconsistent recipes PASS
- creature morphology refinement stays allow-listed PASS
- creature morphology learning medians bounded/local PASS
- creature PBR presets PASS
- organic guide-volume + voxel-remesh worker evidence PASS
- Windows payload includes Creation Intelligence modules PASS

## Build-environment limits
This container has Node 22.16.0, an older Go toolchain and no Blender 5.2 runtime. Therefore the strict protected Node 24.19 production verifier, exact Go 1.26.6 Windows compilation, Windows installer lifecycle and physical Blender generation are not claimed as passed here.

## Mandatory physical qualification
1. build Setup.exe on Windows with exact Go 1.26.6;
2. update/install over the existing Forge candidate while preserving Documents data;
3. generate the flagship medieval dragon;
4. verify BLEND, FBX, GLB, LOD, collision, PBR and live viewport;
5. inspect anatomy, mesh repair and triangle-budget QA;
6. verify seven-view dataset capture;
7. mark two creature results Good and verify bounded learning behaviour;
8. generate at least one non-dragon foundation creature (recommended: wolf);
9. repair/relaunch and confirm assets remain intact.

**Status:** Candidate. Not a Qualified Release until these target-machine gates pass.
