@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Nexu AI 3D Forge - Build

echo ============================================================
echo  NEXU AI 3D FORGE v0.2.0 - ASSET QUALITY BUILD
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found on PATH.
  echo Run SETUP-AND-VERIFY.cmd first.
  echo.
  pause
  exit /b 2
)

node 3d-forge\cli.mjs build-interactive
set "NEXU_EXIT=%ERRORLEVEL%"

echo.
if "%NEXU_EXIT%"=="0" (
  echo ============================================================
  echo  BUILD FINISHED SUCCESSFULLY
  echo ============================================================
) else (
  echo ============================================================
  echo  BUILD STOPPED - ERROR CODE %NEXU_EXIT%
  echo ============================================================
  echo The window has been kept open deliberately.
  echo Diagnostic log: 3d-forge\logs\last-build.log
)
echo.
pause
exit /b %NEXU_EXIT%
