# Nexu AI 3D Forge v0.5.1 — User Installer Repair

## Why this repair exists
v0.5.0's end-user hand-off used a build bootstrap: the user downloaded a CMD file that unpacked source, acquired a compiler and built Setup before installation. That is an engineering workflow, not an acceptable normal end-user installation experience.

v0.5.1 restores the normal product delivery contract:

- the user downloads one `Nexu-AI-3D-Forge-Setup-0.5.1-x64.exe`;
- Setup performs fresh install, update or same-version repair;
- normal launch uses `Nexu AI 3D Forge.exe`, not CMD/PowerShell;
- generated assets remain under `Documents\\Nexu AI 3D Forge` and are not removed by application updates;
- old installed versions can be retained for rollback;
- missing Node 24.19.x / Blender 5.2.x can be offered through the official WinGet source;
- the application Update Centre continues to enforce HTTPS + exact size + SHA-256 before launching a future setup executable.

## Installed update-fixture repair
The v0.5.0 minimal installer payload omitted the source `packaging/` directory while the Update Centre tried to read its local QA fixture from that source-only directory. v0.5.1 moves the installed fixture beside `studio-server.mjs`, and the packager explicitly includes it.

## Release boundary
The downloadable EXE in this hand-off is an unsigned Windows engineering candidate cross-compiled in the available build container. Physical Windows install/update/repair/uninstall and visual QA remain mandatory before Qualified Release promotion.
