@echo off
setlocal
cd /d "%~dp0"
node compiler\verify.mjs || goto :fail
node compiler\cli.mjs run examples\nexu-ai.nex || goto :fail
echo.
echo [PASS] Nexu AI 0.6.0 reference demo finished.
pause
exit /b 0
:fail
echo.
echo [FAIL] Nexu AI demo failed. See the error above.
pause
exit /b 1
