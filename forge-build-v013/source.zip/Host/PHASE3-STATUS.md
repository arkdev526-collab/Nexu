# Nexu Language 0.3.0 — Feature Modules & Recipes Status

## Implemented

- 0.2.1 cancellable `Task<T>` foundation retained.
- timeout and cancellation propagation.
- safe first-class AI ask expression.
- function capability-effect inference/propagation.
- agent tool approval boundaries.
- compiler-known Feature Module catalogue.
- typed feature configuration validation.
- automatic feature dependency resolution.
- effective capability resolution with explicit-deny protection.
- `ai.chat.full` generated headless chat foundation.
- `chatSend` and `chatClear` built-ins gated by `ai.chat.full`.
- Recipe registry with human aliases.
- recipe show/preview/apply.
- backup + pre/post compilation validation.
- idempotent recipe application.
- feature/capability/effect `explain` CLI.
- authoring expansion `metrics` CLI.
- cheat sheet and language baseline documents.

## Validation in build workspace

- Compiler regression suite: 32/32 PASS before final release QA.
- Nexu AI multi-file check/build/run: PASS.
- Generated TypeScript strict-check with workspace TypeScript 5.8.3: PASS before final release QA.
- Reference runtime output: `Nexu AI online`, `README.md`, `Local Qwen model ready`.
- Production Node.js 24.19.x LTS verification remains pending in this workspace because its installed Node version is older than the pinned production baseline.

## Known limitations

- Full visual UI DSL is not implemented yet.
- AI provider adapter is deliberately disconnected in the bootstrap runtime.
- Feature Modules are built-in compiler catalogue entries; third-party feature package distribution is not implemented.
- Compile-time policies are not an operating-system security sandbox.
