# Nexu AI 3D Forge v0.4.0 — Windows App Foundation QA

**Candidate:** v0.4.0 Windows App Foundation Candidate  
**Verification date:** 17 August 2026

## Passed in this build workspace

- Combined Nexu Language + 3D Forge automated suite: **90/90 PASS**.
- Nexu AI semantic/source check: **PASS**.
- Nexu AI TypeScript generation/build: **PASS**.
- JavaScript/ESM syntax checks across compiler, Forge and test modules: **PASS**.
- Trusted Blender worker Python byte-code compilation: **PASS**.
- Studio loopback/session/origin security tests: **PASS**.
- Prompt bounds and output-path confinement: **PASS**.
- Installed-app data-root separation contract: **PASS**.
- One-file installer/update source tests: **PASS**.
- Pinned dependency bootstrap tests: **PASS**.
- Uninstall registration and graceful Studio shutdown contract tests: **PASS**.

## Release packaging gates

The release packaging step additionally verifies:

- every payload file against `PACKAGE-MANIFEST.sha256`;
- the embedded payload ZIP SHA-256 before extraction;
- an offline decode/extract round trip of the generated one-file Setup;
- no `--ignore-security-hash` or Defender/SmartScreen/UAC disabling in Setup;
- pinned automatic dependency requests only: Node.js 24.19.0 x64 and Blender 5.2.0 x64;
- generated setup and source archive hashes.

## Deliberate verification gaps

This Linux build workspace runs **Node.js 22.16.0**, not the protected production Node 24.19.x toolchain. The strict production verifier is therefore not represented as passing here.

This workspace has no Windows PowerShell runtime, WinGet, Windows registry, WScript shortcut host or Windows shell. The final one-file Windows Setup can be statically and payload-integrity tested here, but **fresh install, repair, in-place update, shortcut creation and uninstall must still be exercised on a real Windows 11 x64 machine before promotion from candidate**.

This workspace also has no Blender 5.2 runtime. Real installed-mode Blender generation is therefore a target-Windows verification gate rather than a claimed build-machine pass.

## Promotion rule

Do not label v0.4.0 a protected/public release until the final generated Setup has completed, on Windows 11 x64:

1. fresh install;
2. first launch;
3. real Blender asset generation;
4. repair install;
5. update-in-place over an earlier installed candidate;
6. persistence of generated assets across update;
7. uninstall while retaining assets;
8. uninstall while explicitly deleting assets.
