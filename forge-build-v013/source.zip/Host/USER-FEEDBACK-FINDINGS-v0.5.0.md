# Nexu AI 3D Forge v0.5.0 — User Feedback Findings

This document records **qualitative signals**, not survey statistics.

## Strong repeated positives to preserve

1. **Fast visual iteration** — users of AI-assisted 3D tools repeatedly value going from an idea/reference to a viewable object quickly. Forge responds with a live viewport and short plan/generate loop.
2. **Editable, controllable output** — control over polygon budget, materials and later changes matters after generation. Forge responds with structured recipe refinement rather than prompt-only rerolls.
3. **Predictable export** — game creators care whether an asset survives the engine pipeline. Forge makes export readiness visible before export.
4. **Simple initial experience** — ordinary creation should not require understanding Blender, Node, JSON or Python. Forge hides those implementation details under normal use.
5. **Reusable work** — users benefit when previous good results remain available. Forge versions every successful generation/refinement.

## Strong repeated negatives to avoid

1. **Prompt drift / contradictory prompts** → Brief Interpreter exposes conflicts.
2. **Looks good only from one angle** → interactive multi-angle viewport, orthographic views and wire/collision inspection.
3. **Messy topology / excessive polycount** → measurable geometry checks and budget deviation warnings.
4. **Destructive regeneration** → version history, undo/redo, duplicate, Recovery.
5. **Cluttered UI** → progressive disclosure and task tabs.
6. **Unclear processing / apparent freezes** → named queue stages and cancellation; no fabricated percentage.
7. **Scattered asset files** → managed Documents library with reveal/export when requested.
8. **Cloud/credit friction** → core Forge remains local-first with no account or credit system.

## Product conclusion

v0.5 prioritises control, inspectability, recoverability and game readiness over adding more generative providers. This directly supports the current product goal: make static game-asset generation trustworthy and usable before expanding into more expensive neural or character workflows.
