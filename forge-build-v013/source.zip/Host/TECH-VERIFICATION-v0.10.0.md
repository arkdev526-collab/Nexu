# Nexu AI 3D Forge v0.10.0 — Technology Verification

**Verification date:** 2026-08-24  
**Status:** Candidate technology review

## Preserved production baselines

- Node.js production gate remains the protected 24.19.x line used by Forge.
- Blender worker remains Blender 5.2.x LTS.
- Windows candidate build route remains the v0.8.1 CMD + official Go archive + SHA verification path.
- Nexu Language parent remains 0.6.0.

## Compression

### FastForge metadata — accepted
Node's stable `node:zlib` Brotli API is used for the small local fingerprint index. The implementation pins moderate Brotli quality/window parameters rather than using Node's experimental Zstd surface.

### Blender master — accepted
Balanced and Maximum Quality save `.blend` with Blender file compression. Fast mode leaves `.blend` uncompressed to favour save/load speed. Blender documents compressed blend-files as a drive-space optimisation with a time cost.

### GLB Draco/Meshopt — deferred
Blender 5.2 supports Draco and Meshopt glTF compression, but Forge's current built-in GLB viewer does not own the corresponding verified decoder path. Compressing the primary GLB now would break a protected workflow, so it is not enabled.

## No new runtime package dependency

v0.10 Prompt Intelligence and FastForge use Node/Blender functionality already in the protected stack. No NPM package, paid API, trial provider, remote model or new binary dependency was added.
