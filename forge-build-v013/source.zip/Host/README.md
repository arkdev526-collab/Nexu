# Nexu AI 3D Forge v0.10.1

**Universal Creation Intelligence, Fast Cache & Full Studio UX Candidate**

Nexu AI 3D Forge is a local-first Windows 3D creation workstation. Natural-language intent becomes a validated Nexu3D recipe, a trusted package-owned Blender worker creates editable game assets, and Forge keeps QA, materials, LODs, collision, learning and version history inspectable.

## v0.10 highlights

- **43 permanent local grammars** spanning creatures, furniture, architecture, nature, weapons, tools and everyday props.
- **387 recognised creation phrases/modifiers**, plus natural action prefixes and common typo repair.
- **Live Prompt Coach** — shows the subject/modifiers Forge understood before generation.
- **FastForge** — SHA-256 exact-recipe reuse avoids rerunning Blender or creating a duplicate full asset when the same validated recipe already exists.
- **Fast / Balanced / Maximum Quality** generation policies.
- **Storage Saver** — Brotli-compressed cache metadata; Blender-native compressed `.blend` masters in Balanced/Maximum Quality.
- **Forge Home** — recent work, creation-language coverage, FastForge metrics and generation-mode guidance.
- **12 new grammars:** Door, Window frame, Sword, Shield, Axe, Hammer, Spear, Bucket, Pot, Book, Torch and Wagon wheel.

## Security boundary

```text
prompt
  ↓
Prompt / Creation Intelligence
  ↓
allow-listed Nexu3D grammar
  ↓
schema validation
  ↓
trusted Forge Blender worker
```

Prompt text is never Python or shell code. Core generation is local; there is no paid/credit-based generation service in this candidate.

## Generation modes

- **Fast** — reduced texture/preview cost, coarser creature remesh, no learning dataset capture, prioritises save/generation speed.
- **Balanced** — recommended normal workflow and compressed master `.blend`.
- **Maximum Quality** — denser organic pass, larger preview/evidence surfaces and 1K material baseline.

Explicit user dimensions/triangle targets remain authoritative.

## Build/install

Use the full v0.10 project pack and run `1-BUILD-INSTALL-WINDOWS-v0.10.1.cmd`. The Windows build route preserves the v0.8.1 no-PowerShell execution-policy repair.

## Release status

Automated source/regression gates pass. Physical Windows 11 + Blender 5.2 generation, installed UX, compression-size measurement and installer lifecycle validation remain mandatory before promotion beyond Candidate.
