# Nexu AI 3D Forge v0.5.0 — Architecture

```text
Windows GUI launcher
        |
        v
loopback Studio host (Node 24.19.x)
        |
        +--> premium local HTML/CSS/JS workspace
        |       +--> WebGL2 GLB viewport
        |       +--> Asset Library / Recovery
        |       +--> Reference board
        |       +--> Update Centre
        |
        +--> Brief Interpreter
        +--> Nexu3D planner / schema
        +--> structured refinement / reference guidance
        +--> queue + QA
        |
        v
trusted Blender 5.2.x worker
        |
        +--> BLEND / FBX / GLB
        +--> collision GLB / UCX
        +--> LOD FBX + GLB
        +--> previews / validation evidence
```

## User storage

`Documents\Nexu AI 3D Forge\Assets` — generated/versioned work  
`Documents\Nexu AI 3D Forge\References` — local reference copies  
`Documents\Nexu AI 3D Forge\Recovery` — recoverable removed versions  
`Documents\Nexu AI 3D Forge\Logs` — bounded diagnostics

## Installed storage

`%LOCALAPPDATA%\Programs\Sumero Studio\Nexu AI 3D Forge\versions\<version>`

`current-version.txt` selects the active version. User content is not stored under the versioned application folder.
