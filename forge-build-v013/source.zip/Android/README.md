# Nexu AI 3D Forge Android 0.12.0 — QR and PC screen source candidate

Separate Android Creator Edition. This update uses the supplied desktop v0.10.1 baseline, updated alongside Android to v0.12.0.
Android talks to the existing authenticated Windows companion protocol and uses
Blender on that host for generation. This is not an on-device Blender build.

## Toolchain used by the candidate

- Microsoft OpenJDK **21.0.12** for the isolated CI build.
- Android Gradle Plugin **9.3.0**, Gradle **9.5.0** wrapper with distribution SHA-256.
- Android compile/target **36**, minimum **30**, Build Tools **36.0.0**.
- Java source/bytecode compatibility **17**; AndroidX Activity **1.13.0**.
- JUnit **4.13.2**, test-only org.json **20260814**; runtime JSON is Android's.
- Dependency locks and full wrapper are included. No production signing secret.

These are the tested compatible pins, not a claim that every dependency is the
newest published version. API 36 is intentionally the product requirement.

## Build the unsigned release and run Android gates

Set `JAVA_HOME` to the supported JDK and `ANDROID_HOME` to the Android SDK.
Install `platforms;android-36` and `build-tools;36.0.0` with the SDK manager.
On Windows run **BUILD-UNSIGNED.cmd**, or on Linux/macOS:

```sh
./gradlew --no-daemon clean testReleaseUnitTest lintRelease assembleRelease --write-locks
```

Output: `app/build/outputs/apk/release/app-release-unsigned.apk`.
This unsigned file is a build intermediate, NOT the Android user download.
Lint reports and JUnit XML are under `app/build/reports` and `app/build/test-results`.
Lint errors block release; reviewed warnings remain visible.

## Offline signing and independent verification

Use Android Build Tools 36.0.0 plus Python 3.10+ and Java. The enrolled certificate
is pinned in `tools/release_apk.py`; it will reject any other signing identity.
The private keystore must be outside source, evidence and release folders.

Set `NEXU_FORGE_KEYSTORE` and `NEXU_FORGE_STOREPASS` through the protected signing
session, not in a script or file committed with this project. Then:

```text
python tools/release_apk.py sign --apk app/build/outputs/apk/release/app-release-unsigned.apk --tools ANDROID_BUILD_TOOLS_36_DIRECTORY --output OUTPUT_APK --evidence EVIDENCE_DIRECTORY
```

Verification of an already signed APK requires no signing secret:

```text
python tools/release_apk.py verify --apk SIGNED_APK --tools ANDROID_BUILD_TOOLS_36_DIRECTORY --evidence EVIDENCE_DIRECTORY
python -m unittest discover -s tools -p test_release_apk.py -v
```

The utility aligns before signing, verifies after signing, checks the exact
package/API/version/launcher metadata and refuses debuggable or wrong-signer
files. It never creates or rotates a key. Backup custody is a separate gate.

## Source navigation

`MainActivity`: native surfaces, lifecycle, back, adaptive layout and local viewer.
`ForgeCompanionClient`, `CompanionCrypto`, `PairingInfo`, `PrivateNetwork`: bounded
host protocol, encryption and destination checks.
`SecurePairingStore`: Android Keystore-protected trust state.
`ReferenceEvidence`, `GlbSafety`, `DownloadsStore`: safe import, inspection/export.
`JobState`: actual host stage interpretation, including cache completion.
`app/src/main/assets/viewer.html`: package-owned local GLB renderer.

Read the parent release package's security/lint review and physical-device
checklist before promotion. See ../START-HERE.md for the new paired host.
