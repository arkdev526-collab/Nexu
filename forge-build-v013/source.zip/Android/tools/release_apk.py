#!/usr/bin/env python3
"""Fail-closed offline Android candidate signing and verification.

Never generates/replaces a key. Secrets are read only from named environment
variables and passed to apksigner as environment references, never command text.
The private keystore belongs OUTSIDE this source tree and all release folders.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile

EXPECTED = {"packageId": "uk.co.sumerostudio.nexuai3dforge", "versionName": "0.13.0",
            "versionCode": 130, "minSdk": 30, "targetSdk": 36, "compileSdk": 36}
CERT_SHA256 = "c69c409a8d184d66650dc0ce2cb294f78a24b6af3c644d98eb65144ade1d2db7"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inspect_metadata(text: str) -> dict:
    line = next((line for line in text.splitlines() if line.startswith("package: ")), "")
    fields = dict(re.findall(r"(\w+)='([^']*)'", line))
    def sdk(label: str) -> int:
        match = re.search(r"^" + label + r":'([0-9]+)'$", text, flags=re.MULTILINE)
        if not match:
            raise ValueError("Missing APK metadata field: " + label)
        return int(match.group(1))
    try:
        found = {"packageId": fields["name"], "versionName": fields["versionName"],
                 "versionCode": int(fields["versionCode"]), "compileSdk": int(fields["compileSdkVersion"]),
                 "minSdk": sdk("minSdkVersion"), "targetSdk": sdk("targetSdkVersion")}
    except (KeyError, ValueError) as error:
        raise ValueError("Malformed/missing APK identity: " + str(error)) from error
    if found != EXPECTED:
        raise ValueError("APK identity/API mismatch: " + json.dumps(found, sort_keys=True))
    if re.search(r"^application-debuggable\b", text, re.MULTILINE):
        raise ValueError("Refusing a debuggable release APK")
    if "uk.co.sumerostudio.nexuai3dforge.MainActivity" not in text:
        raise ValueError("Expected launcher activity is missing")
    return found


def check_certificate(text: str, required_schemes: tuple[str, ...] = ("v2", "v3")) -> str:
    certificates = re.findall(r"^Signer #\d+ certificate SHA-256 digest:\s*([a-fA-F0-9:]+)\s*$", text, re.MULTILINE)
    if len(certificates) != 1:
        raise ValueError("Expected exactly one APK signer")
    fingerprint = certificates[0].replace(":", "").lower()
    if fingerprint != CERT_SHA256:
        raise ValueError("APK signing certificate is not the enrolled Forge identity")
    for scheme in required_schemes:
        if not re.search(r"^Verified using " + scheme + r" scheme .*: true$", text, re.MULTILINE):
            raise ValueError("Required APK signature scheme did not verify: " + scheme)
    return fingerprint


def run(command: list[str], env: dict[str, str] | None = None) -> str:
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, env=env, timeout=180, check=False)
    if result.returncode:
        # Never print argv: callers may supply private keystore locations.
        raise RuntimeError("Android verification tool failed (exit %d):\n%s" % (result.returncode, result.stdout[-6000:]))
    return result.stdout


def verify(apk: Path, tools: Path, evidence: Path, java: str = "java") -> dict:
    if not apk.is_file():
        raise FileNotFoundError("APK is missing")
    evidence.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(apk) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError("APK ZIP CRC failed: " + bad)
        if "AndroidManifest.xml" not in archive.namelist() or "classes.dex" not in archive.namelist():
            raise ValueError("Not a compiled Android application")
        native = [n for n in archive.namelist() if n.endswith(".so")]
    env = os.environ.copy()
    if os.name != "nt":
        env["LD_LIBRARY_PATH"] = str(tools) + os.pathsep + env.get("LD_LIBRARY_PATH", "")
    suffix = ".exe" if os.name == "nt" else ""
    alignment = run([str(tools / ("zipalign" + suffix)), "-c", "-P", "16", "-v", "4", str(apk)], env)
    (evidence / "zipalign-signed.txt").write_text(alignment, encoding="utf-8")
    metadata = run([str(tools / ("aapt2" + suffix)), "dump", "badging", str(apk)], env)
    found = inspect_metadata(metadata)
    (evidence / "apk-metadata-signed.txt").write_text(metadata, encoding="utf-8")
    signer = tools / "lib/apksigner.jar"
    if not signer.exists():
        signer = tools / "apksigner.jar"  # Verified CI tool bundle representation.
    signature = run([java, "-jar", str(signer), "verify", "--verbose", "--print-certs", "-Werr", str(apk)], env)
    # With manifest minSdk 30 the official verifier legitimately checks v3
    # instead of v2. Verify the actual supported range first; then extend only
    # the verification range to API 24 to independently exercise both blocks.
    # This does not edit the APK or lower its declared minSdk (still 30).
    fingerprint = check_certificate(signature, ("v3",))
    (evidence / "signature-tool-output.txt").write_text(signature, encoding="utf-8")
    extended = run([java, "-jar", str(signer), "verify", "--verbose", "--print-certs",
                    "-Werr", "--min-sdk-version", "24", str(apk)], env)
    if check_certificate(extended) != fingerprint:
        raise ValueError("Signer changed between independent verification ranges")
    (evidence / "signature-v2-v3-verification.txt").write_text(extended, encoding="utf-8")
    result = {**found, "status": "Candidate", "apkSha256": sha256(apk), "apkBytes": apk.stat().st_size,
              "certificateSha256": fingerprint, "signatureV2": True, "signatureV3": True,
              "zipAlignment": "PASS (4-byte; -P 16)", "zipCrc": "PASS", "nativeLibraries": native,
              "physicalDeviceQa": "NOT VERIFIED", "durableSigningKeyBackup": "NOT VERIFIED"}
    (evidence / "verified-apk.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def sign(apk: Path, output: Path, tools: Path, evidence: Path, java: str = "java") -> dict:
    if output.exists():
        raise FileExistsError("Refusing to overwrite an existing signed APK")
    key_value = os.environ.get("NEXU_FORGE_KEYSTORE", "")
    if not key_value or not os.environ.get("NEXU_FORGE_STOREPASS"):
        raise ValueError("Set NEXU_FORGE_KEYSTORE and NEXU_FORGE_STOREPASS in the protected signing session")
    key = Path(key_value).resolve(strict=True)
    source = Path(__file__).resolve().parents[1]
    for prohibited in (source, output.parent.resolve(), evidence.resolve()):
        if key == prohibited or prohibited in key.parents:
            raise ValueError("Signing key must be outside source and release/evidence directories")
    env = os.environ.copy()
    if os.name != "nt":
        env["LD_LIBRARY_PATH"] = str(tools) + os.pathsep + env.get("LD_LIBRARY_PATH", "")
    suffix = ".exe" if os.name == "nt" else ""
    inspect_metadata(run([str(tools / ("aapt2" + suffix)), "dump", "badging", str(apk)], env))
    signer = tools / "lib/apksigner.jar"
    if not signer.exists():
        signer = tools / "apksigner.jar"
    output.parent.mkdir(parents=True, exist_ok=True)
    evidence.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="nexu-forge-sign-") as temp:
        aligned = Path(temp) / "unsigned-aligned.apk"
        (evidence / "zipalign-before-signing.txt").write_text(run([
            str(tools / ("zipalign" + suffix)), "-P", "16", "-f", "-v", "4", str(apk), str(aligned)], env), encoding="utf-8")
        candidate = Path(temp) / "signed.apk"
        command = [java, "-jar", str(signer), "sign", "--ks", str(key),
                   "--ks-type", "PKCS12", "--ks-key-alias", "nexu-forge-android-release-1",
                   "--ks-pass", "env:NEXU_FORGE_STOREPASS", "--key-pass", "env:NEXU_FORGE_STOREPASS",
                   "--v1-signing-enabled", "false", "--v2-signing-enabled", "true",
                   "--v3-signing-enabled", "true", "--v4-signing-enabled", "false",
                   "--out", str(candidate), str(aligned)]
        run(command, env)
        result = verify(candidate, tools, evidence, java)
        import shutil
        shutil.copyfile(candidate, output)
    if sha256(output) != result["apkSha256"]:
        raise ValueError("Signed output changed during final copy")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("sign", "verify"))
    parser.add_argument("--apk", required=True, type=Path)
    parser.add_argument("--tools", required=True, type=Path, help="Verified Android Build Tools 36.0.0 directory")
    parser.add_argument("--evidence", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--java", default="java")
    args = parser.parse_args()
    try:
        if args.operation == "sign":
            if args.output is None:
                parser.error("--output is required when signing")
            result = sign(args.apk, args.output, args.tools, args.evidence, args.java)
        else:
            result = verify(args.apk, args.tools, args.evidence, args.java)
        print(json.dumps(result, indent=2))
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired, zipfile.BadZipFile) as error:
        print("BLOCKED: " + str(error), file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
