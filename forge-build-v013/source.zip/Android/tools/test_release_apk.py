import unittest
from release_apk import inspect_metadata, check_certificate, CERT_SHA256
GOOD = """package: name='uk.co.sumerostudio.nexuai3dforge' versionCode='130' versionName='0.13.0' compileSdkVersion='36'
minSdkVersion:'30'
targetSdkVersion:'36'
launchable-activity: name='uk.co.sumerostudio.nexuai3dforge.MainActivity'
"""
SIGNATURE = """Verified using v2 scheme (APK Signature Scheme v2): true
Verified using v3 scheme (APK Signature Scheme v3): true
Signer #1 certificate SHA-256 digest: """ + CERT_SHA256 + "\n"
class ReleaseGateTests(unittest.TestCase):
    def test_valid_metadata(self): self.assertEqual(30,inspect_metadata(GOOD)['minSdk'])
    def test_actual_aapt2_minimum_field(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace('minSdkVersion:','sdkVersion:'))
    def test_wrong_identity(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace("nexuai3dforge'","nexuai3dforge.debug'"))
    def test_wrong_version_name(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace("versionName='0.13.0'","versionName='0.10.1'"))
    def test_wrong_version_code(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace("versionCode='130'","versionCode='101'"))
    def test_raised_minimum_is_blocked(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace("minSdkVersion:'30'","minSdkVersion:'36'"))
    def test_changed_target_is_blocked(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace("targetSdkVersion:'36'","targetSdkVersion:'35'"))
    def test_missing_compile_api_is_blocked(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD.replace("compileSdkVersion='36'",''))
    def test_debuggable_is_blocked(self):
        with self.assertRaises(ValueError): inspect_metadata(GOOD+'application-debuggable\n')
    def test_valid_signature(self): self.assertEqual(CERT_SHA256,check_certificate(SIGNATURE))
    def test_wrong_certificate_is_blocked(self):
        with self.assertRaises(ValueError):check_certificate(SIGNATURE.replace(CERT_SHA256,'0'*64))
    def test_missing_signature_scheme_is_blocked(self):
        with self.assertRaises(ValueError):check_certificate(SIGNATURE.replace('v3 scheme','v1 scheme'))
    def test_multiple_signers_are_blocked(self):
        with self.assertRaises(ValueError):check_certificate(SIGNATURE+'Signer #2 certificate SHA-256 digest: '+CERT_SHA256+'\n')
    def test_failed_signature_is_blocked(self):
        with self.assertRaises(ValueError):check_certificate(SIGNATURE.replace(': true',': false'))

class ActualToolOutputTests(unittest.TestCase):
    def output(self):
        from pathlib import Path
        return (Path(__file__).parent / "fixtures/apksigner-minsdk30.txt").read_text()
    def test_api30_default_verifier_requires_v3_not_unused_v2(self):
        self.assertEqual(check_certificate(self.output(), ("v3",)), CERT_SHA256)
    def test_api30_default_is_not_proof_of_v2_verification(self):
        with self.assertRaises(ValueError):
            check_certificate(self.output())
    def test_extended_range_verification_remains_required(self):
        from pathlib import Path
        source=(Path(__file__).parent / "release_apk.py").read_text()
        self.assertIn('"--min-sdk-version", "24"', source)
        self.assertIn('check_certificate(extended)', source)

if __name__ == '__main__':unittest.main(verbosity=2)
