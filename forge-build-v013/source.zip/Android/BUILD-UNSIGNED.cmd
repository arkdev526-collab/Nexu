@echo off
setlocal
cd /d "%~dp0"
echo Nexu AI 3D Forge Android v0.13.0 - unsigned release gate
call gradlew.bat --no-daemon clean testReleaseUnitTest lintRelease assembleRelease --write-locks
if errorlevel 1 (
  echo [FAIL] Build or Android verification failed. No signed APK is implied.
  exit /b 1
)
echo [PASS] Unsigned release built. Offline signing and verification are still required.
exit /b 0
