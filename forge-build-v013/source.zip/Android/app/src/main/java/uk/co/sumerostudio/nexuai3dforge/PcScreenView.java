package uk.co.sumerostudio.nexuai3dforge;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** View-only, bounded JPEG snapshots over the existing authenticated channel. */
public final class PcScreenView extends LinearLayout {
    private final ForgeCompanionClient client;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final TextView status;
    private final ImageView image;
    private ExecutorService worker;
    private Bitmap current;
    private int generation;
    private boolean running;
    private long lastSequence=-1,frames=0,rateStart;
    private String sessionId="";
    private Runnable stale;
    public PcScreenView(Context context,ForgeCompanionClient client){
        super(context);this.client=client;setOrientation(VERTICAL);setPadding(16,16,16,16);setBackgroundColor(Color.rgb(11,16,23));
        status=new TextView(context);stale=()->{clearImage();status.setText("Screen paused or disconnected. Waiting for a fresh frame…");};status.setTextColor(Color.WHITE);status.setTextSize(18);status.setGravity(Gravity.CENTER);status.setText("PC screen · view only");addView(status,new LayoutParams(-1,-2));
        image=new ImageView(context);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setContentDescription("Live screen of your paired PC");addView(image,new LayoutParams(-1,0,1));
        Button pause=new Button(context);pause.setText("Pause / Resume");pause.setOnClickListener(v->{if(running){stop();status.setText("Viewing paused. Tap Pause / Resume to continue.");}else start();});addView(pause,new LayoutParams(-1,-2));
        Button fit=new Button(context);fit.setText("Fit / Fill screen");fit.setOnClickListener(v->image.setScaleType(image.getScaleType()==ImageView.ScaleType.FIT_CENTER?ImageView.ScaleType.CENTER_CROP:ImageView.ScaleType.FIT_CENTER));addView(fit,new LayoutParams(-1,-2));
        Button retry=new Button(context);retry.setText("Reconnect screen");retry.setOnClickListener(v->{stop();start();});addView(retry,new LayoutParams(-1,-2));
    }
    public void start(){
        if(running)return;
        if(!client.isPaired()){status.setText("Open Pair and scan your PC's QR code first.");return;}
        running=true;lastSequence=-1;sessionId="";frames=0;rateStart=android.os.SystemClock.elapsedRealtime();worker=Executors.newSingleThreadExecutor();int ticket=++generation;
        status.setText("Connecting… On your PC, open System → Start sharing.");poll(ticket);
    }
    public void stop(){client.cancelScreenRequests();running=false;generation++;ui.removeCallbacksAndMessages(null);if(worker!=null)worker.shutdownNow();worker=null;clearImage();}
    private void clearImage(){image.setImageDrawable(null);current=null;}
    private void poll(int ticket){
        if(!running||ticket!=generation||worker==null)return;
        final long afterSequence=lastSequence;final String expectedSession=sessionId;
        worker.execute(()->{
            try{
                JSONObject frame=client.rpc("screen.frame",new JsonObject().put("afterSequence",afterSequence).put("sessionId",expectedSession));Bitmap decoded=null;
                if(frame.optBoolean("active")&&!frame.optBoolean("unchanged")){
                    String encoded=frame.getString("base64");if(encoded.length()>700000)throw new IllegalArgumentException("Screen frame is too large");
                    byte[] bytes=Base64.decode(encoded,Base64.DEFAULT);
                    BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
                    if(bounds.outWidth<1||bounds.outHeight<1||bounds.outWidth>1600||bounds.outHeight>1600)throw new IllegalArgumentException("Invalid screen size");
                    decoded=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(decoded==null)throw new IllegalArgumentException("Invalid screen image");
                }
                final Bitmap bitmap=decoded;
                ui.post(()->{if(!running||ticket!=generation)return;
                    if(frame.optBoolean("unchanged")){ui.postDelayed(()->poll(ticket),250);return;}
                    lastSequence=frame.optLong("sequence",-1);sessionId=frame.optString("sessionId","");
                    ui.removeCallbacks(stale);if(bitmap!=null)ui.postDelayed(stale,5000);clearImage();current=bitmap;image.setImageBitmap(bitmap);
                    status.setText(bitmap==null?"Not sharing. On the PC select this tablet and press Start sharing.":"Live · "+frame.optInt("width")+" × "+frame.optInt("height")+" · "+String.format(java.util.Locale.ROOT,"%.1f",(++frames)*1000.0/Math.max(1000,android.os.SystemClock.elapsedRealtime()-rateStart))+" updates/s · view only");
                    ui.postDelayed(()->poll(ticket),bitmap==null?1500:250);
                });
            }catch(Exception error){ui.post(()->{if(!running||ticket!=generation)return;clearImage();status.setText("Screen connection unavailable. Check Wi-Fi and update both Forge apps to 0.13.0. Retrying…");ui.postDelayed(()->poll(ticket),3000);});}
        });
    }
    @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
}
