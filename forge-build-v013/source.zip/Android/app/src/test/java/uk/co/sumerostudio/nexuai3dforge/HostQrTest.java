package uk.co.sumerostudio.nexuai3dforge;
import org.junit.Test;
import static org.junit.Assert.*;
import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import java.nio.charset.StandardCharsets;
public class HostQrTest {
 @Test public void scannerDecodesActualHostQrMatrix() throws Exception {
  String raw=new String(getClass().getResourceAsStream("/host-pairing-qr.txt").readAllBytes(),StandardCharsets.UTF_8);
  String[] rows=raw.split("\n");int count=rows.length,scale=6,size=(count+8)*scale;int[] pixels=new int[size*size];java.util.Arrays.fill(pixels,0xffffffff);
  for(int y=0;y<count;y++)for(int x=0;x<count;x++)if(rows[y].charAt(x)=='#')for(int dy=0;dy<scale;dy++)for(int dx=0;dx<scale;dx++)pixels[((y+4)*scale+dy)*size+(x+4)*scale+dx]=0xff000000;
  String decoded=new QRCodeReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(size,size,pixels)))).getText();
  PairingInfo p=PairingInfo.parseUri(decoded);assertEquals("192.168.1.40",p.host);assertEquals("ABCDEF12",p.offerCode);assertEquals("ABCDEFGHJKLMNPQR",p.secretCode);
 }
}
